# FantasyWeald (Álomrengeteg)

Holdfényes, bejárható 3D álomvilág a böngészőben. Első fejezet: **A csillagkulcs** — egy nagy, kézzel
megtervezett sziget, körülötte mély álomtenger furcsa, vízből kinövő helyekkel, tele felfedeznivalóval,
mellékküldetésekkel és apró csodákkal. **Multiplayer** (korábban „Közös álom”) módban többen is bolyonghatnak együtt (név, közös csevegés, nincs
regisztráció, nincs küldetés).

Minden kódból készül: a 3D-motor (WebGL2), a modellek, a textúrák, a zene és a hangok is.
Nincs külső könyvtár és nincs letöltött asset; a kész játék egyetlen HTML-fájl.

**Nyelv (v8).** A játék alapból **angolul** indul (a címe v9 óta mindkét nyelven *FantasyWeald*), a címképernyő jobb felső
sarkában és a Beállításokban egy kattintással magyarra (és vissza) váltható; a választást a böngésző
megjegyzi. Minden szöveg le van fordítva: menük, küldetések, párbeszédek, rúnakövek, helyszínek, álomlények,
iránytű (N/NE/E… ↔ É/ÉK/K…), irányszavak, a többjátékos rendszerüzenetek is. A címben `?lang=hu` vagy
`?lang=en` is megadható. A böngészőfül címe: **FantasyWeald** (v9.1 óta). A fordítás a `src/data/en.js`-ben van
(kulcs: a magyar szöveg), a nyelvkezelés a `src/i18n.js`-ben.

A címképernyő alján diszkrét támogató gomb (**Buy me a coffee** → ko-fi.com/fantasyweald, új lapon nyílik;
a Szünet menüben is ott van) és a copyright sor: *© 2026 fantasyweald.com · All rights reserved*.

## Futtatás

```bash
npm install      # csak az esbuild kell a buildhez
npm run build    # -> dist/alomrengeteg.html (artifact-töredék) és dist/local.html (önálló oldal)
npm run dev      # olvashatóbb, nem tömörített build
```

A `dist/local.html` bármelyik modern böngészőben megnyitható (Chrome, Edge, Firefox, Safari, WebGL 2 kell).

**Weboldalként** (pl. Namecheap / cPanel tárhelyen): a build elkészíti a `dist/alomrengeteg-web.zip`-et.
Ezt a cPanel Fájlkezelőjében a `public_html` mappába kell feltölteni és ott kicsomagolni — ennyi.
Benne van: `index.html` (maga a játék), `.htaccess` (tömörítés, gyorsítótár; a HTTPS-átirányítás
egy sor kivételével bekapcsolható), ikonok és `manifest.webmanifest` (telefonon a kezdőképernyőre
téve teljes képernyős alkalmazásként indul), valamint `mp.php`, a többjátékos mód szervere.
Aldomainre vagy almappába is ugyanígy működik.

### Multiplayer (többjátékos mód)

A címképernyőn a **Multiplayer** gombbal lehet belépni: nevet és köpenyszínt kell választani, és már bent
is vagy. Regisztráció nincs. Itt nincs küldetés és nincs mentés, csak az erdő és a többiek:

* a többi játékos törpe alakban jár-kel, a neve a feje fölött (a messze járók apró fénypöttyként látszanak,
  a térképen és az iránytűn színes pöttyök mutatják őket, a Szünet menüben pedig a listájuk, irányukkal);
* közös csevegés: **Enter** (vagy T) — írás, Enter — küldés, Esc — mégse; telefonon a **Csevegés** gomb.
  Amit írsz, a csevegőablakon kívül 7 másodpercig buborékban látszik a karaktered fölött is;
* **közelségi csevegés (v8):** egy sima üzenetet csak a küldőtől **30 méteren belül** lévők kapják meg. Ha az
  üzenet elé azt írod, hogy **`!all`** (pl. `!all Sziasztok, ki jön a Hamuszigetre?`), akkor mindenki látja az
  egész erdőben, bármilyen messze van; az ilyen sor mellett „MINDENKINEK” / „TO ALL” jelzés áll. Mindenkinek
  szóló üzenetet 8 másodpercenként lehet küldeni. Ezt a belépő képernyő, a csevegőmező és az üdvözlő üzenet is
  elmondja (v9: a belépő képernyő helyett az első csevegésnyitáskor megjelenő, bezárható kártya). A szűrést a **szerver** végzi (a távoli üzenet el sem jut a böngészőhöz, és a küldő helyzetét sem
  kapja meg senki), de ez játékélmény, nem titkosítás: aki a saját helyzetét meghamisítja, az hallhatja, amit
  a közelébe hazudott helyen mondanak;
* minden kapu nyitva, a holdkapuk között lehet utazni, a harang hívja a bálnakompot, és kezdettől megvan a
  dupla ugrás, a siklás és a Holdléptek;
* a saját, egyjátékos mentésedhez nem nyúl (kilépéskor ott folytatod, ahol abbahagytad).

**Hogyan működik a tárhelyen?** A zipben lévő `mp.php` egyetlen PHP-fájl, adatbázis nélkül: a játék
másodpercenként 2–5-ször elküldi neki a saját helyzetét, és visszakapja a többiekét. Az adatokat egy kis
JSON-fájlban tartja (`mp-data/state.json`, a mappát magától hozza létre, kívülről nem olvasható).
Bármilyen cPanel-es PHP-tárhelyen megy (PHP 7 vagy újabb), külön beállítás nélkül.

* Egyszerre **80** játékos fér el (az `mp.php` elején a `MAX_PLAYERS` átírható). Minél többen vannak, annál
  ritkábban kérdez a játék (50 fölött kb. 1,7 kérés/mp/fő), hogy a megosztott tárhelyet ne terhelje.
  Tesztben 60 bottal ~100 kérés/mp, 2–5 ms válaszidő, hiba nélkül.
* Ha ennél is többen lennétek: `server/mp-server.mjs` ugyanezt tudja Node.js-sel, memóriában, több száz
  főig (`node server/mp-server.mjs`, a `PORT` és `MAX_PLAYERS` környezeti változóval). Ilyenkor a játék
  `index.html`-jébe egy sor kell: `<meta name="mp-url" content="https://a-te-szervered/">`.
* A Claude-artifactban és a helyben megnyitott fájlban a többjátékos mód nem érhető el (nincs mellette
  szerver) — ezt a játék ki is írja.
* Terheléses teszt: `node tools/mp-bots.mjs http://localhost:8124/mp.php 50 60` (50 bot, 60 mp; helyben
  indítsd így a szervert: `cd dist/web && MP_MAX_PER_IP=500 MP_REQ_MAX=100000 php -S localhost:8124`,
  mert a botok mind egy címről jönnek). Helyi próba a böngészőben: `http://localhost:8124`.

**Biztonság.** A weboldal maga statikus: az `index.html` csak a látogató gépén fut, és ha valaki F12-vel
átírja, azzal csak a saját játékát változtatja meg (a mentés is a saját böngészőjében van; a játék a
szerkesztett vagy sérült mentésen sem akad el). A szerveren egyetlen program fut, az `mp.php`, ami semmit
sem hisz el a böngészőnek:
* egy játékos csak a **saját** alakjának helyzetét, a saját nevét és a saját üzeneteit küldheti, ehhez egy
  titkos kulcs kell, amit a szerver csak neki ad ki, és senki másnak nem küld el; más játékost mozgatni,
  kiléptetni vagy a nevében írni nem lehet;
* minden bejövő adat típusa és mérete ellenőrzött (4 KB fölötti kérés nincs), a pozíció a világ határain
  belülre szorul, a nevekből és üzenetekből kiesnek a vezérlő-, láthatatlan és irányváltó karakterek és a
  „zalgo" jelhalmok; a játék mindent szövegként jelenít meg (HTML-ként soha), így nem lehet beinjektálni
  semmit;
* korlátok: max. 80 fő, egy IP-címről max. 10 fő, belépés és kérések IP-nként ritkítva, csevegésben 1,2 mp
  szünet, 20 mp alatt legfeljebb 6 üzenet, ugyanazt nem lehet ismételgetni;
* hibaüzenet (szerver-elérési út) sosem jut ki; a szerver semmit nem futtat a kapott adatokból, csak a saját
  `mp-data` mappájába ír, és az ottani adatfájl kívülről nem olvasható (és PHP-ként is üres);
* az oldal szigorú tartalombiztonsági szabályt (Content-Security-Policy) kap: csak a saját kódja futhat, és
  más oldal nem teheti keretbe.
Próba: `node tools/mp-security-test.mjs http://localhost:8124/mp.php` (92 ellenőrzés: hamis kulcs, más
játékos kiléptetése, rossz típusok, túl nagy kérés, láthatatlan karakterek, üzenetáradat, tömeges belépés,
a közelségi csevegés és az `!all` szabályai, a régi üzenetek visszaolvasása, emojik, jelek és linkek…). Ugyanez a Node-szerverre:
`node tools/mp-security-test.mjs http://localhost:8787/`.
**Frissítéskor az `mp.php`-t is töltsd fel** (a zipben benne van): a v8-as csevegéshez az új szerver kell.

## Irányítás

| Gép | Mobil |
| --- | --- |
| W A S D / nyilak – mozgás | bal hüvelykujj – mozgás (szélére húzva futás) |
| egér húzása – kamera, görgő – zoom | jobb oldal húzása – kamera |
| Shift – futás, C – lopakodás | Lopakodás gomb (be/ki) |
| Szóköz – ugrás (később dupla ugrás és siklás) | Ugrás gomb (nyomva tartva siklás) |
| E – beszélgetés / felvétel / olvasás | Beszél gomb |
| J – napló, M – térkép, Esc – menü, H – kijelzés elrejtése | Térkép / Menü gomb |
| Enter vagy T – csevegés (Multiplayer) | Csevegés gomb (Multiplayer) |

## v9.1d újdonságai

* **Új égi bálnák:** igazi púpos bálna alkat egyetlen sima, hajló testtel (a farok csapása végigfut a
  faroktövön), széles fej szájvonallal, világító gyöngysorokkal az orrán és az alsó állkapcsán, torokredőkkel,
  szemhéjas oldalsó szemekkel, kettős orrnyílással (időnként csillagfényes párát fúj ki), kis hátúszóval,
  hosszú, hullámos élű mellúszókkal és széles, bemetszett, fűrészes szélű farokúszóval. A hátán lassan
  lélegző csillagpöttyök, az oldalán lámpasor; a két bálna színe különbözik.
* **Kidolgozott utaspavilon a kompbálnán:** mintás, bojtos szőnyeg bőrhevederekkel és csatokkal, deszkás
  fedélzet korláttal (hátul nyitott), bőrnyereg magas háttámlával és csengős nyeregkápával, párnák, egy kis
  láda, gyeplő a fejpánt gyűrűihez, hagymakupolás baldachin négy esztergált oszlopon, csipkés szegély
  bojtokkal és apró fényekkel, két függő lámpás, a csúcson világító holdsarló.
* **Szebb felhőbárányok:** puha felhőgombócokból álló gyapjú, hosszúkás arc, lógó fülek, nagy szemek,
  kontyocska, vékony lábak gyapjúmandzsettával és patákkal, farokpamacs, csengő szalagon. A Bárányfelhő-anyó
  most tényleg fekszik (a lábai maga alá húzva).
* **Végtelen Lépcső teteje:** a körben lebegő felhők már nem nyúlnak bele a lépcső utolsó fordulójába (eddig
  a felhő alja „plafon” volt a lépcsőfokok fölött, ezért kellett „átmenni a talajon”); a felhők kijjebb
  kerültek. A lépcső oszlopa most a víztől a pihenőig ér (eddig félúton kezdődött, és 30 méterrel kilógott a
  tetején), a korlát oszlopai a lépcsőfokokon állnak.
* **Gombakalapok alatt nincs láthatatlan plafon:** a kalapok alja a valódi formáját követi (eddig egy lapos
  sík volt a kalap legalsó pontjának magasságában), így az egymás alatti gombákon és a nagy kalapok alatt
  sem akad el a fejed.
* **Nincsenek többé lebegő korlátok és oszlopok:** az égi mólók oszlopai a deszkákon állnak és a kötélig
  érnek, a bárányakol oszlopai a felhőbe szúródnak, a világítótorony teteje a helyén van, az álomlépcsők
  korlátja a fokok fölött fut, a lámpaoszlopok a földön állnak, a hinták kötele a rúdtól az ülésig ér, az
  oszlopcsarnok gömbjei a zsinórjukon lógnak, a talapzat nem lebeg, a jelzőfény-oszlopok lentről indulnak.

## v9.1c újdonságai

* **A Mélység Lámpásának teste szilárd (csak nekünk):** nem lehet átúszni rajta; ha nekiúszol vagy ő úszik
  beléd, félrelök, és ha a háta kint van a vízből, fel is mászhatsz rá, és rajta maradhatsz — visz magával,
  amíg le nem merül (a víz alatti részei nem járhatók).
* **Kistérkép a jobb felső sarokban:** mutatja, hol vagy (a térkép képe, utak, víz), merre nézel, a
  küldetéscélokat (ha messzebb vannak, a peremén), a holdkapukat, a tengeri szörny fényét (és ha közel van, a
  testét), multiplayerben a többieket. **+ / −** gombbal (vagy az egérgörgővel fölötte) négy fokozatban
  nagyítható és kicsinyíthető, az **×** bezárja — ilyenkor egy kis iránytű-ikon marad a sarokban, arra
  kattintva újra kinyílik (**N** billentyű is ki/be kapcsolja). A böngésző megjegyzi a beállítást. A
  küldetéslista a kistérkép alá került; mobilon kisebb, és a fenti gombok alá kerül.
* **Ritkábban és csak közelről hallani a tengeri szörny búgását:** kb. 280 méterig hallatszik (a sziget
  túlsó feléről nem), és két búgás között legalább 2–3 perc telik el (kivéve, amikor vadászni kezd rád).
* **Nyolc új vándortörpe** az egész szigeten, utak közelében, saját dolgaik után járva (Gomba Gáspár, Kóbor
  Kornél, Bogyó Berta, Csillagváró Csaba, Dúdoló Dénes, Álmos Ábel, Kavics Kata, Tüske Tivadar) — mindegyikkel
  lehet beszélgetni, és néhányuk hasznos tippet is ad.
* **Mozgó dolgokon rendesen lehet állni:** a Dombteknős páncélján már nem lök le egy láthatatlan fal a pereméről,
  és ráugrani is lehet; a plüssnyuszik fejére (dupla ugrással) felugorhatsz, és vitetheted magad — amíg a
  fejükön állsz, tovább sétálnak.

## v9.1 újdonságai

* **Név mindenhol FantasyWeald:** a böngészőfül címe, a telepített ikon neve, a megosztási előnézet és a
  címképernyő is (a korábbi *takeyourtime* már sehol sem látszik; a böngészőben tárolt beállítások megmaradnak).
* **Nem lehet kijelölni a szövegeket:** a címképernyőn és a játék felületén a szövegek nem jelölhetők ki, a
  linkek és képek nem húzhatók, a jobb gombos menü sem jön elő (a gépelős mezők ugyanúgy működnek).
* **Olvasható felugró szövegek:** a „Felfedezted…” felirat és a kis üzenetek már nem homályosodnak el, amíg
  látszanak: élesen jelennek meg, végig élesek, csak a legvégén halványulnak el.
* **Ködrája (az Álomfaló helyett):** a levegőben úszó rája a fák között, kb. 3 méteres szárnyfesztávval. A szárnyai
  lassú hullámokban mozognak (a hullám a testtől a szárnyvégek felé és elölről hátra fut, a shader hajlítja az egy
  darabból álló, sima testet), a hátán kis csillagképek derengenek, a hasa gyöngyházfehér, a szája mellett két
  felcsavarodó szarvúszó, hosszú ostorfarka világító hegyben végződik. Fordulóban bedől, emelkedéskor felhúzza az
  orrát. Ha csendben megállsz a közelében, lassan leereszkedik hozzád, és megsimogathatod — örömében átfordul a
  levegőben, csillagporral a szárnyvégein. Ha futva rontasz rá, felriad és elsuhan. A rossz álmokat elkapja és
  elnyeli a levegőből.
* **Óriáscsontok:** új koponya (szemgödrök, orrcsont, kosszarv), a nyakcsigolyák lefutnak a koponyához, a farok
  a földre, a bordák hátrahajlanak; a csontváz mindig a legsimább helyre kerül, és semmi sem lebeg.
* **Holdkapuk:** lépcsős, kőből rakott talapzaton állnak, és a közelben a legsimább talajt keresik — a
  lejtőn sem lóg ki a lapjuk. (A Felhőkert kapuja a szigeten talapzat nélkül marad.)
* **A Figyelő (a szemes domb):** a szarvai a dombból nőnek ki (eddig fölötte lebegtek), a felülete sima,
  nagy mohás foltos, nem „gyűrött fólia”. Ugyanez a nyugodtabb mohaanyag van az Alvó Óriáson és a lebegő
  szigeteken.
* **Kőmarok keze:** a csukló lapos és a tenyérbe fut (eddig egy kerek henger lógott ki a tenyérből a vár
  mögött), kerek ujjbegyek körmökkel, bütykök, tenyérvonalak, zuzmó, az ujjakról lelógó moha és egy halványan
  derengő rúnagyűrű a csuklón.
* **A Mélység Lámpása (tengeri szörny), négyszer nagyobb:** kb. 250 méter hosszú, és **egyetlen, simán hajló
  testből** áll (nem szegmensekből): a csúcspontjai két szomszédos gerincszakasz között átúsznak, így úgy hajlik,
  mint egy igazi angolna. Pikkelyes bőr (a hasi pikkelyek között halványan derengő fénnyel), izomsávok,
  oldalvonal, kétsoros fényszervek, kagylótelepek, hegek; összefüggő, sugaras hátúszó-fátyol szakadásokkal,
  hasi úszó és rongyos farokúszó; fodros kopoltyúúszók, bajuszszálak, szem alatti fényszervek és fényfüzér az
  ajkán, kettős fogsor, orrlyukak. **Hosszú S-kanyarokban úszik**, és csak adott ívnél élesebben nem tud fordulni
  (vízszintesen és függőlegesen is), így sosem csavarodik bele önmagába; a visszafordulás mindig tág U-kanyar.
  A hátát és a hátúszóját általában kint hordja a vízből, időnként kiemeli a fejét, a teste nagy, lassú ívekben
  hullámzik át a felszínen, és ha valaki a partról nézi, odafordítja a fejét.
  **Magától támad:** ha a közelében úszol (kb. 115 m, csobbanva messzebbről is), vagy alacsonyan siklasz a
  nyílt tenger fölött, lemerül, pár másodpercig köröz alattad a fénye, aztán egy hosszú, felfelé ívelő
  kapással, tátott szájjal kap el (a parton ébredsz). **Az otthona a Hamusziget távolságáig tart**, de mivel
  hatalmas, ha másként nem fér el vagy nem tud továbbúszni, kiúszhat messzebbre is — akár túl az álom szélén,
  ahová mi már nem mehetünk.
* **Élőben a térképen:** a szörny halvány, a testével együtt hajló sötét sziluettként (fénypöttyökkel) és lassan
  pulzáló lámpásfényként látszik a térképen;
  ha a térkép szélén túl van, egy halvány nyíl mutatja az irányát (vadászat közben vörösesen dereng).
* **Új mellékküldetés – A Mélység Lámpása:** a holdvirág után Horgász Huba mesél a szörnyről. Figyeld a
  tengert a partról, amíg kiemelkedik (a küldetésjelző a szörnyet követi), aztán meséld el Hubának:
  3 csillagszilánk a jutalom (ha elnyel, az is számít…).

## v9 újdonságai

* **Név:** a címképernyőn mindkét nyelven **Fantasyweald** áll (a böngészőfül akkor még *takeyourtime* volt), a
  „Közös álom” gomb neve **Multiplayer** lett.
* **Csevegés-súgó:** a közelségi csevegés leírása nem a belépő képernyőn van, hanem amikor valaki először nyitja
  meg a csevegést a multiplayerben, a csevegőablak fölött megjelenik egy kis kártya (30 méter, `!all`). Addig ott
  marad, amíg az **×**-szel be nem zárják; utána többé nem jön elő (a böngésző megjegyzi).
* **Szünet menü:** új **Főmenü** gomb (egyjátékos módban ment és visszavisz a címképernyőre; multiplayerben
  kilép a közös erdőből). A „Buy me a coffee” gomb itt is a jobb alsó sarokban van, mint a címképernyőn.
* **Csak sima szöveg a csevegésben (és a nevekben):** betűk (bármilyen ábécé), számok, szóköz és a szokásos
  írásjelek. Emojik, szimbólumok, képek nem mennek át (gépelés és beillesztés közben eltűnnek), fájlt nem
  lehet beilleszteni vagy behúzni, **linket nem lehet küldeni** (`https://…`, `www.…`, `valami.hu`,
  `discord.gg/…`, e-mail-cím, „pelda (dot) com”…). A szűrést a **szerver** is elvégzi (`mp.php` és a Node-os
  szerver is), így F12-vel sem lehet megkerülni. A felületen a „30 m” helyett „a közelben lévők” szerepel.
* **Hidak:** a híd végei kőből rakott hídfőkön ülnek, amelyek lenyúlnak a partba, és egy rövid kövezett
  rámpa köti össze a hidat az úttal — nincs többé rés a híd és a talaj között.
* **Kőmarok keze:** az ujjak töve zárt és mélyen a tenyérbe nyúlik (eddig a kéz hátán nyitott „csövek”
  látszottak, át lehetett látni rajtuk); a vár tornyainak és a kapuknak a tetőereszei alulról is zártak, a
  fenyők ágrétegei is. Új `Geometry.weld()`: az összeolvasztott csúcsok miatt a torzított (kő)felületek nem
  repednek szét.
* **A törpe válla:** nincs többé golyó a vállán; a kabát teteje lejtős vállba fut, a ruhaujj alá bújik.
* **Holdszarvas:** ha elriasztod, már nem mindig ugyanott bukkan fel: a sziget egy véletlen, csendes pontján
  jelenik meg újra (70–280 méterre tőled, utak közelében), pár másodperc múlva.
* **Felugró szövegek:** tovább látszanak (legalább 6,5 mp, hosszabb szövegnél akár 14 mp), a „Felfedezted”
  felirat 8 mp.
* **Új egérkurzor:** aranyozott, díszes nyíl éjkék zománccal és holdkővel (kattintható dolgok fölött a kő
  borostyánszínűre melegszik), éles nagy felbontású kijelzőn is.
* **Öt új lényfaj, sok új lakó (57 új példány) az erdőben:**
  * **Csillagsünök** (aranyos, 20 db): kristálytüskéik hegyén csillagfény ül. Ha megijeszted, ragyogó
    gombóccá gömbölyödnek, ha futva rájuk rontasz, el is gurulnak; lopakodva odaszaladnak szimatolni, és meg
    lehet simogatni őket.
  * **Lepkerókák** (aranyos, 15 db, kis falkákban): pici rókák puha, szemfoltos lepkeszárnyakkal. Ülnek,
    kergetőznek, szárnycsapással ugrálnak; ha csendben megállsz, leülnek, félrebillentett fejjel néznek, és
    közelebb jönnek. Futásra szárnyra kapva menekülnek.
  * **Álomfalók** (semleges, 6 db): nagy, szelíd tapírszerű vándorok csillagos bundával, ormánnyal. Néha egy
    lebegő rossz álmot szippantanak be a levegőből. Ha közel mész, rád néznek; meg lehet simogatni őket.
  * **Gyökérpókok** (sötét, 10 db, a holt erdőben, a lápon és a fenyvesben): korhadt tuskónak tettetik magukat,
    a lábuk gyökérként terül szét. Ha túl közel mész (lopakodva alig veszik észre), nyolc gyökérlábon
    felágaskodnak, sziszegnek, nekedrontanak és ellöknek, aztán elszaladnak és máshol ássák be magukat.
  * **A Csendesek** (sötét, 6 db, a fenyvesben és a holt erdőben): magas, agancsos árnyak repedt porcelán
    álarcban. Amíg nézed őket, meg sem mozdulnak; ha hátat fordítasz, közelebb siklanak. Ha odaérnek,
    megérintik a válladat (sötét villanás, suttogás), és eltűnnek.
* **A Mélység Lámpása** (egyetlen példány): hetvenméteres mélytengeri lény az álomtengerben — angolnatest
  világító foltsorokkal, rongyos úszókkal, vak tejfehér szemekkel, hatalmas, üvegtűfogú állkapoccsal és egy
  hosszú száron lógó lámpással. A parthoz közeli mély vízben jár körbe, többnyire mélyen a felszín alatt:
  ilyenkor csak a lámpása fénye és egy óriási sötét árnyék látszik a víz alatt. Néha felbukkan, és a háta
  hatalmas púpokban hömpölyög át a felszínen. Ha a nyílt tengeren úszol, és észrevesz, a fény egyre
  gyorsabban közeledik (figyelmeztető felirat és mély morajlás) — ha nem érsz ki időben a partra vagy egy
  szigetre, alulról, tátott szájjal felcsap a vízből és elnyel; a partra kiköpve ébredsz. Bekerül a
  bestiáriumba.

## v8 újdonságai

* **Hamusziget és a Hétfejű** (kint a tengeren, a vörös fényoszlopnál): hétfejű sárkány alszik a kincsén egy
  vulkáni szigeten (obszidiántüskék, izzó repedések, csontok, romos trón, füstölgő kráter, vörös ég). Zajra
  ébred: a futás gyorsan, a séta lassan ébreszti, a lopakodás alig; ha egy feje felemelkedik szimatolni, **ne
  mozdulj**. Ébren a fejek követnek és felváltva tüzet okádnak (az obszidián mögé nem ér be a tűz, oldalra
  futva kitérhetsz). Szolgái, a **Parázsmanók** (vasvillával vagy parázslámpással) járőröznek; ha meglátnak,
  visítva felébresztik a gazdájukat és üldöznek (a vizet nem bírják). Aki elkapnak, azt a tengerbe hajítják.
  A kincshalom tetején ott a **Hétfejű koronája**: vedd el, és ha eljutsz vele a vízig, a tiéd — onnantól a
  sapkádon viseled. Mindkét lény bekerül a bestiáriumba.
* A sárkány és a manók saját, pikkelyes bőr-shaderrel készültek (a pikkelyek közti rések a hasán és a torkán
  parázslanak, tűzokádás előtt felizzanak).
* **Pontos „hitboxok”:** a felhőkön, a lebegő szigeteken, az ugrógombákon és a sziklákon ott lehet állni, ahol
  a látható alakjuk van (a járható felületet a program magából a kirajzolt modellből számolja), nem egy
  durva korongon — nem lehet átesni a felhő látható szélén, és nem lebeg a törpe a gomba pereme fölött.
* Mélyebb vizek: csak ott úszik a törpe, ahol a víz tényleg mély (mellmagasság fölött), a sekélyben gázol.
* A fák gyökerei nem lógnak a levegőben a lejtőkön és a partokon.
* Egyedi egérkurzor (holdfényes nyíl csillaggal; kattintható dolgok fölött arany).
* A törpe válla nem átlátszó többé (a ruhaujj teteje zárt, lekerekített váll).

## Mi van a világban

* **Mozgás (v7.2.1)**: a kamera az eredeti; a törpe akkora, mint a falu többi törpéje (korábban 8%-kal
  nagyobb volt mindegyiknél). Séta 2,0 m/s, futás 5,0 m/s, lopakodás 1,05 m/s, úszás 1,95 / 3,45 m/s.
* **Úszás (v7)**: a tavakba, folyókba, a tengerbe be lehet menni; a mély vízben a törpe a felszínen úszik
  (evickélő mozdulatokkal, Shifttel gyorsabban), Szóközzel kilöki magát a partra. Akadásgátló mozgás: ha
  nekimész egy fatörzsnek vagy falnak, elcsúszol mellette.
* **Az álomtenger (v7, v7.2)**: a sziget partjain túl mély, sötét víz kezdődik (olyan, mint a tó), és a
  vízből furcsa dolgok nőnek ki: **Végtelen Lépcső** (a felhőkig érő csigalépcső, a tetején ajtó),
  **Elfeledett Játszótér**, **Oszlopcsarnok**, **Alvó Hold** (hálósapkában), **Ajtók Mezeje** (24 ajtó,
  mindegyik máshová visz), köztük pedig véletlenszerűen született furcsaságok: magányos ajtók (némelyik
  hazavezet), sehová sem vezető lépcsők és lámpasorok, óriási székek, ágyak, órák, gumikacsák, labdák, régi
  tévék, boltívek, oszlopok és ráléphető felhőpadok. Fénycsóvák mutatják az utat, a varázsló üstjéből pedig
  holdfény-oszlop száll fel: a tengerről is látszik, merre van haza. **680 méterre** a sziget közepétől egy
  láthatatlan fal jelzi az álom végét.
* **Talajlakók (v7, v7.2)**: lépegető óriások (ha az útjukba kerülsz, óvatosan félretolnak), a Dombteknős
  (a hátán egy egész domb és egy szélkút; ahol a part mélybe szakad, úszik), **plüssnyuszik** (óriási, kopott
  plüssnyulak gombszemmel, akik maguktól járják az utakat, és megölelhetők), **szemvirágok** (gyökérlábakon
  totyogó virágok, a közepükön egy nagy, pislogó szem, ami utánad néz), lámpások, és Brekus, a nagy béka a
  tavirózsa-levelén — összesen 22 fajta álomlény. Új Holdszarvas-modell.
* **A Mumus (v7.2)** — a zsákos ember a régi mesékből: magas, görnyedt alak szakadt fekete köpenyben, sápadt
  maszkarccal, szarvakkal, túl hosszú karokkal és zsákkal a hátán. A sötét helyeken jár (Lidércláp, Feledés
  romjai, az Alvó Óriás környéke). Ha észrevesz, a szeme vörösen felizzik, felsikolt, és utánad ered. Aki
  lopakodik, azt csak egészen közelről veszi észre; sétálva nem lehet elmenekülni előle, futva igen, és a mély
  vízbe vagy magasra nem jön utánad. Ha elkap, a zsákjába dug, és a tisztáson ébredsz.
* **19 helyszín** egy fix, kézzel tervezett térképen: Holdfény-tisztás, Gombafalu, Kéklő Gombaerdő,
  Kőmarok vára, Csillagtó, Álompiramis, Lidércláp, Hullócsillag-kráter, A Kék Láng köre, Légyölő-liget,
  Holdarc-kert, Egyszemű Kő, Csillagász tornya — négy rejtett hely, amelyekhez nem vezet út
  (Lebegő szigetek, Kristálymező, Alvó Óriás, Feledés romjai) —, és fent az égben két új:
  a **Felhőkikötő** (48 m magasan a falu mögött) és a rejtett **Felhőkert** (100 m magasan).
* **Az égi réteg (v6)**: szélkutak repítenek fel (az egyik a falu mögött áll, a másik a lebegő szigetek
  csúcsán ébred fel, ha elvetted onnan a kulcsdarabot). A kikötőben lakik Pihe, a molylány felhőpásztor,
  világítótorony, bárányakol, felhőharang és bálnamóló van; a Felhőkertben csillagliliomok, Égtükör,
  holdkapu, alvó Bárányfelhő-anyó és egy felhőlépcső a világ legmagasabb szilánkjához. Az égen
  hullócsillagok húznak át, és felhőpadok úsznak.
* **Álomlények (v6)** — 16 fajta, a naplóban bestiárium gyűjti őket: pöfetegek (ha észrevesznek,
  gombának tettetik magukat), holdnyulak, gólyalábú lámpásvivők az utakon, háztetőn ülő álommacskák
  (az egyik beszél), baglyok, égi pontyok, lámpák körül keringő holdmolyok, égi bálnák, felhőbárányok,
  valamint a régi lakók (Holdszarvas, óriáscsiga, varjak, halak, medúzák, lidércek, békák).
  Mind a 16 megtalálásáért 3 csillagszilánk jár.
* **Fő küldetés** (A csillagkulcs): három kulcsdarab — a lebegő szigetek csúcsán, a kráter mélyén és a
  csillagász tornyában —, kovácsolás, a kapu kinyitása, fénylépcső a várhoz, Holdkirálynő.
* **Mellékküldetések**: A csillagász lencséje, Pöttöm csigája (jutalom: a rejtett helyek a térképen),
  Holdvirág (Horgász Huba), A Holdszarvas (lopakodva kell megközelíteni; jutalom: Holdléptek),
  Az emlékező kövek (minden rúnakő elolvasása; jutalom: Csillagszem),
  Felhőbárányok (Pihe három bárányát kell megsimogatni az erdőben, hogy hazaszálljanak; jutalom: 3 szilánk
  és a felhőharang titka), Az égi komp (a harang hívására a nyerges bálna a kikötő mólójához úszik, és egy
  kb. másfél perces körúton átviszi a Felhőkertbe; menet közben Szóközzel le lehet ugrani).
* **Csillagszilánkok** (64): 8-nál Csillagugrás (dupla ugrás), 20-nál Holdsiklás.
* **Csodák**: tündérkörök, alvó kőfejek, lebegő kövek, óriáscsontok, lámpásfák, égi medúzák.
* **Holdkapuk**: felébresztés után gyorsutazás közöttük.
* **Lila ugrógombák**: rálépsz, és magasra dobnak — így jutsz fel a gombák kalapjára és a szigetekre.
* **Táj**: a Holdpatak egy szurdokból ered a vár mellett, kőhíd visz át rajta, és a Csillagtóba ömlik;
  a kis Ezüstér átgázolható. Sziklás hegygerinc hágóval a sivatag előtt, rejtett kristályvölgy
  egyetlen szűk bejárattal, Csillaghegy a toronnyal, fenyvesek északon, virágzó holdfák a kertben.

## Felépítés

```
src/
  main.js              belépési pont
  engine/              saját WebGL2 motor
    math.js            vektor, mátrix, kvaternió, seedelt véletlen
    noise.js           simplex zaj
    gl.js              shader programok, textúrák, render targetek
    geometry.js        geometria-építő (box, gömb, lathe, tube, torus ...)
    scene.js           jelenetgráf (csak a megmozdult ágakat számolja újra), Mesh, Material, Camera
    renderer.js        árnyék-pass, HDR, bloom, színkorrekció, LOD-távolságok, dinamikus felbontás
    batch.js           példányosított növényzet: példányonkénti takarás és részletszint, közös rács
    static.js          statikus kötegelés: a mozdulatlan hálók anyagonként és területenként összevonva
    rig.js             a szereplők részei anyagonként egy „csontos" hálóban (kevesebb rajzolás)
    shaders/           GLSL: felületek, ég, víz, fű (két LOD-gyűrű), részecskék, portál, medúzák
  world/
    layout.js          A VILÁG TERVE (fix térkép): helyszínek, utak, folyók, hidak, dombok, gerincek, biomok
    terrain.js         magasságtérkép, utak, splat-súlyok, darabolt terep-mesh 3 LOD-dal
    physics.js         ütközők (kör, szakasz) és ráléphető felületek (doboz, korong, rámpa, függvény)
    world.js           összerakja: víz, fű, szilánkok, részecskék, elhelyezés, lekérdezések
    sites.js           minden helyszín felépítése (épületek, NPC-horgonyok, küldetéstárgyak, kapuk)
    scatter.js         biom-alapú növényzet instancinggel + LOD, a vadon csodái
    fx.js              GPU-s részecskék, pillangók, medúzák, a bot szikranyoma
    sky.js             az égi réteg: Felhőkikötő, Felhőkert, szélkutak, felhőpadok, hullócsillagok
    capsurf.js         a gombakalapok valódi alakjához illő ráléphető felület
    dreamsea.js        az álomtenger: nevezetes helyek, ajtók, véletlen cellák (v7)
  models/
    materials.js       közös anyagok és vászonra rajzolt textúrák
    flora.js           gombák, fák, ciprus, fenyő, pálma, kövek, páfrány, virágok (LOD-változatokkal)
    characters.js      törpék, varázsló, csuklyások, varjú, béka, Holdszarvas, óriáscsiga
    structures.js      kunyhó, üst, kőkéz és vár, kapu, Egyszemű Kő, piramis, rúnakör, Holdarc, móló
    wonders.js         gombaházak, kút, lámpásfüzérek, torony, óriás, romok, holdkapu, lebegő sziget ...
    creatures.js       álomlények: pöfeteg, holdnyúl, gólyalábú, macska, bagoly, ponty, bálna (nyereggel),
                       holdmolyok, Pihe a felhőpásztor, felhőbárány
    sky.js             felhőpamacs, égi móló, világítótorony, harang, akol, csillagliliom, Égtükör
    dream.js           az álomtenger tárgyai (lépcső, játszótér, oszlopok, Alvó Hold, ajtók ...)
    wanderers.js       a talajlakók modelljei (óriások, teknős, plüssnyuszi, szemvirág, lámpás, Mumus)
    fauna.js           (v9) csillagsün, lepkeróka, Álomfaló, gyökérpók, Csendes
    leviathan.js       (v9) a Mélység Lámpása
  game/
    game.js            állapotgép, fő ciklus, küldetés-segédek, gyűjtés, mentés, minőség
    quests.js          a haladás (mentett állapot), célok, napló-adatok
    npcs.js            NPC-k, lények és minden interakció (párbeszéd → küldetéslépés)
    creatures.js       az álomlények viselkedése és a bestiárium
    skylife.js         szélkutak, Pihe és a bárányok, felhőharangok, a kompbálna útvonala és a lovaglás
    player.js          mozgás, fizika, ugrógomba, dupla ugrás, siklás, lopakodás, animáció
    camera.js          külső nézetes kamera ütközéssel
    audio.js           generatív zene, környezet, effektek (WebAudio)
    wanderers.js       lépegető óriások, Dombteknős, plüssnyuszik, szemvirágok, lámpások (v7)
    mumus.js           a Mumus: kóborlás, észrevesz, üldöz, elkap (v7.2)
    fauna.js           (v9) az öt új lényfaj élete: elhelyezés biom szerint, viselkedés, simogatás
    leviathan.js       (v9) a tengeri szörny: útvonal, felbukkanás, vadászat, elnyelés; árnyéka a tenger shaderében
    multiplayer.js     Multiplayer: kapcsolat, a többiek törpéi, névtáblák, buborékok, csevegés (v7)
    input.js, events.js
  data/
    dialogue.js        minden párbeszéd, küldetésszöveg és képesség
    lore.js            a rúnakövek szövegei
  ui/                  HTML, CSS és a felület logikája (HUD, küldetéskövető, napló, térkép, utazás)
web/                   a weboldal-csomag fájljai (.htaccess, ikonok, manifest, mp.php)
server/mp-server.mjs   Node.js-es többjátékos szerver (ugyanaz a protokoll, mint az mp.php-é)
tools/mp-bots.mjs      terheléses teszt a többjátékos szerverhez
tools/mp-security-test.mjs  támadási próbák a többjátékos szerver ellen (mindnek el kell buknia)
```

## Bővítés

**Térkép:** `world/layout.js` → `SITES` (helyszínek koordinátái), `ROADS` (utak átmenőpontokkal),
`RIVERS`, `LAKES`, `HILLS`, `RIDGES`, `BASINS`. A hidak automatikusan kerülnek oda, ahol út keresztez folyót.

**Új helyszín:** `world/layout.js` → `SITES` lista (név, sugár, út vezet-e oda, rejtett-e), majd a
`world/sites.js`-ben egy építő függvény. A felfedezés, térkép, iránytű és napló automatikusan kezeli.

**Új szereplő vagy tárgy:** `game/npcs.js` → `addInteract({ id, name, pos, radius, kind, talk })`.
A `talk()` visszaadhat `{ lines, after }`-t: a sorok után lefut az `after`, itt lehet küldetést léptetni
(`game.setStage`, `game.giveItem`, `game.grantAbility` ...).

**Új küldetés:** `game/quests.js` → `QUESTS` (cím, leírás) és az `objectives()` függvény (mit mutasson a
követő és a térkép), a szövegek a `data/dialogue.js` `SCRIPT` részébe.

Események a `game.events` buszon: `region:enter`, `region:discover`, `interact`, `jump`, `land`,
`bounce`, `shard`. Mentés: `localStorage` → `alomrengeteg.v4` (haladás, pozíció, beállítások).

**Teljesítmény (v5):** a képet nem butítja, csak a munkát szervezi okosabban:
* statikus kötegelés (`engine/static.js`) — ami nem mozdul, anyagonként és területenként egy rajzolás;
  ha mégis megmozdul vagy eltűnik valami, a motor magától kiveszi a kötegből;
* a szereplők részei anyagonként egy hálóban mozognak (`engine/rig.js`);
* a növényzet példányonként kerül a képbe (`engine/batch.js`): ami nem látszik, nem is megy a GPU-ra, és a
  közeli fák mindig a részletes modellt kapják; a lombkártyák a textúra átlátszó sarkai nélkül rajzolódnak;
* uniform- és textúra-gyorsítótár, shader szerint rendezett rajzolás, nincs képkockánkénti szemét;
* a terep a szilárd tárgyak után, az ég a legvégén rajzolódik — a takart pixeleket a GPU ki sem számolja;
* minden shader a töltőképernyőn fordul le (nincs akadás új helyeken), a terep kétszer gyorsabban generálódik.

**Javítások (v7.2.1):** a többjátékos szerver átnézve és megerősítve (lásd Biztonság); két valódi hiba
javítva: a csupa számjegyből álló játékos-azonosítót a PHP számmá alakította (az ilyen játékos kísértetként
látta önmagát, és a buborékjai nem jelentek meg), és hibás kérésre a szerver PHP-figyelmeztetést írhatott a
válaszba; a sérült vagy kézzel szerkesztett mentés nem akaszthatja meg a játékot; Brekus és a szemvirágok
nem járhatók át.

**Változások (v7.2):** vissza az eredeti törpeméret és kamera; mély tenger padló nélkül, puha partszél a
tavaknál és folyóknál (a víz a parton elvékonyodik, nincs fűrészfogas szél); halkabb fények: kevesebb
csillogás, gyengébb ragyogás (bloom), halványabb gombapöttyök, kristályok, kapuk; új békamodell
tavirózsa-levélen; a lépegető óriásoknak ízületes lábuk van.

**Javítások (v7.1):** a hidak járófelülete kifelé néz (eddig a híd tetején a lap „befelé" nézett, ezért
felülről nem látszott), és valódi kövekből, illetve deszkákból áll; a Dombteknős páncélja már az első
pillanattól a helyén van (eddig a világ közepén állt egy képkockáig, és a kezdőpontra lépő játékos 8 méter
magasról esett le); a kamera a hidakon, lépcsőkön, gombakalapokon is a felszín fölött marad.

**Javítások (v6):** a lebegő szigetek és a felhők teteje felülről is látszik (eddig a felső lap
„befelé" nézett, ezért felülről átlátszott); a gombakalapok ráléphető felülete a valódi kalapformát
követi, és a kalapok mindkét oldalról rajzolódnak; a torony lépcsője nem vezet át a kilátó padlóján, és a
szereplők nem mennek át tárgyakon: a statikus modellek meredek felületeiből egy finom „szilárd rács" épül
(0,25 m-es cellák), ami a falakat, oszlopokat, kalaptöveket pontosan követi.

**Grafika:** `game/game.js` → `QUALITY` (felbontás, MSAA, árnyék, fű, fények száma, terep-LOD).
Az első indításkor közepes szint, a képkockaszám alapján egyszer automatikusan vált, játék közben pedig a
dinamikus felbontás tartja simán a képet (a beállításokban kikapcsolható).
