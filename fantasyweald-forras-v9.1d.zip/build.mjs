// Build: bundle src/main.js with esbuild and inline everything into one HTML page.
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, existsSync, rmSync, readdirSync, copyFileSync } from 'node:fs';
// esbuild: from node_modules (npm install), or a path given in the ESBUILD env var
const localBin = 'node_modules/.bin/esbuild';
const ESBUILD = process.env.ESBUILD || (existsSync(localBin) ? localBin : '/home/claude/.npm-global/lib/node_modules/tsx/node_modules/esbuild/bin/esbuild');
const dev = process.argv.includes('--dev');
mkdirSync('dist', { recursive: true });
execFileSync(ESBUILD, ['src/main.js', '--bundle', '--format=iife', '--target=es2020', '--outfile=dist/game.js', ...(dev ? ['--sourcemap=inline'] : ['--minify'])], { stdio: 'inherit' });
const js = readFileSync('dist/game.js', 'utf8');
const css = readFileSync('src/ui/style.css', 'utf8');
const body = readFileSync('src/ui/markup.html', 'utf8');
const head = `<title>FantasyWeald</title>
<meta name="description" content="A moonlit fairy-tale world to wander in your browser.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500&family=Grenze+Gotisch:wght@500;700&display=swap">
<style>${css}</style>`;
const fragment = `${head}\n${body}\n<script>${js.replace(/<\/script/g, '<\\/script')}</script>\n`;
writeFileSync('dist/alomrengeteg.html', fragment);
const local2 = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>${fragment}</body></html>`;
// standalone page for opening directly in a browser
writeFileSync('dist/local.html', local2);
// web package for ordinary hosting (e.g. Namecheap / cPanel): unzip into public_html and it works
{
  const W = 'dist/web';
  rmSync(W, { recursive: true, force: true });
  mkdirSync(W, { recursive: true });
  // Content-Security-Policy: the page may only run its own (inline) code, load its own files and the two
  // font hosts, and talk to its own server (or an https multiplayer server, see README); no plugins, no
  // foreign forms, no <base> tricks
  const csp = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self' https:; " +
    "worker-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'self'";
  const webHead = `<meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="${csp}">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>FantasyWeald</title>
<meta name="description" content="A moonlit fairy-tale world to wander in your browser: mushroom villages, sky whales, cloud sheep, a seven-headed dragon and a lost star key.">
<meta name="theme-color" content="#05060f">
<meta name="color-scheme" content="dark">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="FantasyWeald">
<meta property="og:title" content="FantasyWeald">
<meta property="og:description" content="A moonlit fairy-tale world to wander in your browser.">
<meta property="og:type" content="website">
<meta property="og:image" content="og.png">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="192x192" href="icon-192.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="manifest" href="manifest.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500&family=Grenze+Gotisch:wght@500;700&display=swap">
<style>${css}</style>`;
  const noscript = '<noscript><p style="color:#e2e6ff;font:20px Georgia,serif;text-align:center;margin-top:30vh">Please turn on JavaScript to play. · A játékhoz be kell kapcsolni a JavaScriptet.</p></noscript>';
  const page = `<!doctype html>\n<html lang="en">\n<head>\n${webHead}\n</head>\n<body>\n${noscript}\n${body}\n<script>${js.replace(/<\/script/g, '<\\/script')}</script>\n</body>\n</html>\n`;
  writeFileSync(`${W}/index.html`, page);
  for (const f of readdirSync('web')) copyFileSync(`web/${f}`, `${W}/${f === 'htaccess' ? '.htaccess' : f}`);
  const zip = 'dist/alomrengeteg-web.zip';
  rmSync(zip, { force: true });
  try {
    execFileSync('zip', ['-q', '-X', '-9', '-r', '../alomrengeteg-web.zip', '.'], { cwd: W });
  } catch (e) {
    execFileSync('python3', ['-c', `import zipfile,os\nz=zipfile.ZipFile('${zip}','w',zipfile.ZIP_DEFLATED)\nfor f in sorted(os.listdir('${W}')): z.write(os.path.join('${W}',f), f)\nz.close()`]);
  }
}
console.log('built', (fragment.length / 1024).toFixed(0) + ' KB');
