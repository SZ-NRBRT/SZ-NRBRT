// Álomrengeteg multiplayer server for Node.js (no dependencies). Same protocol and the same checks as
// web/mp.php, but everything stays in memory, so it comfortably serves hundreds of dreamers. Use it when
// the PHP version is not enough (a very busy forest), on any host that runs Node (a VPS, or cPanel's
// "Setup Node.js App").
//
//   node server/mp-server.mjs            (listens on PORT or 8787)
//
// Then point the game at it: in index.html set  <meta name="mp-url" content="https://your.host/mp">
// (by default the game talks to mp.php next to itself).
//
// Like mp.php it trusts nothing from the browser: typed and clamped input, cleaned names and chat,
// secret per-player keys that are never sent to anybody else, per-address limits on players, requests,
// joins and chat. Behind a reverse proxy set TRUST_PROXY=1 so the real address comes from X-Forwarded-For.
import http from 'node:http';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT) || 8787;
const MAX_PLAYERS = Number(process.env.MAX_PLAYERS) || 250;
const MAX_PER_IP = Number(process.env.MP_MAX_PER_IP) || 10;
const JOIN_GAP_MS = process.env.MP_JOIN_GAP_MS !== undefined ? Number(process.env.MP_JOIN_GAP_MS) : 1500;
const REQ_WINDOW_MS = 2000;
const REQ_MAX = Number(process.env.MP_REQ_MAX) || 120;
const TRUST_PROXY = !!process.env.TRUST_PROXY;
const TIMEOUT_MS = 12000;
const CHAT_KEEP = 40;
const CHAT_GAP_MS = 1200;
const CHAT_BURST = 6;
const CHAT_MAX = 160;
const CHAT_NEAR = 30;       // (v8) a normal message is heard this far
const ALL_GAP_MS = 8000;    // (v8) a "!all" message (to everybody) at most this often
const NAME_MAX = 16;
const WORLD_R = 760;
const NEAR_R = 220;

const players = new Map();
const ips = new Map();   // address -> { w, n, join, chat }
const chat = [];
let cid = 0;

const BAD = /[\u0000-\u001F\u007F-\u009F­؜᠎​-‏‪-‮⁠-⁯﻿￹-￻]/g;
// (v9) chat and names are plain words only: letters (any alphabet), digits, spaces and everyday punctuation
// — no emoji, no symbols or pictures — and no links (web addresses, e-mail links, "example dot com"...)
const NOT_PLAIN = /[\uFE00-\uFE0F\u20E3]|[^\p{L}\p{Mn}\p{Mc}\p{Nd} .,!?:;'"()\-\u2013\u2014\u2026%+=\/&@#*_\u201E\u201D\u201C\u2018\u2019\u00AB\u00BB]/gu;
const LINK = /[a-z][a-z0-9+.\-]*:\/\/|(?<![\p{L}\p{N}])(?:www\s?\.|(?:https?|ftp|javascript|mailto|blob)\s?:|data\s?:\s?[a-z]+\/)|[\p{L}\p{N}\-]+(?:\.|\s?(?:\(dot\)|\[dot\]|\[\.\]|\(\.\))\s?|\s+(?:dot|pont)\s+)(?:com|net|org|hu|io|gg|ly|me|co|info|xyz|ru|de|uk|tv|app|dev|link|site|online|biz|us|eu|to|cc|tk|ml|ga|cf|gq|top|shop|store|live|stream|click|fun|pro|club|page|chat|social|tech|ai|gov|edu|fr|it|es|pl|ro|sk|at|ch|nl|be|cz|se|no|dk|fi|jp|cn|in|br|ca|au|nz|ws|pw|sh|gl|gd|vc|so|im|fm|am|bz|xxx|onion)(?![\p{L}\p{N}])/iu;
function plainText(s) {
  return typeof s === 'string' ? s.replace(NOT_PLAIN, '') : '';
}
function hasLink(s) {
  return typeof s === 'string' && LINK.test(s);
}
function cleanText(s, max) {
  if (typeof s !== 'string' || !s || s.length > 1024) return '';
  s = s.normalize('NFC').replace(BAD, '').replace(/(\p{M})\p{M}+/gu, '$1').replace(/\s+/g, ' ');
  s = plainText(s).replace(/ {2,}/g, ' ').trim();
  return [...s].slice(0, max).join('').trim();
}
const num = (v, lo, hi) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : 0);
const r2 = (v, k = 100) => Math.round(v * k) / k;
const intervalFor = (n) => (n <= 10 ? 150 : n <= 40 ? 220 : n <= 100 ? 300 : 400);
function say(text, t, pid = '', name = '', all = 1, pos = null) {
  chat.push([++cid, pid, name, text, t, all ? 1 : 0, pos ? pos[0] : 0, pos ? pos[1] : 0, pos ? pos[2] : 0]);
  if (chat.length > CHAT_KEEP) chat.splice(0, chat.length - CHAT_KEEP);
}

function handle(req, t, ip) {
  for (const [id, p] of players) if (t - p.t > TIMEOUT_MS) players.delete(id);
  for (const [k, r] of ips) if (t - Math.max(r.w, r.join, r.chat) > 60000) ips.delete(k);
  let R = ips.get(ip);
  if (!R) ips.set(ip, (R = { w: t, n: 0, join: 0, chat: 0 }));
  if (t - R.w > REQ_WINDOW_MS) { R.w = t; R.n = 0; }
  if (++R.n > REQ_MAX) return [429, { ok: false, err: 'slow' }];
  const a = req.a;
  if (!['hello', 'join', 'sync', 'leave'].includes(a)) return [400, { ok: false, err: 'action' }];
  if (a === 'hello') return [200, { ok: true, v: 3, players: players.size, max: MAX_PLAYERS }];
  if (a === 'join') {
    if (players.size >= MAX_PLAYERS) return [200, { ok: false, err: 'full' }];
    let mine = 0;
    for (const p of players.values()) if (p.ip === ip) mine++;
    if (mine >= MAX_PER_IP) return [200, { ok: false, err: 'ip' }];
    if (t - R.join < JOIN_GAP_MS) return [200, { ok: false, err: 'slow' }];
    R.join = t;
    let name = cleanText(req.name, NAME_MAX);
    if (hasLink(name)) name = '';
    if (!name || !/[\p{L}\p{N}]/u.test(name)) name = 'Vándor';
    const color = Number.isInteger(req.color) ? Math.max(0, Math.min(7, req.color)) : 0;
    let id;
    do id = 'p' + crypto.randomBytes(4).toString('hex'); while (players.has(id));
    const key = crypto.randomBytes(12).toString('hex');
    players.set(id, { n: name, c: color, k: key, ip, s: [0, 0, 0, 0, 0, 0, 0], t, st: 0, lc: 0, cb: [], lm: '', la: 0, cc: Math.max(0, cid - 12) });
    say(`${name} megérkezett az erdőbe.`, t);
    return [200, { ok: true, id, key, t, interval: intervalFor(players.size), since: Math.max(0, cid - 12) }];
  }
  const id = req.id, key = req.key;
  const me = typeof id === 'string' && /^p[0-9a-f]{8}$/.test(id) ? players.get(id) : null;
  if (!me || typeof key !== 'string' || key.length !== me.k.length || !crypto.timingSafeEqual(Buffer.from(key), Buffer.from(me.k))) {
    return [200, { ok: false, err: 'unknown' }];
  }
  if (a === 'leave') {
    players.delete(id);
    say(`${me.n} felébredt, és hazament.`, t);
    return [200, { ok: true }];
  }
  // sync
  const s = req.s;
  if (Array.isArray(s) && s.length === 7 && t - me.st >= 50) {
    let yaw = num(s[3], -1e4, 1e4);
    yaw = ((yaw + Math.PI * 101) % (2 * Math.PI)) - Math.PI;
    me.s = [r2(num(s[0], -WORLD_R, WORLD_R)), r2(num(s[1], -40, 400)), r2(num(s[2], -WORLD_R, WORLD_R)), r2(yaw, 1000), r2(num(s[4], -30, 30)), r2(num(s[5], -30, 30)), (num(s[6], 0, 1023) | 0) & 31];
    me.st = t;
  }
  me.t = t;
  let cd = null;
  if (req.chat !== undefined && req.chat !== null) {
    let msg = cleanText(req.chat, CHAT_MAX);
    // "!all ..." goes to everybody; anything else only to the ones nearby
    let all = 0;
    const mm = /^!all(\s+|$)/i.exec(msg);
    if (mm) { all = 1; msg = msg.slice(mm[0].length).trim(); }
    me.cb = me.cb.filter((c) => t - c < 20000);
    if (!msg) cd = 'empty';
    else if (hasLink(msg)) cd = 'link';
    else if (t - me.lc < CHAT_GAP_MS || t - R.chat < 500) cd = 'fast';
    else if (me.cb.length >= CHAT_BURST) cd = 'burst';
    else if (msg === me.lm && t - me.lc < 20000) cd = 'repeat';
    else if (all && t - me.la < ALL_GAP_MS) cd = 'allfast';
    else { say(msg, t, id, me.n, all, me.s); me.lc = t; me.lm = msg; me.cb.push(t); R.chat = t; if (all) me.la = t; }
  }
  const since = Number.isInteger(req.since) ? req.since : 0;
  const full = !!req.full;
  const mx = me.s[0], mz = me.s[2];
  const p = [];
  for (const [pid, o] of players) {
    if (pid === id || !o.st) continue; // (just joined, no position yet)
    if (!full && (o.s[0] - mx) ** 2 + (o.s[2] - mz) ** 2 > NEAR_R * NEAR_R) continue;
    p.push([pid, o.n, o.c, ...o.s, t - o.st]);
  }
  // (v8) chat: nearby only, unless it was for everybody (system lines are); the sender's position stays here
  const my = me.s[1];
  const lines = [];
  // (a per-player cursor: out-of-range lines are used up too, and nobody can rewind to old lines)
  const from = Math.max(since, me.cc);
  for (const c of chat) {
    if (c[0] <= from) continue;
    if (!c[5] && c[1] !== id && (c[6] - mx) ** 2 + (c[7] - my) ** 2 + (c[8] - mz) ** 2 > CHAT_NEAR * CHAT_NEAR) continue;
    lines.push([c[0], c[1], c[2], c[3], c[4], c[5]]);
  }
  me.cc = cid;
  const res = { ok: true, t, p, c: lines, n: players.size, cid, full, interval: intervalFor(players.size) };
  if (cd) res.cd = cd;
  return [200, res];
}

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  const fwd = TRUST_PROXY && req.headers['x-forwarded-for'];
  const ip = (fwd ? String(fwd).split(',')[0].trim() : req.socket.remoteAddress) || '?';
  if (req.method !== 'POST') {
    const [code, out] = handle({ a: 'hello' }, Date.now(), ip);
    send(code, out);
    return;
  }
  let body = '', big = false;
  req.setEncoding('utf8');
  req.on('data', (d) => { if (big) return; body += d; if (body.length > 4096) { big = true; send(413, { ok: false, err: 'big' }); req.destroy(); } });
  req.on('end', () => {
    if (big) return;
    let msg = null;
    try { msg = JSON.parse(body); } catch (e) { msg = null; }
    if (!msg || typeof msg !== 'object' || Array.isArray(msg)) { send(400, { ok: false, err: 'bad' }); return; }
    const [code, out] = handle(msg, Date.now(), ip);
    send(code, out);
  });
  req.on('error', () => {});
});
server.requestTimeout = 10000;
server.headersTimeout = 10000;
server.listen(PORT, () => console.log(`Álomrengeteg multiplayer: http://localhost:${PORT}  (max ${MAX_PLAYERS} players)`));
