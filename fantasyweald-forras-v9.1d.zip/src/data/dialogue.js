// All spoken lines and descriptions.
// LINES: ambient chatter keyed by interactable id — shown two lines per conversation, then it loops.
// SCRIPT: quest conversations, shown in full, in order. {dir} and {place} are filled in by the game.
export const LINES = {
  wizard: [
    'Ma éjjel különösen fényes az erdő. A gombák valamit ünnepelnek.',
    'Látod azt a hatalmas kőkezet a hegyek felett? Régen integetett. Aztán elfáradt.',
    'Ha eltévednél, kövesd a világító köveket. Mindig hazavezetnek.',
    'A botod gömbje a te fényed. Amíg világít, nem vagy egyedül.',
    'A lila gombákra bátran ugorj rá. Ők szeretik, ha valaki meglátogatja őket.',
  ],
  pottom: [
    'A piros kalapúakat ne edd meg. Én megettem egyet, és három napig hallottam a színeket.',
    'Ezerkétszáztizenhét… ezerkétszáztizennyolc… jaj, most elrontottad!',
    'A nagy piros gombákon lehet ugrálni! Csak ne szólj a nagyapámnak.',
  ],
  fisher: [
    'Csillagot fogni nehezebb, mint halat. De sokkal szebben világít a vödörben.',
    'Csitt! Ha túl hangos vagy, a csillagok a tó mélyére bújnak.',
    'Tegnap kifogtam egy kis üstököst. Visszadobtam, még nem nőtt meg.',
    'Látod azt a vörös fényoszlopot kint a tengeren? A Hamusziget. Ott alszik a Hétfejű a kincsén. Aki arra evez, csak lopakodva menjen… és a manóktól óvakodjon!',
  ],
  pointer: [
    'Nézd, ott a vízben! Brekus megint minket figyel.',
    'Azt mondják, a vízesés mögött van egy barlang. Azt is mondják, hogy nincs.',
    'A tó azért világít, mert alul is van egy hold. Kisebb, de szorgalmasabb.',
    'Láttál már Holdszarvast? Én egyszer. Tüsszentettem, és elszaladt.',
  ],
  frog: ['Brekk.', '…brekk?', 'BREKK!', 'Brekk-brekk. (Ez nagyon fontosnak hangzott.)'],
  hooded: [
    'A csuklyás alak nem válaszol. A lángban mintha egy kapu képe derengene.',
    'Mozdulatlanul állnak. Mintha a kövek szavára várnának.',
  ],
  watcher: [
    'Az Egyszemű Kő pislog egyet. Úgy tűnik, emlékezni fog rád.',
    'A kő szeme lassan követ. Nem ijesztő. Csak nagyon kíváncsi.',
  ],
  moon: [
    'A lehullott Hold rád vigyorog. „Még nem jött el az ideje” — suttogja.',
    'A Hold arca hideg, de a mosolya meleg. A pillangók körülötte keringenek.',
  ],
  cauldron: [
    'A főzet zölden fortyog. Illata: menta, eső és egy csipet holnap.',
    'Buborék pattan: egy apró csillag száll fel belőle, és eltűnik.',
  ],
  shroomling: [
    '(A gomba nagyon igyekszik gombának látszani.)',
    '…',
    '(Egy apró szem kinyílik a kalap alatt, aztán gyorsan be is csukódik.)',
    '„Mi nem vagyunk itt. Mi csak gombák vagyunk. Nagyon hétköznapi gombák.”',
    '(Halk kuncogás a fűből. Aztán megint csend.)',
  ],
  stilt: [
    'A vándor lehajol hozzád a magasból. A lámpásában egy apró hold ég.',
    '„Minden út visszavezet valahová. Én a visszafelé irányt keresem.”',
    '„Onnan fentről látni, hogy az erdő lélegzik. Be… és ki…”',
    '„A bálnák ma alacsonyan szállnak. Ez jót jelent. Vagy esőt. Vagy mindkettőt.”',
    '„Sietek. Nagyon lassan sietek.”',
    '„Ha a szélkútba lépsz, ne félj. A levegő is tud vinni, csak meg kell kérni.”',
  ],
  cat: [
    'A macska lustán rád pislog. „Miaú. Vagyis: üdv, vándor.”',
    '„Láttad már a Felhőkikötőt? A falu mögötti szélkút felrepít oda. Én nem megyek, utálom a huzatot.”',
    '„Fent a kikötőben egy pásztorlány sír. Elszöktek a báránykái. A felhőbárányok. Igen, jól hallod.”',
    '„Ha a bálnák leszállnak, fel lehet ülni rájuk. Én azt mondom, a macskák számára túl nagyok.”',
    '„A tetőről mindent látok. Például azt, hogy túl sokat beszélgetsz egy macskával.”',
    '„A pöfetegek azt hiszik, nem látom őket. Mindenki azt hiszi, hogy nem látom.”',
  ],
  shepherd: [
    'A bárányok most alszanak. Ha egy felhőt látsz, amelyik horkol, az az enyém.',
    'A bálnák szeretik a harangszót. Egyszer az egész csorda eljött, és leült a kikötő mellé. Nem fértünk el.',
    'Idefent minden lassabban történik. Még a gondolatok is.',
    'A szárnyaim? Porosak, mint egy régi könyv lapjai. De repülni még tudnak. Néha.',
    'A Felhőkertben nyílnak a csillagliliomok. Minden szirmuk egy elfelejtett kívánság.',
    'Ha leesel innen, ne ijedj meg. Az erdő puha. Többnyire.',
  ],
  turtle: [
    'A Dombteknős lassan pislog egyet. Ez nála nagyjából egy teljes percig tart.',
    'A páncélján egy kis ház áll, az ablakában világosság. Valaki lakik odafent.',
    'Ha a teknős oldalánál felkap a szél, hagyd, hogy felvigyen a hátára.',
  ],
  plush: [
    'A plüssnyuszi rád néz a gombszemeivel. Az egyik gomb lóg egy kicsit a cérnáján. Mintha mosolyogna.',
    'Valaki régen nagyon szerette. Még most is érződik rajta a levendulás öblítő illata.',
    'Megöleled. Halkan sípol egyet, aztán megpaskolja a fejed a puha mancsával. Olyan, mint amikor kicsi voltál.',
    'A hátán cipzár van. Belül talán egy másik, kisebb nyuszi alszik.',
    'Nem szól semmit. Csak áll, és vár. Talán azt a gyereket keresi, akié volt.',
  ],
  eyeflower: [
    'A virág közepén egy nagy, nedves szem pislog rád. Aztán lassan követ, bármerre mész.',
    'Ha elég sokáig állsz előtte, a szem lecsukódik, és a virág elbóbiskol. Aztán hirtelen újra rád néz.',
    'Gyökérlábakon totyog a fűben. A szirmain harmat csillog, mintha könnyezne.',
    'Azt mondják, a szemvirágok látják, amit álmodsz. Most épp téged néz.',
  ],
  sheepPen: ['A felhőbárányok egymáshoz bújnak. Halkan dorombolnak.', 'Az egyik bárány tüsszent: egy apró esőfelhő száll el belőle.'],
  flockMother: [
    'A hatalmas bárányfelhő mélyen alszik. Minden lélegzettel apró felhőcskék szállnak fel belőle.',
    'Az álmaiból lesznek az esők. A szép álmaiból a szivárványok.',
    'Egy pillanatra kinyitja az egyik szemét, rád néz, aztán elégedetten visszaalszik.',
  ],
  pier: ['A víz alatt csillagok úsznak. Némelyik visszakacsint.', 'A móló deszkái halkan nyikorognak, mintha dúdolnának.'],
  flame: ['A kék láng hideg. Ha közel hajolsz, hallod a saját neved.', 'A rúnák körbe-körbe forognak, mint egy lassú óra.'],
  pyramid: ['A csúcson lebegő kő úgy dereng, mint egy régi emlék.', 'Az ég kinyitja a szemét. Nem baj. Csak megnéz.'],
  giant: ['Az óriás mélyen alszik. A horkolásától remegnek a fűszálak.', 'Egy mohás hegy, ami néha sóhajt. Jobb nem felébreszteni.'],
  heart: ['A hullócsillag szíve lassan dobog. Minden dobbanásnál kicsit melegebb lesz a levegő.'],
  well: ['A kút mélyén egy másik ég csillagai látszanak.', 'Ha belekiabálsz, egy hang visszakérdez: „Tessék?”'],
  snailBig: ['A csiga házában lámpa ég. Valaki lakik benne — talán épp vacsorázik.', 'Nagyon, nagyon lassan halad. De sosem késik el sehonnan.'],
  ruins: ['Egy név volt ide vésve. Már csak az első betűje látszik.', 'A romok között hideg a levegő, mint egy elfelejtett szobában.'],
  shrine: ['Üres talapzat. Valami fontos állt itt egykor.'],
  // villagers
  elder: [
    'Gombafaluban mindenki a saját gombájában lakik. Kivéve Bódit. Ő a szomszédéban.',
    'Régen a Holdkirálynő minden évben lejött hozzánk. Mióta bezárták a kaput, csak a fénye jön.',
    'Azt mondják, a Hétfejű koronáját még senki sem hozta el. Hét feje van, és mind a hét alszik… de sosem egyszerre mélyen.',
  ],
  // (v9.1c) gnomes wandering the whole island
  wGaspar: [
    "Gombát szedek. Nem, nem a világítósat. Az megeszi a kosarat.",
    "A lila gombák holdtöltekor dúdolnak. Ha nagyon csendben vagy, te is hallod.",
    "Egyszer találtam egy gombát, ami kalapot viselt. Visszaadtam neki.",
  ],
  wKornel: [
    "Negyven éve járom ezt az erdőt, és még mindig találok új ösvényt. Az erdő éjjel átrendezi magát.",
    "Ha eltévedsz, kövesd a fénylő ösvényt. Mindig hazavisz. Majdnem mindig.",
    "A dombteknős hátán is laktam egy nyarat. Lassú, de legalább sosem késik el sehonnan.",
  ],
  wBerta: [
    "Csillagbogyót gyűjtök. A fele a kosárba megy, a fele a számba.",
    "A ködráják néha lejönnek hozzám, ha dúdolok. Szeretik a hamis hangokat.",
    "Láttad már a plüssnyuszikat? Aki elég magasra ugrik, a fejükön is utazhat egyet.",
  ],
  wCsaba: [
    "Várom, hogy leessen egy csillag. Hátha pont ide.",
    "A tenger felől néha hosszú, mély búgást hallok. Olyankor inkább beljebb várok a parttól.",
    "Minden hullócsillag egy elfelejtett álom. Én mindet felírom.",
  ],
  wDenes: [
    "Hmm-hmm-hmmm… Bocsánat, ezt a dalt egy bálnától tanultam. Nem jut eszembe a vége.",
    "Ha elég szépen dúdolsz, a fák is visszadúdolnak. Csak lassabban.",
    "Holnap a kútnál fogok dúdolni. Gyere el, ha van kedved!",
  ],
  wAbel: [
    "*ásít* …Ó, szia. Épp álmodtam valamit. Te is benne voltál.",
    "Ebben az erdőben sosincs reggel. Én ezt nagyon támogatom.",
    "Ha elalszol a holdvirágok között, a rossz álmaidat elviszik a ködráják.",
  ],
  wKata: [
    "Kavicsokat gyűjtök. Ez itt például egy nagyon komoly kavics.",
    "Az óriás csontjai mellett találtam egy fogat. Akkora, mint én!",
    "A kövek itt néha lebegnek. Nem szeretem, ha a kavicsaim elrepülnek.",
  ],
  wTivadar: [
    "Óvatosan a csillagsünökkel! Ha megijednek, gombóccá gömbölyödnek és elgurulnak.",
    "A gyökérpókok a holt erdőben laknak. Én arra csak nappal járok. Ami itt sosincs.",
    "A Holdszarvast csak lopakodva lehet megközelíteni. Én egyszer majdnem megérintettem.",
  ],
  lamplighter: [
    'Minden este meggyújtom a lámpásokat. Reggel eloltom őket. Aztán megint meggyújtom. Szép munka ez.',
    'Az erdőben van egy fa, amin maguktól gyulladnak ki a lámpások. Nem én voltam.',
  ],
  child: [
    'Tudtad, hogy a lila gombáról olyan magasra lehet ugrani, hogy megsimogatod a medúzákat?',
    'Én már voltam a Holdarc-kertben! Kétszer! Egyszer álmomban.',
    'Ha összeszeded a csillagszilánkokat, megtanulsz repülni. Legalábbis majdnem.',
  ],
  baker: [
    'Holdkalácsot sütök. A titka: kelesztés holdfénynél, sütés csillagfénynél.',
    'A kovász a kútból jön. Ne kérdezd, hogyan.',
  ],
  queen: ['A Holdkirálynő mosolyog. A vár ablakaiban ezer gyertya ég érted.'],
  astronomer: ['A csillagok nem hazudnak. Csak néha elfelejtik, mit akartak mondani.', 'Ezen a távcsövön át a Holdra is ráláthatsz. Most épp integet.'],
};

export const SCRIPT = {
  shepherdAsk: [
    'Ó! Egy vándor! Idefent ritkán jár valaki, aki nem felhőből van.',
    'Pihe vagyok, a felhőpásztor. Vagyis… pásztor voltam, amíg meg nem szöktek a báránykáim.',
    'Három felhőbárány ereszkedett le a ködön át az erdőbe. Puhák, kíváncsiak, és semmi eszük.',
    'Ha találsz egyet, simogasd meg. Akkor eszébe jut, hol a helye, és hazaszáll.',
    'Az egyik a Csillagtó felé kószált, a másik a Holdarc-kertbe, a harmadik a Kéklő Gombaerdőbe. Legalábbis a felhőjeik arra úsztak.',
  ],
  shepherdRemind: ['Még {left} bárány hiányzik: {where}', 'Simogasd meg őket, és hazatalálnak. A felhőbárányok mindig hazatalálnak, csak emlékeztetni kell őket.'],
  shepherdThanks: [
    'Mind a három itthon van! Hallod, ahogy dorombolnak? A felhőbárányok dorombolnak. Ezt mindenki tudja.',
    'Fogadd el ezeket a csillagszilánkokat. A gyapjukban akadtak fenn, amikor lehulltak az égről.',
    'És még valami: ha megkongatod a felhőharangot a móló mellett, a bálna eljön érted.',
    'Ő visz fel a Felhőkertbe, ahol a csillagliliomok nyílnak. Kapaszkodj a nyeregbe, és ne nézz le. Vagy nézz — az a legszebb.',
  ],
  bellMute: ['A felhőharang néma. Talán csak a pásztor tudja, hogyan kell megszólaltatni.'],
  bellRing: ['Mély, zengő hang száll végig az égen.', 'Messze, a felhők között egy bálna felel.'],
  bellWait: ['A bálna már úton van. Nézd, ott úszik a felhők között!'],
  bellHere: ['A bálna itt vár a móló végén. Csak fel kell szállni.'],
  mount: ['Felkapaszkodsz a bálna hátára, és leülsz a nyeregbe.', 'A bálna halkan dúdol. Indulunk! (Szóköz: leugrás)'],
  sheepFound: ['Bee?', 'A felhőbárány rád néz, aztán boldogan felemelkedik, és hazaszáll a felhők közé.'],
  // ---------------------------------------------------------------- main quest
  wizardIntro: [
    'Á, felébredtél! Jó, mert szükségem van egy fürge lábú segítőre.',
    'Kőmarok kapuja évek óta zárva. Mögötte a Holdkirálynő vára — és vele együtt a mi holdfényünk fele.',
    'A kaput csak a Csillagkulcs nyitja. Az viszont három darabra tört, és szétszóródott az Álomrengetegben.',
    'Egy darab a magasban, egy a mélyben, egy pedig a tudásban lapul. Így szól a régi mondóka, és a mondókák ritkán hazudnak.',
    'Hozd el nekem mind a hármat, és én újra összekovácsolom őket ebben az üstben. Menj — és nézz fel néha az égre is!',
  ],
  wizardHint: [
    'A magasban: a lebegő szigetek csúcsán. Út nem vezet oda — kövesd a medúzákat {islandsDir}.',
    'A mélyben: a hullócsillag kráterében, {craterDir}. A csillag szíve talán megosztja veled egy darabját.',
    'A tudásban: a csillagász tornyában, {towerDir}. Ő mindent tud — kivéve, hová tette a szemüvegét.',
  ],
  wizardForge: [
    'Megvan mind a három? Mutasd! Ó, hogy ragyognak…',
    'Most hunyd be a szemed. Vagy ne — ezt úgyis csak egyszer láthatod.',
    'Íme: a Csillagkulcs. Vidd el Kőmarok kapujához. És köszönj a nevemben a Királynőnek!',
  ],
  wizardAfterKey: ['A kulcs a kapuhoz vezet, a kapu a lépcsőhöz, a lépcső a Királynőhöz. Én csak főzök tovább.'],
  wizardEnd: ['Érzed? A holdfény visszatért. Most már nyugodtan felfedezhetsz mindent, amit még nem láttál.', 'Az erdő tele van titkokkal. Én is csak a felét ismerem. A másik felét elfelejtettem.'],
  keyA: ['A talapzaton egy csillag alakú kristálydarab lebeg.', 'Megszerezted a Csillagkulcs első darabját: a magasban őrzöttet.'],
  keyB: ['A hullócsillag szíve lassít egy dobbanást — mintha rád várna.', 'Egy fényszilánk válik le róla, és a tenyeredbe hull. A Csillagkulcs mélyben őrzött darabja.'],
  astronomerAsk: [
    'Vendég? Ide fel? Hát ez csodálatos! Vagy borzasztó. Még nem döntöttem el.',
    'Csillagkulcs? Persze, nálam van az egyik darabja. Oda is adnám… ha látnám, hol tettem le.',
    'Elhagytam a csillaglencsémet a Kristálymezőn, {crystalDir}. Nélküle még a saját fiókomat sem találom.',
    'Hozd vissza, és a kulcsdarab a tiéd. Becsszóra. Csillagászbecsszóra!',
  ],
  astronomerRemind: ['A lencse a Kristálymezőn van, {crystalDir}. Csillog, mint egy könnycsepp. Mint egy nagyon okos könnycsepp.'],
  astronomerThanks: [
    'A lencsém! Most már látom… minden csillagot. És téged is. Kisebb vagy, mint hittem.',
    'Tessék, a Csillagkulcs darabja, a tudásban őrzött. Mindig is tudtam, hogy nálam van. Csak nem láttam.',
  ],
  lens: ['A kristályok között egy apró, csillogó lencse hever.', 'Megtaláltad a csillagász lencséjét.'],
  gateLocked: ['A kapu zárva. A kulcslyuk alakja egy csillag.', 'Talán egyszer megtalálod hozzá a kulcsot.'],
  gateOpen: [
    'A Csillagkulcs magától a zárba röppen.',
    'A rácsok lassan felemelkednek, és a vár felé fényből szőtt lépcső bomlik ki az éjszakában.',
  ],
  gateAfter: ['A kapu nyitva áll. A fénylépcső a vár felé vezet.'],
  queen: [
    'Hát eljöttél. Tudtam, hogy egyszer valaki kinyitja azt a kaput.',
    'Én vagyok az, akit a kapu mögé zártak — a Holdkirálynő. Nem gonoszság zárt be, csak a feledés.',
    'Ahogy a kulcs elfordult, a holdfény újra szabadon áradhat az erdőbe. Látod? Minden kicsit fényesebb.',
    'De az Álomrengeteg nagyobb, mint gondolnád. A hegyeken túl is vannak álmok, és nem mind ilyen szelídek.',
    'Pihenj most. Fedezd fel, amit még nem láttál. Ha eljön az ideje, újra hívni foglak.',
  ],
  // ---------------------------------------------------------------- side quests
  pottomAsk: [
    'Jaj, jaj, jaj! Fénylő Fülöp elszökött! Ő a csigám. Nagyon gyors csiga. Legalábbis a csigákhoz képest.',
    'Utoljára {snailDir} láttam, egy tavacska felé tartott. Ha megtalálod, hozd vissza, kérlek!',
    'Cserébe elárulom, hol vannak az erdő rejtett helyei. Én mindet ismerem. Szinte mindet.',
  ],
  pottomRemind: ['Fülöp {snailDir} lehet, egy kis tó partján. Világít, nem lehet eltéveszteni. Hacsak nem alszik.'],
  pottomThanks: [
    'FÜLÖP! Hát itt vagy! Megint a tavat nézted, igaz? Mindig a tavat nézi.',
    'Ígéret az ígéret: berajzoltam a térképedre az erdő rejtett helyeit. A szigeteket, a kristályokat, mindent!',
  ],
  snail: ['Egy apró, világító csiga ücsörög a parton, és a vizet nézi.', 'Óvatosan felveszed. Fénylő Fülöp elégedetten pislog.'],
  fisherAsk: [
    'A csillagok ma nem harapnak. Kellene egy holdvirág csalinak. Azt nem tudják megállni.',
    'A vízesés tetején nő egy. Én már öreg vagyok a mászáshoz. Meg lusta is. Főleg lusta.',
    'Hozd el, és megosztom veled a fogásomat!',
  ],
  fisherRemind: ['A holdvirág a vízesés tetején nő. Fehéren világít, mint egy kis hold.'],
  fisherThanks: ['Egy holdvirág! Most aztán harapni fognak! Tessék, ezeket a csillagszilánkokat tegnap fogtam ki. A tiéd.'],
  fisherDeep: [
    'Tudod, miért nem horgászom soha a nyílt tengeren? Mert ott valami más horgászik.',
    'Egy fény úszik a víz alatt, mint egy elveszett lámpás. Aki utánamegy, azt elnyeli a mélység. A Mélység Lámpásának hívják.',
    'Akkora, mint egy sziget. Én csak a hátát láttam egyszer, meg a fényét. Figyeld a tengert a partról, és ha kiemelkedik, gyere, meséld el, milyen!',
  ],
  fisherDeepRemind: ['Csak a partról nézd! Ha fény közeledik feléd a vízben, ússz, ahogy csak bírsz.', 'Néha felbukkan, és a partot bámulja. Mintha keresne valakit.'],
  fisherDeepThanks: [
    'Kiemelkedett? És láttad a fejét is? A fogait? Hát ez… ez hihetetlen!',
    'Hatvan éve horgászom itt, és sosem mertem közel menni. Tessék, ezeket a csillagszilánkokat a hálóm alján találtam. Megérdemled.',
  ],
  flower: ['Egy fehéren derengő virág hajlik a vízesés fölé.', 'Leszakítod a holdvirágot. Halk, csilingelő hangot ad.'],
  stagBless: [
    'A Holdszarvas nem fut el. Lehajtja a fejét, és agancsa hozzáér a botod gömbjéhez.',
    'Hűvös fény fut végig rajtad. Megkaptad a Holdléptek áldását: mostantól gyorsabban futsz.',
  ],
  stagFled: ['A szarvas felkapja a fejét, és eltűnik a fák között. Valahol máshol bukkan majd fel az erdőben — legközelebb lassabban, csendesebben közelíts (C)…'],
  hoodedWait: ['A csuklyások hallgatnak. Az egyikük a köveidre mutat: {read} / {total} rúnakövet olvastál el.'],
  hoodedSpeak: [
    'A három csuklyás egyszerre emeli fel a fejét. A hangjuk olyan, mint a szél a kövek között.',
    '„Elolvastad a köveket. Most már tudod, amit mi tudunk: az erdő emlékezik mindenkire, aki szerette.”',
    '„Fogadd el a Csillagszemet. Ezentúl megérzed a közeli csillagszilánkok hívását.”',
  ],
  hoodedAfter: ['A csuklyások bólintanak. A láng egy pillanatra aranyszínűvé válik.'],
  storyteller: [
    'Mesélő Menyhért vagyok. Mindent tudok, amit érdemes, és sok mindent, amit nem.',
    'A lebegő szigetek {islandsDir} vannak innen. A Kristálymező {crystalDir}. Az Alvó Óriás {giantDir} horkol.',
    'És van egy rom is, {ruinsDir}, ahol a feledés lakik. Oda csak az menjen, aki emlékezni akar.',
  ],
};

// shards needed for each ability
export const ABILITIES = [
  { id: 'doubleJump', need: 8, name: 'Csillagugrás', text: 'Ugrás közben nyomd meg újra a Szóközt: még egyszer elrugaszkodsz a levegőből.' },
  { id: 'glide', need: 20, name: 'Holdsiklás', text: 'Zuhanás közben tartsd lenyomva a Szóközt, és lassan lesiklasz.' },
];
