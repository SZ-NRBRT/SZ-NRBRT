// Texts of the rune stones scattered around the world. Each stone keeps its own text; they are
// written so that any reading order works.
export const LORE = [
  'Mielőtt az első fa gyökeret eresztett, a Hold már álmodott. Ez az erdő az ő álma — ezért világít minden, ami benne él.',
  'A csillagok nem hullanak le. Csak elfáradnak, és leszállnak pihenni. Aki egy szilánkjukat megtalálja, egy kicsit könnyebb lesz tőle.',
  'Kőmarok várát egy óriás keze tartja. Az óriás elaludt, de a keze sosem engedte el, amit egyszer megfogott.',
  'A gombák a föld alatt beszélgetnek. Ha elég csendben maradsz, meghallod, ahogy rólad suttognak.',
  'Aki a Kék Láng körében hazudik, annak az árnyéka ott marad. Az erdőben sok árnyék bolyong gazda nélkül.',
  'A lidércek nem gonoszak. Csak eltévedt fények, akik még mindig keresik azt, aki meggyújtotta őket.',
  'A piramist nem kőművesek rakták. Egyetlen álomból nőtt ki egyetlen éjszaka alatt — és azóta sem ébredt fel.',
  'A csillagkulcs három részre tört, amikor a Holdkirálynő bezárta a kaput. Egy a magasban, egy a mélyben, egy a tudásban maradt.',
  'Az Egyszemű Kő mindent lát, ami az erdőben történik. Ezért hunyja be néha: vannak dolgok, amiket nem akar látni.',
  'Az égi medúzák a tó vizéből születnek. Amikor elég fényt gyűjtöttek, felúsznak az ég felé, és soha többé nem jönnek le.',
  'A Holdszarvas agancsa a legelső holdfényből nőtt. Csak annak mutatkozik meg, aki lassan és csendben jár.',
  'A régi nép romjai ma is állnak. Nem háború döntötte le őket, hanem a feledés: aki elfelejtette a nevét, annak a háza is összedőlt.',
  'Az alvó óriás horkolása tartja egyensúlyban az évszakokat. Ha egyszer felébredne, itt örökké éjszaka maradna. Vagy talán soha többé nem lenne az.',
  'A csillagász azt mondja, a Hold egyik oldalán ablak van. Aki elég sokáig nézi, egyszer látni fogja, ahogy valaki kinéz rajta.',
  'A felhőbárányok gyapjából szövik az álmokat. Egy nyírásból egy egész falu alhat szépeket egy hétig.',
  'Az égi bálnák a legöregebb lények az erdő fölött. Azt mondják, egyikük hátán épült az első csillagvizsgáló.',
  'A hullócsillag szíve még mindig dobog a kráter mélyén. Minden dobbanása egy új szentjánosbogarat gyújt meg valahol az erdőben.',
  'Az út, amelyik egyszer volt, mindig megmarad valahol. A Holdkapuk ezekre az elfeledett utakra nyílnak.',
];
