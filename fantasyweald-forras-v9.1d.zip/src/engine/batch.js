// Instanced props (trees, rocks, mushrooms, plants...) as one batch per model instead of hundreds of chunk meshes.
// Every frame each instance is culled against the view frustum and its own distance picks the near or far
// model, so nothing outside the view is sent to the GPU and trees next to the camera never use the far model.
// Instances are sorted into cells: whole cells are accepted or rejected at once, and only cells that straddle
// the frustum edge or a distance threshold are tested instance by instance. The selected instance data is only
// re-uploaded when the selection actually changed.
import { Mesh } from './scene.js';
import { sphereFrustumClass, sphereInFrustum } from './math.js';

const F = 20; // floats per instance: mat4 + rgba
const CELL = 40; // metres; the cells of every batch share one grid

class Selection {
  constructor(gl, capacity) {
    this.gl = gl;
    this.buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferData(gl.ARRAY_BUFFER, Math.max(1, capacity) * F * 4, gl.DYNAMIC_DRAW);
    this.staging = new Float32Array(Math.max(1, capacity) * F);
    this.ranges = new Int32Array(2 * capacity + 2);
    this.prev = new Int32Array(2 * capacity + 2);
    this.nr = 0;
    this.prevNr = -1;
    this.count = 0;
    this.meshes = [];
  }
  reset() {
    this.nr = 0;
  }
  add(i) {
    const r = this.ranges, k = this.nr * 2;
    if (this.nr > 0 && r[k - 1] === i) r[k - 1] = i + 1;
    else { r[k] = i; r[k + 1] = i + 1; this.nr++; }
  }
  addRange(a, b) {
    const r = this.ranges, k = this.nr * 2;
    if (this.nr > 0 && r[k - 1] === a) r[k - 1] = b;
    else { r[k] = a; r[k + 1] = b; this.nr++; }
  }
  // upload when the selection differs from the last one
  commit(data) {
    const n2 = this.nr * 2, r = this.ranges, p = this.prev;
    let same = this.nr === this.prevNr;
    if (same) for (let k = 0; k < n2; k++) if (r[k] !== p[k]) { same = false; break; }
    if (same) return false;
    p.set(r.subarray(0, n2));
    this.prevNr = this.nr;
    let n = 0;
    const st = this.staging;
    for (let k = 0; k < n2; k += 2) {
      const a = r[k], b = r[k + 1];
      st.set(data.subarray(a * F, b * F), n * F);
      n += b - a;
    }
    this.count = n;
    if (n) {
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, st, 0, n * F);
    }
    for (const m of this.meshes) m.instanceCount = n;
    return true;
  }
}

export class InstanceBatch {
  // data: 20 floats per instance; parts: [{ geo: GpuGeometry, far: GpuGeometry | 'same' | null, mat, shadow, shadowNear }]
  constructor(gl, data, count, parts, { maxDistance = Infinity, shadowDistance = 70, castShadow = true, lodDist = 0, reach = 0, cell = CELL, name = '' } = {}) {
    this.gl = gl;
    this.name = name;
    this.count = count;
    this.maxDistance = maxDistance + reach;
    this.shadowDistance = shadowDistance + reach;
    this.lodDist = lodDist;

    // a local sphere that covers every part (near and far models)
    const geos = [];
    for (const pt of parts) { geos.push(pt.geo); if (pt.far && pt.far !== 'same') geos.push(pt.far); }
    let big = geos[0];
    for (const g of geos) if (g.bounds.radius > big.bounds.radius) big = g;
    const lc = big.bounds.center;
    let lr = 0;
    for (const g of geos) {
      const c = g.bounds.center;
      lr = Math.max(lr, Math.hypot(c[0] - lc[0], c[1] - lc[1], c[2] - lc[2]) + g.bounds.radius);
    }

    // world spheres per instance
    const sph = new Float64Array(count * 4);
    for (let i = 0; i < count; i++) {
      const o = i * F;
      const x = data[o] * lc[0] + data[o + 4] * lc[1] + data[o + 8] * lc[2] + data[o + 12];
      const y = data[o + 1] * lc[0] + data[o + 5] * lc[1] + data[o + 9] * lc[2] + data[o + 13];
      const z = data[o + 2] * lc[0] + data[o + 6] * lc[1] + data[o + 10] * lc[2] + data[o + 14];
      const s = Math.sqrt(Math.max(
        data[o] * data[o] + data[o + 1] * data[o + 1] + data[o + 2] * data[o + 2],
        data[o + 4] * data[o + 4] + data[o + 5] * data[o + 5] + data[o + 6] * data[o + 6],
        data[o + 8] * data[o + 8] + data[o + 9] * data[o + 9] + data[o + 10] * data[o + 10]));
      sph[i * 4] = x; sph[i * 4 + 1] = y; sph[i * 4 + 2] = z; sph[i * 4 + 3] = lr * s;
    }

    // sort instances by cell so every cell is one contiguous range
    const keys = new Map();
    const order = [];
    for (let i = 0; i < count; i++) {
      const ix = Math.floor(sph[i * 4] / cell), iz = Math.floor(sph[i * 4 + 2] / cell);
      const k = ix * 4096 + iz;
      if (!keys.has(k)) { keys.set(k, []); order.push([k, ix, iz]); }
      keys.get(k).push(i);
    }
    this.data = new Float32Array(count * F);
    this.sph = new Float64Array(count * 4);
    const cells = [];
    let n = 0;
    for (const [k, ix, iz] of order) {
      const list = keys.get(k);
      const start = n;
      let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
      for (const i of list) {
        this.data.set(data.subarray(i * F, i * F + F), n * F);
        for (let q = 0; q < 4; q++) this.sph[n * 4 + q] = sph[i * 4 + q];
        const x = sph[i * 4], y = sph[i * 4 + 1], z = sph[i * 4 + 2], r = sph[i * 4 + 3];
        minx = Math.min(minx, x - r); miny = Math.min(miny, y - r); minz = Math.min(minz, z - r);
        maxx = Math.max(maxx, x + r); maxy = Math.max(maxy, y + r); maxz = Math.max(maxz, z + r);
        n++;
      }
      const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, cz = (minz + maxz) / 2;
      let R = 0;
      for (let j = start; j < n; j++) {
        const s = this.sph;
        R = Math.max(R, Math.hypot(s[j * 4] - cx, s[j * 4 + 1] - cy, s[j * 4 + 2] - cz) + s[j * 4 + 3]);
      }
      cells.push({ start, end: n, x: cx, y: cy, z: cz, r: R, ix, iz });
    }
    this.cells = cells;

    // one selection (instance buffer) per view / detail level, shared by all parts
    const needShadow = castShadow && parts.some((pt) => pt.shadow !== false && pt.mat.castShadow);
    const needFar = lodDist > 0 && parts.some((pt) => pt.far);
    this.near = new Selection(gl, count);
    this.far = needFar ? new Selection(gl, count) : null;
    this.shadow = needShadow ? new Selection(gl, count) : null;
    this.mainMeshes = [];
    this.shadowMeshes = [];
    const proxy = (geo, mat, sel, shadowPass) => {
      const m = new Mesh(geo, mat, name || 'batch');
      m.instanceBuffer = sel.buf;
      m.vao = geo.makeVao(sel.buf);
      m.instanceCount = 0;
      m.frustumCulled = false;
      m.castShadow = shadowPass;
      m.batch = this;
      sel.meshes.push(m);
      return m;
    };
    for (const pt of parts) {
      const nm = proxy(pt.geo, pt.mat, this.near, false);
      nm.solidR = pt.solidR; // how far from the axis the model counts as solid (collision grid)
      this.mainMeshes.push(nm);
      if (lodDist > 0 && pt.far) this.mainMeshes.push(proxy(pt.far === 'same' ? pt.geo : pt.far, pt.mat, this.far, false));
      if (this.shadow && pt.shadow !== false && pt.mat.castShadow) {
        // shadows come from the far model when there is one (cheaper), unless the part asks for the near one
        // (trimmed foliage cards: fewer shadow-map pixels to fill)
        const sg = lodDist > 0 && pt.far && pt.far !== 'same' && !pt.shadowNear ? pt.far : pt.geo;
        this.shadowMeshes.push(proxy(sg, pt.mat, this.shadow, true));
      }
    }
  }

  // camera view, one cell: frustum + distance culling and per-instance detail level
  // fc: the cell's frustum class if already known (1 inside, 0 unknown/straddling)
  mainCell(c, px, pz, planes, fc) {
    const near = this.near, far = this.far;
    const maxD = this.maxDistance, lod = this.lodDist > 0 ? this.lodDist : Infinity;
    const cx = c.x - px, cz = c.z - pz;
    const dC = Math.sqrt(cx * cx + cz * cz);
    if (dC - c.r > maxD) return;
    if (!far && dC - c.r > lod) return;
    if (fc === 0) {
      fc = sphereFrustumClass(planes, c.x, c.y, c.z, c.r);
      if (fc < 0) return;
    }
    if (fc > 0 && dC + c.r <= maxD) {
      if (dC + c.r <= lod) { near.addRange(c.start, c.end); return; }
      if (dC - c.r > lod) { far.addRange(c.start, c.end); return; }
    }
    const s = this.sph;
    for (let i = c.start; i < c.end; i++) {
      const o = i * 4, r = s[o + 3];
      const dx = s[o] - px, dz = s[o + 2] - pz;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d - r > maxD) continue;
      if (fc === 0 && !sphereInFrustum(planes, s[o], s[o + 1], s[o + 2], r)) continue;
      if (d <= lod) near.add(i);
      else if (far) far.add(i);
    }
  }

  // light view, one cell: the shadow box around the focus point
  shadowCell(c, px, pz, planes, fc) {
    const sel = this.shadow;
    const maxD = this.shadowDistance;
    const cx = c.x - px, cz = c.z - pz;
    const dC = Math.sqrt(cx * cx + cz * cz);
    if (dC - c.r > maxD) return;
    if (fc === 0) {
      fc = sphereFrustumClass(planes, c.x, c.y, c.z, c.r);
      if (fc < 0) return;
    }
    if (fc > 0 && dC + c.r <= maxD) { sel.addRange(c.start, c.end); return; }
    const s = this.sph;
    for (let i = c.start; i < c.end; i++) {
      const o = i * 4, r = s[o + 3];
      const dx = s[o] - px, dz = s[o + 2] - pz;
      if (Math.sqrt(dx * dx + dz * dz) - r > maxD) continue;
      if (fc === 0 && !sphereInFrustum(planes, s[o], s[o + 1], s[o + 2], r)) continue;
      sel.add(i);
    }
  }
}


// All batches share one grid of cells. Each frame only the grid cells within reach of the camera (or of the
// shadow focus) are visited, each is tested against the frustum once, and only then are the batches' own
// cells inside it looked at.
export class InstanceWorld {
  constructor(batches, cell = CELL) {
    this.batches = batches;
    this.n = batches.length;
    this.cell = cell;
    let ix0 = Infinity, iz0 = Infinity, ix1 = -Infinity, iz1 = -Infinity;
    const all = [];
    for (const b of batches) {
      for (const c of b.cells) {
        all.push({ b, c, ix: c.ix, iz: c.iz });
        ix0 = Math.min(ix0, c.ix); ix1 = Math.max(ix1, c.ix); iz0 = Math.min(iz0, c.iz); iz1 = Math.max(iz1, c.iz);
      }
    }
    this.ix0 = ix0; this.iz0 = iz0;
    this.nx = all.length ? ix1 - ix0 + 1 : 0;
    this.nz = all.length ? iz1 - iz0 + 1 : 0;
    this.grid = new Array(this.nx * this.nz).fill(null);
    for (const e of all) {
      const k = (e.ix - ix0) * this.nz + (e.iz - iz0);
      let g = this.grid[k];
      if (!g) this.grid[k] = g = { entries: [], x: 0, y: 0, z: 0, r: 0, maxD: 0, maxS: 0 };
      g.entries.push(e);
    }
    this.reachMain = 0;
    this.reachShadow = 0;
    for (const g of this.grid) {
      if (!g) continue;
      let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
      for (const { c } of g.entries) {
        minx = Math.min(minx, c.x - c.r); miny = Math.min(miny, c.y - c.r); minz = Math.min(minz, c.z - c.r);
        maxx = Math.max(maxx, c.x + c.r); maxy = Math.max(maxy, c.y + c.r); maxz = Math.max(maxz, c.z + c.r);
      }
      g.x = (minx + maxx) / 2; g.y = (miny + maxy) / 2; g.z = (minz + maxz) / 2;
      for (const { b, c } of g.entries) {
        g.r = Math.max(g.r, Math.hypot(c.x - g.x, c.y - g.y, c.z - g.z) + c.r);
        g.maxD = Math.max(g.maxD, b.maxDistance);
        if (b.shadow) g.maxS = Math.max(g.maxS, b.shadowDistance);
      }
      this.reachMain = Math.max(this.reachMain, g.maxD + g.r);
      this.reachShadow = Math.max(this.reachShadow, g.maxS + g.r);
    }
    this.selectedMain = false;
    this.selectedShadow = false;
  }
  visit(px, pz, reach, planes, shadow) {
    const G = this.cell, nz = this.nz;
    const R = Number.isFinite(reach) ? reach : 1e6;
    const ax = Math.max(0, Math.floor((px - R) / G) - this.ix0), bx = Math.min(this.nx - 1, Math.floor((px + R) / G) - this.ix0);
    const az = Math.max(0, Math.floor((pz - R) / G) - this.iz0), bz = Math.min(nz - 1, Math.floor((pz + R) / G) - this.iz0);
    for (let i = ax; i <= bx; i++) {
      for (let j = az; j <= bz; j++) {
        const g = this.grid[i * nz + j];
        if (!g) continue;
        const dx = g.x - px, dz = g.z - pz;
        if (Math.sqrt(dx * dx + dz * dz) - g.r > (shadow ? g.maxS : g.maxD)) continue;
        const fc = sphereFrustumClass(planes, g.x, g.y, g.z, g.r);
        if (fc < 0) continue;
        const es = g.entries;
        for (let k = 0; k < es.length; k++) {
          const e = es[k];
          if (shadow) { if (e.b.shadow) e.b.shadowCell(e.c, px, pz, planes, fc); }
          else e.b.mainCell(e.c, px, pz, planes, fc);
        }
      }
    }
  }
  selectMain(cam, planes) {
    const B = this.batches;
    for (let i = 0; i < B.length; i++) { B[i].near.reset(); if (B[i].far) B[i].far.reset(); }
    this.visit(cam[0], cam[2], this.reachMain, planes, false);
    for (let i = 0; i < B.length; i++) { B[i].near.commit(B[i].data); if (B[i].far) B[i].far.commit(B[i].data); }
    this.selectedMain = true;
  }
  selectShadow(focus, planes) {
    const B = this.batches;
    for (let i = 0; i < B.length; i++) if (B[i].shadow) B[i].shadow.reset();
    this.visit(focus[0], focus[2], this.reachShadow, planes, true);
    for (let i = 0; i < B.length; i++) if (B[i].shadow) B[i].shadow.commit(B[i].data);
    this.selectedShadow = true;
  }
}
