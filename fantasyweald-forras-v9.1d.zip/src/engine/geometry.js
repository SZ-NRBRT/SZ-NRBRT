// CPU-side geometry builder. Every vertex carries:
//   position(3) normal(3) uv(2) color(4: linear rgb + ao) extra(4: glow, wind, emissiveMask, seed)
import { mat4, vnorm, vcross, vsub, TAU } from './math.js';

export class Geometry {
  constructor() {
    this.p = [];
    this.n = [];
    this.uv = [];
    this.c = [];
    this.e = [];
    this.idx = [];
    this.color = [1, 1, 1, 1];
    this.extra = [0, 0, 0, 0];
  }

  get vertexCount() {
    return this.p.length / 3;
  }

  vert(x, y, z, nx = 0, ny = 1, nz = 0, u = 0, v = 0) {
    const i = this.p.length / 3;
    this.p.push(x, y, z);
    this.n.push(nx, ny, nz);
    this.uv.push(u, v);
    this.c.push(this.color[0], this.color[1], this.color[2], this.color[3]);
    this.e.push(this.extra[0], this.extra[1], this.extra[2], this.extra[3]);
    return i;
  }

  tri(a, b, c) {
    this.idx.push(a, b, c);
    return this;
  }

  quad(a, b, c, d) {
    this.idx.push(a, b, c, a, c, d);
    return this;
  }

  // ---- bulk attribute editing ----
  setColor(rgb, ao) {
    for (let i = 0; i < this.vertexCount; i++) {
      this.c[i * 4] = rgb[0]; this.c[i * 4 + 1] = rgb[1]; this.c[i * 4 + 2] = rgb[2];
      if (ao !== undefined) this.c[i * 4 + 3] = ao;
    }
    return this;
  }
  paint(fn) {
    const p = [0, 0, 0], n = [0, 0, 0];
    for (let i = 0; i < this.vertexCount; i++) {
      p[0] = this.p[i * 3]; p[1] = this.p[i * 3 + 1]; p[2] = this.p[i * 3 + 2];
      n[0] = this.n[i * 3]; n[1] = this.n[i * 3 + 1]; n[2] = this.n[i * 3 + 2];
      const c = fn(p, n, i);
      if (!c) continue;
      this.c[i * 4] = c[0]; this.c[i * 4 + 1] = c[1]; this.c[i * 4 + 2] = c[2];
      if (c.length > 3) this.c[i * 4 + 3] = c[3];
    }
    return this;
  }
  setExtra(e) {
    for (let i = 0; i < this.vertexCount; i++) {
      for (let k = 0; k < 4; k++) if (e[k] !== undefined && e[k] !== null) this.e[i * 4 + k] = e[k];
    }
    return this;
  }
  paintExtra(fn) {
    const p = [0, 0, 0], n = [0, 0, 0];
    for (let i = 0; i < this.vertexCount; i++) {
      p[0] = this.p[i * 3]; p[1] = this.p[i * 3 + 1]; p[2] = this.p[i * 3 + 2];
      n[0] = this.n[i * 3]; n[1] = this.n[i * 3 + 1]; n[2] = this.n[i * 3 + 2];
      const e = fn(p, n, i, this.e.slice(i * 4, i * 4 + 4));
      if (!e) continue;
      for (let k = 0; k < 4; k++) if (e[k] !== undefined && e[k] !== null) this.e[i * 4 + k] = e[k];
    }
    return this;
  }
  // wind weight from height (0 at y0, 1 at y1)
  windByHeight(y0, y1, power = 1.5) {
    return this.paintExtra((p) => {
      const t = Math.max(0, Math.min(1, (p[1] - y0) / (y1 - y0)));
      return [null, Math.pow(t, power)];
    });
  }

  // ---- transforms ----
  applyMatrix(m) {
    const nm = mat4.create();
    mat4.invert(nm, m);
    // normal matrix = transpose(inverse(m)) (upper 3x3)
    for (let i = 0; i < this.vertexCount; i++) {
      const x = this.p[i * 3], y = this.p[i * 3 + 1], z = this.p[i * 3 + 2];
      this.p[i * 3] = m[0] * x + m[4] * y + m[8] * z + m[12];
      this.p[i * 3 + 1] = m[1] * x + m[5] * y + m[9] * z + m[13];
      this.p[i * 3 + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
      const nx = this.n[i * 3], ny = this.n[i * 3 + 1], nz = this.n[i * 3 + 2];
      let ox = nm[0] * nx + nm[1] * ny + nm[2] * nz;
      let oy = nm[4] * nx + nm[5] * ny + nm[6] * nz;
      let oz = nm[8] * nx + nm[9] * ny + nm[10] * nz;
      const l = Math.hypot(ox, oy, oz) || 1;
      this.n[i * 3] = ox / l; this.n[i * 3 + 1] = oy / l; this.n[i * 3 + 2] = oz / l;
    }
    // flip winding if determinant negative
    const det =
      m[0] * (m[5] * m[10] - m[6] * m[9]) - m[4] * (m[1] * m[10] - m[2] * m[9]) + m[8] * (m[1] * m[6] - m[2] * m[5]);
    if (det < 0) {
      for (let i = 0; i < this.idx.length; i += 3) {
        const t = this.idx[i + 1]; this.idx[i + 1] = this.idx[i + 2]; this.idx[i + 2] = t;
      }
    }
    return this;
  }
  translate(x, y, z) {
    for (let i = 0; i < this.vertexCount; i++) {
      this.p[i * 3] += x; this.p[i * 3 + 1] += y; this.p[i * 3 + 2] += z;
    }
    return this;
  }
  scale(sx, sy = sx, sz = sx) {
    const m = mat4.create();
    m[0] = sx; m[5] = sy; m[10] = sz;
    return this.applyMatrix(m);
  }
  rotateX(a) {
    const m = mat4.create(), c = Math.cos(a), s = Math.sin(a);
    m[5] = c; m[6] = s; m[9] = -s; m[10] = c;
    return this.applyMatrix(m);
  }
  rotateY(a) {
    const m = mat4.create(), c = Math.cos(a), s = Math.sin(a);
    m[0] = c; m[2] = -s; m[8] = s; m[10] = c;
    return this.applyMatrix(m);
  }
  rotateZ(a) {
    const m = mat4.create(), c = Math.cos(a), s = Math.sin(a);
    m[0] = c; m[1] = s; m[4] = -s; m[5] = c;
    return this.applyMatrix(m);
  }
  // generic per-vertex position deform (normals recomputed afterwards by caller if desired)
  deform(fn) {
    const p = [0, 0, 0];
    for (let i = 0; i < this.vertexCount; i++) {
      p[0] = this.p[i * 3]; p[1] = this.p[i * 3 + 1]; p[2] = this.p[i * 3 + 2];
      const r = fn(p, i);
      this.p[i * 3] = r[0]; this.p[i * 3 + 1] = r[1]; this.p[i * 3 + 2] = r[2];
    }
    return this;
  }
  // displace along the normal
  displace(fn, recompute = true) {
    const p = [0, 0, 0], n = [0, 0, 0];
    for (let i = 0; i < this.vertexCount; i++) {
      p[0] = this.p[i * 3]; p[1] = this.p[i * 3 + 1]; p[2] = this.p[i * 3 + 2];
      n[0] = this.n[i * 3]; n[1] = this.n[i * 3 + 1]; n[2] = this.n[i * 3 + 2];
      const d = fn(p, n, i);
      this.p[i * 3] += n[0] * d; this.p[i * 3 + 1] += n[1] * d; this.p[i * 3 + 2] += n[2] * d;
    }
    if (recompute) this.computeNormals();
    return this;
  }

  merge(g) {
    const off = this.vertexCount;
    this.p.push(...g.p);
    this.n.push(...g.n);
    this.uv.push(...g.uv);
    this.c.push(...g.c);
    this.e.push(...g.e);
    for (let i = 0; i < g.idx.length; i++) this.idx.push(g.idx[i] + off);
    return this;
  }

  // merge with big arrays without spreading (avoids call stack limits)
  append(g) {
    const off = this.vertexCount;
    for (let i = 0; i < g.p.length; i++) this.p.push(g.p[i]);
    for (let i = 0; i < g.n.length; i++) this.n.push(g.n[i]);
    for (let i = 0; i < g.uv.length; i++) this.uv.push(g.uv[i]);
    for (let i = 0; i < g.c.length; i++) this.c.push(g.c[i]);
    for (let i = 0; i < g.e.length; i++) this.e.push(g.e[i]);
    for (let i = 0; i < g.idx.length; i++) this.idx.push(g.idx[i] + off);
    return this;
  }

  clone() {
    const g = new Geometry();
    g.p = this.p.slice(); g.n = this.n.slice(); g.uv = this.uv.slice();
    g.c = this.c.slice(); g.e = this.e.slice(); g.idx = this.idx.slice();
    return g;
  }

  // (v9) merge vertices that sit at the same place, so a displacement along the normals moves them
  // together (caps and sides of lathes/tubes otherwise tear apart and leave see-through cracks)
  weld(eps = 1e-4) {
    const inv = 1 / eps, map = new Map(), remap = new Int32Array(this.vertexCount), keep = [];
    for (let i = 0; i < this.vertexCount; i++) {
      const k = Math.round(this.p[i * 3] * inv) + ',' + Math.round(this.p[i * 3 + 1] * inv) + ',' + Math.round(this.p[i * 3 + 2] * inv);
      let j = map.get(k);
      if (j === undefined) { j = keep.length; map.set(k, j); keep.push(i); }
      remap[i] = j;
    }
    const pick = (arr, n) => { const o = new Array(keep.length * n); keep.forEach((v, j) => { for (let q = 0; q < n; q++) o[j * n + q] = arr[v * n + q]; }); return o; };
    this.p = pick(this.p, 3); this.n = pick(this.n, 3); this.uv = pick(this.uv, 2); this.c = pick(this.c, 4); this.e = pick(this.e, 4);
    const idx = [];
    for (let t = 0; t < this.idx.length; t += 3) {
      const a = remap[this.idx[t]], b = remap[this.idx[t + 1]], c = remap[this.idx[t + 2]];
      if (a !== b && b !== c && a !== c) idx.push(a, b, c);
    }
    this.idx = idx;
    return this;
  }

  computeNormals() {
    const n = new Float32Array(this.p.length);
    const p = this.p, idx = this.idx;
    for (let i = 0; i < idx.length; i += 3) {
      const a = idx[i] * 3, b = idx[i + 1] * 3, c = idx[i + 2] * 3;
      const e1x = p[b] - p[a], e1y = p[b + 1] - p[a + 1], e1z = p[b + 2] - p[a + 2];
      const e2x = p[c] - p[a], e2y = p[c + 1] - p[a + 1], e2z = p[c + 2] - p[a + 2];
      const nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
      n[a] += nx; n[a + 1] += ny; n[a + 2] += nz;
      n[b] += nx; n[b + 1] += ny; n[b + 2] += nz;
      n[c] += nx; n[c + 1] += ny; n[c + 2] += nz;
    }
    for (let i = 0; i < n.length; i += 3) {
      const l = Math.hypot(n[i], n[i + 1], n[i + 2]) || 1;
      this.n[i] = n[i] / l; this.n[i + 1] = n[i + 1] / l; this.n[i + 2] = n[i + 2] / l;
    }
    return this;
  }

  bounds() {
    let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
    for (let i = 0; i < this.p.length; i += 3) {
      const x = this.p[i], y = this.p[i + 1], z = this.p[i + 2];
      if (x < minx) minx = x; if (y < miny) miny = y; if (z < minz) minz = z;
      if (x > maxx) maxx = x; if (y > maxy) maxy = y; if (z > maxz) maxz = z;
    }
    const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, cz = (minz + maxz) / 2;
    let r = 0;
    for (let i = 0; i < this.p.length; i += 3) {
      const d = Math.hypot(this.p[i] - cx, this.p[i + 1] - cy, this.p[i + 2] - cz);
      if (d > r) r = d;
    }
    return { center: [cx, cy, cz], radius: r, min: [minx, miny, minz], max: [maxx, maxy, maxz] };
  }

  // =============== primitives ===============
  static box(w, h, d, { y0 = -h / 2 } = {}) {
    const g = new Geometry();
    const x = w / 2, z = d / 2, yb = y0, yt = y0 + h;
    const faces = [
      [[x, yb, z], [x, yb, -z], [x, yt, -z], [x, yt, z], [1, 0, 0]],
      [[-x, yb, -z], [-x, yb, z], [-x, yt, z], [-x, yt, -z], [-1, 0, 0]],
      [[-x, yt, z], [x, yt, z], [x, yt, -z], [-x, yt, -z], [0, 1, 0]],
      [[-x, yb, -z], [x, yb, -z], [x, yb, z], [-x, yb, z], [0, -1, 0]],
      [[-x, yb, z], [x, yb, z], [x, yt, z], [-x, yt, z], [0, 0, 1]],
      [[x, yb, -z], [-x, yb, -z], [-x, yt, -z], [x, yt, -z], [0, 0, -1]],
    ];
    for (const f of faces) {
      const nn = f[4];
      const a = g.vert(...f[0], ...nn, 0, 0);
      const b = g.vert(...f[1], ...nn, 1, 0);
      const c = g.vert(...f[2], ...nn, 1, 1);
      const e = g.vert(...f[3], ...nn, 0, 1);
      g.quad(a, b, c, e);
    }
    return g;
  }

  // Subdivided box (smooth-ish after displacement), useful for rocks and stones
  static roundedBox(w, h, d, seg = 4, round = 0.3) {
    const g = Geometry.sphere(1, seg * 4, seg * 2);
    g.deform((p) => {
      // superellipsoid-like mapping from sphere to box
      const k = 1 - round;
      const f = (v) => Math.sign(v) * Math.pow(Math.abs(v), k * 0.8 + 0.2);
      return [f(p[0]) * w / 2, f(p[1]) * h / 2, f(p[2]) * d / 2];
    });
    g.computeNormals();
    return g;
  }

  static sphere(r = 1, ws = 16, hs = 12) {
    const g = new Geometry();
    // poles
    const top = g.vert(0, r, 0, 0, 1, 0, 0.5, 1);
    const rows = [];
    for (let j = 1; j < hs; j++) {
      const v = j / hs, th = v * Math.PI;
      const row = [];
      for (let i = 0; i < ws; i++) {
        const u = i / ws, ph = u * TAU;
        const x = Math.cos(ph) * Math.sin(th), y = Math.cos(th), z = Math.sin(ph) * Math.sin(th);
        row.push(g.vert(x * r, y * r, z * r, x, y, z, u, 1 - v));
      }
      rows.push(row);
    }
    const bot = g.vert(0, -r, 0, 0, -1, 0, 0.5, 0);
    for (let i = 0; i < ws; i++) {
      const i2 = (i + 1) % ws;
      g.tri(top, rows[0][i2], rows[0][i]);
      for (let j = 0; j < rows.length - 1; j++) {
        g.quad(rows[j][i], rows[j][i2], rows[j + 1][i2], rows[j + 1][i]);
      }
      g.tri(bot, rows[rows.length - 1][i], rows[rows.length - 1][i2]);
    }
    return g;
  }

  static icosphere(r = 1, detail = 2) {
    const t = (1 + Math.sqrt(5)) / 2;
    let verts = [
      [-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0],
      [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t],
      [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1],
    ].map(vnorm);
    let faces = [
      [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
      [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
      [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
      [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
    ];
    for (let d = 0; d < detail; d++) {
      const cache = new Map();
      const mid = (a, b) => {
        const k = a < b ? a * 100000 + b : b * 100000 + a;
        if (cache.has(k)) return cache.get(k);
        const va = verts[a], vb = verts[b];
        verts.push(vnorm([(va[0] + vb[0]) / 2, (va[1] + vb[1]) / 2, (va[2] + vb[2]) / 2]));
        cache.set(k, verts.length - 1);
        return verts.length - 1;
      };
      const nf = [];
      for (const [a, b, c] of faces) {
        const ab = mid(a, b), bc = mid(b, c), ca = mid(c, a);
        nf.push([a, ab, ca], [b, bc, ab], [c, ca, bc], [ab, bc, ca]);
      }
      faces = nf;
    }
    const g = new Geometry();
    for (const v of verts) g.vert(v[0] * r, v[1] * r, v[2] * r, v[0], v[1], v[2], 0, 0);
    for (const f of faces) {
      const a = verts[f[0]], b = verts[f[1]], c = verts[f[2]];
      const nrm = vcross(vsub(b, a), vsub(c, a));
      const cen = [a[0] + b[0] + c[0], a[1] + b[1] + c[1], a[2] + b[2] + c[2]];
      if (nrm[0] * cen[0] + nrm[1] * cen[1] + nrm[2] * cen[2] < 0) g.tri(f[0], f[2], f[1]);
      else g.tri(f[0], f[1], f[2]);
    }
    return g;
  }

  // Cylinder / cone from y=0 to y=h
  static cylinder(rTop, rBot, h, radial = 12, hSeg = 1, { capTop = true, capBottom = true } = {}) {
    const prof = [];
    for (let j = 0; j <= hSeg; j++) {
      const t = j / hSeg;
      prof.push([rBot + (rTop - rBot) * t, h * t]);
    }
    return Geometry.lathe(prof, radial, { capTop: capTop && rTop > 0.0001, capBottom: capBottom && rBot > 0.0001 });
  }

  // Lathe around Y. profile: [[radius, y], ...] from bottom to top
  static lathe(profile, radial = 16, { capTop = false, capBottom = false, phase = 0 } = {}) {
    const g = new Geometry();
    const rings = [];
    for (let j = 0; j < profile.length; j++) {
      const [r, y] = profile[j];
      const ring = [];
      if (r < 1e-5) {
        ring.pin = g.vert(0, y, 0, 0, j === 0 ? -1 : 1, 0, 0.5, j / (profile.length - 1));
      } else {
        for (let i = 0; i < radial; i++) {
          const a = (i / radial) * TAU + phase;
          const c = Math.cos(a), s = Math.sin(a);
          ring.push(g.vert(c * r, y, s * r, c, 0, s, i / radial, j / (profile.length - 1)));
        }
      }
      rings.push(ring);
    }
    for (let j = 0; j < rings.length - 1; j++) {
      const A = rings[j], B = rings[j + 1];
      for (let i = 0; i < radial; i++) {
        const i2 = (i + 1) % radial;
        if (A.pin !== undefined && B.pin !== undefined) continue;
        if (A.pin !== undefined) g.tri(A.pin, B[i], B[i2]);
        else if (B.pin !== undefined) g.tri(A[i], B.pin, A[i2]);
        else g.quad(A[i], B[i], B[i2], A[i2]);
      }
    }
    g.computeNormals();
    const capRing = (ring, y, up) => {
      if (ring.pin !== undefined) return;
      const ny = up ? 1 : -1;
      const ci = g.vert(0, y, 0, 0, ny, 0, 0.5, 0.5);
      const idx = ring.map((vi) => g.vert(g.p[vi * 3], g.p[vi * 3 + 1], g.p[vi * 3 + 2], 0, ny, 0, 0, 0));
      for (let i = 0; i < radial; i++) {
        const i2 = (i + 1) % radial;
        if (up) g.tri(ci, idx[i2], idx[i]);
        else g.tri(ci, idx[i], idx[i2]);
      }
    };
    if (capBottom) capRing(rings[0], profile[0][1], false);
    if (capTop) capRing(rings[rings.length - 1], profile[profile.length - 1][1], true);
    return g;
  }

  // Tube along a polyline with per-point radius (parallel transport frames)
  static tube(points, radii, radial = 8, { capStart = false, capEnd = true } = {}) {
    const g = new Geometry();
    const n = points.length;
    const tangents = [];
    for (let i = 0; i < n; i++) {
      const a = points[Math.max(0, i - 1)], b = points[Math.min(n - 1, i + 1)];
      tangents.push(vnorm(vsub(b, a)));
    }
    let normal = Math.abs(tangents[0][1]) < 0.9 ? vnorm(vcross(tangents[0], [0, 1, 0])) : vnorm(vcross(tangents[0], [1, 0, 0]));
    const rings = [];
    for (let i = 0; i < n; i++) {
      const t = tangents[i];
      if (i > 0) {
        // transport normal
        const d = normal[0] * t[0] + normal[1] * t[1] + normal[2] * t[2];
        normal = vnorm([normal[0] - t[0] * d, normal[1] - t[1] * d, normal[2] - t[2] * d]);
      }
      const bin = vcross(t, normal);
      const r = typeof radii === 'function' ? radii(i / (n - 1), i) : radii[i];
      const ring = [];
      for (let k = 0; k < radial; k++) {
        const a = (k / radial) * TAU;
        const c = Math.cos(a), s = Math.sin(a);
        const nx = normal[0] * c + bin[0] * s, ny = normal[1] * c + bin[1] * s, nz = normal[2] * c + bin[2] * s;
        const p = points[i];
        ring.push(g.vert(p[0] + nx * r, p[1] + ny * r, p[2] + nz * r, nx, ny, nz, k / radial, i / (n - 1)));
      }
      rings.push(ring);
    }
    for (let i = 0; i < n - 1; i++) {
      for (let k = 0; k < radial; k++) {
        const k2 = (k + 1) % radial;
        g.quad(rings[i][k], rings[i][k2], rings[i + 1][k2], rings[i + 1][k]);
      }
    }
    g.computeNormals();
    if (capEnd) {
      const p = points[n - 1], t = tangents[n - 1];
      const ci = g.vert(p[0] + t[0] * 0.001, p[1] + t[1] * 0.001, p[2] + t[2] * 0.001, t[0], t[1], t[2]);
      for (let k = 0; k < radial; k++) g.tri(rings[n - 1][k], rings[n - 1][(k + 1) % radial], ci);
    }
    if (capStart) {
      const p = points[0], t = tangents[0];
      const ci = g.vert(p[0], p[1], p[2], -t[0], -t[1], -t[2]);
      for (let k = 0; k < radial; k++) g.tri(rings[0][(k + 1) % radial], rings[0][k], ci);
    }
    return g;
  }

  static plane(w, d, ws = 1, ds = 1) {
    const g = new Geometry();
    for (let j = 0; j <= ds; j++) {
      for (let i = 0; i <= ws; i++) {
        g.vert((i / ws - 0.5) * w, 0, (j / ds - 0.5) * d, 0, 1, 0, i / ws, j / ds);
      }
    }
    for (let j = 0; j < ds; j++) {
      for (let i = 0; i < ws; i++) {
        const a = j * (ws + 1) + i;
        g.quad(a, a + ws + 1, a + ws + 2, a + 1);
      }
    }
    return g;
  }

  // Vertical quad facing +Z, bottom at y=0
  static quadXY(w, h) {
    const g = new Geometry();
    const a = g.vert(-w / 2, 0, 0, 0, 0, 1, 0, 0);
    const b = g.vert(w / 2, 0, 0, 0, 0, 1, 1, 0);
    const c = g.vert(w / 2, h, 0, 0, 0, 1, 1, 1);
    const d = g.vert(-w / 2, h, 0, 0, 0, 1, 0, 1);
    g.quad(a, b, c, d);
    return g;
  }

  static disc(r, seg = 24) {
    const g = new Geometry();
    const c = g.vert(0, 0, 0, 0, 1, 0, 0.5, 0.5);
    const ring = [];
    for (let i = 0; i < seg; i++) {
      const a = (i / seg) * TAU;
      ring.push(g.vert(Math.cos(a) * r, 0, Math.sin(a) * r, 0, 1, 0, 0.5 + Math.cos(a) * 0.5, 0.5 + Math.sin(a) * 0.5));
    }
    for (let i = 0; i < seg; i++) g.tri(c, ring[(i + 1) % seg], ring[i]);
    return g;
  }

  static torus(R, r, radial = 8, tubular = 24, arc = TAU) {
    const pts = [];
    const closed = arc >= TAU - 1e-4;
    const count = closed ? tubular : tubular + 1;
    for (let i = 0; i < count; i++) {
      const a = (i / tubular) * arc;
      pts.push([Math.cos(a) * R, 0, Math.sin(a) * R]);
    }
    if (closed) {
      // build closed ring manually
      const g = new Geometry();
      const rings = [];
      for (let i = 0; i < tubular; i++) {
        const a = (i / tubular) * TAU;
        const cx = Math.cos(a), cz = Math.sin(a);
        const ring = [];
        for (let k = 0; k < radial; k++) {
          const b = (k / radial) * TAU;
          const nx = cx * Math.cos(b), ny = Math.sin(b), nz = cz * Math.cos(b);
          ring.push(g.vert(cx * R + nx * r, ny * r, cz * R + nz * r, nx, ny, nz));
        }
        rings.push(ring);
      }
      for (let i = 0; i < tubular; i++) {
        const i2 = (i + 1) % tubular;
        for (let k = 0; k < radial; k++) {
          const k2 = (k + 1) % radial;
          g.quad(rings[i][k], rings[i][k2], rings[i2][k2], rings[i2][k]);
        }
      }
      return g;
    }
    return Geometry.tube(pts, pts.map(() => r), radial, { capEnd: true, capStart: true });
  }
}

// Catmull-Rom sampling of a polyline of control points -> dense points
export function catmullRom(ctrl, samplesPerSeg = 8) {
  const out = [];
  const n = ctrl.length;
  const P = (i) => ctrl[Math.max(0, Math.min(n - 1, i))];
  for (let i = 0; i < n - 1; i++) {
    const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    for (let s = 0; s < samplesPerSeg; s++) {
      const t = s / samplesPerSeg, t2 = t * t, t3 = t2 * t;
      const pt = [];
      for (let k = 0; k < p1.length; k++) {
        pt.push(
          0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)
        );
      }
      out.push(pt);
    }
  }
  out.push(ctrl[n - 1].slice());
  return out;
}
