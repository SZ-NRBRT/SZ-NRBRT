// Thin WebGL2 helpers: shader programs with reflected uniforms, textures, render targets.

export const ATTR = {
  aPosition: 0,
  aNormal: 1,
  aUv: 2,
  aColor: 3,
  aExtra: 4,
  aI0: 5,
  aI1: 6,
  aI2: 7,
  aI3: 8,
  aIColor: 9,
  aIData: 10,
  aLocal: 11,
};

export function createContext(canvas) {
  const gl = canvas.getContext('webgl2', {
    antialias: false,
    alpha: false,
    depth: true,
    stencil: false,
    powerPreference: 'high-performance',
    preserveDrawingBuffer: false,
  });
  if (!gl) return null;
  gl.getExtension('EXT_color_buffer_float');
  gl.getExtension('EXT_color_buffer_half_float');
  gl.getExtension('OES_texture_float_linear');
  // lets the driver compile shaders on background threads while the loading screen keeps running
  gl.parallelCompile = gl.getExtension('KHR_parallel_shader_compile');
  return gl;
}

// texture units are global GL state: remember what is bound where so redundant binds are skipped
const boundTex = [];
export function resetTextureCache() {
  boundTex.length = 0;
}

function annotate(src) {
  return src
    .split('\n')
    .map((l, i) => `${String(i + 1).padStart(4)}: ${l}`)
    .join('\n');
}

let programId = 0;

// copy v into the cache c; true when anything changed (the GL upload can be skipped otherwise)
function changed(c, v) {
  let d = false;
  for (let i = 0, n = c.length; i < n; i++) {
    const x = v[i];
    if (c[i] !== x) { c[i] = x; d = true; }
  }
  return d;
}
const cache = (n) => new Float64Array(n).fill(NaN);

// A linked shader program. Compilation is started in the constructor but only checked (and the uniforms
// reflected) on first use, so many programs can compile in parallel while the loading screen runs.
// Uniform setters remember the last value and skip redundant uploads.
export class Program {
  constructor(gl, vsSrc, fsSrc, name = 'program') {
    this.gl = gl;
    this.name = name;
    this.id = ++programId;
    this.vsSrc = vsSrc;
    this.fsSrc = fsSrc;
    const vs = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vs, vsSrc);
    gl.compileShader(vs);
    const fs = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fs, fsSrc);
    gl.compileShader(fs);
    const p = gl.createProgram();
    gl.attachShader(p, vs);
    gl.attachShader(p, fs);
    for (const k in ATTR) gl.bindAttribLocation(p, ATTR[k], k);
    gl.linkProgram(p);
    this.vs = vs;
    this.fs = fs;
    this.handle = p;
    this.ready = false;
    this.uniforms = {};
    this.samplers = {};
    this.frameStamp = -1;
    this.lastMat = null;
  }
  // true when the driver has finished compiling (always true without KHR_parallel_shader_compile)
  compiled() {
    if (this.ready) return true;
    const ext = this.gl.parallelCompile;
    return !ext || this.gl.getProgramParameter(this.handle, ext.COMPLETION_STATUS_KHR);
  }
  ensure() {
    if (this.ready) return this;
    const gl = this.gl, p = this.handle;
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      for (const [sh, src] of [[this.vs, this.vsSrc], [this.fs, this.fsSrc]]) {
        if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
          const log = gl.getShaderInfoLog(sh);
          console.error(this.name, log + '\n' + annotate(src));
          throw new Error('Shader compile error: ' + log);
        }
      }
      const log = gl.getProgramInfoLog(p);
      console.error(this.name, log);
      throw new Error('Program link error: ' + log);
    }
    gl.deleteShader(this.vs);
    gl.deleteShader(this.fs);
    this.vs = this.fs = this.vsSrc = this.fsSrc = null;
    this.ready = true;
    let unit = 0;
    const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < n; i++) {
      const info = gl.getActiveUniform(p, i);
      let uname = info.name;
      const isArray = uname.endsWith('[0]');
      if (isArray) uname = uname.slice(0, -3);
      const loc = gl.getUniformLocation(p, info.name);
      const size = info.size || 1;
      let set;
      switch (info.type) {
        case gl.FLOAT:
          if (isArray) { const c = cache(size); set = (v) => { if (changed(c, v)) gl.uniform1fv(loc, v); }; }
          else { let last = NaN; set = (v) => { if (v !== last) { last = v; gl.uniform1f(loc, v); } }; }
          break;
        case gl.FLOAT_VEC2: { const c = cache(2 * size); set = (v) => { if (changed(c, v)) gl.uniform2fv(loc, v); }; break; }
        case gl.FLOAT_VEC3: { const c = cache(3 * size); set = (v) => { if (changed(c, v)) gl.uniform3fv(loc, v); }; break; }
        case gl.FLOAT_VEC4: { const c = cache(4 * size); set = (v) => { if (changed(c, v)) gl.uniform4fv(loc, v); }; break; }
        case gl.FLOAT_MAT3: { const c = cache(9 * size); set = (v) => { if (changed(c, v)) gl.uniformMatrix3fv(loc, false, v); }; break; }
        case gl.FLOAT_MAT4: { const c = cache(16 * size); set = (v) => { if (changed(c, v)) gl.uniformMatrix4fv(loc, false, v); }; break; }
        case gl.INT:
        case gl.BOOL: { let last = NaN; set = (v) => { if (v !== last) { last = v; gl.uniform1i(loc, v); } }; break; }
        case gl.SAMPLER_2D:
        case gl.SAMPLER_2D_SHADOW:
        case gl.SAMPLER_3D:
        case gl.SAMPLER_CUBE: {
          const u = unit++;
          this.samplers[uname] = u;
          gl.useProgram(p);
          gl.uniform1i(loc, u);
          set = null;
          break;
        }
        default: set = () => {};
      }
      if (set) this.uniforms[uname] = set;
    }
    return this;
  }
  use() {
    if (!this.ready) this.ensure();
    this.gl.useProgram(this.handle);
  }
  has(name) {
    return name in this.uniforms || name in this.samplers;
  }
  set(name, v) {
    const s = this.uniforms[name];
    if (s && v !== undefined) s(v);
  }
  tex(name, texture, target) {
    const u = this.samplers[name];
    if (u === undefined || boundTex[u] === texture) return;
    boundTex[u] = texture;
    const gl = this.gl;
    gl.activeTexture(gl.TEXTURE0 + u);
    gl.bindTexture(target || gl.TEXTURE_2D, texture);
  }
}

export function createTexture(gl, opts = {}) {
  const {
    width, height, data = null, source = null,
    internalFormat = gl.RGBA8, format = gl.RGBA, type = gl.UNSIGNED_BYTE,
    min = gl.LINEAR, mag = gl.LINEAR, wrap = gl.CLAMP_TO_EDGE, mipmaps = false, anisotropy = 0,
  } = opts;
  const t = gl.createTexture();
  resetTextureCache();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
  if (source) {
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, format, type, source);
  } else {
    gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, width, height, 0, format, type, data);
  }
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, mipmaps ? gl.LINEAR_MIPMAP_LINEAR : min);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, mag);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
  if (mipmaps) gl.generateMipmap(gl.TEXTURE_2D);
  if (anisotropy) {
    const ext = gl.getExtension('EXT_texture_filter_anisotropic');
    if (ext) gl.texParameterf(gl.TEXTURE_2D, ext.TEXTURE_MAX_ANISOTROPY_EXT, anisotropy);
  }
  return t;
}

// Color render target (optionally with depth). Formats: 'rgba16f' | 'rgba8'
export class RenderTarget {
  constructor(gl, w, h, { format = 'rgba16f', depth = false, depthTexture = false, samples = 0 } = {}) {
    this.gl = gl;
    this.format = format;
    this.depth = depth;
    this.depthTexture = depthTexture;
    this.samples = samples;
    this.resize(w, h);
  }
  _fmt() {
    const gl = this.gl;
    if (this.format === 'rgba16f') return [gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT];
    if (this.format === 'r11') return [gl.R11F_G11F_B10F, gl.RGB, gl.HALF_FLOAT];
    return [gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE];
  }
  dispose() {
    const gl = this.gl;
    if (this.fbo) gl.deleteFramebuffer(this.fbo);
    if (this.tex) gl.deleteTexture(this.tex);
    if (this.depthRb) gl.deleteRenderbuffer(this.depthRb);
    if (this.depthTex) gl.deleteTexture(this.depthTex);
    if (this.msFbo) gl.deleteFramebuffer(this.msFbo);
    if (this.msColor) gl.deleteRenderbuffer(this.msColor);
    if (this.msDepth) gl.deleteRenderbuffer(this.msDepth);
    this.fbo = this.tex = this.depthRb = this.depthTex = this.msFbo = this.msColor = this.msDepth = null;
  }
  resize(w, h) {
    const gl = this.gl;
    this.dispose();
    this.width = w = Math.max(1, w | 0);
    this.height = h = Math.max(1, h | 0);
    const [ifmt, fmt, type] = this._fmt();
    this.tex = createTexture(gl, { width: w, height: h, internalFormat: ifmt, format: fmt, type });
    this.fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.tex, 0);
    if (this.depth && !this.samples) {
      if (this.depthTexture) {
        this.depthTex = createTexture(gl, {
          width: w, height: h, internalFormat: gl.DEPTH_COMPONENT24, format: gl.DEPTH_COMPONENT,
          type: gl.UNSIGNED_INT, min: gl.NEAREST, mag: gl.NEAREST,
        });
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.depthTex, 0);
      } else {
        this.depthRb = gl.createRenderbuffer();
        gl.bindRenderbuffer(gl.RENDERBUFFER, this.depthRb);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.depthRb);
      }
    }
    if (this.samples) {
      this.msFbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.msFbo);
      this.msColor = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, this.msColor);
      gl.renderbufferStorageMultisample(gl.RENDERBUFFER, this.samples, ifmt, w, h);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, this.msColor);
      this.msDepth = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, this.msDepth);
      gl.renderbufferStorageMultisample(gl.RENDERBUFFER, this.samples, gl.DEPTH_COMPONENT24, w, h);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.msDepth);
      const st = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
      if (st !== gl.FRAMEBUFFER_COMPLETE) {
        // fall back to no MSAA
        console.warn('MSAA target incomplete, disabling MSAA');
        gl.deleteFramebuffer(this.msFbo); gl.deleteRenderbuffer(this.msColor); gl.deleteRenderbuffer(this.msDepth);
        this.msFbo = this.msColor = this.msDepth = null;
        this.samples = 0;
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
        this.depthRb = gl.createRenderbuffer();
        gl.bindRenderbuffer(gl.RENDERBUFFER, this.depthRb);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.depthRb);
      }
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  // bind for rendering scene content (MSAA buffer if present)
  bindDraw() {
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.msFbo || this.fbo);
    gl.viewport(0, 0, this.width, this.height);
  }
  // resolve MSAA into the texture
  resolve() {
    if (!this.msFbo) return;
    const gl = this.gl;
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, this.msFbo);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, this.fbo);
    gl.blitFramebuffer(0, 0, this.width, this.height, 0, 0, this.width, this.height, gl.COLOR_BUFFER_BIT, gl.NEAREST);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, null);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, null);
  }
}

export class ShadowTarget {
  constructor(gl, size) {
    this.gl = gl;
    this.size = size;
    this.tex = gl.createTexture();
    resetTextureCache();
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT24, size, size);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    this.fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.tex, 0);
    gl.drawBuffers([gl.NONE]);
    gl.readBuffer(gl.NONE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  dispose() {
    this.gl.deleteTexture(this.tex);
    this.gl.deleteFramebuffer(this.fbo);
  }
}
