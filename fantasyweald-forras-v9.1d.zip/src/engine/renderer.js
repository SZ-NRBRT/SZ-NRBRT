// Forward renderer: shadow pass, HDR scene pass (sky, opaque, transparent), bloom + grade.
import { Program, RenderTarget, ShadowTarget, ATTR } from './gl.js';
import { mat4, frustumPlanes, sphereInFrustum, vnorm } from './math.js';
import { MAX_LIGHTS } from './shaders/common.js';
import { InstanceWorld } from './batch.js';
import { standardVS, standardFS, shadowFS } from './shaders/standard.js';
import { skyVS, skyFS } from './shaders/sky.js';
import { waterVS, waterFS, waterfallVS, waterfallFS } from './shaders/water.js';
import { grassVS, grassFS } from './shaders/grass.js';
import { particleVS, particleFS, butterflyVS, butterflyFS } from './shaders/particles.js';
import { portalVS, portalFS, jellyVS, jellyFS } from './shaders/magic.js';
import { FULLSCREEN_VS, PREFILTER_FS, DOWN_FS, UP_FS, COMPOSITE_FS } from './shaders/post.js';

const LIB = {
  standard: { vs: standardVS, fs: standardFS, shadowFs: shadowFS },
  water: { vs: (d) => waterVS(d), fs: (d) => waterFS(d) },
  waterfall: { vs: () => waterfallVS(), fs: () => waterfallFS() },
  grass: { vs: () => grassVS(), fs: () => grassFS(), shadowFs: null },
  particles: { vs: particleVS, fs: particleFS },
  butterfly: { vs: () => butterflyVS(), fs: () => butterflyFS() },
  portal: { vs: () => portalVS(), fs: () => portalFS() },
  jelly: { vs: () => jellyVS(), fs: () => jellyFS() },
};

const UP = [0, 1, 0];
// copy b into a; true when anything differed
function copyIfChanged(a, b) {
  let d = false;
  for (let i = 0; i < 16; i++) if (a[i] !== b[i]) { a[i] = b[i]; d = true; }
  return d;
}
const byProgramMain = (a, b) => a.material.renderOrder - b.material.renderOrder || a._prog.id - b._prog.id || a.material.id - b.material.id;
const byProgramShadow = (a, b) => a._progS.id - b._progS.id || a.material.id - b.material.id;
const byProgram = (shadow) => (shadow ? byProgramShadow : byProgramMain);
const byDistance = (a, b) => a.material.renderOrder - b.material.renderOrder || b._d - a._d;

export function defaultEnv() {
  return {
    moonDir: vnorm([0.18, 0.52, -0.84]),
    moonColor: [0.62, 0.70, 1.25],
    skyAmb: [0.030, 0.038, 0.10],
    groundAmb: [0.010, 0.010, 0.022],
    rimColor: [0.20, 0.30, 0.85],
    fogColor: [0.016, 0.020, 0.052],
    fogMoonColor: [0.07, 0.08, 0.20],
    fogParams: [0.0095, 0.35, 1.0, 0.012],
    wind: [0.8, 0.6, 1.0, 1.1],
    skyZenith: [0.004, 0.006, 0.022],
    skyHorizon: [0.030, 0.034, 0.090],
    skyGlow: [0.12, 0.14, 0.35],
    eye: 0,
    eyeDir: vnorm([0.0, 0.48, 0.88]),
    starDir: vnorm([-0.62, 0.42, -0.66]),
    cloudCover: 0.55,
    moonSize: 0.075,
    exposure: 1.25,
    bloomStrength: 0.4,
    bloomThreshold: 0.9,
    bloomKnee: 0.5,
    clarity: 0.55,
    vignette: 0.55,
    grain: 0.035,
    saturation: 1.12,
    shadowTint: [0.55, 0.62, 1.15],
    highTint: [0.92, 0.88, 1.08],
    aberration: 0.012,
    dream: 0.25,
    fade: 0,
    pathGlow: [0.10, 0.20, 0.55],
    player: [0, 0, 0, 1.6],
  };
}

export class Renderer {
  constructor(gl, canvas) {
    this.gl = gl;
    this.canvas = canvas;
    this.programs = new Map();
    this.quality = { renderScale: 1, msaa: 4, shadowSize: 2048, shadows: true, bloom: true, clarity: true, maxDpr: 1.5, level: 2 };
    this.frameTextures = {}; // name -> texture (e.g. uHeightTex)
    this.frameUniforms = {}; // extra per-frame uniforms (uTerrainRect ...)
    this.passId = 0;
    this.stats = { draws: 0, tris: 0 };
    this.shadowView = mat4.create();
    this.shadowProj = mat4.create();
    this.shadowVP = mat4.create();
    this.shadowFocus = [0, 0, 0];
    this.shadowExtent = 55;
    this.planes = new Float32Array(24);
    this.lightPos = new Float32Array(MAX_LIGHTS * 4);
    this.lightCol = new Float32Array(MAX_LIGHTS * 4);
    this.lightCount = 0;
    this.state = {};
    // reused every frame (no per-frame garbage)
    this.frame = 0;
    this.meshes = [];
    this.opaque = [];
    this.transparent = [];
    this.casters = [];
    this.shadowPlanes = new Float32Array(24);
    this.shadowParams = new Float32Array(4);
    this.lastVP = new Float32Array(16).fill(NaN);
    this.lastSVP = new Float32Array(16).fill(NaN);
    this.lightBest = [];
    this.lightScore = [];
    this.eyeTmp = [0, 0, 0];

    // fullscreen triangle
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const b = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, b);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(ATTR.aPosition);
    gl.vertexAttribPointer(ATTR.aPosition, 3, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    this.fsVao = vao;

    this.skyProgram = new Program(gl, skyVS(), skyFS(), 'sky');
    this.prefilter = new Program(gl, FULLSCREEN_VS, PREFILTER_FS, 'prefilter');
    this.down = new Program(gl, FULLSCREEN_VS, DOWN_FS, 'down');
    this.up = new Program(gl, FULLSCREEN_VS, UP_FS, 'up');
    this.composite = new Program(gl, FULLSCREEN_VS, COMPOSITE_FS, 'composite');

    // 1x1 depth-compare texture bound when shadows are disabled (sampler2DShadow needs one)
    this.dummyShadow = new ShadowTarget(gl, 1);
    this.sceneRT = null;
    this.bloomMips = [];
    this.bloomUps = [];
    this.shadow = null;
    this.width = 0;
    this.height = 0;
  }

  setQuality(q) {
    Object.assign(this.quality, q);
    this.width = 0; // force resize
    if (this.shadow && this.shadow.size !== this.quality.shadowSize) {
      this.shadow.dispose();
      this.shadow = null;
    }
  }

  resize() {
    const gl = this.gl;
    const dpr = Math.min(window.devicePixelRatio || 1, this.quality.maxDpr);
    const cw = this.canvas.clientWidth || window.innerWidth;
    const ch = this.canvas.clientHeight || window.innerHeight;
    const scale = this.quality.renderScale * (this.dynScale || 1);
    const w = Math.max(1, Math.round(cw * dpr * scale));
    const h = Math.max(1, Math.round(ch * dpr * scale));
    if (w === this.width && h === this.height && this.sceneRT) return false;
    this.width = w;
    this.height = h;
    this.canvas.width = w;
    this.canvas.height = h;
    if (this.sceneRT) this.sceneRT.dispose();
    this.sceneRT = new RenderTarget(gl, w, h, { format: 'rgba16f', depth: true, samples: this.quality.msaa });
    for (const m of this.bloomMips) m.dispose();
    for (const m of this.bloomUps) m.dispose();
    this.bloomMips = [];
    this.bloomUps = [];
    let bw = w >> 1, bh = h >> 1;
    for (let i = 0; i < 6; i++) {
      this.bloomMips.push(new RenderTarget(gl, Math.max(1, bw), Math.max(1, bh), { format: 'rgba16f' }));
      if (i < 5) this.bloomUps.push(new RenderTarget(gl, Math.max(1, bw), Math.max(1, bh), { format: 'rgba16f' }));
      bw >>= 1; bh >>= 1;
    }
    return true;
  }

  getProgram(material, instanced, shadowPass, baked = false, skinned = false) {
    const kind = material.kind;
    let key = kind + '|' + (instanced ? 'I' : '') + (shadowPass ? 'S' : '') + (baked ? 'B' : '') + (skinned ? 'K' : '');
    const defs = Object.keys(material.defines).sort();
    for (const d of defs) if (material.defines[d]) key += '|' + d;
    let p = this.programs.get(key);
    if (p) return p;
    const lib = LIB[kind];
    let defStr = '';
    for (const d of defs) if (material.defines[d]) defStr += `#define ${d} ${material.defines[d] === true ? 1 : material.defines[d]}\n`;
    if (instanced) defStr += '#define INSTANCED 1\n';
    if (shadowPass) defStr += '#define SHADOW_PASS 1\n';
    if (baked) defStr += '#define BAKED 1\n';
    if (skinned) defStr += '#define SKINNED 1\n';
    const fs = shadowPass ? lib.shadowFs(defStr) : lib.fs(defStr);
    p = new Program(this.gl, lib.vs(defStr), fs, key);
    this.programs.set(key, p);
    return p;
  }
  // the program variant a mesh needs, cached on its material (no key strings built per draw)
  progFor(mesh, shadowPass) {
    const mat = mesh.material;
    const inst = !!mesh.instanceBuffer;
    const baked = !!mesh.baked && !shadowPass; // world-space merged meshes cast shadows with the plain variant
    const skinned = !!mesh.skinned;
    const idx = (inst ? 1 : 0) | (shadowPass ? 2 : 0) | (baked ? 4 : 0) | (skinned ? 8 : 0);
    const pc = mat._progs || (mat._progs = []);
    let p = pc[idx];
    if (p === undefined) {
      p = shadowPass && !LIB[mat.kind].shadowFs ? null : this.getProgram(mat, inst, shadowPass, baked, skinned);
      pc[idx] = p;
    }
    return p;
  }
  // start compiling every program the scene will need (the driver may do it in parallel); resolves when done
  async precompile(scene, onProgress = null) {
    const list = new Set();
    const add = (m) => {
      if (!m.material || !m.geometry) return;
      list.add(this.progFor(m, false));
      if (this.quality.shadows !== false && m.castShadow && m.material.castShadow) {
        const s = this.progFor(m, true);
        if (s) list.add(s);
      }
    };
    scene.traverse((n) => add(n));
    for (const b of scene.batches) { for (const m of b.mainMeshes) add(m); for (const m of b.shadowMeshes) add(m); }
    if (scene.statics) for (const b of scene.statics.batches) if (b.mesh) add(b.mesh);
    for (const p of [this.skyProgram, this.prefilter, this.down, this.up, this.composite]) list.add(p);
    const progs = [...list];
    if (this.gl.parallelCompile) {
      const t0 = performance.now();
      for (;;) {
        const done = progs.filter((p) => p.compiled()).length;
        if (onProgress) onProgress(done / progs.length);
        if (done === progs.length || performance.now() - t0 > 20000) break;
        await new Promise((r) => setTimeout(r, 16));
      }
    }
    for (const p of progs) p.ensure();
    return progs.length;
  }

  // ---------------------------------------------------------------- state helpers
  setBlend(mode) {
    if (this.state.blend === mode) return;
    const gl = this.gl;
    this.state.blend = mode;
    if (mode === 'none') gl.disable(gl.BLEND);
    else {
      gl.enable(gl.BLEND);
      if (mode === 'additive') gl.blendFuncSeparate(gl.ONE, gl.ONE, gl.ZERO, gl.ONE);
      else if (mode === 'premult') gl.blendFuncSeparate(gl.ONE, gl.ONE_MINUS_SRC_ALPHA, gl.ZERO, gl.ONE);
      else gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ZERO, gl.ONE);
    }
  }
  setCull(mode) {
    if (this.state.cull === mode) return;
    const gl = this.gl;
    this.state.cull = mode;
    if (mode === 'none') gl.disable(gl.CULL_FACE);
    else {
      gl.enable(gl.CULL_FACE);
      gl.cullFace(mode === 'front' ? gl.FRONT : gl.BACK);
    }
  }
  setDepth(test, write) {
    const gl = this.gl;
    if (this.state.depthTest !== test) {
      this.state.depthTest = test;
      if (test) gl.enable(gl.DEPTH_TEST); else gl.disable(gl.DEPTH_TEST);
    }
    if (this.state.depthWrite !== write) {
      this.state.depthWrite = write;
      gl.depthMask(write);
    }
  }
  setDepthFunc(f) {
    if (this.state.depthFunc === f) return;
    this.state.depthFunc = f;
    this.gl.depthFunc(f);
  }

  // ---------------------------------------------------------------- uniforms
  applyFrame(p, cam, env, time, viewProj) {
    if (p.frameStamp === this.passId) return;
    p.frameStamp = this.passId;
    p.set('uViewProj', viewProj);
    p.set('uView', cam.view);
    p.set('uCamPos', cam.position);
    p.set('uTime', time);
    p.set('uMoonDir', env.moonDir);
    p.set('uMoonColor', env.moonColor);
    p.set('uSkyAmb', env.skyAmb);
    p.set('uGroundAmb', env.groundAmb);
    p.set('uRimColor', env.rimColor);
    p.set('uFogColor', env.fogColor);
    p.set('uFogMoonColor', env.fogMoonColor);
    p.set('uFogParams', env.fogParams);
    p.set('uWind', env.wind);
    p.set('uPlayer', env.player);
    p.set('uQuality', this.quality.level);
    p.set('uShadowMatrix', this.shadowVP);
    p.set('uShadowParams', this.shadowParams);
    p.set('uLightPos', this.lightPos);
    p.set('uLightCol', this.lightCol);
    p.set('uLightCount', this.lightCount);
    p.set('uPathGlow', env.pathGlow);
    // sky uniforms (used by sky & water)
    p.set('uSkyZenith', env.skyZenith);
    p.set('uSkyHorizon', env.skyHorizon);
    p.set('uSkyGlow', env.skyGlow);
    p.set('uEye', env.eye);
    p.set('uEyeDir', env.eyeDir);
    p.set('uStarDir', env.starDir);
    p.set('uCloudCover', env.cloudCover);
    p.set('uMoonSize', env.moonSize);
    for (const k in this.frameUniforms) p.set(k, this.frameUniforms[k]);
  }
  bindFrameTextures(p) {
    p.tex('uShadowMap', this.quality.shadows && this.shadow ? this.shadow.tex : this.dummyShadow.tex);
    for (const k in this.frameTextures) p.tex(k, this.frameTextures[k]);
  }
  applyMaterial(p, m) {
    for (const k in m.uniforms) p.set(k, m.uniforms[k]);
    for (const k in m.textures) p.tex(k, m.textures[k]);
  }

  // ---------------------------------------------------------------- lights
  selectLights(scene, cam, time) {
    // keep the best few candidates in a small sorted list (stable for equal scores, no allocations)
    const cp = cam.position;
    const maxN = Math.min(MAX_LIGHTS, this.quality.lights ?? MAX_LIGHTS);
    const best = this.lightBest, score = this.lightScore;
    let cnt = 0;
    for (const l of scene.lights) {
      if (!l.enabled) continue;
      if (l.node) {
        const w = l.node.world;
        if (!l._ownPos) { l.position = [0, 0, 0]; l._ownPos = true; }
        l.position[0] = w[12]; l.position[1] = w[13]; l.position[2] = w[14];
      }
      const p = l.position;
      const d = Math.hypot(p[0] - cp[0], p[1] - cp[1], p[2] - cp[2]);
      if (d - l.radius > 70) continue;
      if (!sphereInFrustum(this.planes, p[0], p[1], p[2], l.radius)) continue;
      const s = d - l.radius * 0.5 - (l.priority || 0);
      if (cnt === maxN && s >= score[cnt - 1]) continue;
      let j = cnt < maxN ? cnt++ : cnt - 1;
      while (j > 0 && score[j - 1] > s) { score[j] = score[j - 1]; best[j] = best[j - 1]; j--; }
      score[j] = s; best[j] = l;
    }
    const n = cnt;
    const cand = this.lightCand || (this.lightCand = Array.from({ length: MAX_LIGHTS }, () => ({ l: null, score: 0 })));
    for (let i = 0; i < n; i++) { cand[i].l = best[i]; cand[i].score = score[i]; }
    for (let i = 0; i < n; i++) {
      const l = cand[i].l;
      let inten = l.intensity;
      if (l.flicker) {
        const f = Math.sin(time * 13.0 + l.phase) * 0.5 + Math.sin(time * 7.3 + l.phase * 2.1) * 0.35 + Math.sin(time * 23.0 + l.phase * 0.7) * 0.15;
        inten *= 1 + f * l.flicker;
      }
      // fade out lights near the cutoff distance to avoid popping
      const d = cand[i].score;
      const fade = 1 - Math.max(0, Math.min(1, (d - 50) / 20));
      inten *= fade;
      this.lightPos[i * 4] = l.position[0];
      this.lightPos[i * 4 + 1] = l.position[1];
      this.lightPos[i * 4 + 2] = l.position[2];
      this.lightPos[i * 4 + 3] = l.radius;
      this.lightCol[i * 4] = l.color[0] * inten;
      this.lightCol[i * 4 + 1] = l.color[1] * inten;
      this.lightCol[i * 4 + 2] = l.color[2] * inten;
      this.lightCol[i * 4 + 3] = 0;
    }
    this.lightCount = n;
  }

  // ---------------------------------------------------------------- draw
  meshVisible(mesh, planes, cam) {
    if (!mesh.frustumCulled) return true;
    const bw = mesh.boundsWorld;
    if (cam && (mesh.lodMin !== undefined || mesh.lodMax !== undefined)) {
      const x = bw ? bw[0] : mesh.world[12], z = bw ? bw[2] : mesh.world[14];
      const d = Math.hypot(x - cam.position[0], z - cam.position[2]);
      if (mesh.lodMax !== undefined && d > mesh.lodMax) return false;
      if (mesh.lodMin !== undefined && d <= mesh.lodMin) return false;
    }
    if (cam && mesh.maxDistance < Infinity) {
      const x = bw ? bw[0] : mesh.world[12], z = bw ? bw[2] : mesh.world[14];
      const r = bw ? bw[3] : 0;
      if (Math.hypot(x - cam.position[0], z - cam.position[2]) - r > mesh.maxDistance) return false;
    }
    const s = mesh.sphere();
    return sphereInFrustum(planes, s[0], s[1], s[2], s[3]);
  }

  drawList(list, cam, env, time, viewProj, shadowPass) {
    const gl = this.gl;
    const stats = this.stats;
    let cur = null, curMat = null, curVao = null;
    for (let i = 0; i < list.length; i++) {
      const mesh = list[i];
      if (mesh.instanceBuffer && mesh.instanceCount === 0) continue;
      const mat = mesh.material;
      const p = shadowPass ? mesh._progS : mesh._prog;
      if (!p) continue;
      if (p !== cur) {
        p.use();
        cur = p;
        this.applyFrame(p, cam, env, time, viewProj);
        this.bindFrameTextures(p);
        curMat = null;
      }
      if (mat !== curMat) {
        curMat = mat;
        this.applyMaterial(p, mat); // setters skip values the program already has
        if (!shadowPass) {
          this.setBlend(mat.blend);
          this.setDepth(mat.depthTest, mat.depthWrite);
          this.setCull(mat.cull);
        }
      }
      p.set('uModel', mesh.world);
      if (mesh.onBeforeDraw) { mesh.onBeforeDraw(p, this); curVao = null; }
      if (mesh.vao !== curVao) { gl.bindVertexArray(mesh.vao); curVao = mesh.vao; }
      const geo = mesh.geometry;
      const mode = mesh.drawMode === null ? gl.TRIANGLES : mesh.drawMode;
      if (mesh.instanceCount > 0) {
        gl.drawElementsInstanced(mode, geo.count, geo.indexType, 0, mesh.instanceCount);
        stats.tris += (geo.count / 3) * mesh.instanceCount;
      } else {
        gl.drawElements(mode, geo.count, geo.indexType, 0);
        stats.tris += geo.count / 3;
      }
      stats.draws++;
      if (window.__glDebug) {
        const err = gl.getError();
        if (err) console.warn('GL error', err, p.name, mesh.name, shadowPass ? 'shadow' : 'main', Object.keys(p.samplers).map((k) => k + ':' + p.samplers[k]).join(','));
      }
    }
    gl.bindVertexArray(null);
  }

  // light-space matrix for this frame (texel-snapped so shadows don't shimmer)
  updateShadowMatrix(env) {
    const S = this.shadowExtent;
    const c = this.shadowFocus;
    const L = env.moonDir;
    const eye = this.eyeTmp;
    eye[0] = c[0] + L[0] * 200; eye[1] = c[1] + L[1] * 200; eye[2] = c[2] + L[2] * 200;
    mat4.lookAt(this.shadowView, eye, c, UP);
    mat4.ortho(this.shadowProj, -S, S, -S, S, 20, 420);
    mat4.multiply(this.shadowVP, this.shadowProj, this.shadowView);
    const size = this.quality.shadowSize;
    const m = this.shadowVP;
    const ox = m[12] / (m[15] || 1), oy = m[13] / (m[15] || 1);
    const tx = (ox * size) / 2, ty = (oy * size) / 2;
    this.shadowProj[12] += ((Math.round(tx) - tx) * 2) / size;
    this.shadowProj[13] += ((Math.round(ty) - ty) * 2) / size;
    mat4.multiply(this.shadowVP, this.shadowProj, this.shadowView);
    frustumPlanes(this.shadowVP, this.shadowPlanes);
  }

  renderShadows(meshes, batches, cam, env, time) {
    const gl = this.gl;
    if (!this.shadow) this.shadow = new ShadowTarget(gl, this.quality.shadowSize);
    const size = this.quality.shadowSize;
    const c = this.shadowFocus;
    const planes = this.shadowPlanes;
    const casters = this.casters;
    casters.length = 0;
    for (let i = 0; i < meshes.length; i++) {
      const m = meshes[i];
      if (!m.castShadow || !m.material.castShadow) continue;
      if (!this.meshVisible(m, planes)) continue;
      if (m.shadowDistance < Infinity) {
        const b = m.boundsWorld;
        const x = b ? b[0] : m.world[12], z = b ? b[2] : m.world[14];
        const r = b ? b[3] : 0;
        if (Math.hypot(x - c[0], z - c[2]) - r > m.shadowDistance) continue;
      }
      const p = this.progFor(m, true);
      if (!p) continue;
      m._progS = p;
      casters.push(m);
    }
    for (const b of batches) {
      for (const m of b.shadowMeshes) {
        if (m.instanceCount === 0) continue;
        m._progS = this.progFor(m, true);
        casters.push(m);
      }
    }
    casters.sort(byProgram(true));
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadow.fbo);
    gl.viewport(0, 0, size, size);
    this.setDepth(true, true);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    this.setBlend('none');
    this.setCull('none');
    gl.enable(gl.POLYGON_OFFSET_FILL);
    gl.polygonOffset(1.5, 3.0);
    this.passId++;
    this.inShadowPass = true;
    this.drawList(casters, cam, env, time, this.shadowVP, true);
    this.inShadowPass = false;
    gl.disable(gl.POLYGON_OFFSET_FILL);
  }

  render(scene, cam, env, time) {
    const gl = this.gl;
    this.resize();
    this.stats.draws = 0;
    this.stats.tris = 0;
    cam.aspect = this.width / this.height;
    cam.update();
    frustumPlanes(cam.viewProj, this.planes);

    // one walk: world matrices (only where something moved) + visible meshes + static batch upkeep
    const frame = ++this.frame;
    const meshes = this.meshes;
    meshes.length = 0;
    scene.collect(meshes, frame);
    if (scene.statics) scene.statics.finish(meshes, frame);
    this.selectLights(scene, cam, time);

    const shadows = this.quality.shadows;
    const sz = this.quality.shadowSize;
    const sp4 = this.shadowParams;
    sp4[0] = 1 / sz; sp4[1] = 0.00035; sp4[2] = (this.shadowExtent * 2 / sz) * 1.6; sp4[3] = shadows && this.shadow ? 1 : 0;
    if (shadows) this.updateShadowMatrix(env);

    // instanced props: per-instance culling and detail selection, redone only when a view changed
    const batches = scene.batches;
    if (!scene.instances || scene.instances.n !== batches.length) scene.instances = new InstanceWorld(batches);
    const IW = scene.instances;
    const camMoved = copyIfChanged(this.lastVP, cam.viewProj);
    const lightMoved = shadows && copyIfChanged(this.lastSVP, this.shadowVP);
    if (camMoved || !IW.selectedMain) IW.selectMain(cam.position, this.planes);
    if (shadows && (lightMoved || !IW.selectedShadow)) IW.selectShadow(this.shadowFocus, this.shadowPlanes);

    if (shadows) {
      this.renderShadows(meshes, batches, cam, env, time);
      sp4[3] = 1;
    }

    // ---- main pass
    this.passId++;
    const rt = this.sceneRT;
    rt.bindDraw();
    this.setDepth(true, true);
    gl.clearColor(env.fogColor[0], env.fogColor[1], env.fogColor[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    const opaque = this.opaque, transparent = this.transparent;
    opaque.length = 0;
    transparent.length = 0;
    for (let i = 0; i < meshes.length; i++) {
      const m = meshes[i];
      if (!this.meshVisible(m, this.planes, cam)) continue;
      m._prog = this.progFor(m, false);
      if (m.material.transparent) transparent.push(m);
      else opaque.push(m);
    }
    for (const b of batches) {
      for (const m of b.mainMeshes) {
        if (m.instanceCount === 0) continue;
        m._prog = this.progFor(m, false);
        (m.material.transparent ? transparent : opaque).push(m);
      }
    }
    // opaque: grouped by shader and material (fewest state changes); the expensive terrain has renderOrder 1,
    // so it comes last and the depth test skips every terrain pixel already covered by something in front
    opaque.sort(byProgram(false));
    const cp = cam.position;
    for (let i = 0; i < transparent.length; i++) {
      const m = transparent[i];
      const s = m.boundsWorld || null;
      const x = s ? s[0] : m.world[12], y = s ? s[1] : m.world[13], z = s ? s[2] : m.world[14];
      m._d = (x - cp[0]) ** 2 + (y - cp[1]) ** 2 + (z - cp[2]) ** 2;
    }
    transparent.sort(byDistance);

    this.drawList(opaque, cam, env, time, cam.viewProj, false);

    // sky last among the solid things: it only shades the pixels nothing covered (depth still at the far plane)
    this.setDepth(true, false);
    this.setDepthFunc(gl.LEQUAL);
    this.setBlend('none');
    this.setCull('none');
    const sky = this.skyProgram;
    sky.use();
    this.applyFrame(sky, cam, env, time, cam.viewProj);
    sky.set('uInvViewProj', cam.invViewProj);
    gl.bindVertexArray(this.fsVao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindVertexArray(null);
    this.setDepthFunc(gl.LESS);

    this.drawList(transparent, cam, env, time, cam.viewProj, false);
    rt.resolve();
    this.post(env, time);
  }

  fullscreen() {
    const gl = this.gl;
    gl.bindVertexArray(this.fsVao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  post(env, time) {
    const gl = this.gl;
    this.setDepth(false, false);
    this.setBlend('none');
    this.setCull('none');
    const mips = this.bloomMips, ups = this.bloomUps;
    // prefilter
    let p = this.prefilter;
    p.use();
    gl.bindFramebuffer(gl.FRAMEBUFFER, mips[0].fbo);
    gl.viewport(0, 0, mips[0].width, mips[0].height);
    p.tex('uTex', this.sceneRT.tex);
    p.set('uTexel', [1 / this.sceneRT.width, 1 / this.sceneRT.height]);
    p.set('uThreshold', [env.bloomThreshold, env.bloomKnee, 40, 0]);
    this.fullscreen();
    // downsample
    p = this.down;
    p.use();
    for (let i = 1; i < mips.length; i++) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, mips[i].fbo);
      gl.viewport(0, 0, mips[i].width, mips[i].height);
      p.tex('uTex', mips[i - 1].tex);
      p.set('uTexel', [1 / mips[i - 1].width, 1 / mips[i - 1].height]);
      this.fullscreen();
    }
    // upsample
    p = this.up;
    p.use();
    let src = mips[mips.length - 1];
    for (let i = ups.length - 1; i >= 0; i--) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, ups[i].fbo);
      gl.viewport(0, 0, ups[i].width, ups[i].height);
      p.tex('uTex', src.tex);
      p.tex('uBase', mips[i].tex);
      p.set('uTexel', [1 / src.width, 1 / src.height]);
      p.set('uMix', 1.0);
      this.fullscreen();
      src = ups[i];
    }
    // composite
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.width, this.height);
    p = this.composite;
    p.use();
    p.tex('uScene', this.sceneRT.tex);
    p.tex('uBloom', ups[0].tex);
    p.set('uTexel', [1 / this.width, 1 / this.height]);
    p.set('uTime', time);
    p.set('uExposure', env.exposure);
    p.set('uBloomStrength', this.quality.bloom ? env.bloomStrength : 0);
    p.set('uClarity', this.quality.clarity ? env.clarity : 0);
    p.set('uVignette', env.vignette);
    p.set('uGrain', env.grain);
    p.set('uSaturation', env.saturation);
    p.set('uShadowTint', env.shadowTint);
    p.set('uHighTint', env.highTint);
    p.set('uFade', env.fade);
    p.set('uAberration', env.aberration);
    p.set('uDream', this.quality.bloom ? env.dream : 0);
    this.fullscreen();
  }
}
