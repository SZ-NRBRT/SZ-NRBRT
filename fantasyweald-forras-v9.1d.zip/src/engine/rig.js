// Characters are built from many rigid parts (coat, hat, arms, boots...), one mesh each. mergeRig() packs the
// parts that share a material into a single "skinned" mesh: every vertex keeps its part's model-space
// position plus the index of its part, and the vertex shader places it with that part's current world
// matrix. The animation code keeps moving the same nodes as before, the pixels are the same, but a gnome
// costs ~5 draw calls instead of ~13. Hidden parts (or ones that don't cast shadows, in the shadow pass)
// get a zero matrix and vanish.
import { Mesh } from './scene.js';
import { ATTR } from './gl.js';
import { mat4 } from './math.js';
import { MAX_BONES } from './shaders/standard.js';

const ZERO = new Float32Array(16);

function eligible(m) {
  const mat = m.material;
  return !!(m.geometry && m.geometry.cpu && mat && mat.kind === 'standard' && !mat.transparent && !m.instanceBuffer &&
    !m.onBeforeDraw && m.drawMode === null && m.frustumCulled && m.lodMin === undefined && m.lodMax === undefined &&
    !m.boundsWorld && !m.noBatch && !m._skin && !m.skinned);
}

function build(gl, root, members, material) {
  const inv = mat4.invert(mat4.create(), root.world) || mat4.create();
  const rel = mat4.create();
  let nv = 0, ni = 0;
  for (const m of members) { nv += m.geometry.vertexCount; ni += m.geometry.count; }
  const P = new Float32Array(nv * 3), N = new Float32Array(nv * 3), UV = new Float32Array(nv * 2);
  const COL = new Float32Array(nv * 4), EX = new Float32Array(nv * 4), BONE = new Float32Array(nv);
  const big = nv > 65535;
  const IDX = big ? new Uint32Array(ni) : new Uint16Array(ni);
  let vo = 0, io = 0;
  // bounds in the root's space (bind pose), used for culling with the root's transform
  let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
  members.forEach((m, slot) => {
    const g = m.geometry.cpu, n = m.geometry.vertexCount;
    mat4.multiply(rel, inv, m.world);
    P.set(g.p, vo * 3);
    N.set(g.n, vo * 3);
    UV.set(g.uv, vo * 2);
    COL.set(g.c, vo * 4);
    EX.set(g.e, vo * 4);
    BONE.fill(slot, vo, vo + n);
    for (let i = 0; i < n; i++) {
      const x = g.p[i * 3], y = g.p[i * 3 + 1], z = g.p[i * 3 + 2];
      const rx = rel[0] * x + rel[4] * y + rel[8] * z + rel[12];
      const ry = rel[1] * x + rel[5] * y + rel[9] * z + rel[13];
      const rz = rel[2] * x + rel[6] * y + rel[10] * z + rel[14];
      if (rx < minx) minx = rx; if (ry < miny) miny = ry; if (rz < minz) minz = rz;
      if (rx > maxx) maxx = rx; if (ry > maxy) maxy = ry; if (rz > maxz) maxz = rz;
    }
    for (let k = 0; k < g.idx.length; k++) IDX[io + k] = g.idx[k] + vo;
    vo += n;
    io += g.idx.length;
  });
  const mk = (data, target = gl.ARRAY_BUFFER) => {
    const b = gl.createBuffer();
    gl.bindBuffer(target, b);
    gl.bufferData(target, data, gl.STATIC_DRAW);
    return b;
  };
  const buffers = { p: mk(P), n: mk(N), uv: mk(UV), c: mk(COL), e: mk(EX), b: mk(BONE) };
  const vao = gl.createVertexArray();
  gl.bindVertexArray(vao);
  const bind = (buf, loc, size) => {
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
  };
  bind(buffers.p, ATTR.aPosition, 3);
  bind(buffers.n, ATTR.aNormal, 3);
  bind(buffers.uv, ATTR.aUv, 2);
  bind(buffers.c, ATTR.aColor, 4);
  bind(buffers.e, ATTR.aExtra, 4);
  bind(buffers.b, ATTR.aIData, 1);
  buffers.idx = mk(IDX, gl.ELEMENT_ARRAY_BUFFER);
  gl.bindVertexArray(null);
  const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, cz = (minz + maxz) / 2;
  const r = Math.hypot(maxx - cx, maxy - cy, maxz - cz);
  // generous: limbs swing, heads turn, rods cast
  const bounds = { center: [cx, cy, cz], radius: r * 1.5 + 0.5 };
  const gpu = { gl, vertexCount: nv, count: ni, bounds, buffers, indexType: big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT, vao, cpu: null };

  const mesh = new Mesh(gpu, material, 'rig:' + root.name);
  mesh.skinned = true;
  mesh.members = members;
  mesh.castShadow = members.some((m) => m.castShadow);
  mesh.maxDistance = members[0].maxDistance;
  mesh.shadowDistance = members[0].shadowDistance;
  const bones = new Float32Array(MAX_BONES * 16);
  mesh.onBeforeDraw = (p, renderer) => {
    const frame = renderer.frame, shadow = renderer.inShadowPass;
    for (let i = 0; i < members.length; i++) {
      const m = members[i];
      bones.set(m._seen === frame && (!shadow || m.castShadow) ? m.world : ZERO, i * 16);
    }
    p.set('uBones', bones);
  };
  for (const m of members) m._skin = mesh;
  return mesh;
}

// merge the parts of one character (call after it is built and added to the scene)
export function mergeRig(gl, root) {
  root.updateWorld(root.parent ? root.parent.world : null, true);
  const groups = new Map();
  root.traverse((n) => {
    if (n === root || !eligible(n) || !n.visible) return;
    const key = n.material.id + '|' + n.maxDistance + '|' + n.shadowDistance;
    let g = groups.get(key);
    if (!g) groups.set(key, (g = []));
    g.push(n);
  });
  let made = 0, parts = 0;
  for (const list of groups.values()) {
    if (list.length < 2) continue;
    for (let i = 0; i < list.length; i += MAX_BONES) {
      const chunk = list.slice(i, i + MAX_BONES);
      if (chunk.length < 2) continue;
      root.add(build(gl, root, chunk, chunk[0].material));
      made++;
      parts += chunk.length;
    }
  }
  return { meshes: made, parts };
}
