// Scene graph, GPU geometry, materials, cameras.
import { mat4, quat } from './math.js';
import { ATTR } from './gl.js';

export class Node {
  constructor(name = '') {
    this.name = name;
    this.position = [0, 0, 0];
    this.quaternion = [0, 0, 0, 1];
    this.scale = [1, 1, 1];
    this.local = mat4.create();
    this.world = mat4.create();
    this.children = [];
    this.parent = null;
    this.visible = true;
    this.matrixAuto = true;
    // change tracking: the last composed position/rotation/scale and a counter bumped whenever `world` changes
    this._trs = new Float64Array(10).fill(NaN);
    this.worldVersion = 0;
    this.localDirty = false; // set by code that writes `local` directly (with matrixAuto = false)
  }
  // recompose the local matrix only when position/rotation/scale really changed
  _updateLocal() {
    if (!this.matrixAuto) {
      if (!this.localDirty) return false;
      this.localDirty = false;
      return true;
    }
    const p = this.position, q = this.quaternion, s = this.scale, c = this._trs;
    if (p[0] === c[0] && p[1] === c[1] && p[2] === c[2] && q[0] === c[3] && q[1] === c[4] && q[2] === c[5] && q[3] === c[6] && s[0] === c[7] && s[1] === c[8] && s[2] === c[9]) return false;
    c[0] = p[0]; c[1] = p[1]; c[2] = p[2]; c[3] = q[0]; c[4] = q[1]; c[5] = q[2]; c[6] = q[3]; c[7] = s[0]; c[8] = s[1]; c[9] = s[2];
    mat4.compose(this.local, p, q, s);
    return true;
  }
  add(...nodes) {
    for (const n of nodes) {
      if (n.parent) n.parent.remove(n);
      n.parent = this;
      this.children.push(n);
    }
    return this;
  }
  remove(n) {
    const i = this.children.indexOf(n);
    if (i >= 0) this.children.splice(i, 1);
    n.parent = null;
  }
  setPos(x, y, z) {
    this.position[0] = x; this.position[1] = y; this.position[2] = z;
    return this;
  }
  setRotY(a) {
    quat.fromEuler(this.quaternion, 0, a, 0);
    return this;
  }
  setEuler(x, y, z) {
    quat.fromEuler(this.quaternion, x, y, z);
    return this;
  }
  setScale(x, y = x, z = x) {
    this.scale[0] = x; this.scale[1] = y; this.scale[2] = z;
    return this;
  }
  // world matrices are only recomputed along branches where something moved
  updateWorld(parentWorld = null, parentDirty = false) {
    const dirty = this._updateLocal() || parentDirty || this.worldVersion === 0;
    if (dirty) {
      if (parentWorld) mat4.multiply(this.world, parentWorld, this.local);
      else mat4.copy(this.world, this.local);
      this.worldVersion++;
    }
    const ch = this.children;
    for (let i = 0; i < ch.length; i++) ch[i].updateWorld(this.world, dirty);
  }
  // update world matrices and gather the visible meshes in one walk
  collect(out, frame, parentWorld = null, parentDirty = false, visible = true) {
    const dirty = this._updateLocal() || parentDirty || this.worldVersion === 0;
    if (dirty) {
      if (parentWorld) mat4.multiply(this.world, parentWorld, this.local);
      else mat4.copy(this.world, this.local);
      this.worldVersion++;
    }
    const vis = visible && this.visible;
    if (vis && this.material && this.geometry) {
      if (this._skin) this._seen = frame; // drawn by its character's merged mesh
      else {
        const b = this._batch;
        if (b === undefined || b === null) out.push(this);
        else if (b.accept(this, frame)) { /* drawn as part of a merged static batch */ }
        else out.push(this);
      }
    }
    const ch = this.children;
    for (let i = 0; i < ch.length; i++) ch[i].collect(out, frame, this.world, dirty, vis);
  }
  traverse(fn) {
    fn(this);
    for (const c of this.children) c.traverse(fn);
  }
  traverseVisible(fn) {
    if (!this.visible) return;
    fn(this);
    for (const c of this.children) c.traverseVisible(fn);
  }
  worldPosition() {
    return [this.world[12], this.world[13], this.world[14]];
  }
}

// ----------------------------------------------------------------------------
export class GpuGeometry {
  constructor(gl, geo) {
    this.gl = gl;
    const nv = geo.vertexCount;
    this.vertexCount = nv;
    this.count = geo.idx.length;
    this.bounds = geo.bounds();
    const mk = (data, target = gl.ARRAY_BUFFER) => {
      const b = gl.createBuffer();
      gl.bindBuffer(target, b);
      gl.bufferData(target, data, gl.STATIC_DRAW);
      return b;
    };
    const big = nv > 65535;
    // typed copies stay around until the static batcher has merged what it needs (then released)
    this.cpu = {
      p: new Float32Array(geo.p), n: new Float32Array(geo.n), uv: new Float32Array(geo.uv),
      c: new Float32Array(geo.c), e: new Float32Array(geo.e),
      idx: big ? new Uint32Array(geo.idx) : new Uint16Array(geo.idx),
    };
    this.buffers = {
      p: mk(this.cpu.p),
      n: mk(this.cpu.n),
      uv: mk(this.cpu.uv),
      c: mk(this.cpu.c),
      e: mk(this.cpu.e),
    };
    this.indexType = big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
    this.buffers.idx = mk(this.cpu.idx, gl.ELEMENT_ARRAY_BUFFER);
    this.vao = this.makeVao(null);
  }
  makeVao(instanceBuffer) {
    const gl = this.gl;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const bind = (buf, loc, size) => {
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
    };
    bind(this.buffers.p, ATTR.aPosition, 3);
    bind(this.buffers.n, ATTR.aNormal, 3);
    bind(this.buffers.uv, ATTR.aUv, 2);
    bind(this.buffers.c, ATTR.aColor, 4);
    bind(this.buffers.e, ATTR.aExtra, 4);
    if (instanceBuffer) {
      gl.bindBuffer(gl.ARRAY_BUFFER, instanceBuffer);
      const stride = 20 * 4;
      const locs = [ATTR.aI0, ATTR.aI1, ATTR.aI2, ATTR.aI3, ATTR.aIColor];
      for (let k = 0; k < 5; k++) {
        gl.enableVertexAttribArray(locs[k]);
        gl.vertexAttribPointer(locs[k], 4, gl.FLOAT, false, stride, k * 16);
        gl.vertexAttribDivisor(locs[k], 1);
      }
    }
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buffers.idx);
    gl.bindVertexArray(null);
    return vao;
  }
}

// ----------------------------------------------------------------------------
const STANDARD_DEFAULTS = {
  uColor: [1, 1, 1],
  uEmissive: [0, 0, 0],
  uGlowStrength: 1,
  uRough: 0.85,
  uRim: 0.35,
  uWrap: 0.3,
  uGlitter: [9, 0.1, 0.0],
  uGlitterColor: [0.75, 0.85, 1.6],
  uDetail: [1, 0, 0, 0],
  uSpots: [3, 1, 0, 0],
  uSpotColor: [1, 1, 1],
  uSpotGlowPulse: 0,
  uFogScale: 1,
  uAlpha: 1,
  uAmbientBoost: 0,
  uFill: 0,
  uWindParams: [0, 1, 0, 0],
};

let materialId = 0;
export class Material {
  constructor(opts = {}) {
    this.id = ++materialId;
    this.kind = opts.kind || 'standard';
    this.defines = Object.assign({}, opts.defines || {});
    this.uniforms = Object.assign({}, this.kind === 'standard' ? STANDARD_DEFAULTS : {}, opts.uniforms || {});
    this.textures = Object.assign({}, opts.textures || {});
    this.transparent = !!opts.transparent;
    this.blend = opts.blend || (this.transparent ? 'normal' : 'none');
    this.depthWrite = opts.depthWrite !== undefined ? opts.depthWrite : !this.transparent;
    this.depthTest = opts.depthTest !== undefined ? opts.depthTest : true;
    this.cull = opts.cull || 'back';
    this.castShadow = opts.castShadow !== undefined ? opts.castShadow : true;
    this.renderOrder = opts.renderOrder || 0;
  }
  set(name, v) {
    this.uniforms[name] = v;
    return this;
  }
}

// ----------------------------------------------------------------------------
let meshId = 0;
export class Mesh extends Node {
  constructor(gpuGeom, material, name = '') {
    super(name);
    this.id = ++meshId;
    this.geometry = gpuGeom;
    this.material = material;
    this.castShadow = true;
    this.frustumCulled = true;
    this.instanceCount = 0;
    this.instanceBuffer = null;
    this.instanceData = null;
    this.vao = gpuGeom ? gpuGeom.vao : null;
    this.boundsWorld = null; // for instanced batches: [x,y,z,r] in world space
    this.drawMode = null;
    this.shadowDistance = Infinity; // skip in shadow pass when farther than this from shadow center
    this.maxDistance = Infinity;    // skip drawing when farther than this from the camera (xz)
    this.onBeforeDraw = null;
    this._sphere = new Float64Array(4);
    this._sphereV = -1;
  }
  // world-space bounding sphere [x, y, z, r], cached until the world matrix changes
  sphere() {
    if (this.boundsWorld) return this.boundsWorld;
    if (this._sphereV !== this.worldVersion) {
      this._sphereV = this.worldVersion;
      const w = this.world, g = this.geometry, c = g.bounds.center, s = this._sphere;
      s[0] = w[0] * c[0] + w[4] * c[1] + w[8] * c[2] + w[12];
      s[1] = w[1] * c[0] + w[5] * c[1] + w[9] * c[2] + w[13];
      s[2] = w[2] * c[0] + w[6] * c[1] + w[10] * c[2] + w[14];
      s[3] = g.bounds.radius * mat4.maxScale(w);
    }
    return this._sphere;
  }
  // data: Float32Array with 20 floats per instance (mat4 + rgba)
  setInstances(data, count, dynamic = false) {
    const gl = this.geometry.gl;
    if (!this.instanceBuffer) {
      this.instanceBuffer = gl.createBuffer();
      this.vao = this.geometry.makeVao(this.instanceBuffer);
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.instanceBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data, dynamic ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW);
    this.instanceData = data;
    this.instanceCount = count;
    // compute world bounds of the batch (assumes this node sits at identity)
    const b = this.geometry.bounds;
    let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
    let maxR = 0;
    for (let i = 0; i < count; i++) {
      const o = i * 20;
      const s = Math.hypot(data[o], data[o + 1], data[o + 2]);
      const cx = data[o] * b.center[0] + data[o + 4] * b.center[1] + data[o + 8] * b.center[2] + data[o + 12];
      const cy = data[o + 1] * b.center[0] + data[o + 5] * b.center[1] + data[o + 9] * b.center[2] + data[o + 13];
      const cz = data[o + 2] * b.center[0] + data[o + 6] * b.center[1] + data[o + 10] * b.center[2] + data[o + 14];
      const r = b.radius * Math.max(s, Math.hypot(data[o + 4], data[o + 5], data[o + 6]));
      if (cx - r < minx) minx = cx - r; if (cy - r < miny) miny = cy - r; if (cz - r < minz) minz = cz - r;
      if (cx + r > maxx) maxx = cx + r; if (cy + r > maxy) maxy = cy + r; if (cz + r > maxz) maxz = cz + r;
      if (r > maxR) maxR = r;
    }
    if (count > 0) {
      const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, cz = (minz + maxz) / 2;
      this.boundsWorld = [cx, cy, cz, Math.hypot(maxx - cx, maxy - cy, maxz - cz)];
    } else this.boundsWorld = [0, -1000, 0, 0];
    return this;
  }
  updateInstances(count) {
    const gl = this.geometry.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.instanceBuffer);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.instanceData, 0, count * 20);
    this.instanceCount = count;
  }
}

// helper to write one instance into a Float32Array
export function writeInstance(arr, i, m, color = [1, 1, 1, 1]) {
  const o = i * 20;
  for (let k = 0; k < 16; k++) arr[o + k] = m[k];
  arr[o + 16] = color[0]; arr[o + 17] = color[1]; arr[o + 18] = color[2]; arr[o + 19] = color[3] === undefined ? 1 : color[3];
}

// ----------------------------------------------------------------------------
export class Camera {
  constructor(fov = 60, near = 0.1, far = 1000) {
    this.fov = (fov * Math.PI) / 180;
    this.near = near;
    this.far = far;
    this.aspect = 1;
    this.position = [0, 5, 10];
    this.target = [0, 0, 0];
    this.up = [0, 1, 0];
    this.view = mat4.create();
    this.proj = mat4.create();
    this.viewProj = mat4.create();
    this.invViewProj = mat4.create();
  }
  update() {
    mat4.lookAt(this.view, this.position, this.target, this.up);
    mat4.perspective(this.proj, this.fov, this.aspect, this.near, this.far);
    mat4.multiply(this.viewProj, this.proj, this.view);
    mat4.invert(this.invViewProj, this.viewProj);
  }
}

export class Scene extends Node {
  constructor() {
    super('scene');
    this.lights = []; // {position:[x,y,z], color:[r,g,b], intensity, radius, flicker, enabled}
    this.updaters = [];
    this.batches = [];  // InstanceBatch: instanced props culled and LOD-selected per instance every frame
    this.statics = null; // StaticBatcher: static meshes merged per material and area
  }
  addLight(l) {
    const light = Object.assign({ intensity: 1, radius: 8, flicker: 0, enabled: true, phase: Math.random() * 100 }, l);
    this.lights.push(light);
    return light;
  }
}
