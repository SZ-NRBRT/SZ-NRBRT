// Shared GLSL chunks: frame uniforms, noise, lighting, fog, glitter, shadows.

export const MAX_LIGHTS = 12;

export const HEADER = /* glsl */ `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2DShadow;
`;

export const FRAME_UNIFORMS = /* glsl */ `
uniform mat4 uViewProj;
uniform mat4 uView;
uniform vec3 uCamPos;
uniform float uTime;
uniform vec3 uMoonDir;       // direction TO the moon
uniform vec3 uMoonColor;
uniform vec3 uSkyAmb;
uniform vec3 uGroundAmb;
uniform vec3 uRimColor;
uniform vec3 uFogColor;
uniform vec3 uFogMoonColor;
uniform vec4 uFogParams;     // density, heightFalloff, heightBase, heightDensity
uniform vec4 uWind;          // dirX, dirZ, strength, speed
uniform vec4 uPlayer;        // xyz, radius for foliage push
uniform float uQuality;      // 0 low .. 2 high
`;

export const NOISE = /* glsl */ `
float hash11(float p){ p = fract(p * .1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float hash13(vec3 p3){ p3 = fract(p3 * .1031); p3 += dot(p3, p3.zyx + 31.32); return fract((p3.x + p3.y) * p3.z); }
vec2 hash22(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973)); p3 += dot(p3, p3.yzx+33.33); return fract((p3.xx+p3.yz)*p3.zy); }
vec3 hash33(vec3 p3){ p3 = fract(p3 * vec3(.1031, .1030, .0973)); p3 += dot(p3, p3.yxz+33.33); return fract((p3.xxy + p3.yxx)*p3.zyx); }

float vnoise2(vec2 p){
  vec2 i = floor(p), f = fract(p);
  vec2 u = f*f*(3.0-2.0*f);
  return mix(mix(hash12(i), hash12(i+vec2(1,0)), u.x), mix(hash12(i+vec2(0,1)), hash12(i+vec2(1,1)), u.x), u.y);
}
float vnoise3(vec3 p){
  vec3 i = floor(p), f = fract(p);
  vec3 u = f*f*(3.0-2.0*f);
  float a = hash13(i), b = hash13(i+vec3(1,0,0)), c = hash13(i+vec3(0,1,0)), d = hash13(i+vec3(1,1,0));
  float e = hash13(i+vec3(0,0,1)), f1 = hash13(i+vec3(1,0,1)), g = hash13(i+vec3(0,1,1)), h = hash13(i+vec3(1,1,1));
  return mix(mix(mix(a,b,u.x), mix(c,d,u.x), u.y), mix(mix(e,f1,u.x), mix(g,h,u.x), u.y), u.z);
}
float fbm2(vec2 p){ float s = 0.0, a = 0.5; for(int i=0;i<4;i++){ s += a*vnoise2(p); p = p*2.03 + 17.1; a *= 0.5; } return s; }
float fbm3(vec3 p){ float s = 0.0, a = 0.5; for(int i=0;i<3;i++){ s += a*vnoise3(p); p = p*2.07 + 11.3; a *= 0.5; } return s / 0.875; }

// cellular: returns (F1, F2, cellHash)
vec3 voronoi2(vec2 x){
  vec2 n = floor(x), f = fract(x);
  float f1 = 8.0, f2 = 8.0, id = 0.0;
  for(int j=-1;j<=1;j++) for(int i=-1;i<=1;i++){
    vec2 g = vec2(float(i), float(j));
    vec2 o = hash22(n + g);
    vec2 r = g + o - f;
    float d = dot(r, r);
    if(d < f1){ f2 = f1; f1 = d; id = hash12(n + g); } else if(d < f2){ f2 = d; }
  }
  return vec3(sqrt(f1), sqrt(f2), id);
}
`;

export const SHADOW = /* glsl */ `
uniform sampler2DShadow uShadowMap;
uniform mat4 uShadowMatrix;
uniform vec4 uShadowParams; // texelSize, bias, normalOffset, enabled
float getShadow(vec3 P, vec3 N){
  if(uShadowParams.w < 0.5) return 1.0;
  vec3 wp = P + N * uShadowParams.z;
  vec4 sc = uShadowMatrix * vec4(wp, 1.0);
  vec3 s = sc.xyz / sc.w * 0.5 + 0.5;
  if(s.x <= 0.001 || s.x >= 0.999 || s.y <= 0.001 || s.y >= 0.999 || s.z >= 1.0) return 1.0;
  float z = s.z - uShadowParams.y;
  float t = uShadowParams.x;
  float sum = 0.0;
  sum += texture(uShadowMap, vec3(s.xy + vec2(-0.5,-0.5)*t*1.5, z));
  sum += texture(uShadowMap, vec3(s.xy + vec2( 0.5,-0.5)*t*1.5, z));
  sum += texture(uShadowMap, vec3(s.xy + vec2(-0.5, 0.5)*t*1.5, z));
  sum += texture(uShadowMap, vec3(s.xy + vec2( 0.5, 0.5)*t*1.5, z));
  float sh = sum * 0.25;
  // fade shadows at the edge of the shadow volume
  vec2 e = abs(s.xy - 0.5) * 2.0;
  float fade = smoothstep(0.8, 0.98, max(e.x, e.y));
  return mix(sh, 1.0, fade);
}
`;

export const LIGHTS = /* glsl */ `
uniform vec4 uLightPos[${MAX_LIGHTS}];   // xyz, radius
uniform vec4 uLightCol[${MAX_LIGHTS}];   // rgb * intensity, unused
uniform int uLightCount;

// moon dapple: patches of brighter moonlight on the ground
float moonDapple(vec3 P){
  vec2 q = P.xz * 0.045 + vec2(uTime * 0.004, 0.0);
  float n = vnoise2(q) * 0.62 + vnoise2(q * 2.3 + 11.0) * 0.38;
  return smoothstep(0.3, 0.72, n);
}

vec3 shadeLit(vec3 albedo, vec3 N, vec3 V, vec3 P, float rough, float shadow, float ao, float rimAmt, float wrap){
  vec3 L = uMoonDir;
  float ndl = dot(N, L);
  float diff = clamp((ndl + wrap) / (1.0 + wrap), 0.0, 1.0);
  vec3 H = normalize(L + V);
  float ndh = clamp(dot(N, H), 0.0, 1.0);
  rough = clamp(rough, 0.05, 1.0);
  float shin = mix(90.0, 6.0, rough);
  float fres = 0.04 + 0.96 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
  float spec = pow(ndh, shin) * (shin + 8.0) / 40.0 * mix(0.25, 1.0, fres) * (1.0 - rough * 0.85);
  float dap = mix(0.55, 1.35, moonDapple(P));
  vec3 col = uMoonColor * (albedo * diff + spec * 0.6) * shadow * dap;
  // hemisphere ambient
  vec3 amb = mix(uGroundAmb, uSkyAmb, N.y * 0.5 + 0.5);
  col += albedo * amb * ao;
  // cold rim light (the "moonlit edge" look)
  float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0);
  float rimMask = mix(0.35, 1.0, shadow) * (0.55 + 0.45 * max(dot(-V, L) * 0.5 + 0.5, 0.0));
  col += uRimColor * rim * rimAmt * rimMask * ao;
  // point lights
  for(int i = 0; i < ${MAX_LIGHTS}; i++){
    if(i >= uLightCount) break;
    vec3 lv = uLightPos[i].xyz - P;
    float d2 = dot(lv, lv);
    float r = uLightPos[i].w;
    if(d2 > r * r) continue;
    float d = sqrt(d2);
    vec3 l = lv / max(d, 1e-4);
    float x = d / r;
    float att = (1.0 - x * x); att *= att; att /= (1.0 + d2 * 0.35);
    float nl = clamp((dot(N, l) + 0.2) / 1.2, 0.0, 1.0);
    vec3 h2 = normalize(l + V);
    float sp = pow(clamp(dot(N, h2), 0.0, 1.0), shin) * (1.0 - rough * 0.8);
    col += uLightCol[i].rgb * att * (albedo * nl + sp * 0.4);
  }
  return col;
}
`;

export const FOG = /* glsl */ `
vec3 applyFog(vec3 col, vec3 P, float scale){
  vec3 d = P - uCamPos;
  float dist = length(d);
  vec3 dir = d / max(dist, 1e-4);
  float dens = uFogParams.x * scale;
  float f = 1.0 - exp(-pow(dist * dens, 1.6));
  // ground-hugging mist
  float hb = uFogParams.z;
  float hfall = uFogParams.y;
  float h0 = uCamPos.y - hb, h1 = P.y - hb;
  float hmist = exp(-max(min(h0, h1), 0.0) * hfall);
  f = max(f, (1.0 - exp(-dist * uFogParams.w * scale)) * hmist);
  float moonGlow = pow(max(dot(dir, uMoonDir), 0.0), 6.0);
  vec3 fc = mix(uFogColor, uFogMoonColor, moonGlow);
  return mix(col, fc, clamp(f, 0.0, 1.0));
}
`;

export const GLITTER = /* glsl */ `
// Sparkling "stardust" on surfaces. Returns intensity.
float glitterLayer(vec3 P, vec3 N, vec3 V, float density, float coverage, float seed){
  vec3 q = P * density + seed;
  vec3 cell = floor(q);
  vec3 f = fract(q);
  float h = hash13(cell);
  if(h > coverage) return 0.0;
  vec3 o = hash33(cell + 3.7) * 0.6 + 0.2;
  float d = length(f - o);
  float fp = length(fwidth(q));
  float size = 0.11 + 0.5 * fp;
  float dotm = smoothstep(size, size * 0.2, d);
  // each flake has its own orientation -> view dependent flashes
  vec3 fn = normalize(hash33(cell + 9.1) - 0.5 + N * 0.9);
  float flash = pow(max(dot(reflect(-V, fn), uMoonDir), 0.0), 6.0) * 1.3;
  float tw = 0.5 + 0.5 * sin(uTime * (1.5 + h * 7.0) + h * 91.0);
  tw = tw * tw * tw;
  float vis = 1.0 - smoothstep(0.45, 0.95, fp);
  return dotm * (tw * 0.8 + flash) * vis;
}
float glitter(vec3 P, vec3 N, vec3 V, float density, float coverage){
  float g = glitterLayer(P, N, V, density, coverage, 0.0);
  if(uQuality > 0.5) g += glitterLayer(P, N, V, density * 0.33, coverage * 0.6, 17.0) * 0.8;
  return g;
}
`;

// Screen-space derivative bump mapping (Mikkelsen)
export const BUMP = /* glsl */ `
vec3 perturbNormal(vec3 P, vec3 N, float h, float amount){
  vec3 dpx = dFdx(P), dpy = dFdy(P);
  float dhx = dFdx(h) * amount, dhy = dFdy(h) * amount;
  vec3 r1 = cross(dpy, N), r2 = cross(N, dpx);
  float det = dot(dpx, r1);
  if(abs(det) < 1e-8) return N;
  vec3 grad = sign(det) * (dhx * r1 + dhy * r2);
  vec3 r = abs(det) * N - grad;
  float l = length(r);
  if(l < 1e-10) return N;
  return r / l;
}
`;

export const TONEMAP = /* glsl */ `
vec3 acesFilm(vec3 x){
  const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
  return clamp((x*(a*x+b))/(x*(c*x+d)+e), 0.0, 1.0);
}
`;
