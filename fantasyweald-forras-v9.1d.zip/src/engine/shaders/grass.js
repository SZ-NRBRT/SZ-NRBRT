// Instanced grass blades that wrap around the player, placed on the terrain via a height texture.
import { HEADER, FRAME_UNIFORMS, NOISE, SHADOW, LIGHTS, FOG, GLITTER } from './common.js';
import { TERRAIN_SAMPLE } from './water.js';

export function grassVS() {
  return HEADER + FRAME_UNIFORMS + NOISE + TERRAIN_SAMPLE + /* glsl */ `
layout(location=0) in vec3 aPosition;   // x: side (-.5..5), y: t (0..1)
layout(location=5) in vec4 aI0;         // u, v, r1, r2
uniform vec3 uGrassCenter;
uniform float uPatchSize;
uniform float uGrassRadius;
uniform float uBladeHeight;
uniform float uInnerRadius;
uniform float uBladeWidth;
out vec3 vWorld;
out float vT;
out vec3 vNormal;
out float vSeed;
out float vFlower;

void main(){
  vec2 base = uGrassCenter.xz - uPatchSize * 0.5;
  vec2 off = aI0.xy * uPatchSize;
  vec2 wxz = base + mod(off - base, uPatchSize);
  vec4 td = terrainData(wxz);
  float dens = td.g;
  float keep = step(aI0.z, dens);
  float d = length(wxz - uGrassCenter.xz);
  float fade = (1.0 - smoothstep(uGrassRadius * 0.65, uGrassRadius, d)) * smoothstep(uInnerRadius * 0.85, uInnerRadius * 1.15 + 0.01, d);
  float hgt = uBladeHeight * mix(0.45, 1.15, aI0.w) * (0.55 + 0.6 * dens) * keep * fade;
  vSeed = aI0.w;
  vFlower = td.b;
  if(hgt < 0.02){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vWorld = vec3(0.0); vT = 0.0; vNormal = vec3(0.0,1.0,0.0); return; }
  float ang = aI0.z * 43.0 + aI0.w * 17.0;
  vec2 dir = vec2(cos(ang), sin(ang));
  float t = aPosition.y;
  float width = uBladeWidth * (1.0 - t * 0.8) * (0.7 + aI0.w * 0.6);
  vec3 p = vec3(wxz.x, td.r - 0.03, wxz.y);
  p.xz += dir * aPosition.x * width;
  float gust = 0.6 + 0.4 * sin(uTime * 0.4 + wxz.x * 0.05);
  float w = (sin(uTime * 1.9 + dot(wxz, vec2(0.37, 0.23)) + aI0.w * 3.0) * 0.5 + 0.5) * uWind.z * gust;
  vec2 lean = (vec2(sin(ang * 3.1), cos(ang * 2.3)) * (0.25 + 0.35 * fract(aI0.z * 91.0)) + uWind.xy * w * 0.55) * t * t * hgt;
  vec2 pd = wxz - uPlayer.xz;
  float pl = length(pd);
  float push = (1.0 - smoothstep(0.0, 1.1, pl)) * step(abs(td.r - uPlayer.y), 1.5);
  lean += pd / max(pl, 0.01) * push * t * hgt * 1.3;
  p.xz += lean;
  p.y += t * hgt * (1.0 - push * 0.55);
  vWorld = p;
  vT = t;
  vNormal = normalize(vec3(-dir.y, 0.9, dir.x));
  gl_Position = uViewProj * vec4(p, 1.0);
}
`;
}

export function grassFS() {
  return HEADER + FRAME_UNIFORMS + NOISE + SHADOW + LIGHTS + FOG + GLITTER + /* glsl */ `
in vec3 vWorld;
in float vT;
in vec3 vNormal;
in float vSeed;
in float vFlower;
out vec4 fragColor;
uniform vec3 uRootCol;
uniform vec3 uTipCol;
uniform vec3 uTipCol2;
void main(){
  vec3 V = normalize(uCamPos - vWorld);
  vec3 N = normalize(vNormal);
  if(dot(N, V) < 0.0) N = -N;
  N = normalize(mix(N, vec3(0.0, 1.0, 0.0), 0.4));
  vec3 tip = mix(uTipCol, uTipCol2, vSeed);
  vec3 albedo = mix(uRootCol, tip, smoothstep(0.0, 1.0, vT));
  float patchN = vnoise2(vWorld.xz * 0.15);
  albedo *= 0.75 + 0.5 * patchN;
  float shadow = getShadow(vWorld, vec3(0.0, 1.0, 0.0));
  vec3 col = shadeLit(albedo, N, V, vWorld, 0.7, shadow, mix(0.35, 1.0, vT), 0.25, 0.5);
  // moon translucency
  float trans = pow(max(dot(-V, uMoonDir), 0.0), 3.0) * vT;
  col += uMoonColor * tip * trans * 0.6 * shadow;
  col += tip * uSkyAmb * 2.0 * vT;
  // faint bioluminescent tips
  col += tip * vec3(0.35, 0.7, 1.2) * pow(vT, 3.0) * 0.35 * (0.6 + 0.4 * sin(uTime * 1.5 + vSeed * 30.0));
  // dew sparkles on tips
  float g = glitterLayer(vWorld, N, V, 14.0, 0.18, 3.0) * smoothstep(0.5, 1.0, vT);
  col += vec3(0.7, 0.85, 1.6) * g * 0.7;
  col = applyFog(col, vWorld, 1.0);
  fragColor = vec4(col, 1.0);
}
`;
}
