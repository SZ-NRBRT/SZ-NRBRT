// Magical effects: moon-gate portal surface and drifting sky jellyfish.
import { HEADER, FRAME_UNIFORMS, NOISE } from './common.js';

export function portalVS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
layout(location=0) in vec3 aPosition;
layout(location=2) in vec2 aUv;
uniform mat4 uModel;
out vec2 vUv;
out vec3 vWorld;
void main(){
  vec4 wp = uModel * vec4(aPosition, 1.0);
  vUv = aUv;
  vWorld = wp.xyz;
  gl_Position = uViewProj * wp;
}
`;
}

export function portalFS() {
  return HEADER + FRAME_UNIFORMS + NOISE + /* glsl */ `
in vec2 vUv;
in vec3 vWorld;
out vec4 fragColor;
uniform float uPortalActive;
void main(){
  vec2 p = vUv * 2.0 - 1.0;
  float r = length(p);
  float a = atan(p.y, p.x);
  float t = uTime;
  float swirl = fbm2(vec2(a * 1.6 + r * 5.0 - t * 0.9, r * 3.0 - t * 0.6));
  float swirl2 = vnoise2(vec2(a * 4.0 - r * 8.0 + t * 1.3, r * 6.0));
  float ring = smoothstep(0.75, 1.0, r) * smoothstep(1.02, 0.95, r);
  vec3 c1 = vec3(0.30, 0.18, 1.2), c2 = vec3(0.35, 0.9, 1.4);
  vec3 col = mix(c1, c2, swirl) * (0.35 + swirl2 * 0.6);
  col += vec3(0.9, 0.8, 1.6) * ring * 1.4;
  col += vec3(0.6, 0.7, 1.4) * exp(-r * r * 6.0) * 0.8 * (0.7 + 0.3 * sin(t * 2.0));
  // sparkles
  vec2 sp = vec2(a * 6.0, r * 14.0 - t * 2.0);
  float s = step(0.965, hash12(floor(sp))) * smoothstep(0.5, 0.0, length(fract(sp) - 0.5));
  col += vec3(1.2, 1.2, 1.8) * s;
  float edge = smoothstep(1.0, 0.9, r);
  float dist = length(vWorld - uCamPos);
  float fade = exp(-dist * uFogParams.x * 0.6);
  fragColor = vec4(col * edge * fade * (0.55 + 0.45 * uPortalActive) * 0.72, 0.0);
}
`;
}

export function jellyVS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=4) in vec4 aExtra;   // x: 0 bell / 1 tentacle, y: t along tentacle, w: phase
layout(location=5) in vec4 aI0;      // center xyz, seed
layout(location=6) in vec4 aI1;      // radius, height amp, speed, scale
layout(location=9) in vec4 aIColor;
out vec3 vN;
out vec3 vWorld;
out vec4 vCol;
out float vTent;
void main(){
  float s = aI0.w;
  float t = uTime * aI1.z + s * 6.2831;
  vec3 c = aI0.xyz + vec3(cos(t * 0.3) * aI1.x, sin(t * 0.21 + s) * aI1.y, sin(t * 0.27) * aI1.x);
  float pulse = sin(uTime * 1.6 + s * 10.0);
  vec3 p = aPosition;
  if(aExtra.x < 0.5){
    p.xz *= 1.0 + pulse * 0.12;
    p.y *= 1.0 - pulse * 0.1;
  } else {
    float k = aExtra.y;
    p.x += sin(uTime * 2.1 + k * 3.0 + aExtra.w) * 0.18 * k;
    p.z += cos(uTime * 1.7 + k * 2.5 + aExtra.w) * 0.18 * k;
    p.y -= pulse * 0.08 * k;
  }
  vec3 wp = c + p * aI1.w;
  vN = aNormal;
  vWorld = wp;
  vCol = aIColor;
  vTent = aExtra.x;
  gl_Position = uViewProj * vec4(wp, 1.0);
}
`;
}

export function jellyFS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
in vec3 vN;
in vec3 vWorld;
in vec4 vCol;
in float vTent;
out vec4 fragColor;
void main(){
  vec3 V = normalize(uCamPos - vWorld);
  vec3 N = normalize(vN);
  float rim = pow(1.0 - abs(dot(N, V)), 2.0);
  float core = vTent > 0.5 ? 0.35 : 0.18 + rim * 0.9;
  vec3 col = vCol.rgb * vCol.a * core;
  float dist = length(vWorld - uCamPos);
  float fade = exp(-dist * uFogParams.x * 0.5);
  fragColor = vec4(col * fade, 0.0);
}
`;
}
