// GPU-animated particles (fireflies, flames, smoke, motes, sparks) and glowing butterflies.
import { HEADER, FRAME_UNIFORMS, NOISE, FOG } from './common.js';

export function particleVS(defs) {
  return HEADER + defs + FRAME_UNIFORMS + NOISE + /* glsl */ `
layout(location=0) in vec3 aPosition;   // quad corner
layout(location=5) in vec4 aI0;         // base xyz, seed
layout(location=6) in vec4 aI1;         // params (behaviour specific)
layout(location=7) in vec4 aI2;         // size, lifetime, speed, spread
layout(location=9) in vec4 aIColor;     // rgb, intensity
uniform float uTimeOffset;
uniform vec3 uOrigin;                   // for emitters that move (player trail uses absolute positions)
out vec2 vUv;
out vec4 vCol;
out vec3 vWorld;

void main(){
  float t = uTime + uTimeOffset;
  float s = aI0.w;
  vec3 pos = aI0.xyz + uOrigin;
  float size = aI2.x;
  float alpha = 1.0;
  float spread = aI2.w;
#ifdef FIREFLY
  float sp = aI2.z;
  pos += vec3(sin(t * sp * 0.31 + s * 6.0) + sin(t * sp * 0.13 + s * 2.0) * 0.6,
              sin(t * sp * 0.23 + s * 3.0) * 0.5,
              cos(t * sp * 0.27 + s * 4.0) + cos(t * sp * 0.11 + s * 9.0) * 0.6) * spread;
  float bl = sin(t * aI1.x + s * 20.0) * 0.5 + 0.5;
  alpha = mix(0.15, 1.0, smoothstep(0.3, 1.0, bl));
#endif
#ifdef RISE
  float life = fract(t / aI2.y + s);
  vec3 drift = vec3(vnoise2(vec2(s * 17.0, t * 0.3)) - 0.5, 0.0, vnoise2(vec2(s * 31.0, t * 0.3 + 5.0)) - 0.5);
  pos += drift * spread * life * 2.0 + vec3(0.0, life * aI2.z, 0.0);
  pos.xz += uWind.xy * life * life * aI1.w;
  size *= mix(aI1.x, aI1.y, life);
  alpha = smoothstep(0.0, 0.12, life) * (1.0 - smoothstep(aI1.z, 1.0, life));
#endif
#ifdef FALL
  vec3 box = vec3(spread, spread * 0.6, spread);
  vec3 rel = aI0.xyz * box + vec3(sin(t * 0.3 + s * 10.0) * 0.5, -t * aI2.z, cos(t * 0.25 + s * 7.0) * 0.5);
  vec3 c = uCamPos - box * 0.5;
  pos = c + mod(rel - c, box);
  float tw = sin(t * aI1.x + s * 40.0) * 0.5 + 0.5;
  alpha = tw * tw * tw;
  float dd = length(pos - uCamPos);
  alpha *= smoothstep(0.8, 2.5, dd) * (1.0 - smoothstep(spread * 0.3, spread * 0.5, dd));
#endif
#ifdef PETAL
  float ph = aI1.x;
  float lifeP = fract(t * aI2.z / ph + s);
  pos += vec3(sin(t * 1.3 + s * 12.0) * spread + (vnoise2(vec2(s * 7.0, t * 0.4)) - 0.5) * spread * 2.0,
              -lifeP * ph,
              cos(t * 1.1 + s * 9.0) * spread);
  pos.xz += uWind.xy * lifeP * 2.5;
  alpha = smoothstep(0.0, 0.08, lifeP) * (1.0 - smoothstep(0.85, 1.0, lifeP));
  size *= 0.8 + 0.4 * abs(sin(t * 3.0 + s * 20.0));
#endif
#ifdef TRAIL
  float age = t - aI1.x;
  float life = clamp(age / aI2.y, 0.0, 1.0);
  pos += vec3(0.0, life * aI2.z, 0.0) + vec3(sin(s * 30.0), 0.0, cos(s * 30.0)) * life * spread;
  alpha = (1.0 - life) * step(age, aI2.y) * step(0.0, age);
  size *= 1.0 - life * 0.6;
#endif
#ifdef FIRE
  // dragon fire: aI1 = birth time, velocity xyz; aI2 = size, lifetime, rise, spread
  float ageF = t - aI1.x;
  float lifeF = clamp(ageF / aI2.y, 0.0, 1.0);
  pos += aI1.yzw * ageF * (1.0 - lifeF * 0.4) + vec3(0.0, lifeF * lifeF * aI2.z, 0.0)
       + vec3(sin(s * 30.0), cos(s * 17.0) * 0.6, cos(s * 30.0)) * lifeF * spread;
  alpha = (1.0 - lifeF) * step(ageF, aI2.y) * step(0.0, ageF) * smoothstep(0.0, 0.05, lifeF);
  size *= 0.3 + lifeF * 1.7;
#endif
#ifdef SWIRL
  // wind column: streaks spiralling upwards around aI0.xyz (base centre). aI1: size in/out, fade start, radius;
  // aI2: size, lifetime, rise height, turns
  float lifeS = fract(t / aI2.y + s);
  float ang = s * 40.0 + lifeS * aI2.w * 6.2831853;
  float rad = aI1.w * (0.45 + 0.55 * fract(s * 7.31));
  pos += vec3(cos(ang) * rad, lifeS * aI2.z, sin(ang) * rad);
  size *= mix(aI1.x, aI1.y, lifeS);
  alpha = smoothstep(0.0, 0.1, lifeS) * (1.0 - smoothstep(aI1.z, 1.0, lifeS));
#endif
#ifdef METEOR
  // shooting stars: each instance flies now and then somewhere in the sky around the camera.
  // aI1: flight seconds, distance, height, -; aI2: size, period, travel length, streak length
  float per = aI2.y;
  float cyc = floor(t / per + s);
  float ph = fract(t / per + s);
  float u = ph * per / aI1.x;
  float h1 = fract(sin(cyc * 12.9898 + s * 78.233) * 43758.5453);
  float h2 = fract(sin(cyc * 39.3468 + s * 11.135) * 24634.6345);
  float ang0 = h1 * 6.2831853;
  vec3 mdir = normalize(vec3(cos(ang0 + 1.9 + h2), -0.28 - h2 * 0.25, sin(ang0 + 1.9 + h2)));
  pos = vec3(uCamPos.x, 0.0, uCamPos.z) + vec3(cos(ang0) * aI1.y, aI1.z + h2 * 60.0, sin(ang0) * aI1.y) + mdir * u * aI2.z;
  alpha = step(u, 1.0) * sin(clamp(u, 0.0, 1.0) * 3.14159);
#endif
  vec3 right = vec3(uView[0][0], uView[1][0], uView[2][0]);
  vec3 up = vec3(uView[0][1], uView[1][1], uView[2][1]);
#ifdef FLAME
  up = vec3(0.0, 1.0, 0.0);
#endif
#ifdef SWIRL
  up = vec3(0.0, 1.0, 0.0);
  vec3 wp = pos + right * aPosition.x * size * 0.35 + up * aPosition.y * size * 3.2;
#elif defined(METEOR)
  vec3 fwdM = vec3(uView[0][2], uView[1][2], uView[2][2]);
  vec3 sideM = normalize(cross(mdir, fwdM));
  vec3 wp = pos + sideM * aPosition.x * size + mdir * aPosition.y * size * aI2.w;
#else
  vec3 wp = pos + (right * aPosition.x + up * aPosition.y) * size;
#endif
  vUv = aPosition.xy + 0.5;
  vCol = vec4(aIColor.rgb * aIColor.a * 0.72, alpha);
#ifdef FIRE
  // white-hot at the mouth, then orange, then a dull red as it dies
  vCol.rgb *= mix(mix(vec3(1.6, 1.3, 0.9), vec3(1.0, 0.45, 0.12), smoothstep(0.0, 0.35, lifeF)), vec3(0.35, 0.06, 0.03), smoothstep(0.45, 1.0, lifeF));
#endif
  vWorld = wp;
  gl_Position = uViewProj * vec4(wp, 1.0);
}
`;
}

export function particleFS(defs) {
  return HEADER + defs + FRAME_UNIFORMS + NOISE + FOG + /* glsl */ `
in vec2 vUv;
in vec4 vCol;
in vec3 vWorld;
out vec4 fragColor;
void main(){
  vec2 p = vUv * 2.0 - 1.0;
  float d = length(p);
#ifdef SMOKE
  {
    float n = vnoise2(p * 2.0 + vWorld.xz * 0.3 + uTime * 0.2);
    float sa = smoothstep(1.0, 0.2, d) * (0.6 + 0.4 * n) * vCol.a;
    vec3 c = applyFog(vCol.rgb, vWorld, 1.0);
    fragColor = vec4(c, sa * 0.4);
    return;
  }
#endif
  float core = exp(-d * d * 18.0);
  float halo = exp(-d * d * 3.5) * 0.35;
  float a = core + halo;
#ifdef STAR
  a += exp(-abs(p.x) * 25.0 - abs(p.y) * 3.0) * 0.6 + exp(-abs(p.y) * 25.0 - abs(p.x) * 3.0) * 0.6;
#endif
#ifdef FLAME
  float fl = smoothstep(1.0, 0.0, length(vec2(p.x * 1.6, (p.y + 0.3) * 0.8)));
  a = fl * fl;
#endif
#ifdef SWIRL
  a = exp(-p.x * p.x * 9.0) * (1.0 - p.y * p.y) * 0.8;
#endif
#ifdef METEOR
  // bright head in front (+y), a long fading tail behind
  a = exp(-p.x * p.x * 14.0) * pow(clamp(p.y * 0.5 + 0.5, 0.0, 1.0), 2.2) * 1.4 + exp(-(p.x * p.x + (p.y - 0.9) * (p.y - 0.9)) * 60.0) * 2.0;
#endif
#if defined(SWIRL) || defined(METEOR)
  a *= smoothstep(1.0, 0.8, abs(p.x)) * smoothstep(1.0, 0.85, abs(p.y)) * vCol.a;
#else
  a *= smoothstep(1.0, 0.7, d) * vCol.a;
#endif
  float dist = length(vWorld - uCamPos);
#ifdef METEOR
  float fade = 1.0;
#else
  float fade = exp(-dist * uFogParams.x * 0.6);
#endif
  fragColor = vec4(vCol.rgb * a * fade, 0.0);
}
`;
}

export function butterflyVS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
layout(location=0) in vec3 aPosition;   // wing geometry, x<0 left wing, x>0 right wing
layout(location=2) in vec2 aUv;
layout(location=5) in vec4 aI0;         // center xyz, seed
layout(location=6) in vec4 aI1;         // radius, height, speed, flapSpeed
layout(location=9) in vec4 aIColor;
out vec2 vUv;
out vec4 vCol;
out vec3 vWorld;
void main(){
  float s = aI0.w;
  float t = uTime * aI1.z + s * 6.2831;
  float r = aI1.x * (1.0 + 0.35 * sin(t * 1.7 + s * 3.0));
  vec3 c = aI0.xyz + vec3(cos(t) * r, sin(t * 1.3 + s) * aI1.y + aI1.y, sin(t) * r * 0.8);
  vec3 vel = normalize(vec3(-sin(t) * r, cos(t * 1.3 + s) * aI1.y * 1.3, cos(t) * r * 0.8) + 1e-4);
  float flap = sin(uTime * aI1.w + s * 20.0);
  vec3 lp = aPosition;
  float side = sign(lp.x);
  float ang = flap * 1.1 * side;
  float ax = abs(lp.x);
  lp = vec3(side * ax * cos(flap * 1.1), ax * sin(flap * 1.1) , lp.z);
  // orient: forward = vel
  vec3 fwd = normalize(vec3(vel.x, vel.y * 0.3, vel.z));
  vec3 right = normalize(cross(fwd, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, fwd);
  vec3 wp = c + right * lp.x + up * lp.y + fwd * (-lp.z);
  vUv = aUv;
  vCol = aIColor;
  vWorld = wp;
  gl_Position = uViewProj * vec4(wp, 1.0);
}
`;
}

export function butterflyFS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
in vec2 vUv;
in vec4 vCol;
in vec3 vWorld;
out vec4 fragColor;
void main(){
  // wing shape drawn procedurally in uv space (u: 0 root -> 1 tip, v: -1..1 front/back)
  vec2 p = vUv;
  float upper = length((p - vec2(0.55, 0.35)) * vec2(1.0, 1.25));
  float lower = length((p - vec2(0.45, -0.45)) * vec2(1.3, 1.1));
  float wing = min(upper - 0.48, lower - 0.36);
  if(wing > 0.0) discard;
  float vein = abs(sin(atan(p.y, p.x) * 7.0)) ;
  float edge = smoothstep(-0.12, 0.0, wing);
  vec3 c = vCol.rgb * vCol.a * (0.55 + 0.45 * vein) + vCol.rgb * vCol.a * edge * 1.8;
  float dist = length(vWorld - uCamPos);
  float fade = exp(-dist * uFogParams.x * 0.5);
  fragColor = vec4(c * fade, 0.0);
}
`;
}
