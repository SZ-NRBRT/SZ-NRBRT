// Post-processing: bloom chain + final grade (ACES, split-toning, clarity, vignette, grain).
import { HEADER, TONEMAP } from './common.js';

export const FULLSCREEN_VS = HEADER + /* glsl */ `
layout(location=0) in vec3 aPosition;
out vec2 vUv;
void main(){
  vUv = aPosition.xy * 0.5 + 0.5;
  gl_Position = vec4(aPosition.xy, 0.0, 1.0);
}
`;

export const PREFILTER_FS = HEADER + /* glsl */ `
in vec2 vUv;
out vec4 fragColor;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform vec4 uThreshold; // threshold, knee, clamp, -
void main(){
  vec3 c = texture(uTex, vUv + uTexel * vec2(-0.5, -0.5)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(0.5, -0.5)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(-0.5, 0.5)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(0.5, 0.5)).rgb;
  c *= 0.25;
  c = min(c, vec3(uThreshold.z));
  float br = max(c.r, max(c.g, c.b));
  float t = uThreshold.x, k = uThreshold.y;
  float soft = clamp(br - t + k, 0.0, 2.0 * k);
  soft = soft * soft / (4.0 * k + 1e-4);
  float contrib = max(soft, br - t) / max(br, 1e-4);
  fragColor = vec4(c * contrib, 1.0);
}
`;

export const DOWN_FS = HEADER + /* glsl */ `
in vec2 vUv;
out vec4 fragColor;
uniform sampler2D uTex;
uniform vec2 uTexel;
void main(){
  vec3 c = texture(uTex, vUv).rgb * 4.0;
  c += texture(uTex, vUv + uTexel * vec2(-1.0, -1.0)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(1.0, -1.0)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(1.0, 1.0)).rgb;
  fragColor = vec4(c / 8.0, 1.0);
}
`;

export const UP_FS = HEADER + /* glsl */ `
in vec2 vUv;
out vec4 fragColor;
uniform sampler2D uTex;      // lower resolution (to upsample)
uniform sampler2D uBase;     // current level
uniform vec2 uTexel;         // texel of uTex
uniform float uMix;
void main(){
  vec3 c = vec3(0.0);
  c += texture(uTex, vUv + uTexel * vec2(-1.0, -1.0)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(0.0, -1.0)).rgb * 2.0;
  c += texture(uTex, vUv + uTexel * vec2(1.0, -1.0)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(-1.0, 0.0)).rgb * 2.0;
  c += texture(uTex, vUv).rgb * 4.0;
  c += texture(uTex, vUv + uTexel * vec2(1.0, 0.0)).rgb * 2.0;
  c += texture(uTex, vUv + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture(uTex, vUv + uTexel * vec2(0.0, 1.0)).rgb * 2.0;
  c += texture(uTex, vUv + uTexel * vec2(1.0, 1.0)).rgb;
  c /= 16.0;
  vec3 b = texture(uBase, vUv).rgb;
  fragColor = vec4(b + c * uMix, 1.0);
}
`;

export const COMPOSITE_FS = HEADER + TONEMAP + /* glsl */ `
in vec2 vUv;
out vec4 fragColor;
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform vec2 uTexel;
uniform float uTime;
uniform float uExposure;
uniform float uBloomStrength;
uniform float uClarity;
uniform float uVignette;
uniform float uGrain;
uniform float uSaturation;
uniform vec3 uShadowTint;
uniform vec3 uHighTint;
uniform float uFade;         // fade to black (0 = none)
uniform float uAberration;
uniform float uDream;        // extra dreamy haze

float h12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }

void main(){
  vec2 uv = vUv;
  vec2 cc = uv - 0.5;
  float r2 = dot(cc, cc);
  vec3 col;
  if(uAberration > 0.0){
    vec2 off = cc * r2 * uAberration;
    col.r = texture(uScene, uv - off).r;
    col.g = texture(uScene, uv).g;
    col.b = texture(uScene, uv + off).b;
  } else {
    col = texture(uScene, uv).rgb;
  }
  // clarity / local contrast (unsharp mask on luminance)
  if(uClarity > 0.0){
    vec3 blur = texture(uScene, uv + uTexel * vec2(1.5, 0.5)).rgb;
    blur += texture(uScene, uv + uTexel * vec2(-1.5, -0.5)).rgb;
    blur += texture(uScene, uv + uTexel * vec2(0.5, -1.5)).rgb;
    blur += texture(uScene, uv + uTexel * vec2(-0.5, 1.5)).rgb;
    blur *= 0.25;
    float lc = dot(col, vec3(0.2126, 0.7152, 0.0722));
    float lb = dot(blur, vec3(0.2126, 0.7152, 0.0722));
    float detail = (lc - lb) / (lb + 0.05);
    col *= 1.0 + clamp(detail, -0.6, 0.6) * uClarity;
  }
  vec3 bloom = texture(uBloom, uv).rgb;
  col += bloom * uBloomStrength;
  col += bloom * uDream * 0.6;
  col *= uExposure;
  col = acesFilm(col);
  float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = mix(vec3(lum), col, uSaturation);
  // split toning: cold shadows, lavender highlights
  vec3 tint = mix(uShadowTint, uHighTint, smoothstep(0.0, 0.7, lum));
  col = mix(col, col * tint * 1.6, 0.5);
  col = max(col, 0.0);
  // vignette
  float vig = 1.0 - smoothstep(0.25, 0.95, sqrt(r2) * 1.35) * uVignette;
  col *= vig;
  // gamma
  col = pow(col, vec3(1.0 / 2.2));
  // grain
  float g = h12(uv * vec2(1920.0, 1080.0) + fract(uTime * 7.13) * 100.0) - 0.5;
  col += g * uGrain;
  col *= 1.0 - uFade;
  fragColor = vec4(col, 1.0);
}
`;
