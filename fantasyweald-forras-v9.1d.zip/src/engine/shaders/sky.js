// Night sky: gradient, stars, milky way, moon with craters, moonlit clouds,
// a flaring star and (in dream areas) giant eyes opening in the sky.
import { HEADER, FRAME_UNIFORMS, NOISE } from './common.js';

export const SKY_UNIFORMS = /* glsl */ `
uniform vec3 uSkyZenith;
uniform vec3 uSkyHorizon;
uniform vec3 uSkyGlow;
uniform float uEye;          // 0..1 opening of sky eyes
uniform vec3 uEyeDir;
uniform vec3 uStarDir;
uniform float uCloudCover;
uniform float uMoonSize;
`;

export const SKY_FN = /* glsl */ `
vec2 dirToLocal(vec3 dir, vec3 center){
  vec3 right = normalize(cross(center, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, center);
  float d = max(dot(dir, center), 1e-3);
  return vec2(dot(dir, right), dot(dir, up)) / d;
}

float cloudDensity(vec3 dir, out float thick){
  vec2 p = dir.xz / (max(dir.y, 0.0) + 0.14);
  vec2 q = p * 0.55 + vec2(uTime * 0.012, uTime * 0.004);
  vec2 w = vec2(fbm2(q * 0.7 + 3.1), fbm2(q * 0.7 - 5.7));
  float n = fbm2(q + w * 1.6);
  float n2 = vnoise2(q * 4.0 + w * 3.0);
  float d = smoothstep(0.52 - uCloudCover * 0.25, 0.92 - uCloudCover * 0.2, n * 0.85 + n2 * 0.2);
  thick = n;
  float horizon = smoothstep(-0.02, 0.18, dir.y);
  return d * horizon;
}

vec4 eyeShape(vec2 uv, float open, float t, float seed){
  // uv in eye space: x -1..1 corner to corner
  float x = uv.x, y = uv.y;
  if(abs(x) > 1.15 || abs(y) > 0.9) return vec4(0.0);
  float ex = clamp(x, -1.0, 1.0);
  float upper = 0.52 * pow(1.0 - ex * ex, 0.8) * open;
  float lower = 0.38 * pow(1.0 - ex * ex, 0.9) * open;
  float edgeU = y - upper, edgeL = -y - lower;
  float inside = smoothstep(0.015, -0.015, max(edgeU, edgeL));
  // iris looks around slowly
  vec2 look = vec2(sin(t * 0.21 + seed) * 0.18, cos(t * 0.17 + seed * 2.0) * 0.05);
  vec2 iv = uv - look;
  float r = length(iv * vec2(1.0, 1.05));
  float ang = atan(iv.y, iv.x);
  // sclera: pale, darker to the corners, faint veins
  vec3 sclera = mix(vec3(0.30, 0.30, 0.62), vec3(0.03, 0.02, 0.10), smoothstep(0.15, 1.0, abs(x)) + smoothstep(0.0, 0.5, abs(y)) * 0.3);
  float veins = pow(abs(sin(ang * 7.0 + r * 9.0 + seed)), 40.0) * smoothstep(0.45, 0.9, r) * 0.4;
  sclera = mix(sclera, vec3(0.35, 0.08, 0.25), veins);
  // iris: glowing violet-blue fibres with a dark limbal ring
  float fib = vnoise2(vec2(ang * 12.0 + seed, r * 9.0)) * 0.55 + vnoise2(vec2(ang * 31.0, r * 4.0 + seed)) * 0.45;
  vec3 iris = mix(vec3(0.10, 0.05, 0.62), vec3(0.62, 0.38, 2.3), fib) * (1.3 - r * 2.2);
  iris += vec3(0.4, 0.35, 1.2) * smoothstep(0.2, 0.05, abs(r - 0.18)) * 0.5;
  float irisM = smoothstep(0.34, 0.32, r);
  float limbal = smoothstep(0.26, 0.33, r) * irisM;
  iris *= 1.0 - limbal * 0.7;
  float pupil = smoothstep(0.12, 0.105, length(iv * vec2(1.35, 0.95)));
  vec3 c = mix(sclera, iris, irisM);
  c = mix(c, vec3(0.0), pupil);
  // wet highlight
  c += vec3(1.6) * smoothstep(0.045, 0.0, length(iv - vec2(-0.08, 0.08)));
  // dark lid rims + lashes on the upper lid
  float rimU = smoothstep(0.06, 0.0, abs(edgeU)) * step(abs(x), 1.0);
  float rimL = smoothstep(0.04, 0.0, abs(edgeL)) * step(abs(x), 1.0);
  float lash = step(0.0, edgeU) * smoothstep(0.12, 0.0, edgeU) * pow(abs(sin(x * 34.0)), 6.0) * step(abs(x), 0.95);
  vec3 col = c;
  col *= 1.0 - (rimU + rimL) * 0.85;
  float a = clamp(inside + (rimU + rimL + lash) * 0.9 * step(abs(x), 1.0) * open, 0.0, 1.0);
  col *= 1.0 - lash * 0.9;
  // rgb = eye colour, a = coverage (the halo is added by the caller)
  return vec4(col, a);
}

vec3 skyColor(vec3 dir, float detail){
  float y = dir.y;
  float h = max(y, 0.0);
  vec3 col = mix(uSkyHorizon, uSkyZenith, pow(h, 0.5));
  float md = dot(dir, uMoonDir);
  float mdp = max(md, 0.0);
  col += uSkyGlow * (pow(mdp, 6.0) * 0.3 + pow(mdp, 40.0) * 0.55 + pow(mdp, 300.0) * 1.2);

  float thick;
  float cloud = cloudDensity(dir, thick);

  if(detail > 0.5 && y > -0.05){
    // stars
    float st = 0.0;
    vec3 q = dir * 260.0;
    vec3 c = floor(q);
    float hs = hash13(c);
    if(hs > 0.93){
      vec3 o = hash33(c) * 0.7 + 0.15;
      float d = length(fract(q) - o);
      float tw = 0.6 + 0.4 * sin(uTime * (1.0 + hs * 4.0) + hs * 50.0);
      st += smoothstep(0.16, 0.0, d) * (hs - 0.93) * 30.0 * tw;
    }
    vec3 q2 = dir * 90.0;
    vec3 c2 = floor(q2);
    float hs2 = hash13(c2 + 3.0);
    if(hs2 > 0.97){
      vec3 o = hash33(c2) * 0.7 + 0.15;
      float d = length(fract(q2) - o);
      float tw = 0.5 + 0.5 * sin(uTime * (0.7 + hs2 * 3.0) + hs2 * 80.0);
      st += smoothstep(0.1, 0.0, d) * 4.0 * tw;
    }
    // milky band
    vec3 bandAxis = normalize(vec3(0.6, 0.35, 0.72));
    float band = exp(-pow(dot(dir, bandAxis) / 0.22, 2.0));
    float bn = fbm3(dir * 5.0 + 2.0);
    col += vec3(0.05, 0.05, 0.12) * band * smoothstep(0.3, 0.8, bn) * 1.5;
    st *= 1.0 + band * 1.5;
    float starFade = smoothstep(-0.02, 0.15, y) * (1.0 - pow(mdp, 30.0));
    col += vec3(0.8, 0.85, 1.2) * st * starFade * (1.0 - cloud * 0.95);

    // shooting stars: one every few seconds somewhere in the sky
    {
      float period = 9.0;
      float cyc = floor(uTime / period);
      float tt = uTime - cyc * period;
      float dur = 1.1;
      if(tt < dur){
        vec3 h = hash33(vec3(cyc, 1.3, 7.1));
        float az = h.x * 6.2831, el = 0.3 + h.y * 0.45;
        vec3 s0 = vec3(cos(el) * sin(az), sin(el), cos(el) * cos(az));
        vec3 side = normalize(cross(s0, vec3(0.0, 1.0, 0.0))) * (h.z > 0.5 ? 1.0 : -1.0);
        vec3 tdir = normalize(side - vec3(0.0, 0.45, 0.0) * 0.8);
        float prog = tt / dur;
        vec3 head = normalize(s0 + tdir * prog * 0.45);
        vec3 tail = normalize(s0 + tdir * max(prog - 0.28, 0.0) * 0.45);
        vec3 ab = head - tail;
        float k = clamp(dot(dir - tail, ab) / max(dot(ab, ab), 1e-6), 0.0, 1.0);
        float d = length(dir - (tail + ab * k));
        float w = 0.0022;
        float streak = exp(-d * d / (w * w)) * k * k;
        float life = sin(prog * 3.14159);
        col += vec3(0.8, 0.9, 1.6) * streak * life * 3.0 * (1.0 - cloud * 0.9);
      }
    }
    // four-pointed guiding star
    vec2 sv = dirToLocal(dir, uStarDir);
    if(dot(dir, uStarDir) > 0.9){
      float core = exp(-length(sv) * 60.0) * 6.0;
      float rays = exp(-abs(sv.x) * 500.0 - abs(sv.y) * 18.0) + exp(-abs(sv.y) * 500.0 - abs(sv.x) * 18.0);
      float pulse = 0.85 + 0.15 * sin(uTime * 1.7);
      col += vec3(0.7, 0.8, 1.6) * (core + rays * 1.6) * pulse * (1.0 - cloud * 0.8);
      col += vec3(0.15, 0.2, 0.5) * exp(-length(sv) * 10.0) * 0.6;
    }
  }

  // moon disc
  float mr = uMoonSize;
  if(md > 0.95){
    vec2 mv = dirToLocal(dir, uMoonDir) / mr;
    float r = length(mv);
    float aa = fwidth(r) * 1.5 + 0.004;
    float disc = smoothstep(1.0 + aa, 1.0 - aa, r);
    if(disc > 0.0){
      vec3 n = vec3(mv, sqrt(max(1.0 - r * r, 0.0)));
      float maria = fbm3(n * 2.2 + 4.0);
      float crater = 0.0;
      vec3 v = voronoi2(mv * 3.5 + 1.3);
      crater = smoothstep(0.35, 0.0, v.x) * 0.25 * step(0.5, v.z);
      float albedo = 0.75 - smoothstep(0.45, 0.65, maria) * 0.35 + crater - vnoise2(mv * 12.0) * 0.08;
      float limb = pow(n.z, 0.35);
      vec3 mc = vec3(1.0, 1.06, 1.3) * albedo * limb * 2.6;
      col = mix(col, mc, disc * (1.0 - cloud * 0.7));
    }
  }

  // clouds
  if(cloud > 0.001){
    float lit = pow(mdp, 5.0);
    vec3 dark = vec3(0.012, 0.014, 0.045);
    vec3 bright = vec3(0.22, 0.24, 0.52);
    vec3 cc = mix(dark, bright, clamp(lit * 1.2 + (1.0 - thick) * 0.25, 0.0, 1.0));
    // silver lining towards the moon
    cc += vec3(0.6, 0.65, 1.2) * pow(mdp, 20.0) * (1.0 - cloud) * 2.0;
    cc += vec3(0.05, 0.05, 0.12) * smoothstep(0.3, 0.9, thick);
    col = mix(col, cc, cloud * 0.92);
  }

  // eyes in the sky
  if(uEye > 0.001 && dot(dir, uEyeDir) > 0.6){
    vec2 ev = dirToLocal(dir, uEyeDir) / 0.3;
    float blink = smoothstep(0.0, 0.08, abs(sin(uTime * 0.25)) ) ;
    vec4 e1 = eyeShape(ev, uEye * blink, uTime, 0.0);
    float halo = exp(-length(ev * vec2(0.8, 1.6)) * 2.2) * uEye * blink;
    col += vec3(0.12, 0.08, 0.45) * halo;
    col = mix(col, e1.rgb, e1.a * uEye);
    vec3 d2 = normalize(uEyeDir + vec3(0.55, -0.12, 0.2));
    vec2 e2 = dirToLocal(dir, d2) / 0.16;
    vec4 e2c = eyeShape(e2, uEye * smoothstep(0.0, 0.1, abs(sin(uTime * 0.31 + 1.0))), uTime, 3.0);
    col = mix(col, e2c.rgb, e2c.a * uEye);
    vec3 d3 = normalize(uEyeDir + vec3(-0.6, -0.15, 0.1));
    vec2 e3 = dirToLocal(dir, d3) / 0.14;
    vec4 e3c = eyeShape(e3, uEye * smoothstep(0.0, 0.1, abs(sin(uTime * 0.21 + 2.0))), uTime, 7.0);
    col = mix(col, e3c.rgb, e3c.a * uEye);
  }

  // below horizon blend into fog
  if(y < 0.0) col = mix(col, uFogColor, clamp(-y * 5.0, 0.0, 1.0));
  return col;
}
`;

export function skyVS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
layout(location=0) in vec3 aPosition;
uniform mat4 uInvViewProj;
out vec3 vDir;
void main(){
  vec4 w = uInvViewProj * vec4(aPosition.xy, 1.0, 1.0);
  vDir = w.xyz / w.w - uCamPos;
  // exactly on the far plane: drawn after the opaque pass, the sky only shades pixels nothing else covers
  gl_Position = vec4(aPosition.xy, 1.0, 1.0);
}
`;
}

export function skyFS() {
  return HEADER + FRAME_UNIFORMS + NOISE + SKY_UNIFORMS + SKY_FN + /* glsl */ `
in vec3 vDir;
out vec4 fragColor;
void main(){
  vec3 dir = normalize(vDir);
  vec3 col = skyColor(dir, 1.0);
  // subtle haze band on the horizon, matching the fog
  float hz = exp(-abs(dir.y) * 9.0);
  float moonGlow = pow(max(dot(dir, uMoonDir), 0.0), 6.0);
  col = mix(col, mix(uFogColor, uFogMoonColor, moonGlow), hz * 0.55);
  fragColor = vec4(col, 1.0);
}
`;
}
