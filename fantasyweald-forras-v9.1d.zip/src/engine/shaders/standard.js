// The "uber" surface shader used by almost everything solid in the world.
import { HEADER, FRAME_UNIFORMS, NOISE, SHADOW, LIGHTS, FOG, GLITTER, BUMP } from './common.js';

export const MAX_BONES = 24;

export function standardVS(defs) {
  return HEADER + defs + FRAME_UNIFORMS + NOISE + /* glsl */ `
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUv;
layout(location=3) in vec4 aColor;
layout(location=4) in vec4 aExtra;
#ifdef INSTANCED
layout(location=5) in vec4 aI0;
layout(location=6) in vec4 aI1;
layout(location=7) in vec4 aI2;
layout(location=8) in vec4 aI3;
layout(location=9) in vec4 aIColor;
#endif
#ifdef BAKED
// merged static geometry is stored in world space; the original model-space position drives the detail noise
layout(location=11) in vec3 aLocal;
#endif
#ifdef SKINNED
// a character's parts merged per material: each vertex follows the world matrix of the part it came from
layout(location=10) in float aBone;
uniform mat4 uBones[${MAX_BONES}];
#endif
uniform mat4 uModel;
uniform vec4 uWindParams; // amplitude, frequency scale, push strength, bend
#ifdef FLAP
// (v9.1b) soft membrane wings: a wave runs from the body out to the tips and from front to back
uniform vec4 uFlap;   // phase, amplitude, spanwise wave number, chordwise wave number
uniform vec4 uFlap2;  // tail whip amplitude, body half-width (rigid), wingtip span, -
#endif
out vec3 vWorld;
out vec3 vNormal;
out vec2 vUv;
out vec4 vColor;
out vec4 vExtra;
out vec3 vLocal;
out float vSeed;

void main(){
#ifdef SKINNED
  // (v9.1b) a fractional bone index blends two neighbouring bones (b + w): long bodies bend smoothly
  int bi = int(floor(aBone + 0.001));
  float bw = clamp(aBone - float(bi), 0.0, 1.0);
  mat4 M = uBones[bi];
  if(bw > 0.004) M = M * (1.0 - bw) + uBones[bi + 1] * bw;
#else
  mat4 M = uModel;
#endif
  vec4 tint = vec4(1.0);
#ifdef INSTANCED
  M = M * mat4(aI0, aI1, aI2, aI3);
  tint = aIColor;
#endif
  vec3 lp = aPosition, ln = aNormal;
#ifdef FLAP
  {
    float sx = abs(lp.x);
    float e0 = uFlap2.y, e1 = uFlap2.z;
    float u = clamp((sx - e0) / (e1 - e0), 0.0, 1.0);
    float w = u * u * (3.0 - 2.0 * u);
    float dw = (sx > e0 && sx < e1) ? 6.0 * u * (1.0 - u) / (e1 - e0) : 0.0;
    float th = uFlap.x - sx * uFlap.z + lp.z * uFlap.w;
    float sn = sin(th), cs = cos(th);
    float amp = uFlap.y * w * sx;
    lp.y += amp * sn;
    float dyds = uFlap.y * (w + sx * dw) * sn - amp * uFlap.z * cs;
    float dydz = amp * uFlap.w * cs;
    ln = normalize(ln + vec3(-sign(lp.x) * dyds, 0.0, -dydz) * ln.y);
    // the long thin tail whips slowly from side to side
    float tz = max(0.0, -lp.z - 0.62);
    lp.x += sin(uFlap.x * 0.55 - tz * 2.6) * uFlap2.x * tz * tz;
  }
#endif
  vec4 wp = M * vec4(lp, 1.0);
  vec3 n = normalize(mat3(M) * ln);
  float seed = aExtra.w + tint.a * 0.0;
#ifdef INSTANCED
  seed += fract(aI3.x * 0.137 + aI3.z * 0.311);
#endif
#ifdef WIND
  float w = aExtra.y * uWindParams.x;
  if(w > 0.0){
    vec2 wd = uWind.xy;
    float ph = dot(wp.xz, vec2(0.21, 0.17)) * uWindParams.y + uTime * uWind.w;
    float gust = 0.55 + 0.45 * sin(uTime * 0.37 + wp.x * 0.02 + wp.z * 0.015);
    float sway = (sin(ph) * 0.6 + sin(ph * 2.37 + seed * 6.0) * 0.3 + 0.35) * gust * uWind.z;
    wp.xz += wd * sway * w;
    wp.x += sin(uTime * 3.1 + seed * 40.0 + wp.y) * 0.04 * w * uWind.z;
    // push away from the player
    vec3 pd = wp.xyz - uPlayer.xyz;
    float pl = length(pd.xz);
    float push = (1.0 - smoothstep(0.0, uPlayer.w, pl)) * uWindParams.z;
    wp.xz += (pd.xz / max(pl, 0.01)) * push * w;
    wp.y -= push * w * 0.4;
  }
#endif
  vWorld = wp.xyz;
  vNormal = n;
  vUv = aUv;
  vColor = vec4(aColor.rgb * tint.rgb, aColor.a);
  vExtra = vec4(aExtra.x * tint.a, aExtra.yzw);
#ifdef BAKED
  vLocal = aLocal;
#else
  vLocal = aPosition;
#endif
  vSeed = seed;
  gl_Position = uViewProj * wp;
}
`;
}

export function standardFS(defs) {
  return HEADER + defs + FRAME_UNIFORMS + NOISE + SHADOW + LIGHTS + FOG + GLITTER + BUMP + /* glsl */ `
in vec3 vWorld;
in vec3 vNormal;
in vec2 vUv;
in vec4 vColor;
in vec4 vExtra;
in vec3 vLocal;
in float vSeed;
out vec4 fragColor;

uniform vec3 uColor;
uniform vec3 uEmissive;
uniform float uGlowStrength;
uniform float uRough;
uniform float uRim;
uniform float uWrap;
uniform vec3 uGlitter;       // density, coverage, intensity
uniform vec3 uGlitterColor;
uniform vec4 uDetail;        // scale, albedo variation, bump, type
uniform vec4 uSpots;         // scale, threshold, emissive, bump
uniform vec3 uSpotColor;
uniform float uSpotGlowPulse;
uniform vec4 uScales;         // (SCALES) cells per metre, crease width, bump, ember strength
uniform vec3 uEmberColor;
uniform float uEmber;
uniform float uFogScale;
uniform float uAlpha;
uniform float uAmbientBoost;
uniform float uFill;
#ifdef HOLE
uniform vec4 uHole; // centre xz, radius, edge noise: nothing is drawn inside (the island lies there)
#endif
#ifdef MAP
uniform sampler2D uMap;
#endif
#ifdef TERRAIN
uniform vec3 uPathGlow;
#endif

float detailNoise(vec3 p, float type){
  if(type < 0.5) return 0.5;
  if(type < 1.5) return fbm3(p);                                          // stone / blotchy
  if(type < 2.5) return fbm3(p * vec3(1.0, 0.12, 1.0)) * 0.7 + vnoise3(p * vec3(4.0, 0.4, 4.0)) * 0.3; // bark
  if(type < 3.5) return vnoise3(p * vec3(6.0, 0.35, 6.0)) * 0.7 + vnoise3(p * vec3(14.0, 1.0, 14.0)) * 0.3; // hair
  if(type < 4.5) return vnoise3(p * 0.6) * 0.6 + vnoise3(p * 2.1) * 0.4;                // cloth
  return fbm3(p) * 0.6 + vnoise3(p * 5.0) * 0.4;                          // soft moss
}

void main(){
  vec3 N = normalize(vNormal);
  if(!gl_FrontFacing) N = -N;
  vec3 V = normalize(uCamPos - vWorld);
  vec3 P = vWorld;
  float alpha = uAlpha;
#ifdef HOLE
  if(length(P.xz - uHole.xy) < uHole.z + (vnoise2(P.xz * 0.045) - 0.5) * uHole.w) discard;
#endif
#ifdef MAP
  vec4 tx = texture(uMap, vUv);
  alpha *= tx.a;
  #ifdef ALPHA_TEST
  if(alpha < 0.5) discard;
  // foliage right in front of the camera dissolves instead of filling the screen with flat cards
  #ifndef SHADOW_PASS
  float camD = length(uCamPos - vWorld);
  if(camD < 3.2 && hash12(gl_FragCoord.xy) > smoothstep(1.2, 3.2, camD)) discard;
  #endif
  #endif
#endif
#ifdef SHADOW_PASS
  fragColor = vec4(1.0);
  return;
#endif

  vec3 albedo;
  float rough = uRough;
  float ao = vColor.a;
  vec3 emissive = uEmissive;
  float glitterAmt = uGlitter.z;
  float rimAmt = uRim;

#ifdef TERRAIN
  float wPath = vColor.r, wSand = vColor.g, wRock = vColor.b, wMoss = vColor.a;
  ao = vExtra.x;
  float n1 = fbm2(P.xz * 0.21);
  // break up per-vertex splat borders with noise so they read organic, not gridded
  float bn = fbm2(P.xz * 0.9 + 5.0) - 0.5;
  wMoss = smoothstep(0.25, 0.75, wMoss + bn * 0.7);
  wSand = smoothstep(0.2, 0.8, wSand + bn * 0.5);
  wRock = smoothstep(0.2, 0.8, wRock + bn * 0.5);
  float fwT = length(fwidth(P.xz));
  float lodA = 1.0 - smoothstep(0.08, 0.3, fwT);   // fine detail
  float lodB = 1.0 - smoothstep(0.2, 0.7, fwT);    // medium detail
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  float n2 = vnoise2(rot * P.xz * 1.7) * 0.55 + mix(0.5, vnoise2(rot * rot * P.xz * 4.3 + 3.1), lodA) * 0.45;
  n2 = mix(0.5, n2, lodB * 0.8 + 0.2);
  vec3 ground = mix(vec3(0.012, 0.022, 0.030), vec3(0.030, 0.055, 0.062), n1);
  ground = mix(ground, vec3(0.034, 0.034, 0.064), smoothstep(0.35, 0.95, n2) * 0.45);
  vec3 mossC = mix(vec3(0.014, 0.050, 0.046), vec3(0.040, 0.110, 0.090), n2);
  float rn = 0.5;
  vec3 rockC = vec3(0.07, 0.076, 0.1);
  if(wRock > 0.01){
    rn = fbm3(P * vec3(0.35, 1.1, 0.35));
    rockC = mix(vec3(0.030, 0.034, 0.050), vec3(0.110, 0.118, 0.160), rn);
  }
  vec3 sandC = mix(vec3(0.040, 0.052, 0.060), vec3(0.090, 0.105, 0.115), n2);
  float stone = 0.0, dome = 0.5, lodC = 0.0;
  vec3 vor = vec3(0.0, 1.0, 0.5);
  vec3 pathC = vec3(0.0);
  if(wPath > 0.01){
    vec2 cp = P.xz * 3.1 + vec2(vnoise2(P.xz * 0.8), vnoise2(P.xz * 0.8 + 7.0)) * 0.8;
    vor = voronoi2(cp);
    float edge = vor.y - vor.x;
    lodC = 1.0 - smoothstep(0.12, 0.45, fwT * 3.1);
    stone = mix(0.8, smoothstep(0.06, 0.24, edge), lodC);
    dome = mix(0.5, smoothstep(0.0, 0.5, edge), lodC);
    vec3 cob = mix(vec3(0.032, 0.036, 0.056), vec3(0.085, 0.092, 0.135), vor.z) * (0.75 + 0.5 * n2) * (0.8 + 0.4 * dome);
    pathC = mix(vec3(0.006, 0.008, 0.014), cob, stone);
  }
  albedo = ground;
  albedo = mix(albedo, mossC, wMoss);
  albedo = mix(albedo, sandC, wSand);
  albedo = mix(albedo, rockC, wRock);
  albedo = mix(albedo, pathC, wPath);
  float h = n2 * 0.12;
  h = mix(h, rn * 1.6, wRock);
  h = mix(h, (stone * 0.35 + dome * 0.35) * lodC + vor.z * 0.05 + n2 * 0.05, wPath);
  N = perturbNormal(P, N, h, mix(0.15, 1.0, lodB));
  rough = mix(mix(0.92, 0.75, wRock), 0.58, wPath * stone);
  // glowing path patches like wet moonlit stone
  if(wPath > 0.01){
    float patchN = fbm2(P.xz * 0.09 + vec2(uTime * 0.006, -uTime * 0.004));
    float glow = smoothstep(0.45, 0.8, patchN) * stone * wPath * (0.4 + 0.6 * dome);
    emissive += uPathGlow * glow * (0.6 + 0.4 * vor.z);
    emissive += uPathGlow * 0.08 * wPath * stone * dome;
  }
  glitterAmt *= (0.6 + wPath * 1.6 + wRock * 0.5);
#else
  albedo = vColor.rgb * uColor;
  float dt = uDetail.w;
  if(dt > 0.5){
    vec3 dp = vLocal * uDetail.x + vSeed * 13.0;
    float fw = length(fwidth(dp)) * (dt > 1.5 && dt < 3.5 ? 4.0 : 1.5);
    float lod = 1.0 - smoothstep(0.25, 0.9, fw);
    float h = detailNoise(dp, dt);
    h = mix(0.5, h, lod * 0.75 + 0.25);
    albedo *= mix(1.0 - uDetail.y, 1.0 + uDetail.y, h);
    N = perturbNormal(P, N, h, uDetail.z * lod);
  }
  #ifdef MAP
  albedo *= tx.rgb;
  #endif
  #ifdef SPOTS
  {
    vec3 sp = vLocal * uSpots.x + vSeed * 7.0;
    vec3 c = floor(sp); vec3 f = fract(sp);
    float best = 9.0;
    float bestH = 0.0;
    for(int k = 0; k < 8; k++){
      vec3 o = vec3(float(k & 1), float((k >> 1) & 1), float((k >> 2) & 1));
      vec3 cell = floor(sp - 0.5) + o;
      vec3 jit = hash33(cell) * 0.5 + 0.25;
      float d = length(sp - cell - jit);
      float hh = hash13(cell + 5.0);
      float rad = mix(0.18, 0.42, hh) * uSpots.y;
      float sd = d - rad;
      if(sd < best){ best = sd; bestH = hh; }
    }
    float spot = smoothstep(0.03, -0.03, best);
    float capMask = clamp(vExtra.z, 0.0, 1.0);   // only where vertex allows spots
    spot *= capMask;
    albedo = mix(albedo, uSpotColor, spot);
    float pulse = 1.0 + uSpotGlowPulse * sin(uTime * 1.3 + bestH * 20.0 + vSeed * 9.0);
    emissive += uSpotColor * spot * uSpots.z * pulse * 0.42;
    N = perturbNormal(P, N, spot, uSpots.w);
  }
  #endif
  #ifdef SCALES
  {
    // (v8) reptile scales: domed plates with dark creases. vExtra.y makes them finer (heads), vExtra.z lets
    // the creases smoulder like embers (bellies, throats), uEmber makes the whole creature glow hotter.
    float fine = mix(1.0, 2.6, clamp(vExtra.y, 0.0, 1.0));
    vec3 sp = vLocal * uScales.x * fine;
    float fwS = length(fwidth(sp));
    float lodS = 1.0 - smoothstep(0.3, 1.0, fwS);
    float f1 = 9.0, f2 = 9.0, hid = 0.0;
    for(int k = 0; k < 8; k++){
      vec3 o = vec3(float(k & 1), float((k >> 1) & 1), float((k >> 2) & 1));
      vec3 cell = floor(sp - 0.5) + o;
      vec3 jit = hash33(cell) * 0.5 + 0.25;
      float d = length(sp - cell - jit);
      if(d < f1){ f2 = f1; f1 = d; hid = hash13(cell + 3.0); }
      else if(d < f2){ f2 = d; }
    }
    float edge = f2 - f1;
    float plate = mix(0.85, smoothstep(0.0, uScales.y, edge), lodS);
    float domeS = sqrt(clamp(edge * 2.4, 0.0, 1.0)) * lodS;
    albedo *= mix(0.2, 1.0, plate) * mix(1.0, 0.72 + 0.56 * hid, lodS);
    N = perturbNormal(P, N, domeS, uScales.z / fine);
    rough = mix(rough, rough * 0.6, plate * lodS);
    float emb = clamp(vExtra.z, 0.0, 1.0) * (1.0 - plate) * uScales.w;
    emissive += uEmberColor * emb * (0.7 + 0.3 * sin(uTime * 2.2 + hid * 12.0)) * (1.0 + uEmber * 2.5);
  }
  #endif
  emissive += vColor.rgb * vExtra.x * uGlowStrength * 0.72;
#endif

#ifdef UNLIT
  vec3 col = (albedo + emissive) * 0.8;
#else
  float shadow = getShadow(P, normalize(vNormal) * (gl_FrontFacing ? 1.0 : -1.0));
  vec3 col = shadeLit(albedo, N, V, P, rough, shadow, ao, rimAmt, uWrap);
  // extra ambient for surfaces that should never sink to black
  col += albedo * mix(uGroundAmb, uSkyAmb, N.y * 0.5 + 0.5) * uAmbientBoost * 4.0 * ao;
  // soft camera fill so characters read in any light
  col += albedo * uFill * vec3(0.16, 0.18, 0.32) * (0.35 + 0.65 * max(dot(N, V), 0.0));
  col += emissive;
#endif
  if(glitterAmt > 0.0){
    float g = glitter(P, N, V, uGlitter.x, uGlitter.y);
    col += uGlitterColor * g * glitterAmt * 0.5;
  }
  col = applyFog(col, P, uFogScale);
  col = clamp(col, 0.0, 64.0);
#ifdef ADDITIVE
  col *= alpha;
#endif
  fragColor = vec4(col, alpha);
}
`;
}

export function shadowFS(defs) {
  return HEADER + defs + /* glsl */ `
in vec2 vUv;
out vec4 fragColor;
#ifdef MAP
uniform sampler2D uMap;
#endif
void main(){
#ifdef MAP
  if(texture(uMap, vUv).a < 0.5) discard;
#endif
  fragColor = vec4(1.0);
}
`;
}
