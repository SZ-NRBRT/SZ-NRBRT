// Bioluminescent teal water with sky reflection, sparkles and soft shores.
import { HEADER, FRAME_UNIFORMS, NOISE, FOG, GLITTER, LIGHTS } from './common.js';
import { SKY_UNIFORMS, SKY_FN } from './sky.js';

export const TERRAIN_SAMPLE = /* glsl */ `
uniform sampler2D uHeightTex;
uniform vec4 uTerrainRect; // originX, originZ, size, resolution(samples)
vec4 terrainData(vec2 xz){
  vec2 uv = (xz - uTerrainRect.xy) / uTerrainRect.z;
  float n = uTerrainRect.w;
  uv = uv * ((n - 1.0) / n) + 0.5 / n;
  return texture(uHeightTex, uv);
}
`;

export function waterVS(defs = '') {
  return HEADER + defs + FRAME_UNIFORMS + /* glsl */ `
layout(location=0) in vec3 aPosition;
uniform mat4 uModel;
out vec3 vWorld;
#ifdef RIVER
layout(location=2) in vec2 aUv;   // flow direction (xz) * speed
out vec2 vFlow;
#endif
void main(){
#ifdef RIVER
  vFlow = aUv;
#endif
  vec4 wp = uModel * vec4(aPosition, 1.0);
  wp.y += sin(wp.x * 0.35 + uTime * 0.9) * 0.025 + sin(wp.z * 0.27 - uTime * 0.7) * 0.025;
  vWorld = wp.xyz;
  gl_Position = uViewProj * wp;
}
`;
}

export function waterFS(defs = '') {
  return HEADER + defs + FRAME_UNIFORMS + NOISE + SKY_UNIFORMS + SKY_FN + FOG + GLITTER + LIGHTS + TERRAIN_SAMPLE + /* glsl */ `
in vec3 vWorld;
#ifdef RIVER
in vec2 vFlow;
#endif
out vec4 fragColor;
uniform vec3 uDeep;
uniform vec3 uShallow;
uniform vec3 uGlowCol;
uniform float uLevel;
#ifdef SEA
uniform vec4 uHole;
uniform vec4 uLev[12];   // (v9) the leviathan under the surface: xz, radius, darkness (0 = nothing there)
uniform vec4 uLure;      // its lantern: xz, brightness, spread
#endif

float wh(vec2 p){
  float t = uTime;
  float h = 0.0;
  h += sin(dot(p, vec2(0.8, 0.6)) * 1.3 + t * 1.1) * 0.5;
  h += sin(dot(p, vec2(-0.5, 0.9)) * 2.1 + t * 1.5) * 0.3;
  h += vnoise2(p * 1.6 + vec2(t * 0.35, t * 0.2)) * 0.7;
  h += vnoise2(p * 4.3 - vec2(t * 0.5, -t * 0.3)) * 0.3;
  return h;
}

void main(){
  vec3 P = vWorld;
#ifdef SEA
  // the lakes and rivers of the island have their own water; the sea begins beyond them
  if(length(P.xz - uHole.xy) < uHole.z) discard;
#endif
  vec3 V = normalize(uCamPos - P);
  // rivers: everything drifts downstream
  vec2 Q = P.xz;
#ifdef RIVER
  Q -= vFlow * uTime;
#endif
  float e = 0.08;
  float h0 = wh(Q);
  float hx = wh(Q + vec2(e, 0.0));
  float hz = wh(Q + vec2(0.0, e));
  float dist = length(uCamPos - P);
  float strength = 0.05 * mix(1.0, 0.3, smoothstep(10.0, 80.0, dist));
  vec3 N = normalize(vec3(-(hx - h0) / e * strength, 1.0, -(hz - h0) / e * strength));

  float depth = uLevel - terrainData(P.xz).r;
  float fres = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
  vec3 R = reflect(-V, N);
  R.y = abs(R.y);
  vec3 refl = skyColor(normalize(R), 0.0);

  float dz = smoothstep(0.0, 3.5, depth);
  vec3 body = mix(uShallow, uDeep, dz);
  // bioluminescent drifting patches
  float pn = fbm2(Q * 0.07 + vec2(uTime * 0.015, -uTime * 0.01));
  float pn2 = vnoise2(Q * 0.5 - uTime * 0.05);
  float glow = smoothstep(0.35, 0.8, pn) * (0.6 + 0.4 * pn2);
  vec3 col = body * (0.35 + 0.65 * glow) + uGlowCol * glow * 0.9;
  // moonlight on the surface
  float spec = pow(max(dot(R, uMoonDir), 0.0), 350.0) * 14.0 + pow(max(dot(R, uMoonDir), 0.0), 40.0) * 0.45;
  col = mix(col, refl, fres * 0.8);
  col += uMoonColor * spec;
  // point lights reflected
  for(int i = 0; i < ${'12'}; i++){
    if(i >= uLightCount) break;
    vec3 lv = uLightPos[i].xyz - P;
    float d2 = dot(lv, lv);
    float r = uLightPos[i].w * 1.5;
    if(d2 > r * r) continue;
    vec3 l = normalize(lv);
    float s = pow(max(dot(R, l), 0.0), 60.0);
    float att = 1.0 - sqrt(d2) / r;
    col += uLightCol[i].rgb * s * att * 1.3;
  }
  // sparkles
  float g = glitter(vec3(Q.x, P.y + uTime * 0.05, Q.y), N, V, 6.0, 0.2);
  col += vec3(0.8, 1.2, 1.6) * g * 1.1;
  // shore foam
  float foamN = vnoise2(Q * 3.0 + uTime * 0.3);
  float foam = (1.0 - smoothstep(0.0, 0.35 + foamN * 0.25, depth)) * (0.5 + 0.5 * foamN);
  col = mix(col, vec3(0.35, 0.75, 0.85), foam * 0.6);
#ifdef SEA
  // a vast dark shape gliding under the water, and the cold light of its lantern
  float sh = 0.0, dots = 0.0;
  for(int i = 0; i < 11; i++){
    vec4 a = uLev[i], b = uLev[i + 1];
    if(a.w <= 0.001 && b.w <= 0.001) continue;
    vec2 pa = P.xz - a.xy, ba = b.xy - a.xy;
    float hh = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-4), 0.0, 1.0);
    float d = length(pa - ba * hh);
    float r = mix(a.z, b.z, hh);
    float w = mix(a.w, b.w, hh);
    sh = max(sh, (1.0 - smoothstep(r * 0.3, r, d)) * w);
    // two rows of faint lights along its flanks
    float lat = d / max(r, 0.01);
    float row = exp(-pow((lat - 0.6) / 0.07, 2.0));
    float along = (float(i) + hh) * 5.4;
    float bead = 1.0 - smoothstep(0.08, 0.2, abs(fract(along / 1.35) - 0.5));
    dots = max(dots, row * bead * w * (i > 0 ? 1.0 : 0.0));
  }
  col *= 1.0 - sh * 0.88;
  col += vec3(0.35, 0.9, 1.05) * dots * 0.45;
  if(uLure.z > 0.001){
    float ld = length(P.xz - uLure.xy);
    float lg = exp(-ld * ld / (uLure.w * uLure.w));
    col += vec3(0.45, 0.95, 1.05) * uLure.z * (lg * 1.3 + exp(-ld * ld / (uLure.w * uLure.w * 0.08)) * 1.6);
  }
#endif
  col = applyFog(col, P, 1.0);
  // the shore fades out softly (the water thins to nothing before it meets the bank, so the edge
  // follows the smooth height texture instead of the terrain's triangles)
  float alpha = clamp(mix(0.72, 0.98, dz) + fres * 0.3, 0.0, 1.0) * smoothstep(0.0, 0.4, depth);
  fragColor = vec4(col, alpha);
}
`;
}

export function waterfallVS() {
  return HEADER + FRAME_UNIFORMS + /* glsl */ `
layout(location=0) in vec3 aPosition;
layout(location=2) in vec2 aUv;
uniform mat4 uModel;
out vec2 vUv;
out vec3 vWorld;
void main(){
  vec4 wp = uModel * vec4(aPosition, 1.0);
  vUv = aUv;
  vWorld = wp.xyz;
  gl_Position = uViewProj * wp;
}
`;
}

export function waterfallFS() {
  return HEADER + FRAME_UNIFORMS + NOISE + /* glsl */ `
in vec2 vUv;
in vec3 vWorld;
out vec4 fragColor;
void main(){
  float t = uTime;
  vec2 uv = vUv;
  float s1 = vnoise2(vec2(uv.x * 26.0, uv.y * 3.0 - t * 2.6));
  float s2 = vnoise2(vec2(uv.x * 60.0 + 3.0, uv.y * 7.0 - t * 4.1));
  float streak = smoothstep(0.35, 0.95, s1 * 0.65 + s2 * 0.5);
  float edge = smoothstep(0.0, 0.12, uv.x) * smoothstep(1.0, 0.88, uv.x);
  float foam = smoothstep(0.8, 1.0, uv.y) ;
  vec3 col = mix(vec3(0.05, 0.35, 0.45), vec3(0.6, 1.2, 1.5), streak) * (0.6 + foam * 1.2);
  float a = edge * (0.25 + streak * 0.75);
  float dist = length(vWorld - uCamPos);
  float fade = exp(-dist * uFogParams.x * 0.8);
  fragColor = vec4(col * a * fade, 0.0);
}
`;
}
