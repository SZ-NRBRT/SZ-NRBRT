// Static batching: meshes that never move are merged, per material and per area, into one world-space mesh,
// so a village or a castle costs a handful of draw calls instead of hundreds. Nothing changes visually: the
// vertices are baked with the same transform the shader would apply, and the original model-space position
// is kept in an extra attribute for the surface detail noise.
//
// It is safe for things that do move after all: every frame the scene walk checks the members, and a member
// that moved, was hidden or stopped casting shadows is taken out of its batch (the batch is rebuilt without
// it) and simply drawn on its own from then on.
import { Mesh } from './scene.js';
import { ATTR } from './gl.js';

const MAX_VERTS = 180000;

class StaticBatch {
  constructor(owner, members, key) {
    this.owner = owner;
    this.members = members;
    this.material = members[0].material;
    this.castShadow = members[0].castShadow;
    this.maxDistance = members[0].maxDistance;
    this.shadowDistance = members[0].shadowDistance;
    this.key = key;
    this.mesh = null;
    this.gpu = null;
    this.frame = -1;
    this.seen = 0;
    this.dirty = true;
    for (const m of members) { m._batch = this; m._batchV = m.worldVersion; }
  }
  // called by the scene walk for every visible member
  accept(m, frame) {
    if (m.worldVersion !== m._batchV || m.castShadow !== this.castShadow || m.material !== this.material) {
      this.eject(m);
      return false;
    }
    if (this.frame !== frame) { this.frame = frame; this.seen = 0; }
    this.seen++;
    m._seen = frame;
    return true;
  }
  eject(m) {
    const i = this.members.indexOf(m);
    if (i >= 0) this.members.splice(i, 1);
    m._batch = null;
    m.dynamic = true;
    this.dirty = true;
    this.owner.ejected++;
  }
  // after the walk: drop members that were not reached (hidden), rebuild if needed, draw
  finish(out, frame) {
    if (this.frame !== frame) this.seen = 0;
    if (this.seen !== this.members.length) {
      const keep = [];
      for (const m of this.members) {
        if (m._seen === frame) keep.push(m);
        else { m._batch = null; m.dynamic = true; this.owner.ejected++; }
      }
      this.members = keep;
      this.dirty = true;
    }
    if (this.dirty) {
      const before = this.members;
      this.rebuild();
      // too few left for a batch: the survivors (already skipped by the walk this frame) draw on their own
      if (!this.mesh) for (const m of before) if (m._seen === frame) out.push(m);
    }
    if (this.mesh) out.push(this.mesh);
  }
  dispose() {
    if (!this.gpu) return;
    const gl = this.owner.gl;
    for (const k in this.gpu.buffers) gl.deleteBuffer(this.gpu.buffers[k]);
    gl.deleteVertexArray(this.gpu.vao);
    this.gpu = null;
    this.mesh = null;
  }
  rebuild() {
    this.dirty = false;
    this.dispose();
    if (this.members.length < 2) {
      // not worth a batch any more: the survivor draws on its own
      for (const m of this.members) m._batch = null;
      this.members = [];
      return;
    }
    const gl = this.owner.gl;
    let nv = 0, ni = 0;
    for (const m of this.members) { nv += m.geometry.vertexCount; ni += m.geometry.count; }
    const P = new Float32Array(nv * 3), N = new Float32Array(nv * 3), LOC = new Float32Array(nv * 3);
    const UV = new Float32Array(nv * 2), COL = new Float32Array(nv * 4), EX = new Float32Array(nv * 4);
    const big = nv > 65535;
    const IDX = big ? new Uint32Array(ni) : new Uint16Array(ni);
    let vo = 0, io = 0;
    let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
    for (const m of this.members) {
      const g = m.geometry.cpu, w = m.world, n = m.geometry.vertexCount;
      const p = g.p, nn = g.n;
      for (let i = 0; i < n; i++) {
        const x = p[i * 3], y = p[i * 3 + 1], z = p[i * 3 + 2];
        const o = (vo + i) * 3;
        const wx = w[0] * x + w[4] * y + w[8] * z + w[12];
        const wy = w[1] * x + w[5] * y + w[9] * z + w[13];
        const wz = w[2] * x + w[6] * y + w[10] * z + w[14];
        P[o] = wx; P[o + 1] = wy; P[o + 2] = wz;
        if (wx < minx) minx = wx; if (wy < miny) miny = wy; if (wz < minz) minz = wz;
        if (wx > maxx) maxx = wx; if (wy > maxy) maxy = wy; if (wz > maxz) maxz = wz;
        LOC[o] = x; LOC[o + 1] = y; LOC[o + 2] = z;
        const a = nn[i * 3], b = nn[i * 3 + 1], c = nn[i * 3 + 2];
        // same as the shader: normalize(mat3(model) * normal)
        const tx = w[0] * a + w[4] * b + w[8] * c, ty = w[1] * a + w[5] * b + w[9] * c, tz = w[2] * a + w[6] * b + w[10] * c;
        const l = Math.sqrt(tx * tx + ty * ty + tz * tz) || 1;
        N[o] = tx / l; N[o + 1] = ty / l; N[o + 2] = tz / l;
      }
      UV.set(g.uv, vo * 2);
      COL.set(g.c, vo * 4);
      EX.set(g.e, vo * 4);
      const idx = g.idx;
      for (let k = 0; k < idx.length; k++) IDX[io + k] = idx[k] + vo;
      vo += n;
      io += idx.length;
    }
    const mk = (data, target = gl.ARRAY_BUFFER) => {
      const b = gl.createBuffer();
      gl.bindBuffer(target, b);
      gl.bufferData(target, data, gl.STATIC_DRAW);
      return b;
    };
    const buffers = { p: mk(P), n: mk(N), uv: mk(UV), c: mk(COL), e: mk(EX), l: mk(LOC) };
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const bind = (buf, loc, size) => {
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
    };
    bind(buffers.p, ATTR.aPosition, 3);
    bind(buffers.n, ATTR.aNormal, 3);
    bind(buffers.uv, ATTR.aUv, 2);
    bind(buffers.c, ATTR.aColor, 4);
    bind(buffers.e, ATTR.aExtra, 4);
    bind(buffers.l, ATTR.aLocal, 3);
    buffers.idx = mk(IDX, gl.ELEMENT_ARRAY_BUFFER);
    gl.bindVertexArray(null);
    const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, cz = (minz + maxz) / 2;
    let r = 0;
    for (let i = 0; i < nv; i++) {
      const dx = P[i * 3] - cx, dy = P[i * 3 + 1] - cy, dz = P[i * 3 + 2] - cz;
      const d = dx * dx + dy * dy + dz * dz;
      if (d > r) r = d;
    }
    const bounds = { center: [cx, cy, cz], radius: Math.sqrt(r) };
    this.gpu = { gl, vertexCount: nv, count: ni, bounds, buffers, indexType: big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT, vao, cpu: null };
    const mesh = new Mesh(this.gpu, this.material, 'static:' + (this.members[0].name || ''));
    mesh.baked = true;
    mesh.castShadow = this.castShadow;
    mesh.maxDistance = this.maxDistance;
    mesh.shadowDistance = this.shadowDistance;
    mesh.boundsWorld = [cx, cy, cz, bounds.radius];
    mesh.worldVersion = 1;
    this.mesh = mesh;
  }
}

export class StaticBatcher {
  constructor(gl) {
    this.gl = gl;
    this.batches = [];
    this.ejected = 0;
  }
  // remember the current world versions; nodes that change before build() are treated as moving
  snapshot(scene) {
    scene.traverse((n) => { n._v0 = n.worldVersion; n._w0 = n.world.slice(); });
  }
  static eligible(m) {
    const mat = m.material;
    return !!(m.geometry && m.geometry.cpu && mat && mat.kind === 'standard' && !mat.transparent && !m.instanceBuffer &&
      !m.onBeforeDraw && m.drawMode === null && m.frustumCulled && m.lodMin === undefined && m.lodMax === undefined &&
      !m.boundsWorld && !m.noBatch && !m.baked && !m._skin && !m.skinned);
  }
  // cells: fine cells first (good culling for dense places), then the leftovers (lamps along a road, lone
  // props) get a second chance in coarse cells
  build(scene, { cells = [24, 64] } = {}) {
    let pool = [];
    const visit = (n, dyn) => {
      if (!n.visible) return; // hidden things (quest items, the light stairs before they appear...) stay separate
      const moving = dyn || n.dynamic === true || (n._v0 !== undefined && n.worldVersion !== n._v0);
      if (!moving && n.material && StaticBatcher.eligible(n)) pool.push(n);
      for (const c of n.children) visit(c, moving);
    };
    visit(scene, false);
    let merged = 0;
    for (const cell of cells) {
      const groups = new Map();
      for (const n of pool) {
        const s = n.sphere();
        const key = n.material.id + '|' + (n.castShadow ? 1 : 0) + '|' + n.maxDistance + '|' + n.shadowDistance + '|' +
          Math.floor(s[0] / cell) + ',' + Math.floor(s[2] / cell);
        let g = groups.get(key);
        if (!g) groups.set(key, (g = []));
        g.push(n);
      }
      const rest = [];
      for (const [key, list] of groups) {
        if (list.length < 2) { rest.push(...list); continue; }
        // split very large groups
        let cur = [], verts = 0;
        const flush = () => {
          if (cur.length >= 2) { this.batches.push(new StaticBatch(this, cur, key)); merged += cur.length; }
          else rest.push(...cur);
          cur = []; verts = 0;
        };
        for (const m of list) {
          if (verts + m.geometry.vertexCount > MAX_VERTS) flush();
          cur.push(m);
          verts += m.geometry.vertexCount;
        }
        flush();
      }
      pool = rest;
    }
    for (const b of this.batches) b.rebuild();
    this.merged = merged;
    return { batches: this.batches.length, merged, single: pool.length };
  }
  finish(out, frame) {
    const list = this.batches;
    let alive = 0;
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      if (b.members.length) b.finish(out, frame);
      if (b.members.length) list[alive++] = b;
      else b.dispose();
    }
    list.length = alive;
  }
  // CPU copies of geometry are only needed for batch members (to rebuild after an ejection)
  releaseCpu(scene) {
    if (typeof window !== 'undefined' && window.__keepCpu) return; // debug tools (collision audit) read the meshes
    const keep = new Set();
    for (const b of this.batches) for (const m of b.members) keep.add(m.geometry);
    const drop = (g) => { if (g && g.cpu && !keep.has(g)) g.cpu = null; };
    scene.traverse((n) => drop(n.geometry));
    for (const b of scene.batches) { for (const m of b.mainMeshes) drop(m.geometry); for (const m of b.shadowMeshes) drop(m.geometry); }
  }
}
