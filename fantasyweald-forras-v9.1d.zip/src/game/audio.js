// Generative audio: dreamy pad + music-box melody, wind & crickets, positional water/fire/hum,
// and small sound effects. Everything is synthesized with WebAudio, no samples.
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.started = false;
    this.volumes = { master: 0.8, music: 0.6, ambience: 0.8, sfx: 0.8 };
    this.sources = [];
    this.muted = false;
  }

  start() {
    if (this.started) {
      if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      this.ctx = new AC();
    } catch (e) {
      return;
    }
    this.started = true;
    const c = this.ctx;
    this.master = c.createGain();
    this.master.gain.value = this.volumes.master;
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.ratio.value = 3;
    this.master.connect(comp).connect(c.destination);
    this.reverb = c.createConvolver();
    this.reverb.buffer = this.impulse(4.5, 2.2);
    this.reverbGain = c.createGain();
    this.reverbGain.gain.value = 0.9;
    this.reverb.connect(this.reverbGain).connect(this.master);
    this.musicBus = c.createGain();
    this.musicBus.gain.value = this.volumes.music;
    this.musicBus.connect(this.master);
    this.ambBus = c.createGain();
    this.ambBus.gain.value = this.volumes.ambience;
    this.ambBus.connect(this.master);
    this.sfxBus = c.createGain();
    this.sfxBus.gain.value = this.volumes.sfx;
    this.sfxBus.connect(this.master);
    this.noiseBuf = this.makeNoise(3);
    this.startMusic();
    this.startAmbience();
  }

  setVolume(k, v) {
    this.volumes[k] = v;
    if (!this.ctx) return;
    const node = { master: this.master, music: this.musicBus, ambience: this.ambBus, sfx: this.sfxBus }[k];
    if (node) node.gain.setTargetAtTime(v, this.ctx.currentTime, 0.1);
  }

  impulse(sec, decay) {
    const c = this.ctx;
    const len = Math.floor(c.sampleRate * sec);
    const buf = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
    return buf;
  }
  makeNoise(sec) {
    const c = this.ctx;
    const len = Math.floor(c.sampleRate * sec);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    // pinkish noise
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + w * 0.099;
      b1 = 0.963 * b1 + w * 0.2965;
      b2 = 0.57 * b2 + w * 1.0526;
      d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.2;
    }
    return buf;
  }
  noise(loop = true) {
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = loop;
    s.loopStart = Math.random();
    return s;
  }

  // ------------------------------------------------------------ music
  startMusic() {
    const c = this.ctx;
    const chords = [
      [146.83, 220.0, 261.63, 329.63, 349.23],
      [116.54, 174.61, 220.0, 293.66, 349.23],
      [98.0, 146.83, 174.61, 220.0, 233.08],
      [110.0, 164.81, 196.0, 261.63, 329.63],
    ];
    const melody = [587.33, 698.46, 783.99, 880.0, 1046.5, 1174.66, 1396.9];
    this.padFilter = c.createBiquadFilter();
    this.padFilter.type = 'lowpass';
    this.padFilter.frequency.value = 900;
    this.padFilter.Q.value = 0.7;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.05;
    const lfoG = c.createGain();
    lfoG.gain.value = 350;
    lfo.connect(lfoG).connect(this.padFilter.frequency);
    lfo.start();
    const padOut = c.createGain();
    padOut.gain.value = 0.16;
    this.padFilter.connect(padOut);
    padOut.connect(this.musicBus);
    const send = c.createGain();
    send.gain.value = 0.6;
    padOut.connect(send).connect(this.reverb);
    // delay for melody
    this.delay = c.createDelay(2);
    this.delay.delayTime.value = 0.55;
    const fb = c.createGain();
    fb.gain.value = 0.35;
    this.delay.connect(fb).connect(this.delay);
    const dOut = c.createGain();
    dOut.gain.value = 0.4;
    this.delay.connect(dOut).connect(this.musicBus);
    let chordIdx = 0;
    let nextChord = c.currentTime + 0.3;
    let nextNote = c.currentTime + 3;
    const CH = 9;
    this.musicTimer = setInterval(() => {
      if (!this.ctx) return;
      const now = c.currentTime;
      while (nextChord < now + 1.0) {
        this.playChord(chords[chordIdx % chords.length], nextChord, CH + 3);
        chordIdx++;
        nextChord += CH;
      }
      while (nextNote < now + 1.0) {
        const n = melody[Math.floor(Math.random() * melody.length)];
        this.musicBox(n, nextNote, 0.07 + Math.random() * 0.05);
        if (Math.random() < 0.35) this.musicBox(n * (Math.random() < 0.5 ? 1.5 : 0.75), nextNote + 0.22, 0.05);
        nextNote += 1.2 + Math.random() * 4.5;
      }
    }, 250);
  }
  playChord(notes, t, dur) {
    const c = this.ctx;
    for (const f of notes) {
      for (const det of [-6, 5]) {
        const o = c.createOscillator();
        o.type = 'sawtooth';
        o.frequency.value = f;
        o.detune.value = det + (Math.random() - 0.5) * 4;
        const g = c.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(0.05, t + 3.5);
        g.gain.setValueAtTime(0.05, t + dur - 4);
        g.gain.linearRampToValueAtTime(0, t + dur);
        o.connect(g).connect(this.padFilter);
        o.start(t);
        o.stop(t + dur + 0.1);
      }
    }
    // soft sub
    const s = c.createOscillator();
    s.type = 'sine';
    s.frequency.value = notes[0] / 2;
    const sg = c.createGain();
    sg.gain.setValueAtTime(0, t);
    sg.gain.linearRampToValueAtTime(0.12, t + 3);
    sg.gain.linearRampToValueAtTime(0, t + dur);
    s.connect(sg).connect(this.musicBus);
    s.start(t);
    s.stop(t + dur + 0.1);
  }
  musicBox(f, t, vol) {
    const c = this.ctx;
    const g = c.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0005, t + 2.6);
    for (const [mul, amp] of [[1, 1], [2.01, 0.35], [3.98, 0.12]]) {
      const o = c.createOscillator();
      o.type = 'sine';
      o.frequency.value = f * mul;
      const og = c.createGain();
      og.gain.value = amp;
      o.connect(og).connect(g);
      o.start(t);
      o.stop(t + 2.7);
    }
    g.connect(this.musicBus);
    g.connect(this.delay);
    const rs = c.createGain();
    rs.gain.value = 0.8;
    g.connect(rs).connect(this.reverb);
  }

  // ------------------------------------------------------------ ambience
  startAmbience() {
    const c = this.ctx;
    // wind
    const wind = this.noise();
    const wf = c.createBiquadFilter();
    wf.type = 'bandpass';
    wf.frequency.value = 500;
    wf.Q.value = 0.6;
    const wl = c.createOscillator();
    wl.frequency.value = 0.07;
    const wlg = c.createGain();
    wlg.gain.value = 260;
    wl.connect(wlg).connect(wf.frequency);
    wl.start();
    const wg = c.createGain();
    wg.gain.value = 0.22;
    const wAmp = c.createOscillator();
    wAmp.frequency.value = 0.11;
    const wAmpG = c.createGain();
    wAmpG.gain.value = 0.1;
    wAmp.connect(wAmpG).connect(wg.gain);
    wAmp.start();
    wind.connect(wf).connect(wg).connect(this.ambBus);
    wind.start();
    // crickets: bursts of high chirps
    this.cricketGain = c.createGain();
    this.cricketGain.gain.value = 0.05;
    this.cricketGain.connect(this.ambBus);
    const cr = c.createGain();
    cr.gain.value = 0.25;
    this.cricketGain.connect(cr).connect(this.reverb);
    this.cricketTimer = setInterval(() => {
      if (!this.ctx) return;
      const t = c.currentTime + 0.05;
      const f = 4200 + Math.random() * 900;
      const n = 3 + Math.floor(Math.random() * 4);
      for (let i = 0; i < n; i++) {
        const o = c.createOscillator();
        o.frequency.value = f;
        const g = c.createGain();
        const s = t + i * 0.055;
        g.gain.setValueAtTime(0, s);
        g.gain.linearRampToValueAtTime(0.5, s + 0.008);
        g.gain.linearRampToValueAtTime(0, s + 0.035);
        const p = c.createStereoPanner();
        p.pan.value = Math.random() * 2 - 1;
        o.connect(g).connect(p).connect(this.cricketGain);
        o.start(s);
        o.stop(s + 0.05);
      }
    }, 700);
    // positional loops
    this.water = this.loopSource('water');
    this.falls = this.loopSource('falls');
    this.fire = this.loopSource('fire');
    this.hum = this.loopSource('hum');
    this.crackleTimer = setInterval(() => this.crackle(), 90);
  }
  loopSource(kind) {
    const c = this.ctx;
    const g = c.createGain();
    g.gain.value = 0;
    const pan = c.createStereoPanner();
    g.connect(pan).connect(this.ambBus);
    if (kind === 'water') {
      const n = this.noise();
      const f = c.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = 700;
      const f2 = c.createBiquadFilter();
      f2.type = 'peaking';
      f2.frequency.value = 350;
      f2.gain.value = 6;
      const lfo = c.createOscillator();
      lfo.frequency.value = 0.3;
      const lg = c.createGain();
      lg.gain.value = 200;
      lfo.connect(lg).connect(f.frequency);
      lfo.start();
      n.connect(f).connect(f2).connect(g);
      n.start();
    } else if (kind === 'falls') {
      const n = this.noise();
      const f = c.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = 1200;
      f.Q.value = 0.4;
      n.connect(f).connect(g);
      n.start();
    } else if (kind === 'fire') {
      const n = this.noise();
      const f = c.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = 400;
      n.connect(f).connect(g);
      n.start();
    } else if (kind === 'hum') {
      for (const [fr, a] of [[55, 0.5], [82.4, 0.3], [110.5, 0.2], [164.8, 0.12]]) {
        const o = c.createOscillator();
        o.type = 'sine';
        o.frequency.value = fr;
        const og = c.createGain();
        og.gain.value = a;
        const trem = c.createOscillator();
        trem.frequency.value = 0.2 + Math.random() * 0.3;
        const tg = c.createGain();
        tg.gain.value = a * 0.5;
        trem.connect(tg).connect(og.gain);
        trem.start();
        o.connect(og).connect(g);
        o.start();
      }
      const rs = c.createGain();
      rs.gain.value = 0.5;
      g.connect(rs).connect(this.reverb);
    }
    return { gain: g, pan, level: 0 };
  }
  crackle() {
    if (!this.ctx || !this.fire || this.fire.level < 0.02) return;
    if (Math.random() > 0.5) return;
    const c = this.ctx;
    const t = c.currentTime;
    const s = this.noise(false);
    const f = c.createBiquadFilter();
    f.type = 'highpass';
    f.frequency.value = 1500 + Math.random() * 2500;
    const g = c.createGain();
    g.gain.setValueAtTime(this.fire.level * (0.4 + Math.random() * 0.8), t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03 + Math.random() * 0.04);
    s.connect(f).connect(g).connect(this.fire.pan);
    s.start(t);
    s.stop(t + 0.1);
  }

  // listener update: gains & pans for positional loops
  update(listener, yaw, levels) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const set = (src, level, pos, maxGain) => {
      src.level = level;
      src.gain.gain.setTargetAtTime(level * maxGain, t, 0.3);
      if (pos) {
        const dx = pos[0] - listener[0], dz = pos[2] - listener[2];
        const ang = Math.atan2(dx, dz) - yaw;
        src.pan.pan.setTargetAtTime(clamp(-Math.sin(ang) * 0.8, -0.9, 0.9), t, 0.2);
      }
    };
    set(this.water, levels.water.level, levels.water.pos, 0.35);
    set(this.falls, levels.falls.level, levels.falls.pos, 0.6);
    set(this.fire, levels.fire.level, levels.fire.pos, 0.25);
    set(this.hum, levels.hum.level, levels.hum.pos, 0.18);
    this.cricketGain.gain.setTargetAtTime(levels.crickets * 0.05, t, 0.5);
  }

  // ------------------------------------------------------------ sfx
  step(surface, speed) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime;
    const s = this.noise(false);
    const f = c.createBiquadFilter();
    const g = c.createGain();
    const v = 0.1 + Math.min(speed / 7, 1) * 0.12;
    if (surface === 'stone') {
      f.type = 'bandpass';
      f.frequency.value = 1400 + Math.random() * 600;
      f.Q.value = 1.5;
      g.gain.setValueAtTime(v * 1.6, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
    } else if (surface === 'wood') {
      f.type = 'bandpass';
      f.frequency.value = 500 + Math.random() * 200;
      f.Q.value = 2.5;
      g.gain.setValueAtTime(v * 2.2, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
    } else if (surface === 'water') {
      f.type = 'bandpass';
      f.frequency.value = 900 + Math.random() * 500;
      f.Q.value = 0.8;
      g.gain.setValueAtTime(v * 1.5, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    } else {
      f.type = 'lowpass';
      f.frequency.value = 700 + Math.random() * 400;
      g.gain.setValueAtTime(v * 1.3, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    }
    s.connect(f).connect(g).connect(this.sfxBus);
    s.start(t);
    s.stop(t + 0.3);
  }
  jump() {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    const s = this.noise(false);
    const f = c.createBiquadFilter();
    f.type = 'bandpass';
    f.Q.value = 1.2;
    f.frequency.setValueAtTime(400, t);
    f.frequency.exponentialRampToValueAtTime(1800, t + 0.18);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.18, t + 0.04);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
    s.connect(f).connect(g).connect(this.sfxBus);
    s.start(t);
    s.stop(t + 0.3);
    this.chime([1318.5], 0.03, 0.4);
  }
  // bounce mushroom: a soft rubbery "boing" with a sparkle on top
  bounce() {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(140, t);
    o.frequency.exponentialRampToValueAtTime(520, t + 0.16);
    o.frequency.exponentialRampToValueAtTime(380, t + 0.32);
    const vib = c.createOscillator();
    vib.frequency.value = 22;
    const vg = c.createGain();
    vg.gain.value = 18;
    vib.connect(vg).connect(o.frequency);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.2, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
    o.connect(g).connect(this.sfxBus);
    o.start(t); vib.start(t);
    o.stop(t + 0.4); vib.stop(t + 0.4);
    this.chime([1568, 2093], 0.03, 0.05, 0.6);
  }
  land(strength) {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator();
    o.frequency.setValueAtTime(120, t);
    o.frequency.exponentialRampToValueAtTime(50, t + 0.15);
    const g = c.createGain();
    g.gain.setValueAtTime(0.25 * clamp(strength, 0.3, 1.5), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    o.connect(g).connect(this.sfxBus);
    o.start(t);
    o.stop(t + 0.25);
    this.step('grass', 7);
  }
  chime(freqs, vol = 0.08, spacing = 0.12, rev = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    let t = c.currentTime + 0.02;
    for (const f of freqs) {
      const g = c.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0005, t + 2.2);
      for (const [m, a] of [[1, 1], [2.76, 0.25], [5.4, 0.08]]) {
        const o = c.createOscillator();
        o.frequency.value = f * m;
        const og = c.createGain();
        og.gain.value = a;
        o.connect(og).connect(g);
        o.start(t);
        o.stop(t + 2.3);
      }
      g.connect(this.sfxBus);
      const rs = c.createGain();
      rs.gain.value = rev;
      g.connect(rs).connect(this.reverb);
      t += spacing;
    }
  }
  discover() {
    this.chime([587.33, 739.99, 880, 1108.73, 1318.51, 1760], 0.07, 0.11, 1.4);
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    const s = this.noise(false);
    const f = c.createBiquadFilter();
    f.type = 'highpass';
    f.frequency.setValueAtTime(3000, t);
    f.frequency.exponentialRampToValueAtTime(9000, t + 1.5);
    const g = c.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.06, t + 0.4);
    g.gain.exponentialRampToValueAtTime(0.0005, t + 2.5);
    s.connect(f).connect(g);
    g.connect(this.sfxBus);
    g.connect(this.reverb);
    s.start(t);
    s.stop(t + 2.6);
  }
  talk() {
    this.chime([1046.5, 1567.98], 0.05, 0.08, 0.8);
  }
  click() {
    this.chime([1760], 0.03, 0, 0.3);
  }
  caw(pan = 0) {
    if (!this.ctx) return;
    const c = this.ctx;
    for (let k = 0; k < 2; k++) {
      const t = c.currentTime + k * 0.3 + Math.random() * 0.05;
      const o = c.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(620, t);
      o.frequency.exponentialRampToValueAtTime(380, t + 0.22);
      const f = c.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = 1300;
      f.Q.value = 3;
      const g = c.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.12, t + 0.03);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.26);
      const p = c.createStereoPanner();
      p.pan.value = pan;
      o.connect(f).connect(g).connect(p).connect(this.sfxBus);
      const rs = c.createGain();
      rs.gain.value = 0.3;
      g.connect(rs).connect(this.reverb);
      o.start(t);
      o.stop(t + 0.3);
    }
  }
  flap() {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    for (let k = 0; k < 6; k++) {
      const s = this.noise(false);
      const f = c.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = 600;
      const g = c.createGain();
      const tt = t + k * 0.09;
      g.gain.setValueAtTime(0.0001, tt);
      g.gain.linearRampToValueAtTime(0.12 * (1 - k / 7), tt + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, tt + 0.08);
      s.connect(f).connect(g).connect(this.sfxBus);
      s.start(tt);
      s.stop(tt + 0.1);
    }
  }
  // owl: a soft two-note hoot
  hoot(vol = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t0 = c.currentTime + 0.05;
    [[0, 392, 0.32], [0.55, 370, 0.5]].forEach(([dt, f, len]) => {
      const t = t0 + dt;
      const o = c.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(f * 1.04, t);
      o.frequency.exponentialRampToValueAtTime(f * 0.94, t + len);
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.09 * vol, t + 0.06);
      g.gain.exponentialRampToValueAtTime(0.0008, t + len);
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 900;
      o.connect(lp).connect(g).connect(this.sfxBus);
      const rs = c.createGain();
      rs.gain.value = 0.6;
      g.connect(rs).connect(this.reverb);
      o.start(t);
      o.stop(t + len + 0.05);
    });
  }
  // sky whale: slow, low, gliding song with a shimmering overtone
  whale(vol = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime + 0.1;
    const base = 140 + Math.random() * 60;
    const out = c.createGain();
    out.gain.setValueAtTime(0.0001, t);
    out.gain.linearRampToValueAtTime(0.16 * vol, t + 1.2);
    out.gain.linearRampToValueAtTime(0.12 * vol, t + 3.2);
    out.gain.exponentialRampToValueAtTime(0.0008, t + 5.2);
    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 1200;
    out.connect(lp);
    lp.connect(this.ambBus);
    const rs = c.createGain();
    rs.gain.value = 1.4;
    lp.connect(rs).connect(this.reverb);
    const glide = [1, 1.5, 1.25, 0.9];
    for (const [type, mul, amp] of [['triangle', 1, 1], ['sine', 2.01, 0.35], ['sine', 3.02, 0.12]]) {
      const o = c.createOscillator();
      o.type = type;
      const f = base * mul;
      o.frequency.setValueAtTime(f * glide[0], t);
      o.frequency.linearRampToValueAtTime(f * glide[1], t + 1.6);
      o.frequency.linearRampToValueAtTime(f * glide[2], t + 3.0);
      o.frequency.linearRampToValueAtTime(f * glide[3], t + 5.0);
      const vib = c.createOscillator();
      vib.frequency.value = 4.5;
      const vg = c.createGain();
      vg.gain.value = f * 0.012;
      vib.connect(vg).connect(o.frequency);
      const g = c.createGain();
      g.gain.value = amp;
      o.connect(g).connect(out);
      o.start(t); vib.start(t);
      o.stop(t + 5.4); vib.stop(t + 5.4);
    }
  }
  // falling into water
  splash(k = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime + 0.01;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    const bp = c.createBiquadFilter();
    bp.type = 'lowpass';
    bp.frequency.setValueAtTime(2600, t);
    bp.frequency.exponentialRampToValueAtTime(400, t + 0.5);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.28 * clamp(k, 0.25, 1), t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    s.connect(bp).connect(g).connect(this.sfxBus);
    s.start(t, Math.random() * 2);
    s.stop(t + 0.65);
  }
  // a big frog's croak: two throaty pulses
  croak(vol = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    for (let k = 0; k < 2; k++) {
      const t = c.currentTime + 0.02 + k * 0.22;
      const o = c.createOscillator();
      o.type = 'square';
      o.frequency.setValueAtTime(118, t);
      o.frequency.linearRampToValueAtTime(92, t + 0.16);
      const bp = c.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 420;
      bp.Q.value = 1.6;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.14 * vol, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      o.connect(bp).connect(g).connect(this.sfxBus);
      const rs = c.createGain();
      rs.gain.value = 0.25;
      g.connect(rs).connect(this.reverb);
      o.start(t);
      o.stop(t + 0.2);
    }
  }
  // the Mumus: a low breathing growl, a shriek when it sees you, a thump and a falling moan when it catches you
  mumus(kind, vol = 1, pan = 0) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime + 0.01;
    const out = c.createStereoPanner();
    out.pan.value = pan;
    out.connect(this.sfxBus);
    const wet = c.createGain();
    wet.gain.value = 0.45;
    out.connect(wet).connect(this.reverb);
    if (kind === 'growl') {
      const n = c.createBufferSource();
      n.buffer = this.noiseBuf;
      const bp = c.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(260, t);
      bp.frequency.linearRampToValueAtTime(180, t + 1.8);
      bp.Q.value = 1.2;
      const o = c.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(55, t);
      o.frequency.linearRampToValueAtTime(43, t + 1.8);
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 320;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.2 * vol, t + 0.45);
      g.gain.exponentialRampToValueAtTime(0.001, t + 2.0);
      const og = c.createGain();
      og.gain.value = 0.35;
      n.connect(bp).connect(g);
      o.connect(lp).connect(og).connect(g);
      g.connect(out);
      n.start(t, Math.random() * 2);
      n.stop(t + 2.1);
      o.start(t);
      o.stop(t + 2.1);
    } else if (kind === 'screech') {
      for (const det of [0, 7]) {
        const o = c.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(380 + det, t);
        o.frequency.exponentialRampToValueAtTime(980 + det * 3, t + 0.45);
        o.frequency.exponentialRampToValueAtTime(620, t + 1.1);
        const lfo = c.createOscillator();
        lfo.frequency.value = 13;
        const lg = c.createGain();
        lg.gain.value = 35;
        lfo.connect(lg).connect(o.frequency);
        const bp = c.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.value = 1300;
        bp.Q.value = 2.5;
        const g = c.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.1 * vol, t + 0.08);
        g.gain.exponentialRampToValueAtTime(0.001, t + 1.2);
        o.connect(bp).connect(g).connect(out);
        o.start(t); o.stop(t + 1.25);
        lfo.start(t); lfo.stop(t + 1.25);
      }
    } else if (kind === 'catch') {
      const n = c.createBufferSource();
      n.buffer = this.noiseBuf;
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 240;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.5 * vol, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
      n.connect(lp).connect(g).connect(out);
      n.start(t, Math.random() * 2);
      n.stop(t + 0.55);
      const o = c.createOscillator();
      o.type = 'triangle';
      o.frequency.setValueAtTime(240, t + 0.1);
      o.frequency.exponentialRampToValueAtTime(48, t + 1.6);
      const og = c.createGain();
      og.gain.setValueAtTime(0.0001, t + 0.1);
      og.gain.linearRampToValueAtTime(0.16 * vol, t + 0.25);
      og.gain.exponentialRampToValueAtTime(0.001, t + 1.7);
      o.connect(og).connect(out);
      o.start(t + 0.1); o.stop(t + 1.75);
    }
  }
  // (v8) the Seven-Headed Dragon and its imps: snoring, a growl, the roar, the fire, an imp's shriek
  dragon(kind, vol = 1, pan = 0) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime + 0.01;
    const out = c.createStereoPanner();
    out.pan.value = pan;
    out.connect(this.sfxBus);
    const wet = c.createGain();
    wet.gain.value = kind === 'imp' ? 0.3 : 0.6;
    out.connect(wet).connect(this.reverb);
    const noiseThrough = (type, f0, f1, q, gain, t0, dur, attack = 0.05) => {
      const n = c.createBufferSource();
      n.buffer = this.noiseBuf;
      const f = c.createBiquadFilter();
      f.type = type;
      f.frequency.setValueAtTime(f0, t0);
      f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
      f.Q.value = q;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(gain * vol, t0 + attack);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      n.connect(f).connect(g).connect(out);
      n.start(t0, Math.random() * 2);
      n.stop(t0 + dur + 0.05);
    };
    const saw = (f0, f1, gain, t0, dur, lpf = 400, attack = 0.1) => {
      const o = c.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(f0, t0);
      o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = lpf;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(gain * vol, t0 + attack);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      o.connect(lp).connect(g).connect(out);
      o.start(t0);
      o.stop(t0 + dur + 0.05);
    };
    if (kind === 'snore') {
      noiseThrough('lowpass', 180, 420, 0.8, 0.22, t, 1.6, 1.0);   // in...
      saw(38, 34, 0.12, t + 0.2, 1.4, 160, 0.9);
      noiseThrough('bandpass', 700, 260, 1.2, 0.12, t + 1.9, 1.3, 0.15); // ...and out
    } else if (kind === 'growl') {
      saw(46, 36, 0.22, t, 2.2, 260, 0.5);
      saw(69, 52, 0.12, t + 0.1, 2.0, 380, 0.5);
      noiseThrough('bandpass', 240, 150, 1.4, 0.2, t, 2.3, 0.5);
    } else if (kind === 'roar') {
      // seven throats, each a little different
      for (let i = 0; i < 7; i++) {
        const f = 62 + i * 13 + Math.random() * 6, d = 0.08 * i;
        saw(f, f * 0.62, 0.075, t + d, 2.6, 700 + i * 90, 0.18);
      }
      noiseThrough('bandpass', 380, 140, 0.9, 0.5, t, 2.8, 0.15);
      noiseThrough('lowpass', 120, 60, 0.7, 0.45, t, 2.4, 0.3);
    } else if (kind === 'fire') {
      noiseThrough('bandpass', 1400, 500, 0.6, 0.32, t, 2.1, 0.12);
      noiseThrough('lowpass', 220, 90, 0.7, 0.4, t, 2.0, 0.2);
      saw(52, 40, 0.1, t, 1.9, 200, 0.2);
    } else if (kind === 'imp') {
      for (let k = 0; k < 4; k++) {
        const o = c.createOscillator();
        o.type = 'square';
        const t0 = t + k * 0.11;
        o.frequency.setValueAtTime(1500 + k * 180, t0);
        o.frequency.exponentialRampToValueAtTime(2300 + k * 120, t0 + 0.07);
        o.frequency.exponentialRampToValueAtTime(1100, t0 + 0.1);
        const bp = c.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.value = 2000;
        bp.Q.value = 3;
        const g = c.createGain();
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.linearRampToValueAtTime(0.07 * vol, t0 + 0.015);
        g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.1);
        o.connect(bp).connect(g).connect(out);
        o.start(t0);
        o.stop(t0 + 0.12);
      }
    }
  }
  // (v9) the new creatures and the leviathan
  beast(kind, vol = 1, pan = 0) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime + 0.01;
    const out = c.createStereoPanner();
    out.pan.value = pan;
    out.connect(this.sfxBus);
    const wet = c.createGain();
    wet.gain.value = kind.startsWith('lev') ? 0.9 : kind.startsWith('silent') ? 1.1 : 0.35;
    out.connect(wet).connect(this.reverb);
    const env = (g, t0, a, peak, dur) => {
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(peak * vol, t0 + a);
      g.gain.exponentialRampToValueAtTime(0.0005, t0 + dur);
    };
    const tone = (type, f0, f1, peak, t0, dur, a = 0.02, filt = null) => {
      const o = c.createOscillator();
      o.type = type;
      o.frequency.setValueAtTime(f0, t0);
      o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t0 + dur);
      const g = c.createGain();
      env(g, t0, a, peak, dur);
      let n = o;
      if (filt) { const f = c.createBiquadFilter(); f.type = filt[0]; f.frequency.value = filt[1]; f.Q.value = filt[2] || 0.8; n = n.connect(f); }
      n.connect(g).connect(out);
      o.start(t0);
      o.stop(t0 + dur + 0.05);
      return o;
    };
    const hiss = (type, f0, f1, q, peak, t0, dur, a = 0.05) => {
      const n = c.createBufferSource();
      n.buffer = this.noiseBuf;
      const f = c.createBiquadFilter();
      f.type = type;
      f.frequency.setValueAtTime(f0, t0);
      f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
      f.Q.value = q;
      const g = c.createGain();
      env(g, t0, a, peak, dur);
      n.connect(f).connect(g).connect(out);
      n.start(t0, Math.random() * 2);
      n.stop(t0 + dur + 0.05);
    };
    if (kind === 'hogSqueak') {
      tone('sine', 1900, 2600, 0.05, t, 0.09);
      tone('sine', 2300, 1700, 0.04, t + 0.1, 0.12);
      this.chime([2637, 3136, 3951], 0.012, 0.04, 0.5);
    } else if (kind === 'hogHappy') {
      hiss('bandpass', 2600, 1800, 3, 0.05, t, 0.18, 0.02);
      hiss('bandpass', 2400, 1600, 3, 0.05, t + 0.25, 0.18, 0.02);
      this.chime([1568, 2093, 2637], 0.02, 0.06, 0.6);
    } else if (kind === 'foxYip') {
      tone('triangle', 900, 1500, 0.07, t, 0.07, 0.01, ['bandpass', 1300, 2]);
      tone('triangle', 1100, 700, 0.06, t + 0.09, 0.12, 0.01, ['bandpass', 1100, 2]);
      hiss('highpass', 5000, 7000, 0.7, 0.03, t, 0.5, 0.05); // the rustle of wings
    } else if (kind === 'bakuHum') {
      // (v9.1b) the mist ray's call: a soft, rising whale-song glide with a glassy shimmer
      tone('sine', 392, 587, 0.05, t, 1.3, 0.35);
      tone('sine', 587, 494, 0.04, t + 0.7, 1.4, 0.4);
      tone('triangle', 196, 220, 0.025, t, 2.0, 0.5);
      this.chime([1568, 2093, 2637], 0.012, 0.12, 0.9);
    } else if (kind === 'spiderHiss') {
      hiss('highpass', 2500, 4200, 0.6, 0.22, t, 0.7, 0.03);
      hiss('bandpass', 900, 500, 1.5, 0.12, t, 0.5, 0.02);
      for (let k = 0; k < 6; k++) hiss('bandpass', 3000 + k * 200, 2500, 6, 0.1, t + 0.05 + k * 0.07, 0.03, 0.002);
    } else if (kind === 'silentChime') {
      // a single cold note, as if someone had brushed a glass
      tone('sine', 1567.98, 1561, 0.035, t, 2.4, 0.01);
      tone('sine', 2349.3, 2340, 0.018, t, 1.8, 0.01);
    } else if (kind === 'silentWhisper') {
      for (let k = 0; k < 5; k++) hiss('bandpass', 1800 + Math.random() * 1600, 900 + Math.random() * 600, 4, 0.08, t + k * 0.16, 0.35, 0.06);
      tone('sine', 220, 207, 0.05, t, 2.2, 0.4);
      tone('sine', 233.08, 220, 0.04, t, 2.2, 0.4);
    } else if (kind === 'levMoan') {
      // a whale song gone wrong: two deep voices sliding against each other
      tone('sawtooth', 58, 41, 0.1, t, 5.5, 1.4, ['lowpass', 220, 0.9]);
      tone('sawtooth', 61, 44, 0.08, t + 0.4, 5.2, 1.6, ['lowpass', 260, 0.9]);
      tone('sine', 176, 110, 0.05, t + 1.2, 4.0, 1.2);
      hiss('lowpass', 160, 70, 0.7, 0.18, t, 5.5, 1.5);
    } else if (kind === 'levSurface') {
      hiss('lowpass', 900, 180, 0.6, 0.45, t, 3.2, 0.25);
      hiss('bandpass', 1400, 400, 0.8, 0.25, t + 0.1, 2.6, 0.3);
      tone('sawtooth', 44, 33, 0.12, t, 3.5, 0.6, ['lowpass', 180, 0.8]);
    } else if (kind === 'levStrike') {
      hiss('lowpass', 1600, 150, 0.6, 0.7, t, 2.2, 0.05);
      hiss('bandpass', 700, 200, 1.0, 0.4, t, 1.8, 0.05);
      for (let i = 0; i < 4; i++) tone('sawtooth', 70 + i * 17, 38 + i * 9, 0.09, t + i * 0.05, 2.4, 0.08, ['lowpass', 520 + i * 80, 0.8]);
    } else if (kind === 'levSwallow') {
      hiss('lowpass', 400, 60, 0.7, 0.5, t, 1.4, 0.02);
      tone('sine', 55, 30, 0.2, t, 1.3, 0.02);
    }
  }
  // the cloud bell: a deep bronze strike with a long tail
  bell() {
    if (!this.ctx) return;
    this.chime([146.83, 220.0, 293.66], 0.11, 0.02, 2.2);
    this.chime([587.33], 0.03, 0, 1.5);
  }
  // wind well: a rising whoosh of filtered noise
  gust(vol = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    const t = c.currentTime + 0.02;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 0.9;
    bp.frequency.setValueAtTime(300, t);
    bp.frequency.exponentialRampToValueAtTime(1400, t + 1.4);
    bp.frequency.exponentialRampToValueAtTime(700, t + 2.6);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.22 * vol, t + 0.5);
    g.gain.exponentialRampToValueAtTime(0.001, t + 2.8);
    s.connect(bp).connect(g).connect(this.sfxBus);
    const rs = c.createGain();
    rs.gain.value = 0.5;
    g.connect(rs).connect(this.reverb);
    s.start(t, Math.random() * 1.5);
    s.stop(t + 2.9);
  }
  suspend() {
    if (this.ctx && this.ctx.state === 'running') this.ctx.suspend();
  }
  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }
}
