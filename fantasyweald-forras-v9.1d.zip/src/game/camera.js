// Third-person orbit camera with collision against terrain and solid things, and gentle auto-follow.
import { clamp, damp, lerp, angleDiff } from '../engine/math.js';
import { PLAYER_SCALE } from './player.js';

// The original (v6) third-person camera: it orbits a point just above the gnome's head.
const PIVOT = 0.95 * PLAYER_SCALE;
const LOOK_UP = 0.15;
const GROUND_CLEAR = 0.3;

export class FollowCamera {
  constructor(camera, world) {
    this.cam = camera;
    this.world = world;
    this.yaw = Math.PI;
    this.pitch = 0.26;
    this.dist = 4.6;
    this.targetDist = 4.6;
    this.minDist = 1.8;
    this.maxDist = 14;
    this.target = [0, 0, 0];
    this.lastManual = -10;
    this.shake = 0;
    this.fovBase = 55;
    this.override = null; // {pos, target} for cinematic moments
    this.overrideBlend = 0;
    this.pullIn = 1;
  }
  gazeUp(angle = 0.5, seconds = 5, delay = 0) {
    this.gazeAngle = angle;
    this.lookUp = seconds;
    this.gazeDelay = delay;
  }
  snap(player) {
    this.aim = 0;
    this.lookUp = 0;
    this.gazeDelay = 0;
    this.target = this.pivot(player);
    this.yaw = player.yaw;
    this.update(0, null, player, 0, true);
  }
  pivot(player) {
    return [player.pos[0], player.visY + PIVOT, player.pos[2]];
  }
  update(dt, input, player, time, instant = false) {
    if (input) {
      const [dx, dy] = input.consumeLook();
      if (dx || dy) { this.lastManual = time; if (this.gazeDelay <= 0) this.lookUp = 0; }
      this.yaw -= dx * 0.0042;
      this.pitch = clamp(this.pitch + dy * 0.0032, -0.5, 1.25);
      const z = input.consumeZoom();
      if (z) this.targetDist = clamp(this.targetDist * (1 + z * 0.12), this.minDist, this.maxDist);
      const hs = Math.hypot(player.vel[0], player.vel[2]);
      if (time - this.lastManual > 2.5 && hs > 1.0) {
        const [mx, my] = input.moveVector();
        if (my > 0.3 && Math.abs(mx) < 0.5) this.yaw += angleDiff(this.yaw, player.yaw) * (1 - Math.exp(-0.9 * dt));
      }
    }
    if (this.gazeDelay > 0) this.gazeDelay -= dt;
    else if (this.lookUp > 0) this.lookUp -= dt;
    const aimT = this.gazeDelay <= 0 && this.lookUp > 0 ? this.gazeAngle : 0;
    this.aim = damp(this.aim || 0, aimT, aimT > 0 ? 1.1 : 0.7, dt);
    const hp = this.pivot(player);
    if (instant) this.target = hp.slice();
    else {
      this.target[0] = damp(this.target[0], hp[0], 14, dt);
      this.target[1] = damp(this.target[1], hp[1], 9, dt);
      this.target[2] = damp(this.target[2], hp[2], 14, dt);
    }
    this.dist = instant ? this.targetDist : damp(this.dist, this.targetDist, 6, dt);
    const fx = Math.sin(this.yaw), fz = Math.cos(this.yaw);
    const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    // the camera hugs whatever is under it (terrain, bridges, stairs, mushroom caps, the water surface):
    // down here a slope or a bridge deck would otherwise swallow the lens
    this.swimLift = instant ? (player.swimming ? 1 : 0) : damp(this.swimLift || 0, player.swimming ? 1 : 0, 3, dt);
    const WL = this.world.L.waterLevel;
    const floorY = WL + 0.2 + 0.5 * this.swimLift;
    const lift = (px, pz, py) => Math.max(py, this.world.groundHeight(px, pz, py, 0.6) + GROUND_CLEAR, floorY);
    // collision: march from the target outwards, stop before anything solid
    const P = this.world.physics;
    let d = this.dist;
    const steps = 12;
    for (let i = 1; i <= steps; i++) {
      const t = (i / steps) * this.dist;
      const px = this.target[0] - fx * cp * t, pz = this.target[2] - fz * cp * t;
      const py = lift(px, pz, this.target[1] + sp * t);
      if (P.pointSolid(px, py, pz)) {
        d = Math.max(0.5, t - this.dist / steps * 0.8);
        break;
      }
    }
    // pull in quickly, ease back out slowly (no popping)
    this.pullIn = instant ? d : d < this.pullIn ? d : damp(this.pullIn, d, 3, dt);
    d = Math.min(d, this.pullIn);
    let pos = [this.target[0] - fx * cp * d, this.target[1] + sp * d, this.target[2] - fz * cp * d];
    // rise at once when something is under the lens, settle back down gently
    const up = lift(pos[0], pos[2], pos[1]) - pos[1];
    this.camLift = instant ? up : Math.max(up, damp(this.camLift || 0, up, 5, dt));
    pos[1] += this.camLift;
    let tgt = [this.target[0], this.target[1] + LOOK_UP + Math.tan(this.aim || 0) * d * cp, this.target[2]];
    if (this.override) this.overrideBlend = damp(this.overrideBlend, 1, 2.5, dt);
    else this.overrideBlend = damp(this.overrideBlend, 0, 3, dt);
    if (this.overrideBlend > 0.001 && (this.override || this.lastOverride)) {
      const o = this.override || this.lastOverride;
      const b = this.overrideBlend * this.overrideBlend * (3 - 2 * this.overrideBlend);
      pos = pos.map((v, i) => lerp(v, o.pos[i], b));
      tgt = tgt.map((v, i) => lerp(v, o.target[i], b));
    }
    if (this.override) this.lastOverride = this.override;
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt * 2);
      pos[1] += Math.sin(time * 40) * this.shake * 0.05;
    }
    this.cam.position = pos;
    this.cam.target = tgt;
    const run = clamp(Math.hypot(player.vel[0], player.vel[2]) / 5, 0, 1.3);
    this.cam.fov = ((this.fovBase + run * 6) * Math.PI) / 180;
  }
}
