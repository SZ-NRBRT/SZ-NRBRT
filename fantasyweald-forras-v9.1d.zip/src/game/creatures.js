// The dream creatures: ambient life all over the map (most of them don't talk, they just live there),
// plus the bestiary that remembers which kinds you have met.
import { buildMushroomFolk, buildMoonRabbit, buildStiltWalker, buildDreamCat, buildOwl, buildSkyKoi, buildSkyWhale, moths } from '../models/creatures.js';
import { RNG, clamp, damp, lerp, angleDiff, TAU, smoothstep } from '../engine/math.js';
import { C } from '../models/materials.js';
import { LINES } from '../data/dialogue.js';
import { Wanderers } from './wanderers.js';
import { Mumus } from './mumus.js';
import { Realm } from './realm.js';
import { Fauna } from './fauna.js';
import { Leviathan } from './leviathan.js';

export const SPECIES = [
  { id: 'shroomling', name: 'Pöfetegek', blurb: 'Térdig érő, sétáló gombák. Ha észreveszik, hogy nézed őket, leguggolnak, és egyszerű gombának tettetik magukat.' },
  { id: 'rabbit', name: 'Holdnyulak', blurb: 'Fénylő fülű nyulak a réteken. Aki lopakodva jön, azt egészen közel engedik.' },
  { id: 'stilt', name: 'Gólyalábú vándorok', blurb: 'Hosszú lábakon lépkedő lámpásvivők. Senki sem tudja, honnan jönnek, és hová tartanak.' },
  { id: 'cat', name: 'Álommacskák', blurb: 'A háztetőkön ülnek, és mindent látnak. Az egyikük beszél is, ha épp kedve van.' },
  { id: 'owl', name: 'Álombaglyok', blurb: 'Borostyánszemükkel követik a vándort. Huhogásuk a mélyerdő harangja.' },
  { id: 'koi', name: 'Égi pontyok', blurb: 'Úgy úsznak a levegőben, mintha az éjszaka is víz volna.' },
  { id: 'moth', name: 'Holdmolyok', blurb: 'A lámpások körül keringenek, és fényport szórnak.' },
  { id: 'whale', name: 'Égi bálnák', blurb: 'Az erdő fölött vonulnak, és néha énekelnek. A felhőpásztor hívására leereszkednek.' },
  { id: 'sheep', name: 'Felhőbárányok', blurb: 'Pihe-puha felhőből vannak, és hajlamosak elkószálni.' },
  { id: 'stag', name: 'Holdszarvas', blurb: 'Fénylő agancsú szellemszarvas. Csak a csendes vándort engedi közel.' },
  { id: 'snail', name: 'Óriáscsiga', blurb: 'Lassan vonul az úton, és senkinek sem tér ki.' },
  { id: 'crow', name: 'Varjak', blurb: 'Fekete őrszemek a köveken. Ha közel mész, felrebbennek.' },
  { id: 'fish', name: 'Fénylő halak', blurb: 'Kiugranak a vízből, ha arra jársz, és egy pillanatra fényt hoznak fel a mélyből.' },
  { id: 'jelly', name: 'Égi medúzák', blurb: 'Lámpásként lebegnek a magasban, a kristályok felett.' },
  { id: 'wisp', name: 'Lidércek', blurb: 'A lápon táncoló fények. Aki követi őket, eltéved… vagy valami szépet talál.' },
  { id: 'frog', name: 'Lápi békák', blurb: 'Bölcs, öreg békák a láp szélén. Brekus mindent tud, csak kérdezni kell tőle.' },
  { id: 'colossus', name: 'Lépegető óriások', blurb: 'Magasabbak a legmagasabb fánál is. Lassan járják körbe a világot, szárazon és vízen, és sosem néznek le.' },
  { id: 'turtle', name: 'Dombteknős', blurb: 'Egy egész kert nő a hátán. Ha a szél felkap mellette, fel is szállhatsz rá.' },
  { id: 'mumus', name: 'A Mumus', blurb: 'A zsákos ember a régi mesékből. Sötét helyeken csoszog, és akit észrevesz, azt a zsákjába dugja. Lopakodj, fuss előle, vagy ugorj vízbe!' },
  { id: 'plush', name: 'Plüssnyuszik', blurb: 'Óriási, kopott plüssnyulak, amelyek maguktól járják az utakat. Gombszemük van, és mindig integetnek. Talán azt a gyereket keresik, akié voltak.' },
  { id: 'eyeflower', name: 'Szemvirágok', blurb: 'Gyökérlábakon járó, magas virágok, a szirmaik közepén egy nagy, pislogó szemmel. Bárhová mész, utánad néznek.' },
  { id: 'dragon', name: 'A Hétfejű', blurb: 'Hétfejű sárkány a Hamuszigeten, messze kint a tengeren. A kincsén alszik, de a zajra felébred, és mind a hét feje tüzet okád. Csak lopakodva szabad a közelébe menni.' },
  { id: 'imp', name: 'Parázsmanók', blurb: 'A Hétfejű apró szolgái. Vasvillával járják a szigetet, és ha meglátnak, visítva ébresztik a gazdájukat. A vizet ki nem állhatják.' },
  { id: 'lampling', name: 'Lámpások', blurb: 'Kis papírlámpások lábakkal. Kíváncsiak: ha közel mész, egy darabig a nyomodban totyognak.' },
  { id: 'starhog', name: 'Csillagsünök', blurb: 'A tüskéik apró kristályok, a hegyükön csillagfény ül. Ha megijednek, ragyogó gombóccá gömbölyödnek. Aki lassan jön, megsimogathatja őket.' },
  { id: 'mothfox', name: 'Lepkerókák', blurb: 'Kis rókák puha lepkeszárnyakkal a hátukon. Kíváncsiak, de félénkek: ha csendben megállsz, leülnek, és téged néznek.' },
  { id: 'baku', name: 'Ködráják', blurb: 'Ráják, amelyek a levegőben úsznak a fák között. A szárnyuk lassú hullámokban mozog, a hátukon csillagképek derengenek. A levegőből szűrik ki a rossz álmokat, és elnyelik őket. Ha csendben megállsz, leereszkednek hozzád.' },
  { id: 'rootspider', name: 'Gyökérpókok', blurb: 'Korhadt tuskónak tettetik magukat a holt erdőben és a lápon. Ha túl közel mész, nyolc gyökérlábon felágaskodnak. Lopakodva elkerülheted őket.' },
  { id: 'silent', name: 'A Csendesek', blurb: 'Agancsos, álarcos árnyak a fenyvesben és a holt erdőben. Amíg nézed őket, meg sem mozdulnak. Ne fordíts nekik hátat.' },
  { id: 'leviathan', name: 'A Mélység Lámpása', blurb: 'Az álomtenger mélyén úszik, akkora, mint egy sziget. A lámpását előbb látod, mint őt. Ha a víz alatt fény közeledik feléd, ússz a partra, amilyen gyorsan csak tudsz.' },
];

const hyp = (x, z) => Math.sqrt(x * x + z * z);

export class Creatures {
  constructor(npcs) {
    this.npcs = npcs;
    this.game = npcs.game;
    this.world = npcs.world;
    this.scene = npcs.scene;
    this.ctx = npcs.ctx;
    this.rng = new RNG(this.world.L.seed + 777);
    this.list = [];      // { update(dt, t, player, near) } with a position for distance throttling
    this.watch = [];     // bestiary: { id, range, points() }
    this.seenTimer = 0;
    this.buildShroomlings();
    this.buildRabbits();
    this.buildStiltWalkers();
    this.buildCats();
    this.buildOwls();
    this.buildKoi();
    this.buildMoths();
    this.buildWhales();
    this.wanderers = new Wanderers(this);
    this.fauna = new Fauna(this);
    this.leviathan = new Leviathan(this);
    {
      const lev = this.leviathan;
      this.list.push({ update: (dt, t, player) => lev.update(dt, t, player) });
      this.watch.push({ id: 'leviathan', range: 190, points: () => (lev.revealed ? [[lev.h.x, this.world.L.waterLevel, lev.h.z]] : []) });
    }
    this.mumus = new Mumus(this);
    this.realm = new Realm(this);
    this.watchExisting();
  }

  // ---------------------------------------------------------------- helpers
  groundAt(x, z) {
    return Math.max(this.world.h(x, z), this.world.L.waterLevel - 0.1);
  }
  freeSpot(cx, cz, r, tries = 40) {
    const W = this.world, rng = this.rng;
    for (let i = 0; i < tries; i++) {
      const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * r;
      const x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
      if (W.waterDepth(x, z) > -0.25) continue;
      const g = W.h(x, z);
      if (W.physics.ground(x, z, g + 0.3) > g + 0.35) continue; // on something
      if (W.physics.blocked(x, z, g, 0.3, 1.0, 0.5)) continue;
      return [x, z];
    }
    return null;
  }
  add(rig, maxDistance = 80) {
    rig.root.traverse((n) => {
      if (!n.geometry) return;
      n.maxDistance = maxDistance;
      if (n.geometry.bounds.radius < 0.25) n.castShadow = false;
    });
    this.scene.add(rig.root);
  }

  // ---------------------------------------------------------------- mushroom folk
  buildShroomlings() {
    const S = this.world.L.sites;
    const groups = [
      { c: [S.mushroom.x, S.mushroom.z], ring: [44, 62], n: 3, kind: 0 },
      { c: [S.mushroom.x, S.mushroom.z], ring: [44, 62], n: 3, kind: 2 },
      { c: [S.amanita.x, S.amanita.z], ring: [16, 30], n: 3, kind: 1 },
      { c: [S.swamp.x, S.swamp.z], ring: [18, 30], n: 2, kind: 2 },
      { c: [S.village.x, S.village.z], ring: [26, 36], n: 2, kind: 1 },
    ];
    const all = [];
    groups.forEach((g, gi) => {
      const a = this.rng.range(0, TAU), d = this.rng.range(g.ring[0], g.ring[1]);
      const home = this.freeSpot(g.c[0] + Math.cos(a) * d, g.c[1] + Math.sin(a) * d, 8) || [g.c[0] + Math.cos(a) * d, g.c[1] + Math.sin(a) * d];
      for (let i = 0; i < g.n; i++) {
        const p = this.freeSpot(home[0], home[1], 4) || home;
        const rig = buildMushroomFolk(this.ctx, 300 + gi * 10 + i, g.kind + (i === 1 ? 1 : 0));
        this.add(rig, 75);
        const c = { rig, home, x: p[0], z: p[1], yaw: this.rng.range(0, TAU), state: 'wander', t: 0, target: null, wait: this.rng.range(0, 3), speed: 0, phase: this.rng.range(0, 10), squat: 0, calm: 0 };
        all.push(c);
      }
    });
    this.shroomlings = all;
    const W = this.world;
    this.list.push({
      update: (dt, t, player) => {
        const sneaking = player.sneaking;
        const pv = Math.hypot(player.vel[0], player.vel[2]);
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z;
          const pd = hyp(dxp, dzp);
          if (pd > 95) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = true;
          const b = c.rig.bones;
          c.t += dt;
          const noticed = pd < 6.5 && !sneaking && (pv > 0.85 || pd < 3) && Math.abs(player.pos[1] - W.h(c.x, c.z)) < 3;
          if (c.state !== 'freeze' && noticed) { c.state = 'freeze'; c.t = 0; }
          if (c.state === 'freeze') {
            c.squat = damp(c.squat, 1, 14, dt);
            if (pd > 9) c.calm += dt; else c.calm = 0;
            if (c.calm > 2.2) {
              c.state = 'flee'; c.t = 0; c.calm = 0;
              c.yaw = Math.atan2(-dxp, -dzp) + this.rng.range(-0.5, 0.5);
            }
          } else {
            c.squat = damp(c.squat, 0, 5, dt);
            if (c.state === 'flee') {
              c.speed = damp(c.speed, 1.9, 4, dt);
              if (c.t > 3.5) { c.state = 'wander'; c.target = null; c.wait = 1; }
            } else {
              if (!c.target) {
                c.wait -= dt;
                c.speed = damp(c.speed, 0, 6, dt);
                if (c.wait <= 0) {
                  c.target = this.freeSpot(c.home[0], c.home[1], 11, 6);
                  c.wait = this.rng.range(1.5, 5);
                }
              } else {
                const tx = c.target[0] - c.x, tz = c.target[1] - c.z, tdist = hyp(tx, tz);
                if (tdist < 0.4) c.target = null;
                else {
                  c.yaw += angleDiff(c.yaw, Math.atan2(tx, tz)) * Math.min(1, dt * 4);
                  c.speed = damp(c.speed, 0.7, 4, dt);
                }
              }
            }
            const nx = c.x + Math.sin(c.yaw) * c.speed * dt, nz = c.z + Math.cos(c.yaw) * c.speed * dt;
            const g = W.h(c.x, c.z);
            if (c.speed > 0.05 && (W.physics.blocked(nx, nz, g, 0.18, 0.6, 0.35, c.x, c.z) || W.waterDepth(nx, nz) > -0.15 || hyp(nx - c.home[0], nz - c.home[1]) > 22)) {
              c.target = null; c.yaw += Math.PI * 0.6; c.speed = 0;
            } else { c.x = nx; c.z = nz; }
          }
          // pose
          const walk = c.speed > 0.08 ? 1 : 0;
          c.phase += dt * (4 + c.speed * 7) * walk;
          const sw = Math.sin(c.phase) * walk * (1 - c.squat);
          const y = W.h(c.x, c.z);
          c.rig.root.setPos(c.x, y - c.squat * 0.08, c.z);
          c.rig.root.setRotY(c.yaw);
          b.body.position[1] = 0.14 + Math.abs(Math.sin(c.phase)) * 0.03 * walk - c.squat * 0.1;
          b.body.scale[1] = 1 - c.squat * 0.25;
          b.body.scale[0] = b.body.scale[2] = 1 + c.squat * 0.12;
          b.body.setEuler(0, 0, Math.sin(c.phase * 0.5) * 0.08 * walk);
          b.legL.setEuler(sw * 0.6, 0, 0);
          b.legR.setEuler(-sw * 0.6, 0, 0);
          b.armL.setEuler(-sw * 0.7 - c.squat * 0.6, 0, 0.2 + c.squat * 0.4);
          b.armR.setEuler(sw * 0.7 - c.squat * 0.6, 0, -0.2 - c.squat * 0.4);
          const blink = Math.sin(t * 0.9 + c.phase * 0.1) > 0.985 ? 0.1 : 1;
          const eyeOpen = Math.max(0, 1 - c.squat * 1.3) * blink;
          b.eyes.setScale(1, Math.max(0.02, eyeOpen), 1);
          b.cap.setEuler(Math.sin(c.phase * 0.5) * 0.06 * walk, Math.sin(t * 0.4 + c.home[0]) * 0.15 * (1 - walk), 0);
          b.cap.position[1] = 0.23 - c.squat * 0.02;
        }
      },
    });
    this.watch.push({ id: 'shroomling', range: 14, points: () => all.map((c) => [c.x, 0, c.z]) });
    // one of them can be talked to (it pretends to be a mushroom)
    const first = all[0];
    if (first) {
      const it = this.npcs.addInteract({ id: 'shroomling', name: 'Pöfeteg', pos: [first.x, 0, first.z], radius: 2.4, kind: 'talk', lines: LINES.shroomling });
      this.list.push({ update: () => { it.pos[0] = first.x; it.pos[1] = W.h(first.x, first.z) + 0.3; it.pos[2] = first.z; } });
    }
  }

  // ---------------------------------------------------------------- moon rabbits
  buildRabbits() {
    const S = this.world.L.sites, W = this.world;
    const homes = [[S.glade, 26, 3], [S.moongarden, 22, 3], [S.village, 34, 2], [S.islands, 26, 2], [S.lake, S.lake.lakeR + 12, 2]];
    const all = [];
    homes.forEach(([s, r, n], hi) => {
      for (let i = 0; i < n; i++) {
        const a = this.rng.range(0, TAU);
        const p = this.freeSpot(s.x + Math.cos(a) * r, s.z + Math.sin(a) * r, 10) || this.freeSpot(s.x, s.z, r + 8);
        if (!p) continue;
        const rig = buildMoonRabbit(this.ctx, 500 + hi * 7 + i);
        this.add(rig, 70);
        all.push({ rig, home: p.slice(), x: p[0], z: p[1], yaw: this.rng.range(0, TAU), hop: 0, hopT: 0, state: 'idle', t: this.rng.range(0, 3), nib: 0, flee: 0 });
      }
    });
    this.rabbits = all;
    this.list.push({
      update: (dt, t, player) => {
        const pv = Math.hypot(player.vel[0], player.vel[2]);
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z;
          const pd = hyp(dxp, dzp);
          if (pd > 90) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = true;
          const b = c.rig.bones;
          c.t -= dt;
          const scared = pd < 7.5 && !player.sneaking && pv > 0.56;
          if (scared && c.flee <= 0) { c.flee = 2.8; c.yaw = Math.atan2(-dxp, -dzp) + this.rng.range(-0.4, 0.4); c.hopT = 0; }
          c.flee -= dt;
          // hopping: short parabolic hops, faster when fleeing
          if (c.hopT > 0) {
            c.hopT -= dt;
            const dur = c.flee > 0 ? 0.28 : 0.36;
            const u = 1 - Math.max(0, c.hopT) / dur;
            const sp = c.flee > 0 ? 5.5 : 1.6;
            const nx = c.x + Math.sin(c.yaw) * sp * dt, nz = c.z + Math.cos(c.yaw) * sp * dt;
            if (W.waterDepth(nx, nz) > -0.2 || W.physics.blocked(nx, nz, W.h(c.x, c.z), 0.15, 0.4, 0.3, c.x, c.z) || hyp(nx - c.home[0], nz - c.home[1]) > 26) { c.yaw += 2.2; }
            else { c.x = nx; c.z = nz; }
            c.hop = Math.sin(u * Math.PI) * (c.flee > 0 ? 0.35 : 0.2);
          } else {
            c.hop = 0;
            if (c.flee > 0) c.hopT = 0.28;
            else if (c.t <= 0) {
              if (this.rng.chance(0.55)) { c.hopT = 0.36; c.yaw += this.rng.range(-0.8, 0.8); c.t = this.rng.range(0.1, 0.5); if (this.rng.chance(0.3)) c.t = this.rng.range(1.5, 4); }
              else { c.nib = this.rng.range(1.5, 3.5); c.t = c.nib + 0.3; }
            }
          }
          c.nib = Math.max(0, c.nib - dt);
          const y = this.groundAt(c.x, c.z);
          c.rig.root.setPos(c.x, y + c.hop, c.z);
          c.rig.root.setRotY(c.yaw);
          b.body.setEuler(c.hopT > 0 ? -0.25 * Math.sin((c.hop / 0.35) * Math.PI) : 0, 0, 0);
          const nibble = c.nib > 0 ? 1 : 0;
          b.head.setEuler(0.5 * nibble + Math.sin(t * 9 + c.home[0]) * 0.05 * nibble, Math.sin(t * 0.5 + c.home[1]) * 0.3 * (1 - nibble), 0);
          const twitch = Math.sin(t * 3.1 + c.home[0]) > 0.93 ? 0.25 : 0;
          b.earL.setEuler(-0.25 - (c.flee > 0 ? 0.6 : 0) + twitch, 0, 0.18);
          b.earR.setEuler(-0.25 - (c.flee > 0 ? 0.6 : 0), 0, -0.18 - twitch * 0.5);
          const leg = c.hopT > 0 ? -0.9 * Math.sin((c.hop / 0.35) * Math.PI) : 0;
          b.legL.setEuler(leg, 0, 0);
          b.legR.setEuler(leg, 0, 0);
        }
      },
    });
    this.watch.push({ id: 'rabbit', range: 14, points: () => all.map((c) => [c.x, 0, c.z]) });
  }

  // ---------------------------------------------------------------- stilt walkers along the long roads
  buildStiltWalkers() {
    const W = this.world, T = W.terrain;
    const routes = [['rune', 'lake'], ['village', 'swamp'], ['glade', 'mushroom']];
    const all = [];
    routes.forEach(([a, b], i) => {
      const p = T.paths.find((q) => (q.from === a && q.to === b) || (q.from === b && q.to === a));
      if (!p) return;
      const pts = p.pts;
      const rig = buildStiltWalker(this.ctx, 40 + i);
      this.add(rig, 200);
      const light = this.scene.addLight({ node: rig.bones.lamp, color: C('#ffc070'), intensity: 2.2, radius: 9, flicker: 0.1 });
      // walk on the side of the road
      const side = i % 2 ? 1 : -1;
      const path = pts.map((q, k) => {
        const nq = pts[Math.min(pts.length - 1, k + 1)], pq = pts[Math.max(0, k - 1)];
        const dx = nq[0] - pq[0], dz = nq[1] - pq[1], l = hyp(dx, dz) || 1;
        const off = (p.width || 3) / 2 + 1.2;
        return [q[0] - (dz / l) * off * side, q[1] + (dx / l) * off * side];
      });
      const len = [0];
      for (let k = 1; k < path.length; k++) len.push(len[k - 1] + hyp(path[k][0] - path[k - 1][0], path[k][1] - path[k - 1][1]));
      all.push({ rig, light, path, len, total: len[len.length - 1], s: this.rng.range(0, len[len.length - 1]), dir: this.rng.sign(), x: 0, z: 0, yaw: 0, phase: 0, stop: 0, look: 0, id: 'stilt' + i });
    });
    const at = (c, s) => {
      s = clamp(s, 0, c.total);
      let k = 1;
      while (k < c.len.length - 1 && c.len[k] < s) k++;
      const u = (s - c.len[k - 1]) / Math.max(1e-4, c.len[k] - c.len[k - 1]);
      const a = c.path[k - 1], b = c.path[k];
      return [lerp(a[0], b[0], u), lerp(a[1], b[1], u), Math.atan2(b[0] - a[0], b[1] - a[1])];
    };
    this.stilts = all;
    this.list.push({
      update: (dt, t, player) => {
        for (const c of all) {
          const pd = hyp(player.pos[0] - c.x, player.pos[2] - c.z);
          // it pauses to look at you when you come close
          const near = pd < 7;
          c.stop = damp(c.stop, near ? 1 : 0, 3, dt);
          const speed = 1.15 * (1 - c.stop);
          c.s += speed * dt * c.dir;
          if (c.s > c.total - 1) c.dir = -1;
          if (c.s < 1) c.dir = 1;
          const [x, z, yaw] = at(c, c.s);
          c.x = x; c.z = z;
          const wantYaw = near ? Math.atan2(player.pos[0] - x, player.pos[2] - z) : yaw + (c.dir < 0 ? Math.PI : 0);
          c.yaw += angleDiff(c.yaw, wantYaw) * Math.min(1, dt * 1.5);
          if (pd > 220) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = true;
          c.phase += speed * dt * 1.35;
          const b = c.rig.bones, H = c.rig.hipH;
          const g = this.groundAt(x, z);
          const sw = Math.sin(c.phase), cw = Math.cos(c.phase);
          const bob = Math.abs(cw) * 0.12 * (1 - c.stop);
          c.rig.root.setPos(x, g - 0.05 - (0.12 - bob), z);
          c.rig.root.setRotY(c.yaw);
          b.hips.setEuler(0, 0, sw * 0.04 * (1 - c.stop));
          const k = 1 - c.stop;
          b.thighL.setEuler(sw * 0.32 * k, 0, 0);
          b.thighR.setEuler(-sw * 0.32 * k, 0, 0);
          b.shinL.setEuler(-Math.max(0, cw) * 0.5 * k, 0, 0);
          b.shinR.setEuler(-Math.max(0, -cw) * 0.5 * k, 0, 0);
          b.arm.setEuler(-0.1 - c.stop * 0.6 + Math.sin(t * 0.8) * 0.05, 0, 0);
          b.lantern.setEuler(sw * 0.15 * k + c.stop * 0.5, 0, Math.sin(t * 1.3) * 0.06);
        }
      },
    });
    this.watch.push({ id: 'stilt', range: 20, points: () => all.map((c) => [c.x, 0, c.z]) });
    for (const c of all) {
      const it = this.npcs.addInteract({ id: c.id, name: 'Gólyalábú vándor', pos: [0, 0, 0], radius: 4.5, kind: 'talk', lines: LINES.stilt, idx: all.indexOf(c) * 2 });
      this.list.push({ update: () => { it.pos[0] = c.x; it.pos[1] = this.groundAt(c.x, c.z) + 1.0; it.pos[2] = c.z; } });
    }
  }

  // ---------------------------------------------------------------- dream cats on roofs and ruins
  buildCats() {
    const W = this.world;
    const perches = [];
    const houses = W.villageHouses || [];
    for (const i of [1, 3, 5]) {
      const h = houses[i];
      if (h && h.anchors.capTop) perches.push({ p: h.world.tp(h.anchors.capTop), talk: i === 1 });
    }
    if (W.anchors.chimney) {
      const c = W.anchors.chimney;
      perches.push({ p: [c[0] + 0.6, W.physics.ground(c[0] + 0.6, c[2], c[1] + 2), c[2]] });
    }
    const tops = (W.ruins && W.ruins.anchors.tops) || [];
    if (tops[3]) perches.push({ p: W.ruins.world.tp(tops[3]) });
    const all = [];
    perches.forEach((q, i) => {
      const p = q.p.slice();
      // sit on whatever is really there
      const gy = W.physics.ground(p[0], p[2], p[1] + 1.5);
      if (Number.isFinite(gy) && Math.abs(gy - p[1]) < 2) p[1] = gy;
      const rig = buildDreamCat(this.ctx, 70 + i, ['#1c1c2e', '#2a2238', '#d8d0e8', '#3a3446'][i % 4]);
      this.add(rig, 90);
      rig.root.setPos(p[0], p[1] - 0.02, p[2]);
      const c = { rig, p, yaw: this.rng.range(0, TAU), look: 0, seed: this.rng.range(0, 10) };
      rig.root.setRotY(c.yaw);
      all.push(c);
      if (q.talk) this.npcs.addInteract({ id: 'cat', name: 'Holdcirmos', pos: [p[0], p[1] - 1.5, p[2]], radius: 5, kind: 'talk', lines: LINES.cat, focus: [p[0], p[1] + 0.3, p[2]] });
    });
    this.list.push({
      update: (dt, t, player) => {
        for (const c of all) {
          const dx = player.pos[0] - c.p[0], dz = player.pos[2] - c.p[2];
          const pd = hyp(dx, dz);
          if (pd > 80) continue;
          const b = c.rig.bones;
          const want = pd < 14 ? angleDiff(c.yaw, Math.atan2(dx, dz)) : Math.sin(t * 0.3 + c.seed) * 0.6;
          c.look = damp(c.look, clamp(want, -1.2, 1.2), 3, dt);
          b.head.setEuler(pd < 14 ? -0.15 : Math.sin(t * 0.2 + c.seed) * 0.1, c.look, Math.sin(t * 0.7 + c.seed) * 0.05);
          const sw = Math.sin(t * 1.6 + c.seed);
          b.tail[0].setEuler(0.4, sw * 0.5, 0);
          b.tail[1].setEuler(0.5, sw * 0.6, 0);
          b.tail[2].setEuler(0.6, Math.sin(t * 1.6 + c.seed - 0.8) * 0.7, 0);
          b.body.scale[1] = 1 + Math.sin(t * 1.8 + c.seed) * 0.01;
        }
      },
    });
    this.watch.push({ id: 'cat', range: 12, points: () => all.map((c) => c.p) });
  }

  // ---------------------------------------------------------------- owls
  buildOwls() {
    const W = this.world;
    const perches = [];
    if (W.tower) {
      const top = W.tower.world.tp(W.tower.anchors.top);
      const a = W.tower.world.yaw + 1.2;
      perches.push([top[0] + Math.cos(a) * 3.95, top[1] + 1.0, top[2] + Math.sin(a) * 3.95]);
    }
    for (const lt of (W.lanternTrees || []).slice(0, 2)) perches.push([lt[0], lt[1] + 6.2, lt[2]]);
    if (W.watcher) perches.push(W.watcher.world.tp([0, 0, 0]));
    const tops = (W.ruins && W.ruins.anchors.tops) || [];
    if (tops[2]) perches.push(W.ruins.world.tp(tops[2]));
    const all = [];
    perches.forEach((q, i) => {
      const p = q.slice();
      const gy = W.physics.ground(p[0], p[2], p[1] + 30);
      if (i >= 3 || !Number.isFinite(p[1])) p[1] = gy;
      const rig = buildOwl(this.ctx, 90 + i);
      this.add(rig, 110);
      rig.root.setPos(p[0], p[1], p[2]);
      const c = { rig, p, yaw: this.rng.range(0, TAU), head: 0, hoot: this.rng.range(4, 12), blink: 0, seed: this.rng.range(0, 10) };
      rig.root.setRotY(c.yaw);
      all.push(c);
    });
    const audio = this.game.audio;
    this.list.push({
      update: (dt, t, player) => {
        for (const c of all) {
          const dx = player.pos[0] - c.p[0], dz = player.pos[2] - c.p[2];
          const pd = hyp(dx, dz);
          if (pd > 110) continue;
          const b = c.rig.bones;
          // the head follows you, turning almost all the way round
          const want = pd < 35 ? clamp(angleDiff(c.yaw, Math.atan2(dx, dz)), -2.4, 2.4) : Math.sin(t * 0.15 + c.seed) * 1.2;
          c.head = damp(c.head, want, 2.5, dt);
          b.head.setEuler(0, c.head, Math.sin(t * 0.5 + c.seed) * 0.08);
          c.blink -= dt;
          if (c.blink < -this.rng.range(2, 6)) c.blink = 0.12;
          b.eyes.setScale(1, c.blink > 0 ? 0.1 : 1, 1);
          b.wingL.setEuler(0, 0, 0.05 + Math.max(0, Math.sin(t * 0.2 + c.seed)) ** 30 * 0.8);
          b.wingR.setEuler(0, 0, -0.05 - Math.max(0, Math.sin(t * 0.2 + c.seed)) ** 30 * 0.8);
          c.hoot -= dt;
          if (c.hoot <= 0) {
            c.hoot = this.rng.range(7, 16);
            if (pd < 40 && audio.started && audio.hoot) audio.hoot(clamp(1 - pd / 40, 0.05, 1));
          }
        }
      },
    });
    this.watch.push({ id: 'owl', range: 18, points: () => all.map((c) => c.p) });
  }

  // ---------------------------------------------------------------- sky koi swimming through the air
  buildKoi() {
    const W = this.world;
    const centers = [];
    if (W.moon) centers.push({ c: W.moon.world.tp([0, 5, 0]), r: [9, 15], h: [3, 9], n: 4 });
    const S = W.L.sites;
    centers.push({ c: [S.islands.x, W.h(S.islands.x, S.islands.z), S.islands.z], r: [14, 26], h: [8, 22], n: 4 });
    centers.push({ c: [S.lake.x, W.L.waterLevel, S.lake.z], r: [12, 30], h: [3, 7], n: 3 });
    const all = [];
    centers.forEach((g, gi) => {
      for (let i = 0; i < g.n; i++) {
        const rig = buildSkyKoi(this.ctx, 120 + gi * 10 + i);
        this.add(rig, 130);
        rig.root.traverse((n) => { if (n.geometry) n.castShadow = false; });
        all.push({ rig, c: g.c, R: this.rng.range(g.r[0], g.r[1]), H: this.rng.range(g.h[0], g.h[1]), w: this.rng.range(0.12, 0.22) * this.rng.sign(), ph: this.rng.range(0, TAU), seed: this.rng.range(0, 10), pos: [0, 0, 0] });
      }
    });
    this.list.push({
      update: (dt, t, player) => {
        for (const k of all) {
          const pd = hyp(player.pos[0] - k.c[0], player.pos[2] - k.c[2]);
          if (pd > 150) { k.rig.root.visible = false; continue; }
          k.rig.root.visible = true;
          const a = t * k.w + k.ph;
          const r = k.R * (1 + 0.25 * Math.sin(t * 0.13 + k.seed));
          const x = k.c[0] + Math.cos(a) * r, z = k.c[2] + Math.sin(a) * r;
          const y = k.c[1] + k.H + Math.sin(a * 2 + k.seed) * 2.0;
          const vx = -Math.sin(a) * k.w, vz = Math.cos(a) * k.w, vy = Math.cos(a * 2 + k.seed) * 4 * k.w / Math.max(1, r);
          k.pos[0] = x; k.pos[1] = y; k.pos[2] = z;
          k.rig.root.setPos(x, y, z);
          k.rig.root.setEuler(-vy * 2, Math.atan2(vx, vz), Math.sign(k.w) * 0.2);
          k.rig.bones.tail.setEuler(0, Math.sin(t * 5 + k.seed) * 0.45, 0);
          k.rig.bones.body.setEuler(0, Math.sin(t * 5 + k.seed + 1.2) * 0.08, 0);
        }
      },
    });
    this.watch.push({ id: 'koi', range: 22, points: () => all.map((k) => k.pos) });
  }

  // ---------------------------------------------------------------- moon moths around lamps
  buildMoths() {
    const W = this.world;
    const spots = [];
    (W.lampSpots || []).forEach((p, i) => { if (i % 2 === 0) spots.push({ p, n: 5 }); });
    for (const lt of W.lanternTrees || []) spots.push({ p: [lt[0], lt[1] + 5.5, lt[2]], n: 9, r: 3.2 });
    const hs = (W.anchors.village && W.anchors.village.houses) || [];
    for (const h of hs.slice(0, 3)) spots.push({ p: [h.door[0], h.door[1] + 2.2, h.door[2]], n: 4 });
    spots.forEach((s, i) => this.scene.add(moths(this.world.gl, s.n, s.p, { radius: s.r || 1.6, height: 0.9, seed: 900 + i })));
    this.watch.push({ id: 'moth', range: 7, points: () => spots.map((s) => s.p) });
  }

  // ---------------------------------------------------------------- sky whales
  buildWhales() {
    const W = this.world;
    const routes = [
      { c: [10, -10], r: 215, h: 88, w: 0.021, ph: 0.5 },
      { c: [-40, 50], r: 136, h: 70, w: -0.028, ph: 2.6 },
    ];
    this.whales = routes.map((rt, i) => {
      const rig = buildSkyWhale(this.ctx, 1 + i, i === 0); // the first one carries a saddle: the ferry whale
      rig.root.traverse((n) => { if (n.geometry) { n.maxDistance = 600; n.castShadow = false; } });
      this.scene.add(rig.root);
      if (i === 1) rig.root.setScale(0.7);
      return { rig, ...rt, pos: [0, 0, 0], song: this.rng.range(8, 20) };
    });
    const audio = this.game.audio;
    this.list.push({
      update: (dt, t, player) => {
        for (const wh of this.whales) {
          if (wh.override) { wh.override(dt, t, wh); }
          else {
            const a = t * wh.w + wh.ph;
            const x = wh.c[0] + Math.cos(a) * wh.r, z = wh.c[1] + Math.sin(a) * wh.r;
            const y = wh.h + Math.sin(t * 0.07 + wh.ph) * 6;
            const vx = -Math.sin(a) * wh.w, vz = Math.cos(a) * wh.w;
            wh.pos[0] = x; wh.pos[1] = y; wh.pos[2] = z;
            wh.rig.root.setPos(x, y, z);
            wh.rig.root.setEuler(Math.cos(t * 0.07 + wh.ph) * 0.05, Math.atan2(vx, vz), -Math.sign(wh.w) * 0.12);
          }
          const b = wh.rig.bones;
          // (v9.1d) the beat rolls down the tail stock: each bone a little later and a little stronger
          const ph = t * 0.55 + wh.ph;
          b.tail1.setEuler(Math.sin(ph + 0.9) * 0.07, 0, 0);
          b.tail2.setEuler(Math.sin(ph + 0.45) * 0.12, 0, 0);
          b.tail.setEuler(Math.sin(ph) * 0.2, 0, 0);
          b.body.setEuler(wh.override ? 0 : Math.sin(ph + 1.4) * 0.03, 0, 0);
          b.finL.setEuler(0, Math.sin(t * 0.4 + wh.ph + 0.6) * 0.06, Math.sin(t * 0.4 + wh.ph) * 0.22);
          b.finR.setEuler(0, -Math.sin(t * 0.4 + wh.ph + 0.6) * 0.06, -Math.sin(t * 0.4 + wh.ph) * 0.22);
          // now and then a misty spout of starlight from the blowhole
          wh.blow = (wh.blow ?? 6 + wh.ph * 3) - dt;
          if (wh.blow <= 0) {
            wh.blow = this.rng.range(16, 34);
            const tr = this.game.trail;
            const dpl = Math.hypot(player.pos[0] - wh.pos[0], player.pos[1] - wh.pos[1], player.pos[2] - wh.pos[2]);
            if (tr && dpl < 160) {
              const r = wh.rig.root, q = r.world, sp = wh.rig.spout;
              const x = q[0] * sp[0] + q[4] * sp[1] + q[8] * sp[2] + q[12];
              const y = q[1] * sp[0] + q[5] * sp[1] + q[9] * sp[2] + q[13];
              const z = q[2] * sp[0] + q[6] * sp[1] + q[10] * sp[2] + q[14];
              for (let k = 0; k < 34; k++) {
                tr.emit([x + (Math.random() - 0.5) * 0.5, y + Math.random() * 0.8, z + (Math.random() - 0.5) * 0.5], t,
                  { size: 0.12 + Math.random() * 0.12, life: 1.6 + Math.random() * 1.0, rise: 2.4 + Math.random() * 2.2, spread: 0.7, color: [0.9, 1.1, 1.8], intensity: 1.6 });
              }
            }
          }
          wh.song -= dt;
          if (wh.song <= 0) {
            wh.song = this.rng.range(14, 30);
            const d = Math.hypot(player.pos[0] - wh.pos[0], player.pos[1] - wh.pos[1], player.pos[2] - wh.pos[2]);
            if (d < 320 && audio.started && audio.whale) audio.whale(clamp(1 - d / 320, 0.08, 1));
          }
        }
      },
    });
    this.watch.push({ id: 'whale', range: 150, points: () => this.whales.map((w) => w.pos) });
  }

  // ---------------------------------------------------------------- creatures that already lived here
  watchExisting() {
    const W = this.world, N = this.npcs;
    this.watch.push({ id: 'stag', range: 16, points: () => (N.stag ? [[N.stag.x, 0, N.stag.z]] : []) });
    this.watch.push({ id: 'snail', range: 14, points: () => (N.bigSnail ? [[N.bigSnail.x, 0, N.bigSnail.z]] : []) });
    const roots = (name) => this.scene.children.filter((n) => n.name === name);
    const crows = roots('crow'), frogs = roots('frog');
    this.watch.push({ id: 'crow', range: 14, points: () => crows.filter((n) => n.visible).map((n) => [n.world[12], 0, n.world[14]]) });
    const lakes = W.L.lakes.map((lk) => [lk.x, 0, lk.z, lk.r]);
    this.watch.push({ id: 'fish', range: 0, points: () => lakes, near: (p, pl) => hyp(p[0] - pl[0], p[2] - pl[2]) < p[3] + 4 });
    this.watch.push({ id: 'jelly', range: 45, points: () => this.scene.children.filter((n) => n.name === 'jellyfish').map((n) => n.boundsWorld) });
    this.watch.push({ id: 'wisp', range: 18, points: () => (W.wisps || []).map((w) => [w.node.position[0], 0, w.node.position[2]]) });
    if (frogs.length) this.watch.push({ id: 'frog', range: 10, points: () => frogs.map((n) => [n.world[12], 0, n.world[14]]) });
  }

  // ---------------------------------------------------------------- per frame
  update(dt, t, player) {
    for (const c of this.list) c.update(dt, t, player);
    // bestiary: every half second, anything new close by?
    this.seenTimer -= dt;
    if (this.seenTimer > 0 || this.game.state !== 'play') return;
    this.seenTimer = 0.5;
    const P = this.game.P;
    for (const w of this.watch) {
      if (P.creatures.has(w.id)) continue;
      for (const p of w.points()) {
        if (!p) continue;
        // ground dwellers only count when you are down there with them (not flying over on a whale)
        if (w.id !== 'whale' && Math.abs((p[1] || this.world.h(p[0], p[2])) - player.pos[1]) > 22) continue;
        const d = w.id === 'whale' ? Math.hypot(p[0] - player.pos[0], p[1] - player.pos[1], p[2] - player.pos[2]) : hyp(p[0] - player.pos[0], p[2] - player.pos[2]);
        if (w.near ? w.near(p, player.pos) : d < w.range) { this.game.meetCreature && this.game.meetCreature(w.id); break; }
      }
    }
  }
}
