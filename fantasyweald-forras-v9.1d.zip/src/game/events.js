// Tiny event bus. Quests and other systems can listen to what happens in the world.
// Events emitted today:
//   'region:enter'    { region }          every time the player walks into a region
//   'region:discover' { region }          the first time
//   'interact'        { target, line }    the player talks to / examines something
//   'jump', 'land', 'bounce'  { }         player movement moments
//   'shard'           { id, count }       a star shard was collected
export class Events {
  constructor() {
    this.map = new Map();
  }
  on(name, fn) {
    if (!this.map.has(name)) this.map.set(name, new Set());
    this.map.get(name).add(fn);
    return () => this.map.get(name).delete(fn);
  }
  emit(name, data) {
    const set = this.map.get(name);
    if (set) for (const fn of set) fn(data);
  }
}
