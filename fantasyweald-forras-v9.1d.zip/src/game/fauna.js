// (v9) The new forest folk and how they live: star hedgehogs, moth foxes, mist rays (v9.1b), root spiders and the
// silent ones. They are spread over the whole island by biome, so there is always someone around.
import { buildStarHog, buildMothFox, buildMistRay, buildRootSpider, buildSilentOne } from '../models/fauna.js';
import { RNG, clamp, damp, lerp, angleDiff, TAU, smoothstep } from '../engine/math.js';

const hyp = (x, z) => Math.sqrt(x * x + z * z);
const FAR = 120; // beyond this a creature is hidden and only its clock runs

export class Fauna {
  constructor(cr) {
    this.cr = cr;
    this.game = cr.game;
    this.world = cr.world;
    this.scene = cr.scene;
    this.ctx = cr.ctx;
    this.npcs = cr.npcs;
    this.rng = new RNG(this.world.L.seed + 9090);
    const hogHomes = this.spots(20, (b) => b.desert < 0.2 && b.dead < 0.3 && b.crystal < 0.3, 24);
    const foxHomes = this.spots(6, (b) => b.desert < 0.2 && b.dead < 0.35 && (b.meadow > 0.2 || b.blossom > 0.25 || b.river > 0.3 || b.mushroom > 0.3 || b.pines > 0.4), 70, this.settlements());
    const bakuHomes = this.spots(6, (b) => b.desert < 0.2 && b.dead < 0.3 && b.pines < 0.5 && b.crystal < 0.2 && b.swamp < 0.5, 80, this.settlements().map((s) => [s[0], s[1], 30]));
    // no long empty stretch along the roads: fill the gaps (mist rays over the dunes, hedgehogs and foxes elsewhere)
    this.fillRoadGaps(hogHomes, foxHomes, bakuHomes);
    this.buildHogs(hogHomes);
    this.buildFoxes(foxHomes);
    this.buildBakus(bakuHomes);
    this.buildSpiders();
    this.buildSilent();
  }
  fillRoadGaps(hogs, foxes, bakus) {
    const cr = this.cr, W = this.world, L = W.L;
    const known = [];
    const take = (list) => { if (list) for (const c of list) if (c && Number.isFinite(c.x)) known.push([c.x, c.z]); };
    take(cr.shroomlings); take(cr.rabbits); take(cr.stilts);
    const wd = cr.wanderers;
    if (wd) { take(wd.plushies); take(wd.eyeFlowers); }
    for (const h of hogs.concat(foxes, bakus)) known.push(h);
    let n = 0;
    for (const p of W.terrain.paths) {
      for (let i = 0; i < p.pts.length; i += 3) {
        const q = p.pts[i];
        if (Math.hypot(q[0], q[1]) > L.borderAt(q[0], q[1]) - 25) continue;
        let best = Infinity;
        for (const c of known) { const d = hyp(c[0] - q[0], c[1] - q[1]); if (d < best) best = d; }
        if (best < 38) continue;
        const a = this.rng.range(0, TAU), off = this.rng.range(7, 14);
        const home = cr.freeSpot(q[0] + Math.cos(a) * off, q[1] + Math.sin(a) * off, 5, 12);
        if (!home) continue;
        const b = L.biome(home[0], home[1]);
        if (b.desert > 0.3) bakus.push(home);
        else if (n % 3 === 2 && b.dead < 0.35) foxes.push(home);
        else hogs.push(home);
        known.push(home);
        n++;
      }
    }
    this.gapFill = n;
  }

  // ---------------------------------------------------------------- where they live
  // random dry, free, walkable spots on the island that pass `test(biome, x, z)`, at least `sep` apart
  spots(n, test, sep, avoid = []) {
    const W = this.world, L = W.L, rng = this.rng, out = [];
    for (let k = 0; k < n * 400 && out.length < n; k++) {
      const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * 330;
      const x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (Math.hypot(x, z) > L.borderAt(x, z) - 22) continue;
      if (W.waterDepth(x, z) > -0.4) continue;
      if (W.terrain.normalAt(x, z)[1] < 0.86) continue;
      if (!test(L.biome(x, z), x, z)) continue;
      if (out.some((q) => hyp(q[0] - x, q[1] - z) < sep) || avoid.some((q) => hyp(q[0] - x, q[1] - z) < q[2])) continue;
      const g = W.h(x, z);
      if (W.physics.ground(x, z, g + 0.3) > g + 0.35) continue;
      if (W.physics.blocked(x, z, g, 0.5, 1.2, 0.5)) continue;
      out.push([x, z]);
    }
    return out;
  }
  // one step forward along c.yaw at c.speed: trunks push it aside, water, walls and the edge of its home
  // stop it (returns false when it could not go on)
  stepOn(c, dt, r, h, homeR = 0) {
    const W = this.world;
    let nx = c.x + Math.sin(c.yaw) * c.speed * dt, nz = c.z + Math.cos(c.yaw) * c.speed * dt;
    [nx, nz] = W.collide(nx, nz, r, W.h(nx, nz));
    if (W.waterDepth(nx, nz) > -0.15) return false;
    if (W.physics.blocked(nx, nz, W.h(c.x, c.z), r, h, 0.4, c.x, c.z)) return false;
    if (homeR && hyp(nx - c.home[0], nz - c.home[1]) > homeR) return false;
    const moved = hyp(nx - c.x, nz - c.z);
    c.x = nx; c.z = nz;
    return moved > c.speed * dt * 0.35;
  }
  settlements() {
    const S = this.world.L.sites, sp = this.world.L.spawn;
    return [[sp.x, sp.z, 40], [S.village.x, S.village.z, 45]];
  }
  // a bestiary entry and an optional petting interaction
  pet(id, name, c, lines, visible) {
    const W = this.world;
    const it = this.npcs.addInteract({
      id: id + '_' + Math.round(c.home[0]) + '_' + Math.round(c.home[1]), name, pos: [c.x, 0, c.z], radius: c.petR || 1.6, kind: 'look', verb: 'Megsimogatom', moving: true,
      visible, talk: () => {
        c.petted = 2.5;
        if (this.game.audio.started) this.game.audio.beast(id === 'baku' ? 'bakuHum' : 'hogHappy', 0.8);
        return { lines: [lines[Math.floor(Math.random() * lines.length)]] };
      },
    });
    c.it = it;
    return it;
  }
  syncIt(c, yOff = 0.3) {
    if (!c.it) return;
    c.it.pos[0] = c.x; c.it.pos[1] = this.world.h(c.x, c.z) + yOff; c.it.pos[2] = c.z;
  }

  // ================================================================ star hedgehogs
  buildHogs(homes) {
    const cr = this.cr, W = this.world;
    const all = homes.map((h, i) => {
      const rig = buildStarHog(this.ctx, 7000 + i);
      cr.add(rig, 60);
      return { rig, home: h, x: h[0], z: h[1], yaw: this.rng.range(0, TAU), state: 'wander', t: 0, target: null, wait: this.rng.range(0, 3), speed: 0, phase: this.rng.range(0, 10), curl: 0, roll: 0, rollV: 0, calm: 0, sniff: 0, petted: 0 };
    });
    this.hogs = all;
    const lines = [
      'A csillagsün boldogan szuszog, és a tüskéi hegyén egy pillanatra kigyúlnak a csillagok.',
      'A csillagsün megszimatolja az ujjadat, aztán elégedetten pislog.',
      'Puha a pocakja, szúrós a háta. A tüskéi halkan csilingelnek, mint a jégcsapok.',
    ];
    for (const c of all.slice(0, 12)) this.pet('starhog', 'Csillagsün', c, lines, () => c.curl < 0.2);
    cr.list.push({
      update: (dt, t, player) => {
        const pv = Math.hypot(player.vel[0], player.vel[2]);
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z, pd = hyp(dxp, dzp);
          if (pd > FAR) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = pd < 62;
          c.t += dt;
          c.petted = Math.max(0, c.petted - dt);
          const sameLevel = Math.abs(player.pos[1] - W.h(c.x, c.z)) < 2.5;
          const startle = sameLevel && !player.sneaking && ((pd < 4.5 && pv > 1.2) || pd < 1.6);
          if (startle && c.state !== 'curl' && c.state !== 'roll') {
            c.state = pv > 3.5 && pd < 3.2 ? 'roll' : 'curl';
            c.t = 0; c.calm = 0;
            c.yaw = Math.atan2(-dxp, -dzp) + this.rng.range(-0.3, 0.3);
            if (this.game.audio.started && pd < 14) this.game.audio.beast('hogSqueak', clamp(1 - pd / 14, 0.2, 1));
          }
          let move = 0;
          if (c.state === 'curl' || c.state === 'roll') {
            c.curl = damp(c.curl, 1, 16, dt);
            if (c.state === 'roll') {
              move = c.t < 1.3 ? 2.4 * (1 - c.t / 1.3) + 0.3 : 0;
              if (c.t > 1.3) c.state = 'curl';
            }
            c.calm = pd > 5 || (player.sneaking && pv < 1.2) ? c.calm + dt : 0;
            if (c.calm > 2.4 || c.t > 12) { c.state = 'wander'; c.target = null; c.wait = 1.2; }
          } else {
            c.curl = damp(c.curl, 0, 4, dt);
            if (pd < 3 && player.sneaking && sameLevel) {
              // a quiet visitor: turn to them and sniff
              c.state = 'sniff';
              c.yaw += angleDiff(c.yaw, Math.atan2(dxp, dzp)) * Math.min(1, dt * 3);
              c.sniff = 1;
            } else if (c.state === 'sniff') {
              c.state = 'wander';
            }
            if (c.state === 'wander') {
              if (!c.target) {
                c.wait -= dt;
                c.sniff = c.wait > 0.4 ? 1 : 0;
                if (c.wait <= 0) { c.target = this.cr.freeSpot(c.home[0], c.home[1], 9, 5); c.wait = this.rng.range(1.2, 4.5); }
              } else {
                const tx = c.target[0] - c.x, tz = c.target[1] - c.z;
                c.sniff = 0;
                if (hyp(tx, tz) < 0.3) c.target = null;
                else { c.yaw += angleDiff(c.yaw, Math.atan2(tx, tz)) * Math.min(1, dt * 5); move = 0.55; }
              }
            }
          }
          c.speed = damp(c.speed, move, 6, dt);
          if (c.speed > 0.02) {
            if (!this.stepOn(c, dt, 0.15, 0.4, 16)) { c.target = null; c.yaw += 2.4; }
          }
          if (c.state === 'roll') c.roll += (c.speed * dt) / 0.13;
          else c.roll = damp(c.roll, Math.round(c.roll / TAU) * TAU, 5, dt);
          if (!c.rig.root.visible) continue;
          // pose
          const b = c.rig.bones, k = c.curl;
          const walk = c.state === 'roll' ? 0 : clamp(c.speed / 0.5, 0, 1);
          c.phase += dt * 16 * walk;
          const y = W.h(c.x, c.z);
          c.rig.root.setPos(c.x, y, c.z);
          c.rig.root.setRotY(c.yaw);
          b.body.position[1] = 0.125 - k * 0.015 + Math.abs(Math.sin(c.phase)) * 0.008 * walk;
          b.body.setEuler(k * 0.55 + c.roll, 0, Math.sin(c.phase) * 0.05 * walk);
          b.body.setScale(1 + k * 0.05, 1 + k * 0.28, 1 - k * 0.22);
          b.head.position[1] = -k * 0.045;
          b.head.position[2] = 0.14 - k * 0.1;
          b.head.setScale(1 - k * 0.55);
          b.head.setEuler(k * 1.2 + (c.sniff ? 0.35 + Math.sin(t * 14 + c.phase) * 0.06 : Math.sin(t * 0.8 + c.home[0]) * 0.08), Math.sin(t * 0.6 + c.home[1]) * 0.25 * (1 - k) * (c.sniff ? 0.3 : 1), 0);
          b.quills.setScale(1 + k * 0.12, 1 + k * 0.08, 1 + k * 0.1);
          const legs = k < 0.55;
          for (const [nm, ph] of [['legFL', 0], ['legBR', 0], ['legFR', Math.PI], ['legBL', Math.PI]]) {
            b[nm].visible = legs;
            b[nm].setEuler(Math.sin(c.phase + ph) * 0.7 * walk, 0, 0);
          }
          b.eyes.setScale(1, k > 0.4 ? 0.05 : Math.sin(t * 0.7 + c.phase) > 0.985 ? 0.1 : 1, 1);
          // curled up (or just petted): the quill tips twinkle
          const shine = Math.max(k, c.petted > 0 ? 1 : 0);
          b.glow.visible = shine > 0.45;
          if (b.glow.visible) b.glow.setScale(0.85 + 0.25 * Math.sin(t * 5 + c.phase));
          this.syncIt(c, 0.2);
        }
      },
    });
    cr.watch.push({ id: 'starhog', range: 9, points: () => all.map((c) => [c.x, 0, c.z]) });
  }

  // ================================================================ moth foxes (little packs)
  buildFoxes(homes) {
    const cr = this.cr, W = this.world;
    const all = [];
    homes.forEach((h, gi) => {
      const n = gi % 3 === 0 ? 3 : 2;
      for (let i = 0; i < n; i++) {
        const p = cr.freeSpot(h[0], h[1], 6) || h;
        const rig = buildMothFox(this.ctx, 8100 + gi * 10 + i);
        cr.add(rig, 75);
        all.push({ rig, home: h, x: p[0], z: p[1], yaw: this.rng.range(0, TAU), state: 'sit', t: this.rng.range(0, 4), dur: this.rng.range(3, 7), target: null, speed: 0, phase: this.rng.range(0, 10), hop: 0, hopV: 0, sit: 1, wing: 1.05, wingT: 0, tilt: 0, look: 0 });
      }
    });
    this.foxes = all;
    cr.list.push({
      update: (dt, t, player) => {
        const pv = Math.hypot(player.vel[0], player.vel[2]);
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z, pd = hyp(dxp, dzp);
          if (pd > FAR) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = pd < 76;
          c.t += dt;
          const sameLevel = Math.abs(player.pos[1] - W.h(c.x, c.z)) < 3;
          const loud = !player.sneaking && pv > 3.2;
          if (sameLevel && ((loud && pd < 9) || (!player.sneaking && pv > 1 && pd < 2.2)) && c.state !== 'flee') {
            c.state = 'flee'; c.t = 0; c.dur = this.rng.range(1.8, 2.8);
            c.yaw = Math.atan2(-dxp, -dzp) + this.rng.range(-0.5, 0.5);
            if (this.game.audio.started && pd < 16) this.game.audio.beast('foxYip', clamp(1 - pd / 16, 0.2, 0.9));
          } else if (c.state !== 'flee' && c.state !== 'pounce' && sameLevel && pd < 8 && !loud) {
            if (c.state !== 'watch') { c.state = 'watch'; c.t = 0; }
          }
          let move = 0, wingWant = 1.05, flap = 0;
          if (c.state === 'flee') {
            move = 4.2;
            flap = 1;
            if (c.hop <= 0 && c.hopV <= 0) c.hopV = 2.3;
            if (c.t > c.dur) { c.state = 'sit'; c.t = 0; c.dur = this.rng.range(3, 6); }
          } else if (c.state === 'watch') {
            // sits and looks at you, head tilted; comes closer if you stand still
            const want = Math.atan2(dxp, dzp);
            c.yaw += angleDiff(c.yaw, want) * Math.min(1, dt * 2.5);
            c.look = 1;
            if (pv < 0.3 && pd > 1.6 && pd < 6 && c.t > 2.5) move = 0.8;
            if (pd > 10 || !sameLevel) { c.state = 'sit'; c.t = 0; c.dur = 2; }
          } else if (c.state === 'sit') {
            c.look = 0;
            if (c.t > c.dur) {
              c.t = 0;
              if (this.rng.chance(0.25)) { c.state = 'pounce'; c.dur = 1.2; }
              else { c.state = 'trot'; c.target = cr.freeSpot(c.home[0], c.home[1], 16, 6); c.dur = 12; }
            }
            // now and then the wings open and close, slowly, like breathing
            wingWant = 1.1 - Math.max(0, Math.sin(t * 0.7 + c.phase)) * 0.75;
          } else if (c.state === 'trot') {
            if (!c.target || c.t > c.dur) { c.state = 'sit'; c.t = 0; c.dur = this.rng.range(3, 7); }
            else {
              const tx = c.target[0] - c.x, tz = c.target[1] - c.z;
              if (hyp(tx, tz) < 0.4) { c.state = 'sit'; c.t = 0; c.dur = this.rng.range(3, 7); }
              else { c.yaw += angleDiff(c.yaw, Math.atan2(tx, tz)) * Math.min(1, dt * 3); move = 1.4; }
            }
          } else if (c.state === 'pounce') {
            // crouch, leap with a flurry of wings, land
            if (c.t < 0.45) { move = 0; }
            else if (c.t < 0.5 && c.hopV <= 0 && c.hop <= 0.001) { c.hopV = 2.8; }
            if (c.t > 0.45) { move = c.hop > 0 ? 2.4 : 0; flap = c.hop > 0 ? 1 : 0; }
            if (c.t > c.dur) { c.state = 'sit'; c.t = 0; c.dur = this.rng.range(2, 5); }
          }
          // hops (a little help from the wings)
          if (c.hopV > 0 || c.hop > 0) {
            c.hopV -= 9 * dt * (flap ? 0.62 : 1);
            c.hop = Math.max(0, c.hop + c.hopV * dt);
            if (c.hop <= 0 && c.hopV < 0) c.hopV = 0;
          }
          c.speed = damp(c.speed, move, 5, dt);
          if (c.speed > 0.02) {
            if (!this.stepOn(c, dt, 0.22, 0.6, 30)) { c.target = null; c.yaw += 2.2; if (c.state === 'trot') { c.state = 'sit'; c.t = 0; } }
          }
          if (!c.rig.root.visible) continue;
          // pose
          const b = c.rig.bones;
          const sitting = c.state === 'sit' || c.state === 'watch' ? 1 : 0;
          c.sit = damp(c.sit, sitting && c.speed < 0.3 ? 1 : 0, 5, dt);
          const walk = clamp(c.speed / 1.4, 0, 1.6);
          c.phase += dt * (5 + c.speed * 3.2) * (walk > 0.05 ? 1 : 0);
          const s = Math.sin(c.phase), co = Math.cos(c.phase);
          const crouch = c.state === 'pounce' && c.t < 0.45 ? smoothstep(0, 0.35, c.t) : 0;
          const y = W.h(c.x, c.z);
          c.rig.root.setPos(c.x, y + c.hop, c.z);
          c.rig.root.setRotY(c.yaw);
          b.body.position[1] = 0.33 - c.sit * 0.085 - crouch * 0.08 + Math.abs(co) * 0.012 * walk;
          b.body.setEuler(-c.sit * 0.36 + crouch * 0.1 - (c.hopV > 0 ? 0.2 : c.hop > 0 ? -0.1 : 0), 0, 0);
          const amp = 0.55 * Math.min(1, walk);
          b.legFL.setEuler(s * amp + c.sit * 0.42, 0, 0);
          b.legBR.setEuler(s * amp - c.sit * 0.9, 0, 0);
          b.legFR.setEuler(-s * amp + c.sit * 0.42, 0, 0);
          b.legBL.setEuler(-s * amp - c.sit * 0.9, 0, 0);
          b.legBL.position[1] = -0.035 + c.sit * 0.05;
          b.legBR.position[1] = -0.035 + c.sit * 0.05;
          c.tilt = damp(c.tilt, c.look ? Math.sin(t * 0.9 + c.phase) * 0.35 : 0, 3, dt);
          const lookYaw = c.look ? 0 : Math.sin(t * 0.5 + c.home[0] + c.phase) * 0.5 * c.sit;
          b.head.setEuler(c.sit * 0.35 - crouch * 0.3 + Math.sin(c.phase * 2) * 0.03 * walk, lookYaw, c.tilt);
          b.earL.setEuler(Math.sin(t * 3 + c.phase) > 0.95 ? -0.4 : 0, 0, 0);
          b.earR.setEuler(Math.sin(t * 2.6 + c.phase + 1) > 0.95 ? -0.4 : 0, 0, 0);
          b.tail.setEuler(0.3 * c.sit - 0.25 * walk, Math.sin(t * (sitting ? 1.6 : 5) + c.phase) * (sitting ? 0.35 : 0.2), 0);
          c.wingT += dt * (flap ? 26 : 0);
          const want = flap ? 0.7 + 0.62 * Math.sin(c.wingT) : wingWant;
          c.wing = flap ? want : damp(c.wing, want, 3, dt);
          b.wingL.setEuler(0.1, 0, c.wing);
          b.wingR.setEuler(0.1, 0, -c.wing);
        }
      },
    });
    cr.watch.push({ id: 'mothfox', range: 14, points: () => all.map((c) => [c.x, 0, c.z]) });
  }

  // ================================================================ (v9.1b) mist rays: they swim through the air
  buildBakus(homes) {
    const cr = this.cr, W = this.world, g = this.game;
    const all = homes.map((h, i) => {
      const rig = buildMistRay(this.ctx, 9100 + i);
      cr.add(rig, 110);
      const r = this.rng;
      return {
        rig, home: h, x: h[0] + r.range(-4, 4), z: h[1] + r.range(-4, 4), yaw: r.range(0, TAU), alt: 2.4, speed: 2.2, turn: 0, bank: 0, pitch: 0, roll: 0,
        phase: r.range(0, 10), flap: 0.3, orbit: r.range(0, TAU), orbitR: r.range(8, 15), dir: r.sign(), state: 'glide', t: 0,
        eatT: r.range(10, 30), petted: 0, scare: 0, petR: 2.4, wx: 0, wy: 0, wz: 0, puffed: false,
      };
    });
    this.bakus = all;
    const lines = [
      'A Ködrája lejjebb ereszkedik, és hagyja, hogy megsimogasd. Hűvös és sima, mint a holdfényes víz.',
      'A Ködrája halk, zengő hangot ad, és a hátán felragyognak a csillagképek.',
      'Ahol hozzáérsz, apró csillagok gyúlnak ki a hátán. Aztán boldogan körbefordul a levegőben.',
    ];
    for (const c of all) this.pet('baku', 'Ködrája', c, lines, () => c.state === 'curious' && c.alt < 1.7);
    // only when it glides down low does it get in your way
    const wd = cr.wanderers;
    if (wd) for (const c of all) wd.pushers.push({ get x() { return c.x; }, get z() { return c.z; }, r: 0.9, get y0() { return W.h(c.x, c.z) + c.alt - 0.25; }, get y1() { return W.h(c.x, c.z) + c.alt + 0.25; } });
    const steer = (c, tx, tz, rate, dt) => {
      const want = Math.atan2(tx - c.x, tz - c.z);
      const d = clamp(angleDiff(c.yaw, want), -rate * dt, rate * dt);
      c.yaw += d;
      c.turn = damp(c.turn, d / Math.max(dt, 1e-4), 2.5, dt);
    };
    cr.list.push({
      update: (dt, t, player) => {
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z, pd = hyp(dxp, dzp);
          if (pd > FAR + 40) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = pd < 112;
          c.t += dt;
          c.eatT -= dt;
          c.petted = Math.max(0, c.petted - dt);
          c.scare = Math.max(0, c.scare - dt);
          const ground = W.h(c.x, c.z);
          const running = Math.hypot(player.vel[0], player.vel[2]) > 4 && !player.sneaking;
          let wantAlt = 2.2 + Math.sin(t * 0.23 + c.phase) * 0.8, wantSpeed = 2.1, wantFlap = 0.3, rate = 0.55;
          // what it does
          if (c.petted > 0 && c.state !== 'joy') { c.state = 'joy'; c.t = 0; if (this.game.audio.started) this.game.audio.beast('bakuHum', 0.8); }
          if (c.state === 'joy') {
            // a happy slow roll up into the air, stars trailing from the wingtips
            wantAlt = 3.2; wantSpeed = 2.6; wantFlap = 0.42;
            c.roll = smoothstep(0.2, 2.4, c.t) * TAU;
            if (Math.random() < dt * 12 && this.game.trail) {
              for (const s of [-1, 1]) {
                const ca = Math.cos(c.yaw), sa = Math.sin(c.yaw), wx = s * 1.3 * c.rig.scale;
                this.game.trail.emit([c.x + ca * wx, ground + c.alt, c.z - sa * wx], t, { size: 0.07, life: 1.4, rise: 0.3, spread: 0.3, color: [1.2, 1.1, 2.0], intensity: 2.2 });
              }
            }
            if (c.t > 2.6) { c.state = 'glide'; c.t = 0; c.roll = 0; }
          } else if (running && pd < 7 && c.alt < 3) {
            c.scare = 3;
          }
          if (c.state !== 'joy') {
            if (c.scare > 0) {
              // startled: up and away
              wantAlt = 3.8; wantSpeed = 4.2; wantFlap = 0.5; rate = 1.0;
              steer(c, c.x - dxp * 3, c.z - dzp * 3, rate, dt);
              c.state = 'glide';
            } else if (pd < 5 && !running && player.onGround && c.state !== 'eat') {
              // curious: it slows down, faces you and glides down within reach of your hand
              c.state = 'curious';
              wantAlt = 1.25; wantSpeed = pd > 2.2 ? 0.7 : 0.15; wantFlap = 0.22; rate = 0.9;
              steer(c, player.pos[0], player.pos[2], rate, dt);
            } else if (c.state === 'eat') {
              // a bad dream drifts past: it swoops after it and swallows it
              wantSpeed = 3.2; wantFlap = 0.45; rate = 1.1;
              wantAlt = c.wy - W.h(c.x, c.z);
              steer(c, c.wx, c.wz, rate, dt);
              const mx = c.x + Math.sin(c.yaw) * 0.7 * c.rig.scale, mz = c.z + Math.cos(c.yaw) * 0.7 * c.rig.scale;
              if (hyp(c.wx - mx, c.wz - mz) < 0.6 || c.t > 9) {
                c.state = 'glide'; c.t = 0; c.eatT = this.rng.range(18, 40);
                const tr = this.game.trail;
                if (tr && c.t <= 9) for (let k = 0; k < 14; k++) tr.emit([mx + (Math.random() - 0.5) * 0.5, c.wy + Math.random() * 0.4, mz + (Math.random() - 0.5) * 0.5], t, { size: 0.1, life: 1.6, rise: 0.8, spread: 0.8, color: [1.2, 0.9, 2.2], intensity: 2.6 });
                if (this.game.audio.started && pd < 25) this.game.audio.beast('bakuHum', clamp(1 - pd / 25, 0.2, 0.9));
              }
            } else {
              c.state = 'glide';
              // slow, wide loops around its home glade, now and then the other way round
              const R = c.orbitR * (0.85 + 0.25 * Math.sin(t * 0.07 + c.phase));
              c.orbit += (dt * c.speed / R) * c.dir;
              if (Math.random() < dt * 0.01) c.dir = -c.dir;
              steer(c, c.home[0] + Math.cos(c.orbit) * R, c.home[1] + Math.sin(c.orbit) * R, rate, dt);
              if (c.eatT <= 0 && pd > 5) {
                c.state = 'eat'; c.t = 0;
                const a = c.yaw + this.rng.range(-0.6, 0.6), d = this.rng.range(5, 8);
                c.wx = c.x + Math.sin(a) * d; c.wz = c.z + Math.cos(a) * d; c.wy = W.h(c.wx, c.wz) + this.rng.range(1.8, 2.8);
              }
            }
          }
          // fly: speed, height, a turn makes it bank, climbing tips the nose up
          c.speed = damp(c.speed, wantSpeed, 1.2, dt);
          let nx = c.x + Math.sin(c.yaw) * c.speed * dt, nz = c.z + Math.cos(c.yaw) * c.speed * dt;
          if (c.alt < 3.5) [nx, nz] = W.collide(nx, nz, 0.7, W.h(nx, nz) + c.alt - 1);
          if (hyp(nx - c.home[0], nz - c.home[1]) > 34) { nx = c.x; nz = c.z; c.yaw += dt * 1.2 * c.dir; }
          c.x = nx; c.z = nz;
          const altPrev = c.alt;
          c.alt = damp(c.alt, Math.max(1.1, wantAlt), 0.8, dt);
          c.flap = damp(c.flap, wantFlap, 1.5, dt);
          c.bank = damp(c.bank, clamp(-c.turn * 0.9, -0.55, 0.55), 2.2, dt);
          c.pitch = damp(c.pitch, clamp(-(c.alt - altPrev) / Math.max(dt, 1e-3) * 0.25, -0.35, 0.35), 2, dt);
          if (!c.rig.root.visible) continue;
          // the wing wave: faster and deeper when it hurries, a lazy ripple when it hovers
          c.phase += dt * (1.4 + c.flap * 2.6);
          const u = c.rig.mat.uniforms;
          u.uFlap[0] = c.phase; u.uFlap[1] = c.flap;
          const b = c.rig.bones;
          c.rig.root.setPos(c.x, ground, c.z);
          c.rig.root.setRotY(c.yaw);
          b.body.position[1] = c.alt - Math.sin(c.phase) * 0.05 * c.flap / 0.3;
          b.body.setEuler(c.pitch + Math.sin(c.phase + 1.2) * 0.03, 0, c.bank + c.roll);
          b.eyes.setScale(1, c.petted > 0 ? 0.25 : 1, 1);
          // the dream morsel: hangs in the air, drifts, shrinks into the mouth as the ray arrives
          const wv = c.state === 'eat';
          b.wisp.visible = wv;
          if (wv) {
            const dxw = c.wx - c.x, dzw = c.wz - c.z;
            const ca = Math.cos(c.yaw), sa = Math.sin(c.yaw);
            const lx = dxw * ca - dzw * sa, lz = dxw * sa + dzw * ca;
            const dist = hyp(dxw, dzw);
            const sc = clamp(dist / 2.5, 0.12, 1) * smoothstep(0, 0.6, c.t);
            b.wisp.setPos(lx + Math.sin(t * 2) * 0.1, c.wy - ground + Math.sin(t * 3) * 0.05, lz);
            b.wisp.setScale(sc);
            b.wisp.setEuler(t * 1.5, t * 2.1, 0);
          }
          this.syncIt(c, c.alt);
        }
      },
    });
    cr.watch.push({ id: 'baku', range: 22, points: () => all.map((c) => [c.x, 0, c.z]) });
  }

  // ================================================================ root spiders
  buildSpiders() {
    const cr = this.cr, W = this.world, S = W.L.sites;
    const avoid = this.settlements().map((s) => [s[0], s[1], 70]);
    const homes = this.spots(10, (b, x, z) => b.dead > 0.35 || b.swamp > 0.5 || (b.pines > 0.6 && hyp(x - S.rune.x, z - S.rune.z) > 30), 34, avoid);
    const all = homes.map((h, i) => {
      const rig = buildRootSpider(this.ctx, 9500 + i);
      cr.add(rig, 70);
      return { rig, home: h, x: h[0], z: h[1], yaw: this.rng.range(0, TAU), state: 'buried', t: 0, rise: 0, speed: 0, phase: 0, target: null, touched: false, cool: 0 };
    });
    this.spiders = all;
    cr.list.push({
      update: (dt, t, player) => {
        const pv = Math.hypot(player.vel[0], player.vel[2]);
        const g = this.game;
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z, pd = hyp(dxp, dzp);
          if (pd > FAR) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = pd < 72;
          c.t += dt;
          c.cool = Math.max(0, c.cool - dt);
          const sameLevel = Math.abs(player.pos[1] - W.h(c.x, c.z)) < 2.2 && !player.swimming;
          const sense = player.sneaking ? 3.2 : pv > 3.5 ? 9 : 6.5;
          let move = 0;
          if (c.state === 'buried') {
            if (sameLevel && pd < sense && c.cool <= 0 && g.state === 'play') {
              c.state = 'rise'; c.t = 0; c.touched = false;
              if (g.audio.started) g.audio.beast('spiderHiss', clamp(1.1 - pd / 12, 0.3, 1));
            }
          } else if (c.state === 'rise') {
            c.yaw += angleDiff(c.yaw, Math.atan2(dxp, dzp)) * Math.min(1, dt * 6);
            if (c.t > 0.55) { c.state = 'threat'; c.t = 0; }
          } else if (c.state === 'threat') {
            c.yaw += angleDiff(c.yaw, Math.atan2(dxp, dzp)) * Math.min(1, dt * 4);
            if (c.t > 1.0) {
              c.state = sameLevel && pd < 7 ? 'charge' : 'flee';
              c.t = 0;
              if (c.state === 'flee') this.spiderRun(c, player);
            }
          } else if (c.state === 'charge') {
            c.yaw += angleDiff(c.yaw, Math.atan2(dxp, dzp)) * Math.min(1, dt * 5);
            move = 3.4;
            if (!c.touched && pd < 1.25 && sameLevel) {
              c.touched = true;
              this.spiderHit(c, player, dxp, dzp, pd);
            }
            if (c.t > 1.6 || c.touched) { c.state = 'flee'; c.t = 0; this.spiderRun(c, player); }
          } else if (c.state === 'flee') {
            if (c.target) {
              const tx = c.target[0] - c.x, tz = c.target[1] - c.z;
              if (hyp(tx, tz) < 0.6 || c.t > 9) { c.state = 'bury'; c.t = 0; }
              else { c.yaw += angleDiff(c.yaw, Math.atan2(tx, tz)) * Math.min(1, dt * 6); move = 3.6; }
            } else { c.state = 'bury'; c.t = 0; }
          } else if (c.state === 'bury') {
            if (c.t > 1.1) { c.state = 'buried'; c.t = 0; c.cool = 6; }
          }
          c.speed = damp(c.speed, move, 8, dt);
          if (c.speed > 0.02) {
            if (!this.stepOn(c, dt, 0.45, 0.9, 60)) { c.yaw += 1.8; if (c.state === 'charge') { c.state = 'flee'; this.spiderRun(c, player); } }
          }
          // up = standing on its legs, 0 = lying low like an old stump
          const upWant = c.state === 'buried' ? 0 : c.state === 'bury' ? 1 - smoothstep(0, 1, c.t) : c.state === 'rise' ? smoothstep(0, 0.5, c.t) : 1;
          c.rise = damp(c.rise, upWant, 12, dt);
          if (!c.rig.root.visible) continue;
          const b = c.rig.bones, up = c.rise;
          const walk = clamp(c.speed / 3.4, 0, 1);
          c.phase += dt * (4 + c.speed * 4.2) * (walk > 0.03 ? 1 : 0);
          const rear = c.state === 'threat' ? Math.min(1, c.t * 4) : 0;
          const y = W.h(c.x, c.z);
          c.rig.root.setPos(c.x, y, c.z);
          c.rig.root.setRotY(c.yaw);
          b.body.position[1] = lerp(0.16, 0.55, up) + rear * 0.12 + Math.abs(Math.sin(c.phase * 2)) * 0.025 * walk;
          b.body.setEuler(-rear * 0.32 + Math.sin(c.phase * 2) * 0.03 * walk, 0, Math.sin(c.phase) * 0.04 * walk);
          b.abdomen.setEuler(rear * 0.25 + Math.sin(t * 1.3 + c.home[0]) * 0.03, Math.sin(c.phase) * 0.06 * walk, 0);
          b.eyes.visible = up > 0.25;
          b.eyes.setScale(1, clamp(up * 1.4, 0.05, 1), 1);
          const fang = c.state === 'threat' || c.state === 'charge' ? 0.35 + Math.sin(t * 18) * 0.25 : 0;
          b.fangL.setEuler(-fang, 0, fang * 0.3);
          b.fangR.setEuler(-fang, 0, -fang * 0.3);
          for (let i = 0; i < b.legs.length; i++) {
            const L = b.legs[i];
            const group = (L.k + (L.side > 0 ? 0 : 1)) % 2;
            const ph = c.phase + group * Math.PI;
            const lift = Math.max(0, Math.sin(ph)) * walk;
            const swing = Math.cos(ph) * 0.32 * walk;
            // lying low: the legs spread flat like roots; rearing: the front pair lifts
            const front = L.k === 0 ? rear : 0;
            const hipP = lerp(0.62, 0, up) - lift * 0.45 - front * 1.0;
            const kneeP = lerp(-1.25, 0, up) + lift * 0.35 + front * 0.6;
            L.hip.setEuler(hipP, L.yaw + swing * (L.side > 0 ? 1 : -1) * (L.k < 2 ? 1 : -1) + Math.sin(t * 7 + i) * 0.04 * front, 0);
            L.knee.setEuler(kneeP, 0, 0);
          }
        }
      },
    });
    cr.watch.push({ id: 'rootspider', range: 9, points: () => all.filter((c) => c.state !== 'buried').map((c) => [c.x, 0, c.z]) });
  }
  spiderRun(c, player) {
    // scuttle off to another hiding place, away from the player
    const a = Math.atan2(c.x - player.pos[0], c.z - player.pos[2]) + this.rng.range(-0.8, 0.8);
    const d = this.rng.range(10, 18);
    let p = this.cr.freeSpot(c.x + Math.sin(a) * d, c.z + Math.cos(a) * d, 5, 10);
    if (!p || hyp(p[0] - c.home[0], p[1] - c.home[1]) > 40) p = this.cr.freeSpot(c.home[0], c.home[1], 12, 10) || c.home;
    c.target = p;
  }
  spiderHit(c, player, dxp, dzp, pd) {
    const g = this.game;
    const k = 1 / Math.max(0.3, pd);
    player.vel[0] += dxp * k * 7;
    player.vel[2] += dzp * k * 7;
    player.vel[1] = Math.max(player.vel[1], 4.2);
    player.onGround = false;
    if (g.follow) g.follow.shake = Math.max(g.follow.shake || 0, 0.6);
    if (g.audio.started) g.audio.beast('spiderHiss', 1);
    if (!this.spiderToastT || g.time - this.spiderToastT > 25) {
      this.spiderToastT = g.time;
      g.ui.toast('Egy gyökérpók rád rontott!', { sub: 'A holt erdő korhadt tuskói néha felállnak. Lopakodva (C) elkerülheted őket.' });
    }
  }

  // ================================================================ the silent ones
  buildSilent() {
    const cr = this.cr, W = this.world, S = W.L.sites;
    const avoid = this.settlements().map((s) => [s[0], s[1], 110]).concat([[S.glade.x, S.glade.z, 60], [S.moongarden.x, S.moongarden.z, 50]]);
    const homes = this.spots(6, (b) => b.pines > 0.55 || b.dead > 0.45, 60, avoid);
    const all = homes.map((h, i) => {
      const rig = buildSilentOne(this.ctx, 9800 + i);
      cr.add(rig, 90);
      return { rig, home: h, x: h[0], z: h[1], yaw: this.rng.range(0, TAU), state: 'still', t: 0, seen: true, speed: 0, fade: 1, cool: 0, pose: this.newPose(), sway: this.rng.range(0, 10) };
    });
    this.silent = all;
    cr.list.push({
      update: (dt, t, player) => {
        const g = this.game, cam = g.cam;
        const fx = cam.target[0] - cam.position[0], fy = cam.target[1] - cam.position[1], fz = cam.target[2] - cam.position[2];
        const fl = Math.hypot(fx, fy, fz) || 1;
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z, pd = hyp(dxp, dzp);
          if (pd > FAR + 20) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = c.fade > 0.02 && pd < 92;
          c.t += dt;
          c.cool = Math.max(0, c.cool - dt);
          const y = W.h(c.x, c.z);
          // are you looking at it? (anywhere near the middle of the screen)
          const vx = c.x - cam.position[0], vy = y + 2.4 - cam.position[1], vz = c.z - cam.position[2];
          const vl = Math.hypot(vx, vy, vz) || 1;
          const cosA = (vx * fx + vy * fy + vz * fz) / (vl * fl);
          const seen = cosA > 0.62 && vl < 95;
          const onLand = !player.swimming && !player.mount && Math.abs(player.pos[1] - y) < 6;
          const homeD = hyp(c.x - c.home[0], c.z - c.home[1]);
          let move = 0, want = null;
          if (c.state === 'vanish') {
            c.fade = Math.max(0, c.fade - dt * 1.4);
            if (c.fade <= 0) this.silentAway(c, player);
          } else if (c.state === 'appear') {
            c.fade = Math.min(1, c.fade + dt * 0.6);
            if (c.fade >= 1) c.state = 'still';
          } else if (!seen && g.state === 'play') {
            // only when nobody is watching
            if (onLand && pd < 42 && pd > 1.2 && c.cool <= 0 && homeD < 70) want = Math.atan2(dxp, dzp);
            else if (homeD > 4) want = Math.atan2(c.home[0] - c.x, c.home[1] - c.z);
            if (want !== null) {
              if (c.state !== 'drift') { c.state = 'drift'; c.t = 0; }
              c.yaw += angleDiff(c.yaw, want) * Math.min(1, dt * 4);
              move = pd < 42 ? 2.3 : 1.5;
            } else c.state = 'still';
          } else if (c.state === 'drift') {
            // caught moving: it freezes, in a slightly different pose than before
            c.state = 'still';
            c.pose = this.newPose();
            if (g.audio.started && pd < 30) g.audio.beast('silentChime', clamp(1 - pd / 30, 0.15, 0.7));
          }
          if (c.state === 'drift' || c.state === 'still') {
            if (pd < 1.35 && onLand && c.cool <= 0 && g.state === 'play') {
              c.state = 'vanish';
              c.cool = 40;
              this.silentTouch(c, player, dxp, dzp, pd);
            }
          }
          c.speed = move ? damp(c.speed, move, 6, dt) : 0; // it stops dead, no slowing down
          if (c.speed > 0.02) {
            if (!this.stepOn(c, dt, 0.35, 2.4)) {
              // slide around whatever is in the way
              c.yaw += 1.1;
              this.stepOn(c, dt, 0.35, 2.4);
              c.yaw -= 1.1;
            }
          }
          if (!c.rig.root.visible) continue;
          const b = c.rig.bones, p = c.pose;
          const drifting = c.state === 'drift' ? 1 : 0;
          if (drifting) c.sway += dt * 2.2;
          c.rig.root.setPos(c.x, y - (1 - c.fade) * 0.6, c.z);
          c.rig.root.setRotY(c.yaw);
          c.rig.root.setScale(lerp(0.4, 1, c.fade), c.fade, lerp(0.4, 1, c.fade));
          b.torso.setEuler(0.12 * drifting + p.lean, 0, p.roll);
          b.skirt.setEuler(-0.06 * drifting + Math.sin(c.sway) * 0.03 * drifting, 0, Math.sin(c.sway * 0.7) * 0.03 * drifting);
          // the head: turned towards you when it moved last; otherwise the pose it was caught in
          const hy = clamp(angleDiff(c.yaw, Math.atan2(dxp, dzp)), -1.1, 1.1);
          b.head.setEuler(p.nod, drifting ? hy : p.turn + hy * 0.6, p.tilt);
          b.armL.setEuler(p.armL + Math.sin(c.sway) * 0.05 * drifting, 0, 0.04);
          b.armR.setEuler(p.armR - Math.sin(c.sway) * 0.05 * drifting, 0, -0.04);
        }
      },
    });
    cr.watch.push({ id: 'silent', range: 20, points: () => all.map((c) => [c.x, 0, c.z]) });
  }
  newPose() {
    const r = this.rng;
    const reach = r.chance(0.4);
    return { lean: r.range(-0.05, 0.12), roll: r.range(-0.06, 0.06), nod: r.range(-0.15, 0.3), turn: r.range(-0.4, 0.4), tilt: r.range(-0.45, 0.45), armL: reach && r.chance(0.5) ? -r.range(0.6, 1.3) : r.range(-0.15, 0.1), armR: reach ? -r.range(0.5, 1.2) : r.range(-0.15, 0.1) };
  }
  silentTouch(c, player, dxp, dzp, pd) {
    const g = this.game;
    const k = 1 / Math.max(0.3, pd);
    player.vel[0] += dxp * k * 4;
    player.vel[2] += dzp * k * 4;
    if (g.follow) g.follow.shake = Math.max(g.follow.shake || 0, 0.4);
    g.ui.dark?.();
    if (g.audio.started) g.audio.beast('silentWhisper', 1);
    if (!this.silentToastT || g.time - this.silentToastT > 30) {
      this.silentToastT = g.time;
      g.ui.toast('Egy Csendes megérintette a válladat…', { sub: 'Amíg nézed őket, nem mozdulnak. Ne fordíts hátat nekik!' });
    }
  }
  silentAway(c, player) {
    // it comes back somewhere else in its part of the forest, well away from you
    let best = null;
    for (let k = 0; k < 20; k++) {
      const p = this.cr.freeSpot(c.home[0], c.home[1], 45, 4);
      if (p && hyp(p[0] - player.pos[0], p[1] - player.pos[2]) > 35) { best = p; break; }
    }
    if (!best) best = c.home;
    c.x = best[0]; c.z = best[1];
    c.state = 'appear';
    c.fade = 0;
    c.pose = this.newPose();
  }
}
