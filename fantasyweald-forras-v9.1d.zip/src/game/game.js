// Game orchestration: state machine, main loop, quests & progress, discovery, interactions, atmosphere, saving.
import { Renderer, defaultEnv } from '../engine/renderer.js';
import { Scene, Camera } from '../engine/scene.js';
import { StaticBatcher } from '../engine/static.js';
import { mergeRig } from '../engine/rig.js';
import { World } from '../world/world.js';
import { TrailEmitter } from '../world/fx.js';
import { generateLayout } from '../world/layout.js';
import { Player, WORLD_EDGE } from './player.js';
import { FollowCamera } from './camera.js';
import { Npcs } from './npcs.js';
import { Input } from './input.js';
import { AudioEngine } from './audio.js';
import { UI } from '../ui/ui.js';
import { Events } from './events.js';
import { Progress, QUESTS, EXTRA_ABILITIES, objectives, journalData } from './quests.js';
import { SPECIES } from './creatures.js';
import { SkyLife } from './skylife.js';
import { ABILITIES, LINES } from '../data/dialogue.js';
import { Multiplayer, MP_COLORS, MP_NAMES, MP_NAMES_EN, mpHello, cleanText, hasLink, filterInput } from './multiplayer.js';
import { clamp, damp, lerp, smoothstep, TAU } from '../engine/math.js';
import { T, getLang } from '../i18n.js';

const SAVE_KEY = 'alomrengeteg.v4';
const MP_KEY = 'alomrengeteg.mp';
// multiplayer: what the forest's inhabitants say when there is no story to tell
const MP_IDLE = [
  'Rád néz, mintha ismerne valahonnan. Aztán elfelejti.',
  'Csak mosolyog. Ma éjjel nincs kedve mesélni.',
  'Valahol messze egy harang szól. Talán neked.',
  'Halkan dúdol valamit, amit te is ismersz. Honnan?',
];
const QUALITY = [
  { renderScale: 0.7, maxDpr: 1, msaa: 0, shadowSize: 1024, shadows: false, bloom: true, clarity: false, level: 0, grassFrac: 0.45, lights: 6, lod: 0 },
  { renderScale: 0.85, maxDpr: 1.5, msaa: 0, shadowSize: 2048, shadows: true, bloom: true, clarity: true, level: 1, grassFrac: 0.75, lights: 10, lod: 1 },
  { renderScale: 1.0, maxDpr: 2, msaa: 4, shadowSize: 2048, shadows: true, bloom: true, clarity: true, level: 2, grassFrac: 1.0, lights: 12, lod: 2 },
];
const DIRS = ['északra', 'északkeletre', 'keletre', 'délkeletre', 'délre', 'délnyugatra', 'nyugatra', 'északnyugatra'];

function loadSave() {
  try {
    const s = localStorage.getItem(SAVE_KEY);
    const v = s ? JSON.parse(s) : null;
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch (e) {
    return null;
  }
}
// settings come from the browser's storage too: keep only sane values
function cleanSettings(def, s) {
  const out = Object.assign({}, def);
  if (!s || typeof s !== 'object') return out;
  const n = (v, lo, hi) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : null);
  if (Number.isInteger(s.quality) && s.quality >= 0 && s.quality <= 2) out.quality = s.quality;
  for (const [k, lo, hi] of [['sensitivity', 0.3, 2.5], ['music', 0, 1], ['ambience', 0, 1], ['sfx', 0, 1]]) { const v = n(s[k], lo, hi); if (v !== null) out[k] = v; }
  for (const k of ['dynRes', 'invertY', 'pointerLock', 'showFps']) if (typeof s[k] === 'boolean') out[k] = s[k];
  return out;
}

export class Game {
  constructor(gl, canvas) {
    this.gl = gl;
    this.canvas = canvas;
    this.ui = new UI();
    this.events = new Events();
    this.input = new Input(canvas);
    this.audio = new AudioEngine();
    this.state = 'loading';
    this.time = 0;
    this.save = loadSave() || {};
    const touch = this.input.isTouch;
    const cores = navigator.hardwareConcurrency || 4;
    const smallScreen = Math.min(screen.width || 1920, screen.height || 1080) < 600;
    const mobileQ = cores >= 8 ? 1 : 0;
    const defaultQ = touch || smallScreen ? mobileQ : 1;
    this.settings = cleanSettings(
      { quality: defaultQ, dynRes: true, sensitivity: 1, music: 0.6, ambience: 0.8, sfx: 0.8, invertY: false, pointerLock: false, showFps: false },
      this.save.settings
    );
    this.worldQuality = touch || smallScreen ? Math.min(this.settings.quality, 1) : 2;
    if (window.__forceQuality !== undefined) {
      this.settings.quality = window.__forceQuality;
      this.worldQuality = window.__forceQuality;
    }
    this.fpsAcc = { t: 0, n: 0, fps: 60 };
    this.autoQ = { t: 0, frames: 0, done: !!this.save.settings };
    this.dyn = { scale: 1, t: 0, frames: 0, cool: 0 };
  }

  async init() {
    const step = (p, text) => new Promise((r) => {
      this.ui.setLoading(p, text);
      setTimeout(r, 30);
    });
    await step(0.05, 'Felkel a hold…');
    this.renderer = new Renderer(this.gl, this.canvas);
    this.cam = new Camera(55, 0.1, 1100);
    this.env = defaultEnv();
    await this.buildWorld(step, this.save.progress || {});
    this.ui.bindSettings(this.settings, (k) => this.onSetting(k));
    this.onSetting('all');
    this.bindButtons();
    this.toTitle();
    this.last = performance.now();
    window.__ready = true;
    requestAnimationFrame((t) => this.loop(t));
  }

  // build the world and everything that lives in it
  async buildWorld(step, progress = {}) {
    await step(0.1, 'Formálódik a táj…');
    this.scene = new Scene();
    const tL = performance.now();
    this.layout = generateLayout();
    const layoutMs = Math.round(performance.now() - tL);
    this.world = new World(this.gl, this.renderer, this.scene, this.worldQuality, this.layout);
    await this.world.build((p, text) => step(0.1 + p * 0.7, text));
    await step(0.8, 'Felébrednek a lakók…');
    this.P = new Progress(progress);
    this.trail = new TrailEmitter(this.gl, 320);
    this.scene.add(this.trail.mesh);
    const staticRoots = new Set(this.scene.children);
    const tN = performance.now();
    this.player = new Player(this.world, this.scene, this.trail);
    this.npcs = new Npcs(this);
    this.sky = new SkyLife(this);
    this.world.loadTimes.layout = layoutMs;
    this.world.loadTimes.npcs = Math.round(performance.now() - tN);
    // characters, creatures and quest props move: keep them out of the static batches, and merge each
    // character's parts per material (one skinned draw instead of one per part)
    for (const c of this.scene.children) {
      if (staticRoots.has(c)) continue;
      c.dynamic = true;
      mergeRig(this.gl, c);
    }
    this.follow = new FollowCamera(this.cam, this.world);
    // every shard spot + Huba's gift + the bestiary gift + Pihe's gift
    this.shardTotal = this.world.shardSpots.length + 12; // + quest rewards: Huba 3, bestiary 3, sheep 3, (v9.1) the Lantern of the Deep 3
    this.hookEvents();
    this.syncWorld();
    const sp = this.save.pos;
    const L = this.layout;
    const okPos = Array.isArray(sp) && [sp[0], sp[1], sp[2]].every(Number.isFinite) && Math.hypot(sp[0], sp[1]) < WORLD_EDGE && (sp[3] === undefined || sp[3] === null || (Number.isFinite(sp[3]) && sp[3] > -50 && sp[3] < 400));
    if (okPos) this.player.spawn(sp[0], sp[1], sp[2], Number.isFinite(sp[3]) ? sp[3] : null);
    else this.player.spawn(L.spawn.x, L.spawn.z, L.spawn.yaw);
    this.follow.yaw = this.player.yaw;
    this.follow.snap(this.player);
    this.applyQuality();
    await step(0.86, 'Szentjánosbogarak ébrednek…');
    // let the world live for a moment; whatever moves by itself stays out of the static batches
    const t0 = performance.now();
    this.attractCamera(0);
    this.scene.updateWorld();
    const statics = new StaticBatcher(this.gl);
    statics.snapshot(this.scene);
    for (let i = 0; i < 10; i++) { this.frame(1 / 30, false); this.scene.updateWorld(); }
    this.batchInfo = statics.build(this.scene);
    this.scene.statics = statics;
    this.world.buildSolidGrid();
    statics.releaseCpu(this.scene);
    const t1 = performance.now();
    // compile every shader now (in parallel where the browser can) instead of stuttering on first sight
    await step(0.9, 'Hangolódnak a fények…');
    const nProg = await this.renderer.precompile(this.scene, (f) => this.ui.setLoading(0.9 + f * 0.08));
    this.loadTimes = { batchMs: Math.round(t1 - t0), shaderMs: Math.round(performance.now() - t1), programs: nProg };
    this.attractCamera(this.time);
    this.renderer.render(this.scene, this.cam, this.env, this.time);
    this.ui.mapBase = null;
    this.refreshHud();
    await step(1, 'Kész.');
  }

  // world state that follows saved progress (gates, portals, shards, abilities)
  syncWorld() {
    const P = this.P, W = this.world;
    // (multiplayer: no shards to collect, everybody can do everything)
    for (const id of [...P.creatures]) if (!SPECIES.some((sp) => sp.id === id)) P.creatures.delete(id);
    W.shardCollected = this.mp ? new Set(W.shardSpots.map((s) => s.id)) : new Set([...P.shards].filter((id) => W.shardSpots.some((s) => s.id === id)));
    for (const g of W.gates) g.portal.material.uniforms.uPortalActive = P.gates.has(g.id) ? 1 : 0;
    this.setGateOpen(P.flags.has('gateOpen'), false);
    this.player.abilities.clear();
    for (const a of ABILITIES) if (P.shards.size >= a.need) this.player.abilities.add(a.id);
    for (const id in EXTRA_ABILITIES) if (P.flags.has('ab_' + id)) this.player.abilities.add(id);
    if (this.mp) for (const id of ['doubleJump', 'glide', 'moonrun']) this.player.abilities.add(id);
    // (v8) the dragon's crown on your hat, once it is yours (in the shared forest too, from your own story)
    const own = this.mp && this.spBackup ? this.spBackup.P : P;
    if (this.player.wearCrown) this.player.wearCrown(!!(own && own.items.has('crown')));
  }

  applyQuality() {
    const q = QUALITY[this.settings.quality];
    this.renderer.setQuality(q);
    if (this.world) this.world.setGrassFraction(q.grassFrac);
  }

  onSetting(k) {
    const s = this.settings;
    if (k === 'quality' || k === 'all') this.applyQuality();
    if (k === 'dynRes' && !s.dynRes) { this.dyn.scale = 1; this.renderer.dynScale = 1; this.renderer.width = 0; }
    this.input.sensitivity = s.sensitivity;
    this.input.invertY = s.invertY;
    this.input.wantPointerLock = s.pointerLock;
    this.audio.setVolume('music', s.music);
    this.audio.setVolume('ambience', s.ambience);
    this.audio.setVolume('sfx', s.sfx);
    if (k !== 'all') this.persist();
  }

  persist() {
    try {
      const p = this.player;
      // in the shared forest the single-player story is parked in spBackup: save that one
      const sp = this.mp && this.spBackup;
      const P = sp ? sp.P : this.P;
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        settings: this.settings,
        progress: P ? P.toJSON() : null,
        pos: sp ? sp.pos : p ? this.savePos() : null,
      }));
    } catch (e) { /* storage unavailable */ }
  }

  savePos() {
    const p = this.player;
    const seat = p.mount && this.sky ? this.sky.savePos() : null;
    if (seat) return [seat[0], seat[2], p.yaw, seat[1]];
    return [p.pos[0], p.pos[2], p.yaw, p.pos[1]];
  }

  hookEvents() {
    const a = this.audio;
    const w = this.world;
    const pl = this.player;
    pl.onStep = (speed) => {
      const p = pl.pos;
      let surface = 'grass';
      if (w.waterDepth(p[0], p[2]) > 0.02 && p[1] < w.L.waterLevel + 0.1) surface = 'water';
      else if (pl.groundSurface && pl.groundSurface.tag === 'ash') surface = 'stone';
      else if (p[1] > w.h(p[0], p[2]) + 0.2) surface = pl.groundSurface && pl.groundSurface.tag === 'bounce' ? 'grass' : 'wood';
      else if (w.terrain.sample(w.terrain.wPath, p[0], p[2]) > 0.5 || w.terrain.sample(w.terrain.wRock, p[0], p[2]) > 0.5) surface = 'stone';
      a.step(surface, speed);
      const n = surface === 'stone' ? 2 : 1;
      for (let i = 0; i < n; i++) {
        this.trail.emit([p[0] + (Math.random() - 0.5) * 0.3, p[1] + 0.05, p[2] + (Math.random() - 0.5) * 0.3], this.time, { size: 0.05 + Math.random() * 0.04, life: 0.8, rise: 0.3, spread: 0.3, color: [0.45, 0.75, 1.6], intensity: 1.4 });
      }
    };
    const burst = (p, n, color, spread = 0.9) => {
      for (let i = 0; i < n; i++) {
        const ang = (i / n) * TAU;
        this.trail.emit([p[0] + Math.cos(ang) * 0.3, p[1] + 0.05, p[2] + Math.sin(ang) * 0.3], this.time, { size: 0.07, life: 0.9, rise: 0.2, spread, color, intensity: 1.7 });
      }
    };
    this.burst = burst;
    pl.onJump = () => {
      a.jump();
      this.events.emit('jump', {});
      burst(pl.pos, 10, [0.55, 0.8, 1.7]);
    };
    pl.onDoubleJump = () => {
      a.chime([1318, 1760], 0.05, 0.05, 0.6);
      burst(pl.pos, 14, [1.0, 0.9, 0.5], 1.4);
    };
    pl.onBounce = (surf) => {
      a.bounce ? a.bounce() : a.jump();
      if (surf.pad) surf.pad.squash = 1;
      burst([pl.pos[0], pl.pos[1], pl.pos[2]], 12, [0.9, 0.5, 1.8], 1.2);
      this.follow.shake = 0.3;
      this.events.emit('bounce', {});
    };
    pl.onSplash = (k) => {
      a.splash && a.splash(k);
      burst([pl.pos[0], this.layout.waterLevel, pl.pos[2]], 14, [0.6, 0.9, 1.6], 0.8);
    };
    pl.onEdge = () => {
      if (this.edgeToastT && this.time - this.edgeToastT < 20) return;
      this.edgeToastT = this.time;
      this.ui.toast('Itt véget ér az álom.', { sub: 'Tovább nem lehet menni. Fordulj vissza a sziget felé.' });
    };
    pl.onLand = (air) => { a.land(air); this.follow.shake = Math.min(1, air * 0.6); this.events.emit('land', { air }); };
    this.npcs.onCrow = (pos) => {
      const dx = pos[0] - this.cam.position[0], dz = pos[2] - this.cam.position[2];
      const ang = Math.atan2(dx, dz) - this.follow.yaw;
      a.caw(clamp(-Math.sin(ang), -0.9, 0.9));
      a.flap();
    };
  }

  bindButtons() {
    const e = this.ui.el;
    const fullscreen = () => this.goFullscreen();
    const start = () => {
      fullscreen();
      this.audio.start();
      this.onSetting('all');
      this.enterPlay();
    };
    e.btnPlay.addEventListener('click', start);
    e.btnNew.addEventListener('click', () => {
      this.P = new Progress({});
      this.syncWorld();
      const L = this.layout;
      this.player.spawn(L.spawn.x, L.spawn.z, L.spawn.yaw);
      this.follow.yaw = this.player.yaw;
      this.follow.snap(this.player);
      this.refreshHud();
      start();
    });
    e.btnTitleSettings.addEventListener('click', () => this.openSettings('title'));
    e.btnMulti.addEventListener('click', () => this.openMpJoin());
    e.btnMpBack.addEventListener('click', () => this.closeMpJoin());
    e.mpJoinForm.addEventListener('submit', (ev) => { ev.preventDefault(); this.startMultiplayer(); });
    // (v9) names are plain text too: no emoji or symbols, nothing dropped or pasted but text
    e.mpName.addEventListener('input', () => filterInput(e.mpName));
    e.mpName.addEventListener('drop', (ev) => ev.preventDefault());
    e.mpName.addEventListener('paste', (ev) => { const cd = ev.clipboardData; if (cd && cd.files && cd.files.length) ev.preventDefault(); });
    e.btnMainMenu.addEventListener('click', () => this.toMainMenu());
    e.tChat.addEventListener('click', () => { if (this.mp && this.state === 'play') this.mp.openChat(); });
    e.btnResume.addEventListener('click', () => { fullscreen(); this.resume(); });
    e.btnMap.addEventListener('click', () => this.openMap());
    e.btnSettings.addEventListener('click', () => this.openSettings('pause'));
    e.btnHome.addEventListener('click', () => {
      const L = this.layout;
      this.player.spawn(L.spawn.x, L.spawn.z, L.spawn.yaw);
      this.follow.yaw = this.player.yaw;
      this.follow.snap(this.player);
      this.resume();
    });
    e.btnSettingsBack.addEventListener('click', () => this.closeSettings());
    e.dialogue.addEventListener('click', () => this.advanceDialogue());
    for (const b of document.querySelectorAll('#ui button')) b.addEventListener('click', () => this.audio.click());
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (this.state === 'play') this.pause();
        this.audio.suspend();
      } else if (this.state !== 'title') this.audio.resume();
    });
    window.addEventListener('beforeunload', () => this.persist());
    // closing the tab in multiplayer: say goodbye to the server right away
    window.addEventListener('pagehide', () => { this.persist(); if (this.mp) this.mp.leave(); });
  }

  // phones and tablets: play in full screen (where the browser allows it; an installed web app is
  // full screen anyway thanks to the manifest)
  goFullscreen() {
    if (!this.input.isTouch || document.fullscreenElement || window.matchMedia?.('(display-mode: fullscreen)').matches) return;
    const el = document.documentElement;
    const req = el.requestFullscreen || el.webkitRequestFullscreen;
    if (req) { try { const r = req.call(el, { navigationUI: 'hide' }); if (r && r.catch) r.catch(() => {}); } catch (err) { /* not allowed */ } }
  }

  // ------------------------------------------------------------ multiplayer
  loadMpPrefs() {
    try { return JSON.parse(localStorage.getItem(MP_KEY) || '{}') || {}; } catch (e) { return {}; }
  }
  openMpJoin() {
    const e = this.ui.el;
    this.ui.show('title', false);
    this.ui.show('mpJoin', true);
    this.state = 'mpjoin';
    const pr = this.loadMpPrefs();
    const names = getLang() === 'en' ? MP_NAMES_EN : MP_NAMES;
    if (!e.mpName.value) e.mpName.value = typeof pr.name === 'string' && pr.name ? pr.name : names[Math.floor(Math.random() * names.length)];
    if (this.mpColor === undefined) this.mpColor = Number.isInteger(pr.color) && pr.color >= 0 && pr.color < MP_COLORS.length ? pr.color : Math.floor(Math.random() * MP_COLORS.length);
    this.ui.mpColors(MP_COLORS, this.mpColor, (i) => { this.mpColor = i; this.audio.click(); });
    e.btnMpGo.disabled = false;
    this.ui.mpStatus('Keresem a közös erdőt…');
    const ask = (this.mpAsk = (this.mpAsk || 0) + 1);
    mpHello().then((j) => {
      if (ask !== this.mpAsk || this.state !== 'mpjoin') return;
      if (j.players >= j.max) this.ui.mpStatus(T('Tele van az erdő ({0} / {1}). Próbáld újra kicsit később!', j.players, j.max), 'err');
      else if (j.players > 0) this.ui.mpStatus(T('Most {0} vándor jár az erdőben.', j.players), 'ok');
      else this.ui.mpStatus('Most senki sincs az erdőben. Te lehetsz az első!', 'ok');
    }).catch((err) => {
      if (ask !== this.mpAsk || this.state !== 'mpjoin') return;
      this.ui.mpStatus(this.mpErrorText(err), 'err');
    });
    if (!this.input.isTouch) setTimeout(() => { e.mpName.focus(); e.mpName.select(); }, 60);
  }
  mpErrorText(err) {
    if (err && err.message === 'file') return 'A közös álom csak a feltöltött weboldalon működik (a web-zipben lévő mp.php kell hozzá).';
    if (err && err.message === 'full') return 'Tele van az erdő. Próbáld újra kicsit később!';
    if (err && err.message === 'ip') return 'Erről a hálózatról már túl sokan vannak bent. Próbáld újra kicsit később!';
    if (err && err.message === 'slow') return 'Egy pillanat… túl gyorsan próbálkozol. Próbáld újra pár másodperc múlva!';
    return 'Nem érem el a közös erdőt. A többjátékos mód a saját weboldaladon működik, ahová a web-zipet (benne az mp.php-val) feltöltötted.';
  }
  closeMpJoin() {
    this.mpAsk = (this.mpAsk || 0) + 1;
    this.ui.show('mpJoin', false);
    this.toTitle();
  }
  async startMultiplayer() {
    const e = this.ui.el;
    if (this.mpBusy || this.mp) return;
    const name = cleanText(e.mpName.value, 16);
    if (!name || !/[\p{L}\p{N}]/u.test(name)) { this.ui.mpStatus('Adj nevet a törpédnek!', 'err'); e.mpName.focus(); return; }
    if (hasLink(name)) { this.ui.mpStatus('A név nem lehet link. Csak sima szöveget használj!', 'err'); e.mpName.focus(); return; }
    const color = this.mpColor || 0;
    this.mpBusy = true;
    e.btnMpGo.disabled = true;
    this.ui.mpStatus('Belépés…');
    try { localStorage.setItem(MP_KEY, JSON.stringify({ name, color })); } catch (err) { /* storage unavailable */ }
    const mp = new Multiplayer(this, { name, color });
    try {
      await mp.join();
    } catch (err) {
      mp.dispose();
      this.mpBusy = false;
      e.btnMpGo.disabled = false;
      if (this.state === 'mpjoin') this.ui.mpStatus(this.mpErrorText(err), 'err');
      return;
    }
    this.mpBusy = false;
    e.btnMpGo.disabled = false;
    if (this.state !== 'mpjoin') { mp.dispose(); return; }
    // park the single-player story (it is saved as it is) and dream together with a clean slate
    this.persist();
    if (this.player.mount && this.sky) this.sky.dismount(false);
    this.spBackup = { P: this.P, pos: this.savePos() };
    this.mp = mp;
    const P = new Progress({});
    for (const g of this.world.gates) P.gates.add(g.id);
    for (const f of ['gateOpen', 'bellTaught', 'introHint', 'metPihe']) P.flags.add(f);
    this.P = P;
    this.syncWorld();
    this.player.setLook(MP_COLORS[color]);
    const L = this.layout;
    const a = Math.random() * Math.PI * 2, r = 1.5 + Math.random() * 3;
    this.player.spawn(L.spawn.x + Math.cos(a) * r, L.spawn.z + Math.sin(a) * r, L.spawn.yaw);
    this.lastRegion = null;
    this.objectivesCache = [];
    this.ui.tracker([]);
    this.ui.setMpMode(true);
    this.ui.show('mpJoin', false);
    this.goFullscreen();
    this.audio.start();
    this.onSetting('all');
    this.enterPlay();
    mp.start();
    mp.system(T('Üdv a közös erdőben, {0}! {1}', name, T(this.input.isTouch ? 'A Csevegés gombbal írhatsz a többieknek.' : 'Enter: írás a többieknek.')));
  }
  stopMultiplayer() {
    const mp = this.mp;
    if (!mp) return;
    mp.dispose();
    this.mp = null;
    const sp = this.spBackup;
    this.spBackup = null;
    if (this.player.mount && this.sky) this.sky.dismount(false);
    this.P = sp.P;
    this.syncWorld();
    this.player.setLook(null);
    const pos = sp.pos;
    if (pos && Number.isFinite(pos[0])) this.player.spawn(pos[0], pos[1], pos[2], Number.isFinite(pos[3]) ? pos[3] : null);
    else this.player.spawn(this.layout.spawn.x, this.layout.spawn.z, this.layout.spawn.yaw);
    this.follow.yaw = this.player.yaw;
    this.follow.snap(this.player);
    this.ui.setMpMode(false);
    for (const s of ['pause', 'map', 'settings', 'travel', 'hud']) this.ui.show(s, false);
    this.ui.closeDialogue();
    this.talk = null;
    this.lastRegion = null;
    this.trackerDirty = true;
    this.ui.trackerKey = '';
    this.refreshHud();
    this.persist();
    this.toTitle();
  }
  // pause menu list: you first, then the others by distance
  mpRoster() {
    const mp = this.mp, p = this.player.pos;
    const list = [{ name: mp.name, css: MP_COLORS[mp.color].css, self: true, where: '' }];
    const others = mp.others().map((o) => ({ ...o, d: Math.hypot(o.x - p[0], o.z - p[2]) })).sort((a, b) => a.d - b.d).slice(0, 40);
    for (const o of others) list.push({ name: o.name, css: o.css, where: o.d < 12 ? T('itt melletted') : `${Math.round(o.d)} m · ${this.dirWord(p, [o.x, 0, o.z])}${o.y - p[1] > 25 ? T(' · fent az égen') : ''}` });
    return list;
  }

  // (v8) the language was switched: redo whatever text is already on screen
  relang() {
    this.ui.relang();
    this.trackerDirty = true;
    if (this.world) this.refreshHud();
    // (the switch is on the title screen and in the settings, which sit over the title or the pause menu)
    const under = this.state === 'settings' ? (this.settingsFrom === 'title' ? 'title' : 'pause') : this.state;
    if (under === 'title' && this.P) this.titleText();
    if (under === 'pause' && this.world) {
      if (this.mp) this.ui.mpPlayers(this.mpRoster(), this.mp.count);
      else this.ui.journal(journalData(this));
    }
    if (this.mp) this.ui.mpColors(MP_COLORS, this.mp.color, () => {});
  }

  // (v9) pause menu → main menu (in multiplayer this leaves the shared forest)
  toMainMenu() {
    if (this.mp) { this.stopMultiplayer(); return; }
    if (this.player.mount && this.sky) this.sky.dismount(false);
    this.ui.closeDialogue();
    this.talk = null;
    for (const s of ['pause', 'map', 'settings', 'travel', 'ending', 'hud']) this.ui.show(s, false);
    this.persist();
    this.toTitle();
  }
  titleish() {
    return this.state === 'title' || this.state === 'mpjoin' || (this.state === 'settings' && this.settingsFrom === 'title');
  }
  toTitle() {
    this.ui.show('loading', false);
    this.ui.show('title', true);
    this.titleText();
    this.state = 'title';
  }
  titleText() {
    const started = this.P.stage.main > 0 || this.P.discovered.size > 1 || this.P.shards.size > 0;
    this.ui.el.btnPlay.textContent = T(started ? 'Folytatás' : 'Belépés');
    this.ui.el.btnNew.hidden = !started;
    if (this.input.isTouch) this.ui.el.titleHint.textContent = T('Bal hüvelykujj: mozgás · jobb oldal húzása: kamera.');
  }

  enterPlay() {
    this.ui.show('title', false);
    this.ui.show('hud', true);
    if (this.input.isTouch) this.ui.enableTouch(this.input);
    this.state = 'play';
    this.follow.yaw = this.player.yaw;
    this.follow.snap(this.player);
    this.playTime = 0;
    this.refreshHud();
    setTimeout(() => this.ui.fadeKeys(), 18000);
    if (!this.mp && this.P.stage.main === 0 && !this.P.flags.has('introHint')) {
      this.P.flags.add('introHint');
      setTimeout(() => this.ui.toast('Vén Barnabás az üstje mellett vár rád.', { sub: 'Menj közel, és nyomd meg az E betűt.' }), 2500);
    }
  }
  pause() {
    if (this.state !== 'play') return;
    this.state = 'pause';
    if (this.mp) this.ui.mpPlayers(this.mpRoster(), this.mp.count);
    else this.ui.journal(journalData(this));
    this.ui.show('pause', true);
    if (document.pointerLockElement) document.exitPointerLock?.();
    this.persist();
  }
  openJournal() {
    this.pause();
  }
  resume() {
    for (const s of ['pause', 'map', 'settings', 'travel', 'ending']) this.ui.show(s, false);
    this.state = 'play';
  }
  openMap() {
    if (this.state === 'play' || this.state === 'pause') {
      this.mapFrom = this.state;
      this.ui.show('pause', false);
      this.ui.show('map', true);
      this.state = 'map';
      if (document.pointerLockElement) document.exitPointerLock?.();
    }
  }
  closeMap() {
    this.ui.show('map', false);
    if (this.mapFrom === 'pause') { this.state = 'pause'; this.ui.show('pause', true); }
    else this.state = 'play';
  }
  openSettings(from) {
    this.settingsFrom = from;
    this.ui.refreshSettings?.();
    this.ui.show(from === 'title' ? 'title' : 'pause', false);
    this.ui.show('settings', true);
    this.state = 'settings';
  }
  closeSettings() {
    this.ui.show('settings', false);
    this.persist();
    if (this.settingsFrom === 'title') { this.ui.show('title', true); this.state = 'title'; }
    else { this.ui.show('pause', true); this.state = 'pause'; }
  }

  // ------------------------------------------------------------ progress helpers used by npcs.js
  dirWord(from, to) {
    const dx = to[0] - from[0], dz = (to.length > 2 ? to[2] : to[1]) - (from.length > 2 ? from[2] : from[1]);
    const deg = ((Math.atan2(dx, -dz) * 180) / Math.PI + 360) % 360;
    const w = T(DIRS[Math.round(deg / 45) % 8]);
    return Math.hypot(dx, dz) > 170 ? T('messze {0}', w) : w;
  }
  fill(text, from) {
    const S = this.layout.sites, A = this.world.anchors;
    const site = (s) => [s.x, 0, s.z];
    const map = { islands: site(S.islands), crater: site(S.crater), tower: site(S.tower), crystal: site(S.crystal), giant: site(S.giant), ruins: site(S.ruins), snail: A.snailSpot || site(S.glade) };
    return T(text).replace(/\{(\w+)Dir\}/g, (m, k) => (map[k] ? this.dirWord(from, map[k]) : m));
  }
  setStage(id, n, silent = false) {
    const P = this.P;
    const old = P.stage[id];
    if (old === n) return;
    P.stage[id] = n;
    if (this.mp) return; // no quests in the shared forest
    if (id !== 'main' && old === 0 && !P.order.includes(id)) P.order.push(id);
    const q = QUESTS[id];
    if (P.done(id)) {
      this.ui.toast(T('Küldetés teljesítve: {0}', T(q.title)), { gold: true });
      this.audio.discover();
    } else if (!silent) {
      if (old === 0) this.ui.toast(T('Új küldetés: {0}', T(q.title)), { sub: objectives(this).find((o) => o.id === id)?.text || '' , gold: id === 'main' });
      else this.ui.toast(q.title, { sub: objectives(this).find((o) => o.id === id)?.text || 'A napló frissült.' });
      this.audio.chime([659, 988], 0.05, 0.1, 0.8);
    }
    this.refreshHud();
    this.persist();
  }
  giveItem(id, name) {
    this.P.items.add(id);
    if (this.mp) return;
    this.ui.toast(T('Megszerezted: {0}', T(name)));
    this.audio.chime([784, 1175, 1568], 0.06, 0.09, 1);
    this.persist();
  }
  checkKeyParts() {
    const P = this.P;
    const n = ['keyA', 'keyB', 'keyC'].filter((k) => P.items.has(k)).length;
    if (P.stage.main === 0 && n > 0) this.setStage('main', 1, true);
    if (P.stage.main === 1 && n === 3) this.ui.toast('Mind a három kulcsdarab megvan!', { sub: 'Vidd vissza őket Vén Barnabásnak.', gold: true });
    this.refreshHud();
  }
  bonusShards(prefix, n) {
    if (this.mp) return;
    for (let i = 1; i <= n; i++) this.P.shards.add(prefix + i);
    this.ui.toast(T('+{0} csillagszilánk', n), { gold: true });
    this.afterShard();
  }
  // bestiary: the first time you meet a kind of creature
  meetCreature(id) {
    const P = this.P;
    if (this.mp || P.creatures.has(id)) return;
    P.creatures.add(id);
    const sp = SPECIES.find((s) => s.id === id);
    this.ui.toast(T('Új álomlény: {0}', T(sp ? sp.name : id)), { sub: T('Álomlények: {0} / {1} · a naplóban olvashatsz róla', P.creatures.size, SPECIES.length) });
    this.audio.chime([659.25, 987.77, 1318.5], 0.045, 0.1, 1);
    if (!this.mp && P.creatures.size >= SPECIES.length && !P.flags.has('allCreatures')) {
      P.flags.add('allCreatures');
      setTimeout(() => {
        this.ui.toast('Minden álomlénnyel találkoztál!', { sub: 'Az erdő lakói megajándékoznak.', gold: true });
        this.bonusShards('creat', 3);
      }, 1800);
    }
    this.persist();
  }
  grantAbility(id) {
    this.P.flags.add('ab_' + id);
    this.player.abilities.add(id);
    const a = EXTRA_ABILITIES[id] || ABILITIES.find((x) => x.id === id);
    if (a) this.ui.banner({ eyebrow: 'Új képesség', name: a.name, blurb: a.text });
    this.audio.discover();
    this.persist();
  }
  readLore(s) {
    const P = this.P;
    if (this.mp || P.lore.has(s.id)) return;
    P.lore.add(s.id);
    if (P.stage.lore === 0) this.setStage('lore', 1);
    const total = this.world.loreSpots.length;
    if (P.lore.size >= total) this.ui.toast('Minden rúnakövet elolvastál.', { sub: 'A csuklyások a Kék Láng körében várnak.', gold: true });
    else this.ui.toast(T('Rúnakő {0} / {1}', P.lore.size, total));
    this.refreshHud();
    this.persist();
  }
  activateGate(gt) {
    this.P.gates.add(gt.id);
    gt.portal.material.uniforms.uPortalActive = 1;
    this.ui.toast(T('Holdkapu felébredt: {0}', T(gt.name)), { sub: 'A felébresztett kapuk között utazni lehet.' });
    this.audio.chime([523, 784, 1046, 1568], 0.06, 0.12, 1.2);
    this.persist();
  }
  openTravel(from) {
    const P = this.P;
    const list = this.world.gates.filter((g) => g !== from && P.gates.has(g.id)).map((g) => ({ ...g, dist: `${Math.round(Math.hypot(g.x - from.x, g.z - from.z))} m · ${this.dirWord([from.x, 0, from.z], [g.x, 0, g.z])}` }));
    this.state = 'travel';
    if (document.pointerLockElement) document.exitPointerLock?.();
    setTimeout(() => {
      this.ui.closeDialogue();
      this.talk = null;
      this.ui.travel(list, (g) => this.travelTo(g), () => this.resume());
    }, 0);
  }
  travelTo(g) {
    this.ui.show('travel', false);
    this.ui.fade(true);
    this.audio.chime([1046, 784, 523], 0.07, 0.14, 1.4);
    setTimeout(() => {
      const f = g.front;
      this.player.spawn(f[0], f[2], g.yaw);
      this.follow.yaw = g.yaw;
      this.follow.snap(this.player);
      this.state = 'play';
      setTimeout(() => this.ui.fade(false), 250);
    }, 850);
  }
  // a dream door: step through, and you are somewhere else
  throughDoor(door) {
    const d = door.dest && door.dest();
    if (!d) return;
    this.ui.fade(true);
    this.audio.chime([392, 587.33, 784, 1174.66], 0.06, 0.1, 1.6);
    this.state = 'travel';
    setTimeout(() => {
      const yaw = Math.random() * Math.PI * 2;
      this.player.spawn(d[0] + Math.sin(yaw) * 0.8, d[2] + Math.cos(yaw) * 0.8, yaw, d[1] ?? null);
      this.follow.yaw = yaw;
      this.follow.snap(this.player);
      this.state = 'play';
      setTimeout(() => {
        this.ui.fade(false);
        this.ui.toast('Az ajtó átvezetett', { sub: door.name });
      }, 250);
    }, 700);
  }
  setGateOpen(open, animate) {
    const W = this.world;
    const G = W.gate;
    if (W.gateDoor) W.gateDoor.yMax = open ? -Infinity : Infinity;
    for (const s of W.lightStairs.surfaces) s.disabled = !open;
    W.lightStairs.node.visible = open;
    G.anchors.dark.visible = !open;
    this.gateAnim = open ? (animate ? 0 : 1) : null;
    G.anchors.bars.position[1] = open && !animate ? 5.4 : 0;
  }
  openGate(animate) {
    this.P.flags.add('gateOpen');
    this.setGateOpen(true, animate);
    if (animate) {
      this.ui.flash();
      this.audio.discover();
      this.follow.gazeUp(0.7, 6, 1.0);
      this.ui.banner({ eyebrow: 'A kapu kinyílt', name: 'A fénylépcső', blurb: 'Fényből szőtt lépcső vezet fel a várhoz.' });
    }
    this.persist();
  }
  forgeFx() {
    this.ui.flash();
    this.audio.discover();
    const c = this.world.anchors.cauldron;
    for (let i = 0; i < 40; i++) this.trail.emit([c[0] + (Math.random() - 0.5) * 0.8, c[1] + 1 + Math.random(), c[2] + (Math.random() - 0.5) * 0.8], this.time, { size: 0.14, life: 1.8, rise: 1.2, spread: 1.4, color: [1.4, 1.2, 0.6], intensity: 3 });
  }
  flash() {
    this.ui.flash();
  }
  hint(text) {
    if (this.lastHint && this.time - this.lastHint < 6) return;
    this.lastHint = this.time;
    this.ui.toast(text);
  }
  revealHidden() {
    if (this.mp) return;
    this.P.flags.add('revealHidden');
    this.ui.toast('A térképen megjelentek a rejtett helyek.', { gold: true });
    this.persist();
  }
  ending() {
    if (this.mp) return;
    setTimeout(() => {
      this.state = 'ending';
      if (document.pointerLockElement) document.exitPointerLock?.();
      const P = this.P;
      const stats = T('✦ {0} / {1} csillagszilánk · {2} / {3} helyszín · {4} / {5} rúnakő', P.shards.size, this.shardTotal, P.discovered.size, this.world.regions.length, P.lore.size, this.world.loreSpots.length);
      this.ui.ending(stats, () => this.resume());
    }, 1400);
  }
  afterShard() {
    const n = this.P.shards.size;
    this.ui.setShards(n, this.shardTotal, true);
    for (const a of ABILITIES) {
      if (n >= a.need && !this.player.abilities.has(a.id)) {
        this.player.abilities.add(a.id);
        this.ui.banner({ eyebrow: 'Új képesség', name: a.name, blurb: a.text });
        this.audio.discover();
      }
    }
    this.persist();
  }
  refreshHud() {
    if (!this.world) return;
    this.ui.setShards(this.P.shards.size, this.shardTotal);
    this.ui.setFound(this.P.discovered.size, this.world.regions.length);
    this.trackerDirty = true;
  }

  // ------------------------------------------------------------ the Mumus
  onMumus(what, m, dist) {
    const a = this.audio;
    if (what === 'notice') {
      if (a.started) a.mumus('screech', clamp(1.2 - dist / 25, 0.4, 1));
      this.follow.shake = Math.max(this.follow.shake, 0.35);
      if (!this.mumusToastT || this.time - this.mumusToastT > 20) {
        this.mumusToastT = this.time;
        this.ui.toast('A Mumus észrevett!', { sub: 'Fuss! (Shift) — a vízbe vagy magasra nem jön utánad.' });
      }
    } else if (what === 'catch') this.mumusCaught();
  }
  mumusCaught() {
    if (this.mumusBusy) return;
    this.mumusBusy = true;
    if (this.audio.started) this.audio.mumus('catch');
    this.follow.shake = 1;
    this.ui.fade(true);
    if (this.talk) { this.ui.closeDialogue(); this.talk = null; }
    this.state = 'travel';
    setTimeout(() => {
      const L = this.layout;
      const a = Math.random() * Math.PI * 2;
      this.player.spawn(L.spawn.x + Math.cos(a) * 2, L.spawn.z + Math.sin(a) * 2, L.spawn.yaw);
      this.follow.yaw = this.player.yaw;
      this.follow.snap(this.player);
      if (this.state === 'travel') this.state = 'play';
      setTimeout(() => {
        this.ui.fade(false);
        this.ui.toast('A Mumus a zsákjába dugott…', { sub: '…aztán kiborított a tisztáson. Legközelebb lopakodj, vagy fuss!' });
        this.mumusBusy = false;
      }, 450);
    }, 1300);
  }

  // (v9) swallowed by the Lantern of the Deep: darkness, then you wake up on the nearest beach
  leviathanCaught() {
    if (this.levBusy) return;
    this.levBusy = true;
    if (this.audio.started) this.audio.beast('levSwallow', 1);
    this.follow.shake = 1;
    this.ui.fade(true);
    if (this.talk) { this.ui.closeDialogue(); this.talk = null; }
    this.state = 'travel';
    const pl = this.player;
    setTimeout(() => { pl.root.visible = false; }, 180);
    setTimeout(() => {
      // the nearest dry sand towards the middle of the island
      const W = this.world, L = this.layout;
      const a = Math.atan2(pl.pos[2], pl.pos[0]);
      let spot = null;
      for (let r = Math.min(Math.hypot(pl.pos[0], pl.pos[2]), 360); r > 150 && !spot; r -= 3) {
        const x = Math.cos(a) * r, z = Math.sin(a) * r;
        if (W.waterDepth(x, z) < -0.5) spot = this.npcs.creatures.freeSpot(x - Math.cos(a) * 4, z - Math.sin(a) * 4, 4, 20) || [x - Math.cos(a) * 4, z - Math.sin(a) * 4];
      }
      if (!spot) spot = [L.spawn.x, L.spawn.z];
      pl.spawn(spot[0], spot[1], Math.atan2(-Math.cos(a), -Math.sin(a)) + Math.PI);
      pl.root.visible = true;
      this.follow.yaw = pl.yaw;
      this.follow.snap(pl);
      if (this.state === 'travel') this.state = 'play';
      this.meetCreature('leviathan');
      if (this.P.stage.deep === 1 && !this.P.flags.has('levSeen')) { this.P.flags.add('levSeen'); this.trackerDirty = true; }
      setTimeout(() => {
        this.ui.fade(false);
        this.ui.toast('A Mélység Lámpása elnyelt…', { sub: '…aztán kiköpött a partra. A nyílt vízen figyeld, nem közeledik-e fény a mélyből!' });
        this.levBusy = false;
      }, 500);
    }, 1500);
  }

  // ------------------------------------------------------------ interactions
  nearestInteractable() {
    const p = this.player.pos;
    let best = null, bd = Infinity;
    for (const it of this.npcs.interactables) {
      const dx = it.pos[0] - p[0], dz = it.pos[2] - p[2];
      const d = Math.hypot(dx, dz);
      if (d > it.radius || Math.abs(it.pos[1] - p[1]) > 4) continue;
      if (it.visible && !it.visible()) continue;
      if (this.mp && (it.kind === 'take' || it.id === 'keyB')) continue; // quest things: not in the shared forest
      if (d < bd) { bd = d; best = it; }
    }
    return best;
  }
  interact(target) {
    let conv = null;
    if (this.mp) {
      // shared forest: gates, bells and whales work; everybody else just chats (no quests)
      const id = target.id || '';
      if (target.kind === 'gate' || id.startsWith('bell_') || id.startsWith('ride_')) conv = target.talk ? target.talk() : null;
      else if (target.kind === 'read' && target.talk) { const c = target.talk(); conv = { name: c.name, lines: c.lines }; }
      else if (!target.lines && !target.mpLines) {
        const lines = LINES[id] || LINES[id.replace(/\d+$/, '')];
        target.mpLines = lines && lines.length ? lines : [MP_IDLE[Math.floor(Math.random() * MP_IDLE.length)]];
      }
    } else conv = target.talk ? target.talk() : null;
    if (this.state !== 'play') return; // travel menu opened
    if (!conv || !conv.lines || !conv.lines.length) {
      if (conv && conv.lines && !conv.lines.length) return;
      // ambient chatter: two lines per conversation, looping
      const lines = target.lines || (this.mp && target.mpLines) || ['…'];
      const n = Math.min(2, lines.length);
      const out = [];
      for (let i = 0; i < n; i++) out.push(lines[(target.idx + i) % lines.length]);
      target.idx = (target.idx + n) % lines.length;
      conv = { lines: out };
    }
    this.talk = { target, name: conv.name || target.name, lines: conv.lines, i: 0, after: conv.after || null };
    this.ui.openDialogue(this.talk.name, conv.lines[0], conv.lines.length > 1);
    this.audio.talk();
    this.events.emit('interact', { target, line: conv.lines[0] });
  }
  advanceDialogue() {
    const ui = this.ui;
    if (ui.dialogueTyping()) { ui.finishTyping(); return; }
    const t = this.talk;
    if (!t) { ui.closeDialogue(); return; }
    t.i++;
    if (t.i >= t.lines.length) {
      ui.closeDialogue();
      this.talk = null;
      if (t.after) t.after();
      return;
    }
    ui.openDialogue(t.name, t.lines[t.i], t.i < t.lines.length - 1);
    this.audio.talk();
  }

  // ------------------------------------------------------------ collecting & discovering
  updatePickups(dt) {
    const W = this.world, P = this.P, pl = this.player;
    const cx = pl.pos[0], cy = pl.pos[1] + 0.7, cz = pl.pos[2];
    for (const s of this.mp ? [] : W.shardSpots) {
      if (W.shardCollected.has(s.id)) continue;
      const dx = s.x - cx, dz = s.z - cz;
      if (Math.abs(dx) > 2 || Math.abs(dz) > 2) continue;
      const dy = s.y + 0.9 - cy;
      if (dx * dx + dz * dz < 1.3 * 1.3 && Math.abs(dy) < 1.5) {
        W.shardCollected.add(s.id);
        P.shards.add(s.id);
        this.audio.chime([1568, 2093, 2637], 0.05, 0.06, 0.8);
        this.burst([s.x, s.y + 0.9, s.z], 16, [1.4, 1.2, 0.6], 1.6);
        this.events.emit('shard', { id: s.id, count: P.shards.size });
        this.afterShard();
      }
    }
    // curiosities
    if ((this.curioTick = (this.curioTick || 0) + 1) % 10 === 0) {
      for (const c of W.curiosities) {
        if (P.curios.has(c.id)) continue;
        if (Math.hypot(c.x - cx, c.z - cz) < c.r && (c.y === undefined || Math.abs(c.y - cy) < 6)) {
          P.curios.add(c.id);
          this.ui.toast(T('Csoda: {0}', T(c.name)), { sub: c.blurb });
          this.audio.chime([880, 1320, 1760], 0.05, 0.1, 1.2);
          this.persist();
        }
      }
    }
  }
  updateRegions() {
    const P = this.P;
    const reg = this.world.regionAt(this.player.pos[0], this.player.pos[2], this.player.pos[1]);
    this.ui.setRegion(reg ? reg.name : 'FantasyWeald');
    if (reg !== this.lastRegion) {
      this.lastRegion = reg;
      if (reg) this.events.emit('region:enter', { region: reg });
    }
    if (reg && !P.discovered.has(reg.id)) {
      P.discovered.add(reg.id);
      this.events.emit('region:discover', { region: reg });
      if (reg.id === 'pyramid') this.follow.gazeUp(0.62, 6, 5.2);
      this.ui.banner({ eyebrow: reg.hidden ? 'Rejtett helyet találtál' : 'Felfedezted', name: reg.name, blurb: reg.blurb });
      this.refreshHud();
      this.audio.discover();
      this.persist();
    }
  }
  updateCompass() {
    const p = this.player.pos, P = this.P;
    const deg = (x, z) => ((Math.atan2(x - p[0], -(z - p[2])) * 180) / Math.PI + 360) % 360;
    const marks = [];
    for (const r of this.world.regions) {
      const d = Math.hypot(r.center[0] - p[0], r.center[1] - p[2]);
      if (d < r.radius * 0.6) continue;
      const known = P.discovered.has(r.id);
      if (r.hidden && !known && !P.flags.has('revealHidden') && d > 120) continue;
      marks.push({ name: r.name, kind: known ? 'known' : 'unknown', deg: deg(r.center[0], r.center[1]) });
    }
    for (const o of this.objectivesCache || []) {
      if (!o.pos) continue;
      if (Math.hypot(o.pos[0] - p[0], o.pos[2] - p[2]) < 6) continue;
      marks.push({ name: o.text, kind: 'quest', deg: deg(o.pos[0], o.pos[2]) });
    }
    if (this.mp) {
      const near = this.mp.others().map((o) => ({ o, d: Math.hypot(o.x - p[0], o.z - p[2]) })).filter((q) => q.d > 8 && q.d < 700).sort((a, b) => a.d - b.d).slice(0, 6);
      for (const q of near) marks.push({ name: `${q.o.name} · ${Math.round(q.d)} m`, kind: 'friend', color: q.o.css, deg: deg(q.o.x, q.o.z) });
    }
    if (!this.mp && this.player.abilities.has('starsight')) {
      const near = this.world.shardSpots.filter((s) => !this.world.shardCollected.has(s.id)).map((s) => ({ s, d: Math.hypot(s.x - p[0], s.z - p[2]) })).filter((o) => o.d < 90 && o.d > 3).sort((a, b) => a.d - b.d).slice(0, 3);
      for (const o of near) marks.push({ name: 'Csillagszilánk', kind: 'shard', deg: deg(o.s.x, o.s.z) });
    }
    this.ui.compass(this.follow.yaw, marks);
  }

  // ------------------------------------------------------------ atmosphere per biome
  updateAtmosphere(dt) {
    const p = this.player.pos;
    const env = this.env;
    const L = this.layout;
    const titleish = this.titleish();
    const S = L.sites;
    const dp = Math.hypot(p[0] - S.pyramid.x, p[2] - S.pyramid.z);
    const eyeT = titleish ? 0 : smoothstep(62, 30, dp);
    env.eye = damp(env.eye, eyeT, 0.8, dt);
    const b = L.biome(p[0], p[2]);
    this.pathGlowK = damp(this.pathGlowK || 1, 1 + b.mushroom * 0.6 + b.crystal * 0.3, 1, dt);
    const pg = env.pathGlow;
    pg[0] = 0.10 * this.pathGlowK; pg[1] = 0.20 * this.pathGlowK; pg[2] = 0.55 * this.pathGlowK;
    const dl = Math.hypot(p[0] - S.lake.x, p[2] - S.lake.z);
    const lakeK = smoothstep(S.lake.lakeR + 45, S.lake.lakeR + 5, dl);
    const wet = Math.max(lakeK, b.swamp);
    // out on the dream sea the air clears: you can see the odd things standing far away
    const seaK = smoothstep(330, 560, Math.hypot(p[0], p[2]));
    const fogD = lerp(0.0088, 0.0112, wet) * lerp(1, 0.82, b.desert) * lerp(1, 0.9, smoothstep(40, 90, p[1])) * lerp(1, 0.55, seaK);
    env.fogParams[0] = damp(env.fogParams[0], fogD, 1, dt);
    env.fogParams[3] = damp(env.fogParams[3], lerp(0.012, 0.032, wet), 1, dt);
    // (v8) Ash Isle: the air turns smoky red around the dragon's realm
    const isle = this.world.ashIsle;
    if (isle) {
      if (!this.baseSky) this.baseSky = { fog: env.fogColor.slice(), fogMoon: env.fogMoonColor.slice(), hor: env.skyHorizon.slice(), glow: env.skyGlow.slice(), moon: env.moonColor.slice(), amb: env.skyAmb.slice(), rim: env.rimColor.slice() };
      const rk = titleish ? 0 : smoothstep(isle.R + 90, isle.R - 10, Math.hypot(p[0] - isle.x, p[2] - isle.z));
      this.realmK = damp(this.realmK || 0, rk, 0.8, dt);
      const k = this.realmK, B = this.baseSky;
      const mixTo = (out, base, red) => { for (let i = 0; i < 3; i++) out[i] = lerp(base[i], red[i], k); };
      mixTo(env.fogColor, B.fog, [0.05, 0.014, 0.016]);
      mixTo(env.fogMoonColor, B.fogMoon, [0.22, 0.07, 0.05]);
      mixTo(env.skyHorizon, B.hor, [0.11, 0.028, 0.026]);
      mixTo(env.skyGlow, B.glow, [0.4, 0.1, 0.06]);
      // the light itself turns: a dim red moon through the smoke
      mixTo(env.moonColor, B.moon, [0.5, 0.26, 0.26]);
      mixTo(env.skyAmb, B.amb, [0.05, 0.02, 0.022]);
      mixTo(env.rimColor, B.rim, [0.5, 0.16, 0.12]);
      env.fogParams[0] = lerp(env.fogParams[0], 0.011, k * 0.6);
    }
    const ep = env.player;
    ep[0] = p[0]; ep[1] = p[1]; ep[2] = p[2]; ep[3] = 1.4;
  }

  audioLevels() {
    const p = this.player.pos;
    const w = this.world;
    const S = this.layout.sites;
    const near = (list, r) => {
      let best = null, bd = Infinity;
      for (const q of list) {
        if (!q) continue;
        const d = Math.hypot(q[0] - p[0], q[1] - p[1], q[2] - p[2]);
        if (d < bd) { bd = d; best = q; }
      }
      return { level: clamp(1 - bd / r, 0, 1) ** 2, pos: best || p };
    };
    let water = 0, wpos = p;
    for (const lk of this.layout.lakes) {
      const d = Math.hypot(p[0] - lk.x, p[2] - lk.z) - lk.r;
      const l = clamp(1 - d / (lk.id === 'lake' ? 35 : 18), 0, 1) * (lk.id === 'lake' ? 1 : 0.6);
      if (l > water) { water = l; wpos = [lk.x, 0, lk.z]; }
    }
    // rivers murmur too
    const rd = w.terrain.sample(w.terrain.riverD, p[0], p[2]);
    const rl = clamp(1 - rd / 22, 0, 1) * 0.8;
    if (rl > water) { water = rl; wpos = [p[0], 0, p[2]]; }
    if (!this._fires) {
      this._fires = [w.anchors.cauldron, w.gate.world.tp(w.gate.anchors.torchL), w.gate.world.tp(w.gate.anchors.torchR), w.runes.world.tp(w.runes.anchors.flame)];
      this._hums = [w.pyramid.world.tp([0, 8, 0]), w.watcher.world.tp([0, 4, 4]), w.runes.world.tp([0, 2, 0]), w.moon.world.tp([0, 5, 0]), [S.crystal.x, w.h(S.crystal.x, S.crystal.z) + 2, S.crystal.z], w.anchors.starHeart, w.anchors.islandShrine, w.anchors.castleDoor];
    }
    return {
      water: { level: water, pos: wpos },
      falls: near([w.anchors.waterfallBase], 70),
      fire: near(this._fires, 14),
      hum: near(this._hums, 34),
      crickets: 1 - water * 0.5,
    };
  }

  // title screen camera: a slow arc around the glade, looking towards the stone hand
  attractCamera(t) {
    const S = this.layout.sites;
    const g = S.glade, c = S.castle;
    const dir = [c.x - g.x, c.z - g.z];
    const dl = Math.hypot(dir[0], dir[1]) || 1;
    dir[0] /= dl; dir[1] /= dl;
    const u = 0.5 - 0.5 * Math.cos(t * 0.04);
    // a slow arc on the glade's eastern side: the hut and the cauldron in front, the stone hand beyond
    const a = lerp(0.55, 1.15, u);
    const bx = -dir[0], bz = -dir[1];
    const rx = bx * Math.cos(a) - bz * Math.sin(a), rz = bx * Math.sin(a) + bz * Math.cos(a);
    const x = g.x + rx * 21, z = g.z + rz * 21;
    const y = Math.max(this.world.h(x, z), this.layout.waterLevel) + 3.6 + Math.sin(t * 0.13) * 0.5;
    this.cam.position = [x, y, z];
    this.cam.target = [g.x + dir[0] * 60 - rx * 8, y + 7, g.z + dir[1] * 60 - rz * 8];
    this.cam.fov = (50 * Math.PI) / 180;
    this.renderer.shadowFocus = [g.x, this.world.h(g.x, g.z), g.z];
    this.world.updateGrass([g.x + dir[0] * 4, 0, g.z + dir[1] * 4]);
    this.env.player = [0, -100, 0, 1];
  }

  // ------------------------------------------------------------ loop
  loop(now) {
    requestAnimationFrame((t) => this.loop(t));
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    if (window.__manual || this.state === 'loading') return;
    this.frame(dt);
  }

  frame(dt, render = true) {
    this.time += dt;
    const t = this.time;
    const input = this.input;
    this.fpsAcc.t += dt; this.fpsAcc.n++;
    if (this.fpsAcc.t > 0.5) {
      this.fpsAcc.fps = this.fpsAcc.n / this.fpsAcc.t; this.fpsAcc.t = 0; this.fpsAcc.n = 0;
      const extra = this.dyn.scale < 0.99 ? ` · ${Math.round(this.dyn.scale * 100)}%` : '';
      this.ui.fps(this.fpsAcc.fps, this.settings.showFps && this.state === 'play', extra);
    }

    if (this.state === 'play') {
      if (input.hit('Escape', 'KeyP')) { this.pause(); input.endFrame(); }
      else if (input.hit('KeyJ')) { this.pause(); this.ui.selectTab('quests'); }
      else if (input.hit('KeyM', 'Tab')) { this.openMap(); input.endFrame(); }
      else if (input.hit('KeyH')) { this.hudHidden = !this.hudHidden; this.ui.el.hud.style.opacity = this.hudHidden ? '0' : '1'; }
      else if (input.hit('KeyN') && this.ui.toggleMinimap) this.ui.toggleMinimap();
      else if (this.mp && !this.mp.chatOpen && input.hit('Enter', 'KeyT')) { this.mp.openChat(); input.endFrame(); }
    } else if (this.state === 'pause') {
      if (input.hit('Escape', 'KeyP', 'KeyJ')) this.resume();
      else if (input.hit('KeyM', 'Tab')) this.openMap();
    } else if (this.state === 'map') {
      if (input.hit('Escape', 'KeyM', 'Tab')) this.closeMap();
    } else if (this.state === 'settings') {
      if (input.hit('Escape')) this.closeSettings();
    } else if (this.state === 'travel') {
      if (input.hit('Escape')) this.resume();
    } else if (this.state === 'title') {
      if (input.hit('Enter')) this.ui.el.btnPlay.click();
    } else if (this.state === 'mpjoin') {
      if (input.hit('Escape')) this.closeMpJoin();
    }

    const playing = this.state === 'play';
    input.enabled = playing && !(this.mp && this.mp.chatOpen);
    const titleish = this.titleish();
    if (this.sky && !titleish) this.sky.update(dt, t);
    if (playing) {
      this.playTime += dt;
      this.player.update(dt, input, this.follow.yaw, t);
      // walking giants and wanderers shove you aside
      const wd = this.npcs.creatures && this.npcs.creatures.wanderers;
      if (wd && !this.player.mount) wd.shove(this.player);
      // the big snail gently pushes you aside
      const bs = this.npcs.bigSnail;
      if (bs) {
        const dx = this.player.pos[0] - bs.x, dz = this.player.pos[2] - bs.z, d = Math.hypot(dx, dz);
        if (d < 2.6 && d > 1e-3 && this.player.pos[1] < this.world.h(bs.x, bs.z) + 4) { this.player.pos[0] = bs.x + (dx / d) * 2.6; this.player.pos[2] = bs.z + (dz / d) * 2.6; }
      }
      this.follow.update(dt, input, this.player, t);
      const target = this.nearestInteractable();
      this.player.lookTarget = target ? (target.focus || target.pos) : null;
      if (this.talk && (!target || target !== this.talk.target)) {
        this.ui.closeDialogue();
        this.talk = null;
      }
      this.ui.prompt(this.ui.dialogue ? null : target, input.isTouch);
      if (input.hit('KeyE') || (!this.mp && input.hit('Enter'))) {
        if (this.ui.dialogue) this.advanceDialogue();
        else if (target) this.interact(target);
      }
      this.ui.updateDialogue(dt);
      this.updateRegions();
      this.updatePickups(dt);
      const door = this.world.dreamSea && !this.player.mount && this.world.dreamSea.checkPortals(this.player, t);
      if (door) this.throughDoor(door);
      if ((this.compassTick = (this.compassTick || 0) + 1) % 3 === 0) {
        if (this.mp) this.objectivesCache = [];
        else if (this.trackerDirty || this.compassTick % 30 === 0) {
          this.trackerDirty = false;
          this.objectivesCache = objectives(this);
          const main = this.objectivesCache.filter((o) => o.id === 'main');
          const side = this.objectivesCache.filter((o) => o.id !== 'main').slice(0, 2);
          this.ui.tracker(main.concat(side).map((o) => ({ quest: o.quest, main: o.id === 'main', text: o.text, detail: o.detail || '' })));
        }
        this.updateCompass();
      }
      // (v9.1c) the minimap, about 30 times a second
      if ((this.miniTick = (this.miniTick || 0) + 1) % 2 === 0 && !this.hudHidden) {
        this.ui.drawMinimap({
          terrain: this.world.terrain, waterLevel: this.layout.waterLevel, player: this.player, time: t,
          targets: this.mp ? [] : (this.objectivesCache || []).flatMap((o) => (o.all && o.all.length ? o.all : o.pos ? [o.pos] : [])).filter(Boolean),
          gates: this.world.gates.map((g) => ({ x: g.x, z: g.z, active: this.P.gates.has(g.id) })),
          leviathan: this.npcs.creatures.leviathan ? this.npcs.creatures.leviathan.mapPos() : null,
          others: this.mp ? this.mp.others() : null,
        });
      }
      this.saveTimer = (this.saveTimer || 0) + dt;
      if (this.saveTimer > 8) { this.saveTimer = 0; this.persist(); }
      this.autoQuality(dt);
    } else if (titleish) {
      this.attractCamera(t);
    } else if (this.state === 'map') {
      this.ui.drawMap({
        terrain: this.world.terrain, waterLevel: this.layout.waterLevel, regions: this.world.regions, player: this.player,
        extent: Math.min(2400, Math.max(820, this.world.regions.some((r) => r.sea && this.P.discovered.has(r.id)) ? 1300 : 820, Math.hypot(this.player.pos[0], this.player.pos[2]) * 2 + 260)),
        discovered: this.P.discovered, revealed: this.P.flags.has('revealHidden'),
        targets: this.mp ? [] : (this.objectivesCache || objectives(this)).flatMap((o) => (o.all && o.all.length ? o.all : o.pos ? [o.pos] : [])).filter(Boolean),
        others: this.mp ? this.mp.others() : null,
        gates: this.world.gates.map((g) => ({ x: g.x, z: g.z, active: this.P.gates.has(g.id) })),
        curios: this.world.curiosities.filter((c) => this.P.curios.has(c.id)),
        leviathan: this.npcs.creatures.leviathan ? this.npcs.creatures.leviathan.mapPos() : null,
        time: t,
      });
    }
    // world life runs in every state (it's beautiful to watch behind menus)
    this.npcs.update(dt, t, this.player);
    for (const f of this.world.animated) f(t);
    this.animateWorld(dt, t);
    this.updateAtmosphere(dt);
    if (!titleish) {
      const p = this.player.pos;
      const fx = Math.sin(this.follow.yaw), fz = Math.cos(this.follow.yaw);
      const sf = this.renderer.shadowFocus;
      sf[0] = p[0] + fx * 16; sf[1] = p[1]; sf[2] = p[2] + fz * 16;
      const gc = this.grassFocus || (this.grassFocus = [0, 0, 0]);
      gc[0] = p[0] + fx * 8; gc[1] = 0; gc[2] = p[2] + fz * 8;
      this.world.updateGrass(gc);
    }
    this.world.terrain.updateLod(this.cam.position, QUALITY[this.settings.quality].lod);
    this.world.updateSea(this.cam.position);
    if (this.world.dreamSea) this.world.dreamSea.update(this.cam.position, t);
    this.trail.flush();
    if (this.audio.started) this.audio.update(this.cam.position, this.follow.yaw, this.audioLevels());
    if (this.mp) this.mp.update(dt);
    if (render) {
      this.dynamicResolution(dt);
      this.renderer.render(this.scene, this.cam, this.env, t);
      if (this.mp) this.mp.overlay(dt);
    }
    input.endFrame();
  }

  animateWorld(dt, t) {
    const W = this.world;
    W.updateShards(t);
    for (const pad of W.bouncePads) {
      if (pad.squash <= 0) continue;
      pad.squash = Math.max(0, pad.squash - dt * 2.2);
      const k = Math.sin(pad.squash * Math.PI * 3) * pad.squash;
      pad.node.setScale(pad.sx * (1 + k * 0.12), pad.sy * (1 - k * 0.3), pad.sx * (1 + k * 0.12));
    }
    if (this.gateAnim !== null && this.gateAnim !== undefined && this.gateAnim < 1) {
      this.gateAnim = Math.min(1, this.gateAnim + dt / 3.2);
      const e = this.gateAnim * this.gateAnim * (3 - 2 * this.gateAnim);
      W.gate.anchors.bars.position[1] = e * 5.4;
    }
  }

  // keep the frame rate smooth: nudge the render scale down when frames get slow, back up when there's headroom
  dynamicResolution(dt) {
    const d = this.dyn;
    if (!this.settings.dynRes || this.state !== 'play') return;
    d.t += dt; d.frames++;
    d.cool = Math.max(0, d.cool - dt);
    if (d.t < 1.5) return;
    const fps = d.frames / d.t;
    d.t = 0; d.frames = 0;
    if (d.cool > 0) return;
    let s = d.scale;
    if (fps < 42 && s > 0.6) s = Math.max(0.6, s - (fps < 30 ? 0.15 : 0.08));
    else if (fps > 57 && s < 1) s = Math.min(1, s + 0.05);
    if (s !== d.scale) {
      d.scale = s;
      this.renderer.dynScale = s;
      d.cool = 2.5;
    }
  }

  // drop quality once if the device struggles during the first seconds of play
  autoQuality(dt) {
    const a = this.autoQ;
    if (a.done) return;
    a.t += dt;
    a.frames++;
    if (a.t < 2) { a.frames = 0; return; }
    if (a.t > 7) {
      const fps = a.frames / (a.t - 2);
      a.done = true;
      if (fps < 28 && this.settings.quality > 0) {
        this.settings.quality--;
        a.downgraded = true;
        this.applyQuality();
        this.ui.refreshSettings?.();
        a.done = false; a.t = 0; a.frames = 0;
      } else if (fps > 57 && !a.downgraded && this.settings.quality < this.worldQuality) {
        this.settings.quality++;
        this.applyQuality();
        this.ui.refreshSettings?.();
        a.done = false; a.t = 0; a.frames = 0;
      }
    }
  }
}
