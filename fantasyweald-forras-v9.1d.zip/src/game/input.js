// Keyboard, mouse (drag or pointer lock) and touch (virtual stick + look pad + buttons).
export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.keys = new Set();
    this.pressed = new Set(); // edge-triggered this frame
    this.lookDX = 0;
    this.lookDY = 0;
    this.zoom = 0;
    this.move = [0, 0];      // from touch stick
    this.touchRun = false;
    this.pointerLocked = false;
    this.dragging = false;
    this.enabled = true;
    this.isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
    this.sensitivity = 1;
    this.invertY = false;

    window.addEventListener('keydown', (e) => {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) return;
      const k = e.code;
      if (!this.keys.has(k)) this.pressed.add(k);
      this.keys.add(k);
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(k)) e.preventDefault();
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());

    canvas.addEventListener('mousedown', (e) => {
      if (!this.enabled) return;
      this.dragging = true;
      this.lastX = e.clientX;
      this.lastY = e.clientY;
      if (this.wantPointerLock && !this.pointerLocked && canvas.requestPointerLock) {
        try {
          const r = canvas.requestPointerLock();
          if (r && r.catch) r.catch(() => {});
        } catch (err) { /* optional */ }
      }
    });
    window.addEventListener('mouseup', () => (this.dragging = false));
    window.addEventListener('mousemove', (e) => {
      if (!this.enabled) return;
      if (this.pointerLocked) {
        this.lookDX += e.movementX;
        this.lookDY += e.movementY;
      } else if (this.dragging) {
        this.lookDX += e.clientX - this.lastX;
        this.lookDY += e.clientY - this.lastY;
        this.lastX = e.clientX;
        this.lastY = e.clientY;
      }
    });
    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === canvas;
    });
    canvas.addEventListener('wheel', (e) => {
      this.zoom += Math.sign(e.deltaY);
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  // touch controls are DOM elements created by the UI; it wires them here
  attachTouch({ stick, knob, lookPad, buttons }) {
    const st = { id: null, cx: 0, cy: 0 };
    const R = 48;
    stick.addEventListener('touchstart', (e) => {
      const t = e.changedTouches[0];
      st.id = t.identifier;
      const r = stick.getBoundingClientRect();
      st.cx = r.left + r.width / 2;
      st.cy = r.top + r.height / 2;
      this.updateStick(t, st, R, knob);
      e.preventDefault();
    }, { passive: false });
    stick.addEventListener('touchmove', (e) => {
      for (const t of e.changedTouches) if (t.identifier === st.id) this.updateStick(t, st, R, knob);
      e.preventDefault();
    }, { passive: false });
    const endStick = (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier === st.id) {
          st.id = null;
          this.move = [0, 0];
          this.touchRun = false;
          knob.style.transform = 'translate(-50%, -50%)';
        }
      }
    };
    stick.addEventListener('touchend', endStick);
    stick.addEventListener('touchcancel', endStick);

    const lk = { id: null, x: 0, y: 0 };
    lookPad.addEventListener('touchstart', (e) => {
      const t = e.changedTouches[0];
      lk.id = t.identifier; lk.x = t.clientX; lk.y = t.clientY;
      e.preventDefault();
    }, { passive: false });
    lookPad.addEventListener('touchmove', (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier !== lk.id) continue;
        this.lookDX += (t.clientX - lk.x) * 1.6;
        this.lookDY += (t.clientY - lk.y) * 1.6;
        lk.x = t.clientX; lk.y = t.clientY;
      }
      e.preventDefault();
    }, { passive: false });
    const endLook = (e) => { for (const t of e.changedTouches) if (t.identifier === lk.id) lk.id = null; };
    lookPad.addEventListener('touchend', endLook);
    lookPad.addEventListener('touchcancel', endLook);
    for (const [code, el] of Object.entries(buttons)) {
      el.addEventListener('touchstart', (e) => {
        this.pressed.add(code);
        this.keys.add(code);
        e.preventDefault();
      }, { passive: false });
      el.addEventListener('touchend', (e) => { this.keys.delete(code); e.preventDefault(); }, { passive: false });
    }
  }

  updateStick(t, st, R, knob) {
    let dx = t.clientX - st.cx, dy = t.clientY - st.cy;
    const d = Math.hypot(dx, dy);
    if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
    this.move = [dx / R, -dy / R];
    this.touchRun = d > R * 0.92;
    knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
  }

  down(...codes) {
    if (!this.enabled) return false;
    return codes.some((c) => this.keys.has(c));
  }
  hit(...codes) {
    return codes.some((c) => this.pressed.has(c));
  }
  // movement vector in "stick space": x right, y forward
  moveVector() {
    if (!this.enabled) return [0, 0];
    let x = 0, y = 0;
    if (this.down('KeyW', 'ArrowUp')) y += 1;
    if (this.down('KeyS', 'ArrowDown')) y -= 1;
    if (this.down('KeyA', 'ArrowLeft')) x -= 1;
    if (this.down('KeyD', 'ArrowRight')) x += 1;
    x += this.move[0];
    y += this.move[1];
    const l = Math.hypot(x, y);
    if (l > 1) { x /= l; y /= l; }
    return [x, y];
  }
  sneaking() {
    if (!this.enabled) return false;
    return this.down('KeyC') || !!this.sneakToggle;
  }
  running() {
    return this.down('ShiftLeft', 'ShiftRight') || this.touchRun;
  }
  consumeLook() {
    const r = [this.lookDX * this.sensitivity, this.lookDY * this.sensitivity * (this.invertY ? -1 : 1)];
    this.lookDX = 0;
    this.lookDY = 0;
    return r;
  }
  consumeZoom() {
    const z = this.zoom;
    this.zoom = 0;
    return z;
  }
  endFrame() {
    this.pressed.clear();
  }
}
