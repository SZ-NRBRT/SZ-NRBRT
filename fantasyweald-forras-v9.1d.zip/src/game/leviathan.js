// (v9) A Mélység Lámpása: one enormous creature in the dream sea.
// (v9.1) Four times bigger, and no longer a flat shape at the waterline: it cruises with its ragged back and
// dorsal veil cutting the surface, its body rolling through the sea in great humps (the humps stay put in the
// water while the body slides through them, like a sea serpent), and from time to time it rears its head out
// of the sea. It senses anyone who comes near it on the water - swimming or gliding low - and hunts them on its
// own: the light dives, comes closer, faster... then it rises from below with its jaws wide open and swallows
// you (you wake up on the beach). It never swims further from the island than the Ash Isle lies.
import { buildLeviathan, levRadius, LEV_SEGS, LEV_SEG, LEV_SCALE } from '../models/leviathan.js';
import { mergeRig } from '../engine/rig.js';
import { RNG, clamp, damp, lerp, angleDiff, TAU, smoothstep } from '../engine/math.js';
import { C } from '../models/materials.js';

const hyp = (x, z) => Math.sqrt(x * x + z * z);
const S = LEV_SCALE;
const SEGL = LEV_SEG * S;                    // world length of one body segment
const R = (s) => levRadius(s) * S;           // world body radius along the body (0 = neck, 1 = tail)
const STEP = 2;                              // spacing of the remembered path points
const BODY = LEV_SEGS * SEGL + 8 * S;        // how much path the body needs
const MOUTH = 8 * S;                         // the mouth is this far ahead of the neck point
const ARCH_A = 16, ARCH_L = 200;             // the humps: height and length of one wave (gentle enough never to fold)
const SENSE = 115;                           // how far it feels you on the water (further if you splash along)
const WEAVE_A = 0.6, WEAVE_L = 170;          // (v9.1b) it swims in long S-curves: heading swing and the length of one curve
const HARD_R = 900;                          // (v9.1b) its sea ends here (past the edge of the dream, where nobody can follow)

export class Leviathan {
  constructor(cr) {
    this.cr = cr;
    this.game = cr.game;
    this.world = cr.world;
    this.scene = cr.scene;
    this.rng = new RNG(this.world.L.seed + 4242);
    const W = this.world;
    this.WL = W.L.waterLevel;
    // depths of the neck point: deep (only the lantern and a dark shape), and cruising with the back awash
    this.DEEP = this.WL - 50;
    this.RIDGE = this.WL + 2.5 - R(0.16) * 1.06;
    // it never goes further out than the Ash Isle lies
    const ai = W.ashIsle;
    this.maxR = ai ? Math.max(480, hyp(ai.x, ai.z) - 15) : 560;
    const rig = (this.rig = buildLeviathan(cr.ctx));
    rig.root.traverse((n) => { if (n.geometry) { n.castShadow = false; n.maxDistance = 1400; } });
    this.scene.add(rig.root);
    mergeRig(W.gl, rig.root);
    // the parts are placed one by one far from the root: never cull the merged meshes by the root's bounds
    rig.root.traverse((n) => { if (n.skinned) { n.frustumCulled = false; n.castShadow = false; } });
    rig.root.dynamic = true;
    rig.head.setScale(S);
    rig.tail.setScale(S);
    this.light = this.scene.addLight({ node: rig.tip, color: C('#8ff4ff'), intensity: 2.4, radius: 70, flicker: 0.06, priority: 4 });
    // head (neck point) state
    const a0 = this.rng.range(0, TAU);
    const r0 = this.coast(a0) + 110;
    this.h = { x: Math.cos(a0) * r0, y: this.RIDGE, z: Math.sin(a0) * r0, yaw: 0, pitch: 0, speed: 7, vy: 0 };
    this.dir = this.rng.sign();
    this.h.yaw = Math.atan2(-Math.sin(a0) * this.dir, Math.cos(a0) * this.dir);
    this.path = [];
    this.teleport(this.h.x, this.h.y, this.h.z, this.h.yaw);
    this.cum = new Float32Array(this.path.length + 8);
    this.state = 'roam';
    this.t = 0;
    this.goal = null;
    this.goalT = 0;
    this.surfaceT = this.rng.range(20, 40);
    this.cruise = 'ridge';
    this.cruiseT = this.rng.range(40, 70);
    this.cool = 10;
    this.jaw = 0;
    this.lure = 1;
    this.arch = 0.25;
    this.rear = 0;
    this.odo = 0;
    this.splashBudget = 0;
    this.revealed = false;
    this.waterY = new Float32Array(LEV_SEGS + 1).fill(-20);
    this.lev = W.sea && W.sea.mat ? W.sea.mat.uniforms.uLev : null;
    this.lureU = W.sea && W.sea.mat ? W.sea.mat.uniforms.uLure : null;
    this.pts = [];
    for (let i = 0; i <= LEV_SEGS; i++) this.pts.push([0, 0, 0]);
    this.prev = this.pts.map(() => [0, 0, 0]);
    this.prevHead = [0, 0, 0];
    this.bb = [0, 0, 0, 0];
    // (v9.1c) a body you cannot swim through, and a back you can stand on while it is out of the water
    // (for us only: the world's physics sees it as a travelling surface, like the hill turtle's shell)
    this.back = W.physics.addMover({ type: 'fn', x: 0, z: 0, r: 1e6, top: 0, yaw: 0, delta: [0, 0, 0, 0], topFn: (x, z) => this.backTop(x, z) });
    this.update(0, 0, this.game.player || { pos: [0, 50, 0], vel: [0, 0, 0] }, true);
  }

  // where the island's beach ends and deep water begins, towards angle a
  coast(a) {
    const L = this.world.L;
    return Math.max(L.border(a) + 8, 300);
  }
  // obstacles in the sea it keeps away from (landmarks, the Ash Isle)
  nearLandmark(x, z, pad = 0) {
    const ds = this.world.dreamSea;
    if (!ds) return false;
    for (const l of ds.landmarks) if (hyp(l.x - x, l.z - z) < 95 + pad) return true;
    const ai = this.world.ashIsle;
    if (ai && hyp(ai.x - x, ai.z - z) < (ai.R || 60) + 95 + pad) return true;
    return false;
  }
  // things in the sea it swims around: the dream-sea landmarks and the Ash Isle ([x, z, radius])
  obstacles() {
    if (this._obs) return this._obs;
    const out = [];
    const ds = this.world.dreamSea;
    if (ds) for (const l of ds.landmarks) out.push([l.x, l.z, 30]);
    const ai = this.world.ashIsle;
    if (ai) out.push([ai.x, ai.z, (ai.R || 60) + 15]);
    return (this._obs = out);
  }
  pickGoal(player) {
    const rng = this.rng, h = this.h;
    const pa = Math.atan2(player.pos[2], player.pos[0]), pr = hyp(player.pos[0], player.pos[2]);
    // (v9.1) someone out at sea draws it near; so does someone watching from the beach for Huba's quest
    const playerAtSea = pr > this.coast(pa) - (this.questWatch() ? 90 : 25) && pr < this.maxR + 60;
    for (let k = 0; k < 30; k++) {
      let a;
      if (playerAtSea && rng.chance(0.4)) {
        // drawn towards whoever is out on the water
        a = pa + rng.range(-0.3, 0.3);
      } else {
        const ha = Math.atan2(h.z, h.x);
        if (rng.chance(0.08)) this.dir = -this.dir;
        a = ha + this.dir * rng.range(0.3, 0.7);
      }
      const c = this.coast(a);
      const r = rng.range(c + 85, Math.max(c + 95, this.maxR - 55));
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (this.nearLandmark(x, z)) continue;
      this.goal = [x, z];
      this.goalT = 80;
      return;
    }
    const a = Math.atan2(h.z, h.x) + this.dir * 0.4, r = Math.min(this.coast(a) + 110, this.maxR - 60);
    this.goal = [Math.cos(a) * r, Math.sin(a) * r];
    this.goalT = 40;
  }

  // position along the remembered path, `d` metres behind the head
  sample(d, out) {
    const P = this.path, cum = this.cum;
    let i = 1;
    while (i < P.length - 1 && cum[i] < d) i++;
    const a = P[i - 1], b = P[i];
    const u = clamp((d - cum[i - 1]) / Math.max(1e-4, cum[i] - cum[i - 1]), 0, 1);
    out[0] = lerp(a[0], b[0], u); out[1] = lerp(a[1], b[1], u); out[2] = lerp(a[2], b[2], u);
    return out;
  }

  // the top of its body at (x, z), or null (only the parts above the water count)
  backTop(x, z) {
    const bb = this.bb;
    if (!this.rig.root.visible || x < bb[0] || x > bb[2] || z < bb[1] || z > bb[3]) return null;
    const hit = this.bodyHit(x, z);
    return hit && hit.top > this.WL - 0.3 ? hit.top : null;
  }
  // nearest point of the body under (x, z): segment, position along it, sideways distance, the top there
  bodyHit(x, z) {
    const P = this.pts;
    let best = null;
    for (let i = 0; i < LEV_SEGS; i++) {
      const a = P[i], b = P[i + 1];
      const vx = b[0] - a[0], vz = b[2] - a[2], l2 = vx * vx + vz * vz || 1;
      const u = clamp(((x - a[0]) * vx + (z - a[2]) * vz) / l2, 0, 1);
      const cx = a[0] + vx * u, cz = a[2] + vz * u;
      const d = hyp(x - cx, z - cz);
      const r = lerp(R(i / LEV_SEGS), R((i + 1) / LEV_SEGS), u);
      const w = r * 0.93;
      if (d >= w) continue;
      const top = lerp(a[1], b[1], u) + r * 1.04 * Math.sqrt(1 - (d / w) ** 2) + r * 0.1 * Math.exp(-((d / (w * 0.25)) ** 2));
      if (!best || top > best.top) best = { i, u, d, w, top, cx, cz };
    }
    // the head: a big rounded dome ahead of the neck
    const h = this.h, hy = this.moveYaw ?? h.yaw;
    const hx = h.x + Math.sin(hy) * 4.4 * S, hz = h.z + Math.cos(hy) * 4.4 * S;
    const hd = hyp(x - hx, z - hz), hr = 4.0 * S;
    if (hd < hr) {
      const top = h.y + 0.6 * S + 3.4 * S * Math.sqrt(1 - (hd / hr) ** 2);
      if (!best || top > best.top) best = { i: 0, u: 0, d: hd, w: hr, top, cx: hx, cz: hz, head: true };
    }
    return best;
  }
  // (v9.1) Huba's quest: the player is supposed to see it rise from the sea
  questWatch() {
    const P = this.game.P;
    return !!(P && P.stage && P.stage.deep === 1 && !P.flags.has('levSeen') && !this.game.mp);
  }
  // can it get at the player? swimming out past the shallows, or gliding low over the open sea
  reachable(player) {
    const W = this.world, p = player.pos;
    const pa = Math.atan2(p[2], p[0]), pr = hyp(p[0], p[2]);
    if (player.mount || pr < this.coast(pa) + 10) return false;
    if (player.swimming) return p[1] < this.WL + 1.5;
    // in the air above deep water, low enough for a leap
    return !player.onGround && W.h(p[0], p[2]) < this.WL - 1 && p[1] < this.WL + 24;
  }
  // horizontal distance from the player to the nearest part of it
  nearestTo(p) {
    let d = hyp(p[0] - this.h.x, p[2] - this.h.z);
    for (let i = 2; i <= LEV_SEGS; i += 2) d = Math.min(d, hyp(p[0] - this.pts[i][0], p[2] - this.pts[i][2]));
    return d;
  }

  update(dt, t, player, init = false) {
    const g = this.game, W = this.world, h = this.h, WL = this.WL;
    this.t += dt;
    this.cool = Math.max(0, this.cool - dt);
    this.displayCool = Math.max(0, (this.displayCool || 0) - dt);
    const busy = g.state !== 'play' || g.mumusBusy || g.realmBusy || g.levBusy;
    // ---------------------------------------------------------------- what it wants
    const cp = Math.cos(h.pitch), my = this.moveYaw ?? h.yaw;
    const mouth = [h.x + Math.sin(my) * cp * MOUTH, h.y + Math.sin(h.pitch) * MOUTH, h.z + Math.cos(my) * cp * MOUTH];
    const reach = !init && this.reachable(player);
    const pdx = player.pos[0] - mouth[0], pdz = player.pos[2] - mouth[2];
    const pdH = hyp(pdx, pdz);
    const near = init ? 1e9 : this.nearestTo(player.pos);
    const splashing = Math.hypot(player.vel[0], player.vel[2]) > 2.6 || !player.swimming;
    let wantY = this.cruise === 'deep' ? this.DEEP : this.RIDGE, wantSpeed = 7.5, rMin = 52, goalX, goalZ;
    let wantArch = this.cruise === 'deep' ? 0 : 0.34, wantRear = 0, aim = null;
    if (!this.goal || this.goalT <= 0 || hyp(this.goal[0] - h.x, this.goal[1] - h.z) < 45) this.pickGoal(player);
    this.goalT -= dt;
    goalX = this.goal[0]; goalZ = this.goal[1];
    const canHunt = !busy && reach && this.cool <= 0;
    if (this.state === 'roam') {
      this.surfaceT -= dt;
      this.cruiseT -= dt;
      if (this.cruiseT <= 0) {
        // mostly it cruises with its back awash; now and then it sinks into the deep for a while
        this.cruise = this.cruise === 'deep' || this.rng.chance(0.35) ? 'ridge' : 'deep';
        this.cruiseT = this.cruise === 'deep' ? this.rng.range(18, 35) : this.rng.range(45, 90);
      }
      const hr = hyp(h.x, h.z);
      if (this.surfaceT <= 0 && !this.nearLandmark(h.x, h.z, 20) && hr > this.coast(Math.atan2(h.z, h.x)) + 60) {
        this.state = 'surface'; this.t = 0;
        this.moan(player, 1);
      }
      // it feels you on the water: from further away if you splash along or fly over it
      if (canHunt && near < (splashing ? SENSE * 1.3 : SENSE)) this.startHunt(player);
      // someone watching from the shore or a rock: it rises and looks at them
      else if (!busy && !reach && this.displayCool <= 0 && hyp(player.pos[0] - h.x, player.pos[2] - h.z) < (this.questWatch() ? 240 : 170) && player.pos[1] > WL - 1) {
        this.displayCool = 70;
        this.state = 'surface'; this.t = 0; this.watching = true;
        this.moan(player, 1.1);
      }
    } else if (this.state === 'surface') {
      // the head rises out of the sea, the body rolls through the surface in great arches, then it sinks again
      // (watching someone on the shore: it keeps cruising along the coast and turns its head towards them)
      const up = this.t < 30;
      wantY = up ? WL - 5 : this.RIDGE - 6;
      wantSpeed = 6;
      wantArch = up ? 1 : 0.3;
      wantRear = up ? smoothstep(3, 8, this.t) : 0;
      if (this.t > 40) { this.state = 'roam'; this.t = 0; this.watching = false; this.surfaceT = this.rng.range(35, 70); }
      // seen rising out of the sea, close enough to count
      if (!busy && this.rear > 0.5 && this.questWatch() && hyp(player.pos[0] - h.x, player.pos[2] - h.z) < 300) this.sighted();
      if (canHunt && near < SENSE * 1.3) { this.watching = false; this.startHunt(player); }
    } else if (this.state === 'stalk') {
      goalX = player.pos[0]; goalZ = player.pos[2];
      wantY = Math.min(WL - 42, player.pos[1] - 42);
      wantSpeed = lerp(7, 15, smoothstep(0, 7, this.t));
      wantArch = 0;
      rMin = 40;
      if (!reach) this.lost = (this.lost || 0) + dt; else this.lost = 0;
      const hd = hyp(player.pos[0] - h.x, player.pos[2] - h.z);
      if (this.lost > 2 || busy || this.t > 35) {
        // it lost you: sink back into the deep
        this.state = 'roam'; this.t = 0; this.cool = 8; this.goal = null; this.cruise = 'deep'; this.cruiseT = 12;
      } else if (this.t > 4 && hd < 62 && h.y < player.pos[1] - 18) {
        // (a few seconds of dread first: the light circles below and comes closer)
        this.state = 'strike'; this.t = 0; this.caught = false;
        this.strikeAt = [player.pos[0], player.pos[2], player.pos[1]];
        this.sound('levStrike', player, 1);
      }
    } else if (this.state === 'strike') {
      // up at the prey with the jaws wide open, in one long swooping curve
      const tx = reach ? player.pos[0] : this.strikeAt[0], tz = reach ? player.pos[2] : this.strikeAt[1];
      const ty = reach ? player.pos[1] : this.strikeAt[2];
      aim = [tx - h.x, ty - 3 - h.y, tz - h.z];
      goalX = tx; goalZ = tz;
      wantSpeed = 24;
      wantArch = 0;
      rMin = 26;
      this.jaw = damp(this.jaw, 1, 7, dt);
      const dm = Math.hypot(player.pos[0] - mouth[0], player.pos[1] - mouth[1], player.pos[2] - mouth[2]);
      if (!this.caught && !busy && reach && dm < 17) {
        this.caught = true;
        this.jawSnap = 0.35;
        g.leviathanCaught && g.leviathanCaught();
      }
      if (mouth[1] > Math.max(WL, ty) + 14 || this.t > 5) {
        this.state = 'breach'; this.t = 0;
        this.cool = this.caught ? 60 : 10;
        this.splash(mouth[0], mouth[2], 4, t);
        this.sound('levSurface', player, 1);
      }
    } else if (this.state === 'breach') {
      // arcs over and crashes back into the sea
      const d = this.d;
      aim = [d[0], -0.8, d[2]];
      wantSpeed = 16;
      wantArch = 0;
      rMin = 34;
      if (h.y < WL - 24 && this.t > 1.5) { this.state = 'roam'; this.t = 0; this.surfaceT = this.rng.range(35, 70); this.cruise = 'deep'; this.cruiseT = 10; this.goal = null; }
    }
    // (v9.1b) where to swim: towards the goal, pushed off the shore and around the landmarks, pulled back
    // into its home waters (out to the Ash Isle's distance). It may swim much further out, past the edge of the
    // dream where nobody can follow, but only when that is the way around - it is too big for tight corners.
    const hr = hyp(h.x, h.z), ha = Math.atan2(h.z, h.x);
    const cst = this.coast(ha);
    let want = h.yaw;
    if (!aim) {
      let vx = goalX - h.x, vz = goalZ - h.z;
      const gl = hyp(vx, vz) || 1;
      vx /= gl; vz /= gl;
      const ox = Math.cos(ha), oz = Math.sin(ha);
      const c = clamp((cst + 95 - hr) / 35, 0, 3) * 1.6;
      const o = clamp((hr - this.maxR) / 90, 0, 1) * 0.8 + clamp((hr - HARD_R) / 40, 0, 4) * 2;
      vx += ox * (c - o); vz += oz * (c - o);
      for (const q of this.obstacles()) {
        const dx = h.x - q[0], dz = h.z - q[1], d = hyp(dx, dz) || 1;
        const k = clamp((q[2] + 75 - d) / 50, 0, 3) * 1.4;
        vx += (dx / d) * k; vz += (dz / d) * k;
      }
      // a head-on pull and push cancel out: then keep turning the way it was turning
      want = hyp(vx, vz) > 0.25 ? Math.atan2(vx, vz) : h.yaw + this.dir * 0.8;
      // stuck (the goal does not come any closer): pick another one, go the other way round
      this.progT = (this.progT || 0) + dt;
      if (this.progT > 25) {
        const gd = hyp(goalX - h.x, goalZ - h.z);
        if (this.state === 'roam' && this.lastGD !== undefined && gd > this.lastGD - 40) { this.dir = -this.dir; this.goal = null; }
        this.lastGD = gd; this.progT = 0;
      }
    }
    // ---------------------------------------------------------------- swim
    // (v9.1b) it swims along a direction that can only turn so fast (a smallest turning circle, in 3D), so the
    // path is always a smooth curve and the long body never folds into itself
    if (!init) {
      this.weaveK = damp(this.weaveK ?? 1, this.state === 'strike' || this.state === 'breach' ? 0 : this.state === 'stalk' ? 0.35 : 1, 1.5, dt);
      // yaw and pitch turn separately: a turn-around is always a wide U-turn in the water, never a loop
      let yawD, pitchD;
      if (aim) {
        yawD = Math.atan2(aim[0], aim[2]);
        pitchD = Math.atan2(aim[1], hyp(aim[0], aim[2]));
      } else {
        yawD = want + Math.sin((this.odo / WEAVE_L) * TAU) * WEAVE_A * this.weaveK;
        // (aim for the depth it wants, easing off early: it cannot level out on the spot)
        pitchD = Math.atan(clamp((wantY - h.y - this.d[1] * 30) * 0.08, -0.42, 0.42));
      }
      pitchD = clamp(pitchD, -1.3, 1.3);
      h.speed = damp(h.speed, wantSpeed, this.state === 'strike' ? 3 : 1.0, dt);
      const d = this.d;
      const maxA = (h.speed * dt) / rMin;
      let yaw = Math.atan2(d[0], d[2]), pitch = Math.asin(clamp(d[1], -1, 1));
      yaw += clamp(angleDiff(yaw, yawD), -maxA, maxA);
      pitch += clamp(pitchD - pitch, -maxA, maxA);
      d[0] = Math.sin(yaw) * Math.cos(pitch); d[1] = Math.sin(pitch); d[2] = Math.cos(yaw) * Math.cos(pitch);
      const mv = h.speed * dt;
      h.x += d[0] * mv; h.y += d[1] * mv; h.z += d[2] * mv;
      if (h.y > WL + 45) { h.y = WL + 45; if (d[1] > 0) { d[1] = 0; const l = hyp(d[0], d[2]) || 1; d[0] /= l; d[2] /= l; } }
      if (h.y < WL - 70) { h.y = WL - 70; if (d[1] < 0) { d[1] = 0; const l = hyp(d[0], d[2]) || 1; d[0] /= l; d[2] /= l; } }
      h.yaw = Math.atan2(d[0], d[2]);
      h.pitch = Math.asin(clamp(d[1], -1, 1));
      h.vy = d[1] * h.speed;
      this.moveYaw = h.yaw;
      this.odo += mv;
      // remember the path: path[0] is always the head, path[1..] are points left behind every STEP metres
      const rec = this.path[1] || this.path[0];
      const dd = Math.hypot(h.x - rec[0], h.y - rec[1], h.z - rec[2]);
      if (dd >= STEP) {
        const n = Math.min(60, Math.floor(dd / STEP));
        const add = [];
        for (let k = n; k >= 1; k--) {
          const u = (k * STEP) / dd;
          add.push([lerp(rec[0], h.x, u), lerp(rec[1], h.y, u), lerp(rec[2], h.z, u)]);
        }
        this.path.splice(1, 0, ...add);
        const keep = Math.ceil((BODY + 12) / STEP) + 2;
        if (this.path.length > keep) this.path.length = keep;
      }
      this.arch = damp(this.arch, wantArch, 0.4, dt);
      this.rear = damp(this.rear, wantRear, 1.0, dt);
    }
    this.path[0] = [h.x, h.y, h.z];
    if (this.cum.length < this.path.length) this.cum = new Float32Array(this.path.length + 16);
    this.cum[0] = 0;
    for (let i = 1; i < this.path.length; i++) {
      const a = this.path[i - 1], b = this.path[i];
      this.cum[i] = this.cum[i - 1] + Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
    }
    // ---------------------------------------------------------------- the body follows the path
    const rig = this.rig, pts = this.pts;
    const wave = t * (0.8 + h.speed * 0.03);
    const tmp = [0, 0, 0];
    for (let i = 0; i <= LEV_SEGS; i++) {
      const s = i / LEV_SEGS;
      this.sample(i * SEGL + 0.001, pts[i]);
      // a slight side-to-side ripple towards the tail (the path itself carries the big S-curves)
      const nxt = this.sample(i * SEGL + 2.0, tmp);
      let fx = pts[i][0] - nxt[0], fz = pts[i][2] - nxt[2];
      const fl = hyp(fx, fz) || 1;
      fx /= fl; fz /= fl;
      const amp = (0.1 + 0.8 * Math.pow(s, 1.6)) * S * (this.state === 'strike' ? 0.3 : 1) * (1 - this.arch * 0.5);
      const off = Math.sin(wave - s * 5.2) * amp;
      pts[i][0] += fz * off;
      pts[i][2] -= fx * off;
      // the arches: fixed in the water, the body slides through them; the neck and the tail tip stay low
      const env = smoothstep(0.12, 0.36, s) * (1 - smoothstep(0.78, 1.0, s));
      pts[i][1] += Math.sin(((this.odo - i * SEGL) / ARCH_L) * TAU) * ARCH_A * this.arch * env + Math.sin(wave * 0.7 - s * 3.1) * 1.2 * s;
    }
    // ---------------------------------------------------------------- for us: solid body, a back to stand on
    {
      const bb = this.bb;
      bb[0] = bb[1] = Infinity; bb[2] = bb[3] = -Infinity;
      for (const p of pts) { bb[0] = Math.min(bb[0], p[0]); bb[1] = Math.min(bb[1], p[2]); bb[2] = Math.max(bb[2], p[0]); bb[3] = Math.max(bb[3], p[2]); }
      const pad = 6 * S;
      bb[0] -= pad; bb[1] -= pad; bb[2] += pad; bb[3] += pad;
      const pp = player.pos, dl = this.back.delta;
      dl[0] = dl[1] = dl[2] = 0;
      if (!init && rig.root.visible && pp[0] > bb[0] && pp[0] < bb[2] && pp[2] > bb[1] && pp[2] < bb[3] && !player.mount) {
        const hit = this.bodyHit(pp[0], pp[2]);
        if (hit) {
          if (player.groundSurface === this.back) {
            // riding it: go where the body under your feet goes
            const a = this.prev[hit.i], b = this.prev[hit.i + 1], na = pts[hit.i], nb = pts[hit.i + 1];
            if (hit.head) { dl[0] = h.x - this.prevHead[0]; dl[1] = h.y - this.prevHead[1]; dl[2] = h.z - this.prevHead[2]; }
            else for (let k = 0; k < 3; k++) dl[k] = lerp(na[k] - a[k], nb[k] - b[k], hit.u);
          } else if (hit.top > pp[1] + 0.7 && hit.top > WL - 0.3 && pp[1] > hit.top - 2 * hit.w) {
            // it swims into you: you are pushed aside, never through it
            const dx = pp[0] - hit.cx, dz = pp[2] - hit.cz, d = hyp(dx, dz) || 1;
            const k = (hit.w + 0.45) / d;
            pp[0] = hit.cx + dx * k; pp[2] = hit.cz + dz * k;
          }
        }
      }
      for (let i = 0; i <= LEV_SEGS; i++) { this.prev[i][0] = pts[i][0]; this.prev[i][1] = pts[i][1]; this.prev[i][2] = pts[i][2]; }
      this.prevHead = [h.x, h.y, h.z];
    }
    let top = -1e9;
    this.splashBudget = Math.min(60, this.splashBudget + dt * 40);
    for (let i = 0; i < LEV_SEGS; i++) {
      const a = pts[i], b = pts[i + 1];
      const dx = a[0] - b[0], dy = a[1] - b[1], dz = a[2] - b[2];
      const l = Math.hypot(dx, dy, dz) || 1;
      const node = rig.segs[i];
      node.setPos(a[0], a[1], a[2]);
      node.setEuler(-Math.asin(clamp(dy / l, -1, 1)), Math.atan2(dx, dz), Math.sin(wave - i * 0.4) * 0.08);
      node.setScale(S, S, l / LEV_SEG);
      const rr = R(i / LEV_SEGS);
      top = Math.max(top, a[1] + rr * 1.1);
      // splashes where the back breaks the surface
      const wy = a[1] + rr;
      if (!init && (this.waterY[i] - WL) * (wy - WL) < 0 && Math.abs(a[1] - WL) < rr * 2.5) this.splash(a[0], a[2], 0.8 + rr * 0.08, t);
      this.waterY[i] = wy;
    }
    const lastA = pts[LEV_SEGS - 1], lastB = pts[LEV_SEGS];
    rig.tail.setPos(lastB[0], lastB[1], lastB[2]);
    rig.tail.setEuler(-Math.asin(clamp((lastA[1] - lastB[1]) / (Math.hypot(lastA[0] - lastB[0], lastA[1] - lastB[1], lastA[2] - lastB[2]) || 1), -1, 1)), Math.atan2(lastA[0] - lastB[0], lastA[2] - lastB[2]), 0);
    rig.head.setPos(h.x, h.y, h.z);
    const look = this.watching ? clamp(angleDiff(this.moveYaw ?? h.yaw, Math.atan2(player.pos[0] - h.x, player.pos[2] - h.z)), -0.7, 0.7) * this.rear : 0;
    const hy = this.moveYaw ?? h.yaw;
    rig.head.setEuler(-h.pitch * (this.state === 'strike' ? 1.25 : 1) - this.rear * 0.42 + Math.sin(t * 0.5) * 0.04 * this.rear, hy + Math.sin(wave) * 0.05 + look, Math.sin(t * 0.37) * 0.06 * this.rear);
    // jaws: slowly working, gaping while it rears, wide open to strike, snapping shut
    if (this.state !== 'strike') this.jaw = damp(this.jaw, this.state === 'surface' ? 0.25 + this.rear * 0.25 + Math.sin(t * 0.6) * 0.12 : 0.06 + Math.max(0, Math.sin(t * 0.35)) * 0.08, 3, dt);
    if (this.jawSnap > 0) { this.jawSnap -= dt; this.jaw = damp(this.jaw, 0, 18, dt); }
    rig.jaw.setEuler(this.jaw * 1.05, 0, 0);
    rig.lure.setEuler(Math.sin(t * 0.9) * 0.08 - (this.state === 'strike' ? 0.3 : 0) + this.rear * 0.25, Math.sin(t * 0.6) * 0.12, 0);
    for (let k = 0; k < rig.fins.length; k++) rig.fins[k].setEuler(0, 0, (k ? -1 : 1) * (0.2 + Math.sin(t * 1.1 + k) * 0.25));
    rig.head.updateWorld(rig.root.world, true);
    // the lantern burns brighter while it hunts
    const hunting = this.state === 'stalk' || this.state === 'strike';
    this.lure = damp(this.lure, hunting ? 2.4 : 1, 2, dt);
    // visible when some of it is near the surface (the sea is dark and deep)
    const headTop = h.y + 4.5 * S;
    rig.root.visible = Math.max(top, headTop) > WL - 8;
    const tip = rig.tip.world;
    const tipY = tip[13];
    this.light.intensity = 2.6 * this.lure * (1 - smoothstep(-8, -60, tipY - WL) * 0.7);
    this.light.enabled = hyp(h.x - player.pos[0], h.z - player.pos[2]) < 500;
    this.revealed = rig.root.visible || (hunting && pdH < 120);
    // ---------------------------------------------------------------- the shape under the water (sea shader)
    if (this.lev) {
      const L = this.lev;
      for (let k = 0; k < 12; k++) {
        const i = Math.min(LEV_SEGS, Math.round((k / 11) * LEV_SEGS));
        const p = k === 0 ? [h.x + Math.sin(hy) * 5 * S, h.y, h.z + Math.cos(hy) * 5 * S] : pts[i];
        const r = k === 0 ? 5 * S : R(i / LEV_SEGS);
        const depth = WL - p[1];
        const above = depth < r * 0.7;
        L[k * 4] = p[0]; L[k * 4 + 1] = p[2];
        L[k * 4 + 2] = r * (1.05 + clamp(depth, 0, 60) * 0.02);
        L[k * 4 + 3] = above ? 0 : 0.9 * (1 - smoothstep(8, 70, depth));
      }
    }
    if (this.lureU) {
      const depth = WL - tipY;
      this.lureU[0] = tip[12]; this.lureU[1] = tip[14];
      this.lureU[2] = depth > 0.5 ? this.lure * 0.9 * (1 - smoothstep(8, 70, depth)) : 0;
      this.lureU[3] = 5 + clamp(depth, 0, 60) * 0.25;
    }
  }

  // for the map: where its head is and whether anything of it shows
  mapPos() {
    const body = [];
    for (let i = 0; i <= LEV_SEGS; i++) body.push([this.pts[i][0], this.pts[i][2], R(i / LEV_SEGS)]);
    const tip = this.rig.tip.world;
    return { x: this.h.x, z: this.h.z, yaw: this.moveYaw ?? this.h.yaw, body, lure: [tip[12], tip[14]], up: this.rig.root.visible, hunting: this.state === 'stalk' || this.state === 'strike' };
  }

  // put it somewhere (straight body behind the head); used at start and by tests
  teleport(x, y, z, yaw) {
    const h = this.h;
    h.x = x; h.y = y; h.z = z; h.yaw = yaw; h.vy = 0; h.pitch = 0;
    this.d = [Math.sin(yaw), 0, Math.cos(yaw)];
    this.moveYaw = yaw;
    this.path.length = 0;
    for (let d = 0; d <= BODY + 8; d += STEP) this.path.push([x - Math.sin(yaw) * d, y, z - Math.cos(yaw) * d]);
    if (this.waterY) this.waterY.fill(-20);
  }
  sighted() {
    const g = this.game, P = g.P;
    if (!P || P.flags.has('levSeen')) return;
    P.flags.add('levSeen');
    g.meetCreature && g.meetCreature('leviathan');
    g.ui.toast('Láttad a Mélység Lámpását!', { sub: 'Meséld el Horgász Hubának, mit láttál.', gold: true });
    g.trackerDirty = true;
    g.persist && g.persist();
  }
  startHunt(player) {
    this.state = 'stalk'; this.t = 0; this.lost = 0;
    const g = this.game;
    this.moan(player, 1.2, true);
    if (!this.warnT || g.time - this.warnT > 45) {
      this.warnT = g.time;
      if (player.swimming) g.ui.toast('Valami hatalmas mozdul alattad a mélyben…', { sub: 'Egy fény úszik feléd a víz alatt. Ússz ki a partra vagy egy szigetre, gyorsan! (Shift)' });
      else g.ui.toast('Valami hatalmas figyel a víz alól…', { sub: 'Túl alacsonyan szállsz a nyílt tenger fölött. Emelkedj, vagy siess a part felé!' });
    }
    if (g.follow) g.follow.shake = Math.max(g.follow.shake || 0, 0.3);
  }
  // (v9.1c) its call carries only so far (about a third of the island): from the far shore you do not hear it,
  // and it calls rarely (except when it starts to hunt you)
  moan(player, vol, force = false) {
    const now = this.game.time || 0;
    if (!force && now < (this.moanAt || 0)) return;
    const d = hyp(this.h.x - player.pos[0], this.h.z - player.pos[2]);
    if (d > 280) return;
    this.moanAt = now + this.rng.range(110, 180);
    this.sound('levMoan', player, (1 - smoothstep(120, 280, d)) * vol);
  }
  sound(kind, player, vol) {
    const a = this.game.audio;
    if (!a.started) return;
    const d = hyp(this.h.x - player.pos[0], this.h.z - player.pos[2]);
    if (d > 300) return;
    a.beast(kind, clamp(vol * (1 - smoothstep(100, 300, d)), 0, 1));
  }
  splash(x, z, k, t) {
    const tr = this.game.trail;
    if (!tr) return;
    const p = this.game.player.pos;
    if (hyp(x - p[0], z - p[2]) > 320) return;
    const n = Math.min(Math.round(8 * k), Math.floor(this.splashBudget));
    if (n <= 0) return;
    this.splashBudget -= n;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU, r = Math.random() * 3.5 * k;
      tr.emit([x + Math.cos(a) * r, this.WL + 0.2 + Math.random() * 1.5 * k, z + Math.sin(a) * r], t, { size: 0.35 * k + 0.2, life: 2.0, rise: 2.0 * k, spread: 2.5 * k, color: [0.7, 1.1, 1.3], intensity: 1.6 });
    }
  }
}
