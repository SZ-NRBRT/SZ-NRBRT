// Multiplayer: many dreamers in the same forest. No accounts: you pick a name and a colour, the server
// (web/mp.php next to the game, or server/mp-server.mjs) hands out an id and a secret key, and from then
// on the game polls it a few times a second with its own position and gets everybody else's back.
// Other players are drawn as gnomes like you, with their name above them; chat messages show up in the
// chat log and, for a few seconds, as a speech bubble above whoever said them.
import { buildGnome } from '../models/characters.js';
import { mergeRig } from '../engine/rig.js';
import { Player, PLAYER_SCALE, GNOME_SIZE } from './player.js';
import { clamp, damp, angleDiff } from '../engine/math.js';
import { T } from '../i18n.js';

// coat / hat colour pairs to choose from; css is the colour of the name in the chat
export const MP_COLORS = [
  { name: 'Éjkék', coat: '#2b44b8', hat: '#b01e2c', css: '#8fb0ff' },
  { name: 'Moha', coat: '#2f6b45', hat: '#d9a431', css: '#8fe0a8' },
  { name: 'Szilva', coat: '#6a2d8a', hat: '#e0c24a', css: '#d7a0ff' },
  { name: 'Rozsda', coat: '#a3502a', hat: '#2a4a8a', css: '#ffb08a' },
  { name: 'Rózsa', coat: '#b8487a', hat: '#f2eef5', css: '#ffa8cf' },
  { name: 'Türkiz', coat: '#23868a', hat: '#8a2a4a', css: '#7ff0ee' },
  { name: 'Holdfehér', coat: '#cfd3e6', hat: '#3a3a8a', css: '#f4f4ff' },
  { name: 'Éjfekete', coat: '#26243a', hat: '#9a3ad0', css: '#b9b0ff' },
];

export const MP_NAMES = ['Holdfény', 'Mohaláb', 'Ködmanó', 'Csillagpor', 'Pitypang', 'Éjbagoly', 'Gombafej', 'Szentjános', 'Harmatcsepp', 'Álomszuszék', 'Tücsök', 'Felhőpamacs', 'Makkocska', 'Ezüstszakáll', 'Kóbor Kobold', 'Lámpás'];
export const MP_NAMES_EN = ['Moonbeam', 'Mossfoot', 'Mistsprite', 'Stardust', 'Dandelion', 'Night Owl', 'Mushroomhead', 'Firefly', 'Dewdrop', 'Sleepyhead', 'Cricket', 'Cloudpuff', 'Acorn', 'Silverbeard', 'Stray Kobold', 'Lantern'];

const FLAG_GROUND = 1, FLAG_SWIM = 2, FLAG_GLIDE = 4, FLAG_MOUNT = 8, FLAG_SNEAK = 16;
const HELP_KEY = 'takeyourtime.chatHelp'; // (v9) set once the chat note has been closed
const BUBBLE_TIME = 7;       // seconds a chat bubble stays above a character
const PLATE_DIST = 34;       // names are shown up to this far
const BUBBLE_DIST = 60;
const DRAW_DIST = 80;        // gnomes further away are not drawn (a faint wisp of light marks them)
const MAX_DRAWN = 32;        // at most this many gnomes are drawn at once (the nearest ones)
const WISP_DIST = 260;

// the same cleaning the server does (it checks again anyway): no control, invisible or direction-flipping
// characters, no piles of combining marks, single spaces, cut by characters (not UTF-16 halves)
const BAD_CHARS = /[\u0000-\u001F\u007F-\u009F\u00AD\u061C\u180E\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF\uFFF9-\uFFFB]/g;
// (v9) chat and names are plain words only: letters (any alphabet), digits, spaces and everyday punctuation
// — no emoji, no symbols or pictures — and no links (web addresses, e-mail links, "example dot com"...)
const NOT_PLAIN = /[\uFE00-\uFE0F\u20E3]|[^\p{L}\p{Mn}\p{Mc}\p{Nd} .,!?:;'"()\-\u2013\u2014\u2026%+=\/&@#*_\u201E\u201D\u201C\u2018\u2019\u00AB\u00BB]/gu;
const LINK = /[a-z][a-z0-9+.\-]*:\/\/|(?<![\p{L}\p{N}])(?:www\s?\.|(?:https?|ftp|javascript|mailto|blob)\s?:|data\s?:\s?[a-z]+\/)|[\p{L}\p{N}\-]+(?:\.|\s?(?:\(dot\)|\[dot\]|\[\.\]|\(\.\))\s?|\s+(?:dot|pont)\s+)(?:com|net|org|hu|io|gg|ly|me|co|info|xyz|ru|de|uk|tv|app|dev|link|site|online|biz|us|eu|to|cc|tk|ml|ga|cf|gq|top|shop|store|live|stream|click|fun|pro|club|page|chat|social|tech|ai|gov|edu|fr|it|es|pl|ro|sk|at|ch|nl|be|cz|se|no|dk|fi|jp|cn|in|br|ca|au|nz|ws|pw|sh|gl|gd|vc|so|im|fm|am|bz|xxx|onion)(?![\p{L}\p{N}])/iu;
export function plainText(s) {
  return typeof s === 'string' ? s.replace(NOT_PLAIN, '') : '';
}
export function hasLink(s) {
  return typeof s === 'string' && LINK.test(s);
}
// keep a text field plain while typing (the caret stays where it was)
export function filterInput(el) {
  const v = el.value;
  const f = plainText(v.replace(BAD_CHARS, ''));
  if (f === v) return;
  let pos = el.selectionStart ?? f.length;
  pos = Math.max(0, pos - (v.length - f.length));
  el.value = f;
  try { el.setSelectionRange(pos, pos); } catch (e) { /* not focused */ }
}
export function cleanText(s, max) {
  if (typeof s !== 'string') return '';
  s = s.normalize('NFC').replace(BAD_CHARS, '').replace(/(\p{M})\p{M}+/gu, '$1').replace(/\s+/g, ' ');
  s = plainText(s).replace(/ {2,}/g, ' ').trim();
  return [...s].slice(0, max).join('').trim();
}

export function mpUrl() {
  const m = document.querySelector('meta[name="mp-url"]');
  return (window.MP_URL || (m && m.content) || 'mp.php').trim();
}

async function post(url, body, timeout = 8000) {
  const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctl ? setTimeout(() => ctl.abort(), timeout) : 0;
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), cache: 'no-store', signal: ctl ? ctl.signal : undefined });
    if (!r.ok) throw new Error('http ' + r.status);
    const j = await r.json();
    if (!j || typeof j !== 'object') throw new Error('bad reply');
    return j;
  } finally {
    clearTimeout(timer);
  }
}

// ask the server how many are in the forest (also tells whether there is a server at all)
export async function mpHello(url = mpUrl()) {
  if (location.protocol === 'file:') throw new Error('file');
  const j = await post(url, { a: 'hello' }, 6000);
  if (!j.ok) throw new Error(j.err || 'hello');
  return j;
}

const $ = (id) => document.getElementById(id);

export class Multiplayer {
  constructor(game, { name, color, url = mpUrl() }) {
    this.game = game;
    this.url = url;
    this.name = name;
    this.color = color;
    this.id = null;
    this.key = null;
    this.since = 0;
    this.remotes = new Map();
    this.pool = new Map();       // colour -> spare avatars
    this.building = 0;
    this.count = 1;
    this.interval = 300;
    this.seq = 0;
    this.outbox = [];            // chat lines waiting to be sent (one per request, the server wants a gap)
    this.lastSent = 0;
    this.alive = true;
    this.connected = false;
    this.failures = 0;
    this.timer = 0;
    this.self = { bubble: null, bubbleT: 0 };
    this.time = 0;
    this.layer = $('mpLayer');
    this.log = $('chatLog');
    this.form = $('chatForm');
    this.input = $('chatInput');
    this.help = $('chatHelp');
    this.helpX = $('chatHelpX');
    this.countEl = $('mpCount');
    this.status = '';
    this.bindChat();
  }

  // ------------------------------------------------------------ connection
  async join() {
    if (location.protocol === 'file:') throw new Error('file');
    const j = await post(this.url, { a: 'join', name: this.name, color: this.color });
    if (!j.ok) throw new Error(j.err || 'join');
    this.id = j.id;
    this.key = j.key;
    this.since = j.since || 0;
    this.interval = j.interval || 300;
    this.connected = true;
    this.failures = 0;
    return j;
  }
  start() {
    this.schedule(0);
  }
  schedule(ms) {
    clearTimeout(this.timer);
    if (!this.alive) return;
    this.timer = setTimeout(() => this.tick(), ms);
  }
  state() {
    const p = this.game.player;
    const f = (p.onGround ? FLAG_GROUND : 0) | (p.swimming ? FLAG_SWIM : 0) | (p.gliding ? FLAG_GLIDE : 0) | (p.mount ? FLAG_MOUNT : 0) | (p.sneaking ? FLAG_SNEAK : 0);
    const r = (v, k = 100) => Math.round(v * k) / k;
    return [r(p.pos[0]), r(p.visY), r(p.pos[2]), r(p.yaw, 1000), r(p.vel[0]), r(p.vel[2]), f];
  }
  async tick() {
    if (!this.alive) return;
    const g = this.game;
    const full = this.seq % 4 === 0 || g.state === 'map' || g.state === 'pause';
    this.seq++;
    const body = { a: 'sync', id: this.id, key: this.key, s: this.state(), since: this.since, full: full ? 1 : 0 };
    const now = performance.now();
    if (this.outbox.length && now - this.lastSent > 1250) { body.chat = this.outbox.shift(); this.lastSent = now; }
    let j = null;
    try {
      j = await post(this.url, body);
    } catch (e) {
      if (body.chat) this.outbox.unshift(body.chat);
      this.fail();
      return;
    }
    if (!this.alive) return;
    if (!j.ok) {
      if (body.chat) this.outbox.unshift(body.chat);
      if (j.err === 'unknown') {
        // we were dropped (the tab slept, or the server restarted): quietly come back with a new id
        try { await this.join(); this.system('Újra csatlakoztál.'); this.schedule(100); } catch (e) { this.fail(); }
        return;
      }
      this.fail();
      return;
    }
    if (!this.connected) { this.connected = true; this.system('Visszatért a kapcsolat.'); }
    this.failures = 0;
    try { this.receive(j, full || j.full); } catch (e) { /* a strange reply: ignore it, keep going */ }
    if (body.chat && j.cd) {
      const why = { fast: 'túl gyorsan írsz', burst: 'túl sok üzenet egymás után', repeat: 'ugyanezt már elküldted', empty: 'üres üzenet', allfast: 'mindenkinek szóló üzenetet csak 8 másodpercenként küldhetsz', link: 'linket nem küldhetsz, csak sima szöveget' }[j.cd] || 'nem ment át';
      this.system(T('Az üzeneted nem ment el ({0}).', T(why)));
    }
    const hidden = typeof document !== 'undefined' && document.hidden;
    this.schedule(hidden ? 1000 : Math.max(150, j.interval || this.interval));
  }
  fail() {
    this.failures++;
    if (this.connected && this.failures >= 3) {
      this.connected = false;
      this.system('Megszakadt a kapcsolat a közös erdővel… újrapróbálom.');
    }
    this.schedule(Math.min(5000, 600 * this.failures));
  }
  leave() {
    if (!this.id) return;
    const body = JSON.stringify({ a: 'leave', id: this.id, key: this.key });
    let sent = false;
    try { if (navigator.sendBeacon) sent = navigator.sendBeacon(this.url, new Blob([body], { type: 'text/plain' })); } catch (e) { /* ignore */ }
    if (!sent) { try { fetch(this.url, { method: 'POST', body, keepalive: true }).catch(() => {}); } catch (e) { /* ignore */ } }
    this.id = null;
  }
  dispose() {
    this.alive = false;
    clearTimeout(this.timer);
    this.leave();
    for (const r of this.remotes.values()) this.dropAvatar(r);
    this.remotes.clear();
    for (const list of this.pool.values()) for (const av of list) this.destroyAvatar(av);
    this.pool.clear();
    this.layer.textContent = '';
    this.log.textContent = '';
    if (this.help) this.help.hidden = true;
    this.closeChat(true);
    this.unbindChat();
    if (this.selfEls) { this.selfEls.plate.remove(); this.selfEls.bubble.remove(); this.selfEls = null; }
  }

  receive(j, full) {
    const now = this.time;
    const seen = new Set();
    if (Number.isFinite(j.n)) this.count = j.n;
    for (const e of Array.isArray(j.p) ? j.p : []) {
      if (!Array.isArray(e) || e.length < 11) continue;
      const [id, name, color, x, y, z, yaw, vx, vz, flags, age] = e;
      if (typeof id !== 'string' || ![x, y, z, yaw].every(Number.isFinite)) continue;
      seen.add(id);
      let r = this.remotes.get(id);
      if (!r) {
        r = { id, name: String(name || 'Vándor'), color: clamp(color | 0, 0, MP_COLORS.length - 1), disp: [x, y, z], dispYaw: yaw, av: null, hs: 0, bubbleT: 0, els: null, lastSeen: now, wispT: Math.random() };
        this.remotes.set(id, r);
      }
      r.name = typeof name === 'string' && name ? name.slice(0, 40) : r.name;
      r.target = [x, y, z];
      r.yaw = yaw;
      r.vel = [clamp(Number(vx) || 0, -30, 30), clamp(Number(vz) || 0, -30, 30)];
      r.flags = flags | 0;
      r.recv = now - Math.min(2, (age || 0) / 1000);
      r.lastSeen = now;
    }
    // the ones not in a full list are gone (partial lists only carry the nearby ones)
    if (full) for (const [id, r] of this.remotes) if (!seen.has(id)) { this.dropAvatar(r); this.remotes.delete(id); }
    // chat
    if (Number.isFinite(j.cid) && j.cid < this.since) this.since = 0;
    for (const c of Array.isArray(j.c) ? j.c : []) {
      if (!Array.isArray(c) || c.length < 4) continue;
      const [cid, pid, name, text] = c;
      const toAll = c[5] === 1;
      if (!Number.isInteger(cid) || typeof text !== 'string' || cid <= this.since) continue;
      this.since = cid;
      if (!pid) { this.system(text); continue; }
      if (pid === this.id) continue; // already shown when sent
      const r = this.remotes.get(pid);
      const col = r ? MP_COLORS[r.color].css : '#cfd6ff';
      this.addLine(name, text, col, false, toAll);
      if (r) { r.bubbleText = text; r.bubbleT = BUBBLE_TIME; }
      if (this.game.audio.started) this.game.audio.chime([1046.5], 0.02, 0, 0.25);
    }
    // (lines that were too far away were never sent: move past them too)
    if (Number.isInteger(j.cid) && j.cid > this.since) this.since = j.cid;
  }

  // ------------------------------------------------------------ avatars
  takeAvatar(color) {
    const list = this.pool.get(color);
    if (list && list.length) { const av = list.pop(); av.root.visible = true; return av; }
    if (this.building >= 2) return null; // build at most two new gnomes per frame
    this.building++;
    const g = this.game;
    const c = MP_COLORS[color];
    const rig = buildGnome(g.world.ctx, { staff: true, coat: c.coat, hat: c.hat, seed: 5 + color * 3 });
    const root = rig.root;
    root.setScale(GNOME_SIZE * PLAYER_SCALE);
    root.dynamic = true;
    g.scene.add(root);
    mergeRig(g.gl, root);
    root.traverse((n) => { if (n.geometry) { n.maxDistance = DRAW_DIST + 10; n.castShadow = false; } });
    const light = g.scene.addLight({ node: rig.bones.orb, color: [0.55, 0.85, 1.0], intensity: 0.7, radius: 3.2, priority: 0, flicker: 0.05, enabled: false });
    // just enough state for Player.animate to pose it like the player
    return {
      color, rig, root, light,
      phase: Math.random() * 6, onGround: true, swimming: false, stepSign: 1, onStep: null, sneaking: false, mount: null,
      gliding: false, landSquash: 0, lookTarget: null, pos: [0, 0, 0], yaw: 0, idleTime: 0, lookYaw: 0,
      vel: [0, 0, 0], prevVel: [0, 0], hatTip: [0, 0, 0, 0],
    };
  }
  dropAvatar(r) {
    if (r.els) { r.els.plate.remove(); r.els.bubble.remove(); r.els = null; }
    if (!r.av) return;
    const av = r.av;
    r.av = null;
    av.root.visible = false;
    av.light.enabled = false;
    if (!this.pool.has(av.color)) this.pool.set(av.color, []);
    this.pool.get(av.color).push(av);
  }
  destroyAvatar(av) {
    const g = this.game;
    g.scene.remove(av.root);
    const i = g.scene.lights.indexOf(av.light);
    if (i >= 0) g.scene.lights.splice(i, 1);
  }

  // every frame: move the remote gnomes smoothly towards where they are, pose them, place names and bubbles
  update(dt) {
    this.time += dt;
    this.building = 0;
    const g = this.game;
    const cp = g.cam.position;
    const list = [];
    for (const r of this.remotes.values()) {
      if (!r.target) continue;
      // where they probably are now: last known position + velocity for a short while
      const ahead = clamp(this.time - r.recv, 0, 0.45);
      const tx = r.target[0] + r.vel[0] * ahead, tz = r.target[2] + r.vel[1] * ahead;
      const d = r.disp;
      const jump = Math.hypot(tx - d[0], tz - d[2], r.target[1] - d[1]);
      const px = d[0], pz = d[2];
      if (jump > 12) { d[0] = tx; d[1] = r.target[1]; d[2] = tz; r.dispYaw = r.yaw; } else {
        d[0] = damp(d[0], tx, 9, dt);
        d[2] = damp(d[2], tz, 9, dt);
        d[1] = damp(d[1], r.target[1], 12, dt);
        r.dispYaw += angleDiff(r.dispYaw, r.yaw) * (1 - Math.exp(-10 * dt));
      }
      const hs = Math.hypot(d[0] - px, d[2] - pz) / Math.max(dt, 1e-3);
      r.hs = damp(r.hs, jump > 12 ? 0 : Math.min(hs, 12), 8, dt);
      r.dist = Math.hypot(d[0] - cp[0], d[1] - cp[1], d[2] - cp[2]);
      if (r.bubbleT > 0) r.bubbleT -= dt;
      list.push(r);
    }
    // draw the nearest ones as gnomes
    list.sort((a, b) => a.dist - b.dist);
    let drawn = 0, lit = 0, wisps = 0;
    for (const r of list) {
      const want = r.dist < DRAW_DIST && drawn < MAX_DRAWN;
      if (want && !r.av) {
        r.av = this.takeAvatar(r.color);
      } else if (!want && r.av) {
        const els = r.els;
        r.els = null;
        this.dropAvatar(r);
        r.els = els;
      }
      if (r.av) {
        drawn++;
        this.pose(r, dt);
        r.av.light.enabled = lit < 3 && r.dist < 16;
        if (r.av.light.enabled) lit++;
      } else if (r.dist < WISP_DIST && g.trail && wisps < 12) {
        // far away: a small drifting light shows where another dreamer walks
        wisps++;
        r.wispT -= dt;
        if (r.wispT <= 0) {
          r.wispT = 0.5;
          g.trail.emit([r.disp[0], r.disp[1] + 0.6, r.disp[2]], g.time, { size: 0.35, life: 1.4, rise: 0.4, spread: 0.2, color: [0.6, 0.85, 1.6], intensity: 2.2 });
        }
      }
    }
    this.list = list;
    if (this.countEl) {
      const txt = this.connected ? T('Vándorok az erdőben: {0}', this.count) : T('Kapcsolódás…');
      if (txt !== this.countText) { this.countText = txt; this.countEl.textContent = txt; }
    }
  }

  pose(r, dt) {
    const av = r.av, f = r.flags || 0;
    av.pos[0] = r.disp[0]; av.pos[1] = r.disp[1]; av.pos[2] = r.disp[2];
    av.yaw = r.dispYaw;
    av.onGround = !!(f & FLAG_GROUND);
    av.swimming = !!(f & FLAG_SWIM);
    av.gliding = !!(f & FLAG_GLIDE);
    av.sneaking = !!(f & FLAG_SNEAK);
    av.mount = f & FLAG_MOUNT ? true : null;
    av.vel[0] = r.vel[0]; av.vel[2] = r.vel[1];
    av.idleTime = r.hs < 0.2 ? av.idleTime + dt : 0;
    // only the ones close by are animated every frame
    if (r.dist < 45 || (av.skip = (av.skip || 0) + 1) % 3 === 0) Player.prototype.animate.call(av, r.dist < 45 ? dt : dt * 3, this.game.time, r.hs);
    av.root.setPos(av.pos[0], av.pos[1], av.pos[2]);
    av.root.setRotY(av.yaw);
  }

  // ------------------------------------------------------------ names and speech bubbles (DOM)
  elsFor(owner) {
    if (owner.els) return owner.els;
    const plate = document.createElement('div');
    plate.className = 'mp-plate';
    const bubble = document.createElement('div');
    bubble.className = 'mp-bubble';
    bubble.hidden = true;
    this.layer.appendChild(plate);
    this.layer.appendChild(bubble);
    owner.els = { plate, bubble, name: null, text: null };
    return owner.els;
  }
  project(x, y, z, out) {
    const m = this.game.cam.viewProj;
    const cx = m[0] * x + m[4] * y + m[8] * z + m[12];
    const cy = m[1] * x + m[5] * y + m[9] * z + m[13];
    const w = m[3] * x + m[7] * y + m[11] * z + m[15];
    if (w < 0.05) return false;
    const W = window.innerWidth, H = window.innerHeight;
    out[0] = (cx / w * 0.5 + 0.5) * W;
    out[1] = (0.5 - cy / w * 0.5) * H;
    return out[0] > -200 && out[0] < W + 200 && out[1] > -200 && out[1] < H + 200;
  }
  // after the frame is rendered (so names sit exactly on this frame's picture)
  overlay(dt) {
    const g = this.game;
    const list = this.list || [];
    const show = g.state === 'play' && !g.hudHidden;
    const sp = this.tmp || (this.tmp = [0, 0]);
    const head = 1.5 * GNOME_SIZE * PLAYER_SCALE; // just above the hat tip
    let plates = 0;
    for (const r of list) {
      const wantPlate = show && r.dist < PLATE_DIST && plates < 24;
      const wantBubble = show && r.bubbleT > 0 && r.dist < BUBBLE_DIST;
      if (!wantPlate && !wantBubble) { if (r.els) { r.els.plate.hidden = true; r.els.bubble.hidden = true; } continue; }
      const els = this.elsFor(r);
      const vis = this.project(r.disp[0], r.disp[1] + head, r.disp[2], sp);
      if (!vis) { els.plate.hidden = true; els.bubble.hidden = true; continue; }
      this.placeOwner(els, sp, r.name, MP_COLORS[r.color].css, wantPlate, wantBubble ? r.bubbleText : null, r.bubbleT, r.dist);
      if (wantPlate) plates++;
    }
    // your own bubble (and no name above yourself)
    const me = this.self;
    if (me.bubbleT > 0) me.bubbleT -= dt;
    const els = this.selfEls || (this.selfEls = this.elsFor({}));
    const p = g.player;
    if (show && me.bubbleT > 0 && this.project(p.pos[0], p.visY + head, p.pos[2], sp)) {
      this.placeOwner(els, sp, '', '', false, me.bubbleText, me.bubbleT, 1.5);
    } else { els.plate.hidden = true; els.bubble.hidden = true; }
  }
  placeOwner(els, sp, name, css, wantPlate, text, t, dist) {
    const fade = clamp((PLATE_DIST - dist) / 8, 0, 1);
    const x = Math.round(sp[0]), y = Math.round(sp[1]);
    els.plate.hidden = !wantPlate;
    if (wantPlate) {
      if (els.name !== name) { els.name = name; els.plate.textContent = name; els.plate.style.color = css; }
      els.plate.style.transform = `translate(${x}px, ${y}px) translate(-50%, -100%)`;
      els.plate.style.opacity = fade.toFixed(2);
    }
    els.bubble.hidden = !text;
    if (text) {
      if (els.text !== text) { els.text = text; els.bubble.textContent = text; }
      els.bubble.style.transform = `translate(${x}px, ${y - (wantPlate ? 24 : 4)}px) translate(-50%, -100%)`;
      els.bubble.style.opacity = clamp(t / 0.6, 0, 1).toFixed(2);
    }
  }

  // ------------------------------------------------------------ chat
  bindChat() {
    this.onSubmit = (e) => {
      e.preventDefault();
      const text = cleanText(this.input.value, 160);
      // (v9) no links: say so, and leave the text there to fix
      if (text && hasLink(text)) { this.system('Linket nem küldhetsz a csevegésbe, csak sima szöveget.'); return; }
      this.input.value = '';
      if (text) this.say(text);
      this.closeChat();
    };
    // (v9) plain text only: emoji and symbols vanish as you type or paste; files can't be pasted or dropped
    this.onInput = () => filterInput(this.input);
    this.onPaste = (e) => {
      const cd = e.clipboardData;
      if (cd && (cd.files && cd.files.length || (cd.types && ![...cd.types].includes('text/plain')))) e.preventDefault();
    };
    this.onDrop = (e) => e.preventDefault();
    this.onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); this.input.value = ''; this.closeChat(); }
      e.stopPropagation();
    };
    this.onBlur = () => setTimeout(() => { if (document.activeElement !== this.input) this.closeChat(true); }, 0);
    // (v9) the little "how the chat works" note: closing it with × keeps it closed for good
    this.onHelpDown = (e) => e.preventDefault(); // (clicking × must not take the focus from the chat input)
    this.onHelpX = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (this.help) this.help.hidden = true;
      try { localStorage.setItem(HELP_KEY, '1'); } catch (err) { /* storage blocked: it stays closed for this visit */ }
      this.helpClosed = true;
    };
    this.form.addEventListener('submit', this.onSubmit);
    this.input.addEventListener('keydown', this.onKey);
    this.input.addEventListener('blur', this.onBlur);
    this.input.addEventListener('input', this.onInput);
    this.input.addEventListener('paste', this.onPaste);
    this.input.addEventListener('drop', this.onDrop);
    this.input.addEventListener('dragover', this.onDrop);
    if (this.helpX) { this.helpX.addEventListener('pointerdown', this.onHelpDown); this.helpX.addEventListener('click', this.onHelpX); }
  }
  unbindChat() {
    this.form.removeEventListener('submit', this.onSubmit);
    this.input.removeEventListener('keydown', this.onKey);
    this.input.removeEventListener('blur', this.onBlur);
    this.input.removeEventListener('input', this.onInput);
    this.input.removeEventListener('paste', this.onPaste);
    this.input.removeEventListener('drop', this.onDrop);
    this.input.removeEventListener('dragover', this.onDrop);
    if (this.helpX) { this.helpX.removeEventListener('pointerdown', this.onHelpDown); this.helpX.removeEventListener('click', this.onHelpX); }
  }
  helpSeen() {
    if (this.helpClosed) return true;
    try { return localStorage.getItem(HELP_KEY) === '1'; } catch (e) { return false; }
  }
  get chatOpen() {
    return !this.form.hidden;
  }
  openChat() {
    if (this.chatOpen) return;
    if (document.pointerLockElement) document.exitPointerLock?.();
    this.form.hidden = false;
    this.log.parentElement.classList.add('open');
    if (this.help && this.help.hidden && !this.helpSeen()) this.help.hidden = false;
    this.game.input.keys.clear();
    this.input.focus();
  }
  closeChat(quiet) {
    this.form.hidden = true;
    this.log.parentElement.classList.remove('open');
    if (!quiet && document.activeElement === this.input) this.input.blur();
  }
  say(text) {
    if (this.outbox.length >= 4) { this.system('Lassabban! Az üzeneteid még úton vannak.'); return; }
    // "!all ..." reaches everybody in the forest; anything else only the ones nearby (30 m; the server decides)
    const m = /^!all(\s+|$)/i.exec(text);
    const shown = m ? text.slice(m[0].length).trim() : text;
    if (!shown) return;
    this.outbox.push(text);
    this.addLine(this.name, shown, MP_COLORS[this.color].css, true, !!m);
    this.self.bubbleText = shown;
    this.self.bubbleT = BUBBLE_TIME;
    if (this.id && performance.now() - this.lastSent > 1250) this.schedule(0);
  }
  addLine(name, text, css, mine = false, toAll = false) {
    const li = document.createElement('li');
    if (name) {
      if (toAll) {
        const tag = document.createElement('span');
        tag.className = 'to-all';
        tag.textContent = T('mindenkinek');
        li.appendChild(tag);
        li.classList.add('all');
      }
      const b = document.createElement('b');
      b.textContent = name;
      b.style.color = css;
      li.appendChild(b);
      li.appendChild(document.createTextNode(' ' + text));
    } else {
      li.className = 'sys';
      li.textContent = text;
    }
    if (mine) li.classList.add('mine');
    this.log.appendChild(li);
    while (this.log.children.length > 60) this.log.firstChild.remove();
    this.log.scrollTop = this.log.scrollHeight;
    setTimeout(() => li.classList.add('old'), 14000);
  }
  system(text) {
    this.addLine('', T(text), '');
  }

  // ------------------------------------------------------------ for the map, the compass and the pause menu
  others() {
    const out = [];
    for (const r of this.remotes.values()) if (r.target) out.push({ name: r.name, css: MP_COLORS[r.color].css, x: r.disp[0], y: r.disp[1], z: r.disp[2] });
    return out;
  }
}

