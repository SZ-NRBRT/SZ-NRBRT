// The Mumus: the one truly scary thing in the forest. The sack man of the old stories lives in the dark
// corners (the will-o'-the-wisp swamp, the forgotten ruins, by the sleeping giant). It shuffles about
// slowly; if it notices you (sneaking gets you much closer), its eyes flare red, it shrieks and comes
// after you. Walking won't save you, running will, and so will deep water or high ground. If it catches
// you, it stuffs you into its sack... and you wake up at the glade.
import { buildMumus } from '../models/wanderers.js';
import { RNG, clamp, damp, angleDiff, TAU } from '../engine/math.js';
import { C } from '../models/materials.js';

const hyp = (x, z) => Math.sqrt(x * x + z * z);
const WANDER = 1.0;
const CHASE = 3.3;       // the gnome walks at 1.75 and runs at 4.35
const SEE = 17;          // it notices you from this far...
const SEE_SNEAK = 5.5;   // ...or only this close if you sneak
const GIVE_UP = 30;
const CATCH = 1.25;

export class Mumus {
  constructor(cr) {
    this.cr = cr;
    this.game = cr.game;
    this.world = cr.world;
    this.scene = cr.scene;
    this.rng = new RNG(this.world.L.seed + 666);
    const S = this.world.L.sites;
    const homes = [S.swamp, S.ruins, S.giant].filter(Boolean);
    this.all = homes.map((s, i) => {
      const a = this.rng.range(0, TAU);
      const home = this.cr.freeSpot(s.x + Math.cos(a) * s.r * 0.6, s.z + Math.sin(a) * s.r * 0.6, 14) || [s.x, s.z];
      const rig = buildMumus(this.cr.ctx, 90 + i);
      rig.root.traverse((n) => { if (n.geometry) n.maxDistance = 150; });
      this.scene.add(rig.root);
      const light = this.scene.addLight({ node: rig.bones.eyes, color: C('#ff3a20'), intensity: 0, radius: 7, flicker: 0.25, priority: 4, enabled: false });
      return { rig, home, x: home[0], z: home[1], yaw: this.rng.range(0, TAU), state: 'wander', t: 0, target: null, wait: this.rng.range(1, 4), speed: 0, phase: 0, glow: 0.15, light, growl: this.rng.range(2, 6), cool: 0, twitch: 0, pos: [home[0], 0, home[1]] };
    });
    cr.list.push({ update: (dt, t, player) => this.update(dt, t, player) });
    cr.watch.push({ id: 'mumus', range: 20, points: () => this.all.map((m) => [m.x, 0, m.z]) });
  }

  update(dt, t, pl) {
    const g = this.game, W = this.world;
    const active = g.state === 'play' && !pl.mount && !g.mumusBusy;
    for (const m of this.all) {
      const dx = pl.pos[0] - m.x, dz = pl.pos[2] - m.z, pd = hyp(dx, dz);
      const gy = W.h(m.x, m.z);
      m.pos[0] = m.x; m.pos[1] = gy; m.pos[2] = m.z;
      if (pd > 170) {
        m.rig.root.visible = false;
        m.light.enabled = false;
        if (m.state === 'chase' || m.state === 'notice') m.state = 'return';
        continue;
      }
      m.rig.root.visible = true;
      m.t += dt;
      if (!m.placed) { m.placed = true; m.rig.root.setPos(m.x, gy, m.z); }
      m.cool -= dt;
      // can it get at you? not in deep water, not up on something high
      const dy = pl.pos[1] - W.h(pl.pos[0], pl.pos[2]);
      const reachable = !pl.swimming && dy < 1.6 && W.waterDepth(pl.pos[0], pl.pos[2]) < 0.35 && Math.abs(pl.pos[1] - gy) < 4;
      let sp = 0, want = null;
      if (m.state === 'wander') {
        if (active && m.cool <= 0 && reachable && (pd < SEE_SNEAK || (pd < SEE && !pl.sneaking))) {
          m.state = 'notice'; m.t = 0;
          if (g.onMumus) g.onMumus('notice', m, pd);
        } else if (!m.target) {
          m.wait -= dt;
          if (m.wait <= 0) { m.target = this.cr.freeSpot(m.home[0], m.home[1], 22, 8); m.wait = this.rng.range(2, 6); }
        } else {
          const tx = m.target[0] - m.x, tz = m.target[1] - m.z;
          if (hyp(tx, tz) < 0.6) m.target = null;
          else { want = Math.atan2(tx, tz); sp = WANDER; }
        }
      }
      if (m.state === 'notice') {
        want = Math.atan2(dx, dz);
        if (m.t > 0.9) { m.state = 'chase'; m.t = 0; }
      } else if (m.state === 'chase') {
        want = Math.atan2(dx, dz);
        sp = CHASE;
        if (!active || !reachable || pd > GIVE_UP || m.t > 16) { m.state = 'return'; m.t = 0; m.cool = 8; }
        else if (pd < CATCH) {
          m.state = 'rest'; m.t = 0; m.cool = 14;
          if (g.onMumus) g.onMumus('catch', m, pd);
        }
      } else if (m.state === 'return') {
        const tx = m.home[0] - m.x, tz = m.home[1] - m.z;
        if (hyp(tx, tz) < 2) { m.state = 'wander'; m.target = null; }
        else { want = Math.atan2(tx, tz); sp = WANDER * 1.3; }
      } else if (m.state === 'rest') {
        if (m.t > 5) { m.state = 'return'; m.t = 0; }
      }
      if (want !== null) m.yaw += angleDiff(m.yaw, want) * Math.min(1, dt * (m.state === 'chase' ? 5 : 2));
      m.speed = damp(m.speed, sp, m.state === 'chase' ? 3 : 4, dt);
      // move, stepping around trunks and rocks; it never goes into deep water
      if (m.speed > 0.02) {
        const step = m.speed * dt;
        let moved = false;
        for (const off of [0, 0.5, -0.5, 1.0, -1.0, 1.5, -1.5]) {
          const a = m.yaw + off;
          const nx = m.x + Math.sin(a) * step, nz = m.z + Math.cos(a) * step;
          if (W.waterDepth(nx, nz) > 0.3) continue;
          if (W.physics.blocked(nx, nz, gy, 0.35, 2.4, 0.6, m.x, m.z)) continue;
          m.x = nx; m.z = nz; moved = true;
          break;
        }
        if (!moved) { m.target = null; if (m.state === 'return') m.state = 'wander'; }
      }
      m.rig.root.setPos(m.x, W.h(m.x, m.z), m.z);
      m.rig.root.setRotY(m.yaw);
      if (pd > 110) continue;
      // pose: a long, loping, hunched walk; when it hunts, it leans in and reaches for you
      const b = m.rig.bones;
      const hunt = m.state === 'chase' ? 1 : 0;
      m.phase += dt * (m.speed * 2.2 + 0.2);
      const sw = Math.sin(m.phase) * Math.min(1, m.speed);
      b.legL.setEuler(sw * 0.55, 0, 0);
      b.legR.setEuler(-sw * 0.55, 0, 0);
      b.hips.position[1] = 1.7 + Math.abs(Math.cos(m.phase)) * 0.05 * Math.min(1, m.speed) - hunt * 0.12;
      b.torso.setEuler(0.3 + hunt * 0.25, 0, Math.sin(m.phase) * 0.05);
      const reach = m.state === 'notice' ? 0.6 : hunt;
      b.armL.setEuler(-sw * 0.3 - reach * 1.1, 0, 0.1 + reach * 0.1);
      b.armR.setEuler(sw * 0.3 - reach * 1.2, 0, -0.1 - reach * 0.1);
      b.sack.setEuler(Math.sin(m.phase) * 0.12, 0, Math.cos(m.phase * 0.5) * 0.08);
      // now and then the head twitches to one side, the way nothing alive should move
      m.twitch -= dt;
      if (m.twitch < -0.25) m.twitch = this.rng.range(1.5, 5);
      const tw = m.twitch < 0 ? 0.55 : 0;
      b.head.setEuler(-hunt * 0.25 + (m.state === 'notice' ? -0.2 : 0), m.state === 'notice' ? Math.sin(m.t * 30) * 0.08 : 0, tw + Math.sin(t * 0.7) * 0.05);
      // ember eyes flare when it has seen you
      m.glow = damp(m.glow, m.state === 'chase' || m.state === 'notice' ? 1 : 0.2, 5, dt);
      const es = 1 + m.glow * 0.9;
      b.eyes.setScale(es, es, es);
      m.light.enabled = m.glow > 0.3;
      m.light.intensity = (m.glow - 0.2) * 2.2;
      // a low breathing growl when you are near
      m.growl -= dt;
      if (m.growl <= 0 && pd < 26 && g.audio.started) {
        m.growl = this.rng.range(3.5, 7) * (hunt ? 0.5 : 1);
        const ang = Math.atan2(m.x - g.cam.position[0], m.z - g.cam.position[2]) - g.follow.yaw;
        g.audio.mumus('growl', clamp(1 - pd / 26, 0, 1), clamp(-Math.sin(ang), -0.8, 0.8));
      }
    }
  }
}
