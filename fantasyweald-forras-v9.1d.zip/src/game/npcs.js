// Inhabitants, creatures and everything the player can interact with.
// Interactable: { id, name, pos, radius, kind, verb?, focus?, visible?(), talk?() -> { lines, after?, name? }, lines? }
import { buildGnome, buildWizard, buildHooded, buildCrow, buildFrog, buildLilyPad, buildStag, buildSnail, makeMesh, GNOME } from '../models/characters.js';
import { Geometry, catmullRom } from '../engine/geometry.js';
import { Node, Material } from '../engine/scene.js';
import { C } from '../models/materials.js';
import * as flora from '../models/flora.js';
import { RNG, clamp, damp, lerp, angleDiff, TAU, smoothstep } from '../engine/math.js';
import { LINES, SCRIPT } from '../data/dialogue.js';
import { particleSystem } from '../world/fx.js';
import { Creatures } from './creatures.js';
import { T } from '../i18n.js';

export class Npcs {
  constructor(game) {
    this.game = game;
    this.world = game.world;
    this.scene = game.scene;
    this.ctx = this.world.ctx;
    this.list = [];
    this.interactables = [];
    this.rng = new RNG(this.world.L.seed + 31);
    this.buildWizard();
    this.buildLakeGnomes();
    this.buildPottom();
    this.buildVillagers();
    this.buildWanderingGnomes();
    this.buildHooded();
    this.buildAstronomer();
    this.buildQueen();
    this.buildCrows();
    this.buildFrog();
    this.buildQuestItems();
    this.buildStag();
    this.buildBigSnail();
    this.buildFish();
    this.buildProps();
    this.creatures = new Creatures(this);
    // characters are small: cull them early and let only their bigger parts cast shadows
    for (const r of this.scene.children) {
      if (!['gnome', 'wizard', 'hooded', 'crow', 'frog', 'stag', 'snail', 'queen'].includes(r.name)) continue;
      const big = r.name === 'snail' && r.scale[0] > 0.5;
      r.traverse((n) => {
        if (!n.geometry) return;
        n.maxDistance = big ? 220 : r.name === 'stag' ? 160 : 90;
        if (n.geometry.bounds.radius < 0.16) n.castShadow = false;
      });
    }
  }

  get P() {
    return this.game.P;
  }
  addInteract(o) {
    const it = Object.assign({ radius: 3, idx: 0, kind: 'look' }, o);
    this.interactables.push(it);
    return it;
  }
  ambient(id) {
    return LINES[id] || ['…'];
  }

  // --------------------------------------------------------------- helpers: walking and sitting gnomes
  walker(rig, { home, radius = 10, speed = 1.5, pause = [2, 6], avoid = null }) {
    const w = this.world, rng = this.rng;
    const st = { x: home[0], z: home[1], yaw: rng.range(0, TAU), target: null, wait: rng.range(0.5, 3), phase: rng.range(0, 6), speed: 0 };
    const b = rig.bones;
    const pick = () => {
      for (let i = 0; i < 24; i++) {
        const a = rng.range(0, TAU), d = rng.range(2, radius);
        const x = home[0] + Math.cos(a) * d, z = home[1] + Math.sin(a) * d;
        if (w.waterDepth(x, z) > -0.2) continue;
        if (avoid && avoid(x, z)) continue;
        return [x, z];
      }
      return [home[0], home[1]];
    };
    const npc = {
      pos: [st.x, w.h(st.x, st.z), st.z],
      st,
      talking: false,
      update: (dt, t, player) => {
        const dxp = player.pos[0] - st.x, dzp = player.pos[2] - st.z;
        const dp = Math.hypot(dxp, dzp);
        const near = dp < 3.4;
        let moveSpeed = 0;
        if (near) {
          st.yaw += angleDiff(st.yaw, Math.atan2(dxp, dzp)) * (1 - Math.exp(-5 * dt));
          st.wait = Math.max(st.wait, 1.5);
        } else if (st.wait > 0) {
          st.wait -= dt;
          if (st.wait <= 0) st.target = pick();
        } else if (st.target) {
          const dx = st.target[0] - st.x, dz = st.target[1] - st.z;
          const d = Math.hypot(dx, dz);
          if (d < 0.4) { st.target = null; st.wait = rng.range(pause[0], pause[1]); }
          else {
            st.yaw += angleDiff(st.yaw, Math.atan2(dx, dz)) * (1 - Math.exp(-6 * dt));
            moveSpeed = speed;
            let nx = st.x + Math.sin(st.yaw) * moveSpeed * dt;
            let nz = st.z + Math.cos(st.yaw) * moveSpeed * dt;
            const y = w.h(st.x, st.z);
            if (w.physics.blocked(nx, nz, y, 0.3, 1.0, 0.5, st.x, st.z) || w.waterDepth(nx, nz) > -0.1) { st.target = null; st.wait = 0.5; nx = st.x; nz = st.z; }
            [nx, nz] = w.collide(nx, nz, 0.3, y);
            if (Math.hypot(nx - st.x, nz - st.z) < moveSpeed * dt * 0.3) { st.target = null; st.wait = 1; }
            st.x = nx; st.z = nz;
          }
        }
        st.speed = damp(st.speed, moveSpeed, 8, dt);
        st.phase += dt * (st.speed * 3.2);
        const s = Math.sin(st.phase);
        const a = clamp(st.speed / 1.6, 0, 1);
        b.legL.setEuler(s * 0.6 * a, 0, 0);
        b.legR.setEuler(-s * 0.6 * a, 0, 0);
        b.armL.setEuler(-s * 0.5 * a, 0, 0.12);
        b.armR.setEuler(s * 0.5 * a, 0, -0.12);
        b.hips.position[1] = 0.3 + Math.abs(Math.cos(st.phase)) * 0.03 * a;
        b.hatTip.setEuler(Math.cos(st.phase * 2) * 0.12 * a + Math.sin(t + st.phase) * 0.05, 0, 0);
        const idleLook = st.speed < 0.2 && !near ? Math.sin(t * 0.8 + home[0]) * 0.7 : 0;
        b.head.setEuler(near ? -0.25 : 0, idleLook, 0);
        const y = w.h(st.x, st.z);
        rig.root.setPos(st.x, y, st.z);
        rig.root.setRotY(st.yaw);
        npc.pos[0] = st.x; npc.pos[1] = y; npc.pos[2] = st.z;
      },
    };
    return npc;
  }
  sitter(rig, pos, yaw, pose = 'idle', seed = 0) {
    rig.root.setPos(pos[0], pos[1] - 0.12 * GNOME, pos[2]);
    rig.root.setRotY(yaw);
    this.scene.add(rig.root);
    const b = rig.bones;
    b.legL.setEuler(-1.4, 0, 0.05);
    b.legR.setEuler(-1.3, 0, -0.05);
    const npc = {
      pos: [pos[0], pos[1], pos[2]],
      update: (dt, t, player) => {
        if (pose === 'fish') {
          b.armL.setEuler(-1.1 + Math.sin(t * 0.8) * 0.04, 0, 0.1);
          b.armR.setEuler(-0.9, 0, -0.3);
          b.torso.setEuler(0.1 + Math.sin(t * 1.3) * 0.01, 0, 0);
        } else if (pose === 'point') {
          const cyc = (t * 0.2) % 1;
          const pointing = cyc < 0.55;
          b.armR.setEuler(pointing ? -2.2 + Math.sin(t * 3) * 0.05 : -0.4, 0, pointing ? -0.25 : -0.15);
          b.armL.setEuler(-0.3, 0, 0.2);
          b.head.setEuler(pointing ? -0.1 : 0, pointing ? 0 : 0.6, 0);
        } else {
          // storytelling: gestures with both hands
          const g = Math.sin(t * 1.3 + seed);
          b.armR.setEuler(-0.9 + g * 0.3, 0, -0.3 - g * 0.1);
          b.armL.setEuler(-0.7 - g * 0.2, 0, 0.3);
          const dx = player.pos[0] - pos[0], dz = player.pos[2] - pos[2];
          const look = Math.hypot(dx, dz) < 8 ? clamp(angleDiff(yaw, Math.atan2(dx, dz)), -1, 1) : Math.sin(t * 0.4) * 0.4;
          npc.look = damp(npc.look || 0, look, 3, dt);
          b.head.setEuler(-0.05, npc.look, 0);
        }
        b.hatTip.setEuler(Math.sin(t * 1.3 + seed) * 0.08, 0, Math.sin(t * 0.9 + seed) * 0.05);
        b.legL.setEuler(-1.4 + Math.sin(t * 1.7 + seed) * 0.08, 0, 0.05);
      },
    };
    this.list.push(npc);
    return npc;
  }

  // --------------------------------------------------------------- the old wizard
  buildWizard() {
    const w = this.world, g = this.game;
    const rig = buildWizard(this.ctx);
    const c = w.anchors.cauldron;
    const yaw = w.anchors.hutFacing;
    const F = [Math.sin(yaw), Math.cos(yaw)];
    const x = c[0] - F[0] * 1.25, z = c[2] - F[1] * 1.25;
    rig.root.setPos(x, w.h(x, z) - 0.05, z);
    rig.root.setRotY(yaw);
    this.scene.add(rig.root);
    const ladle = new Node('ladle');
    ladle.setPos(0, -0.62, 0.05);
    rig.bones.armR.add(ladle);
    const pts = catmullRom([[0, 0.25, 0], [0, -0.3, 0.05], [0, -0.9, 0.12], [0, -1.35, 0.1]], 3);
    const lg = Geometry.tube(pts, (t) => 0.03 * (1 - t * 0.3), 6);
    const bowl = Geometry.sphere(0.12, 10, 6);
    bowl.scale(1, 0.6, 1);
    bowl.translate(0, -1.4, 0.1);
    lg.append(bowl);
    lg.setColor(C('#5a4230'), 1);
    ladle.add(makeMesh(this.ctx, lg, this.ctx.M.wood));
    w.physics.addCircle(x, z, 0.5);
    const b = rig.bones;
    const npc = {
      pos: [x, w.h(x, z), z],
      update: (dt, t, player) => {
        const stir = t * 1.6;
        b.armR.setEuler(-0.75 + Math.sin(stir) * 0.22, 0, -0.25 + Math.cos(stir) * 0.22);
        b.armL.setEuler(-0.35 + Math.sin(t * 0.7) * 0.05, 0, 0.35);
        b.body.setEuler(0.06 + Math.sin(stir) * 0.02, Math.cos(stir) * 0.03, 0);
        const dx = player.pos[0] - x, dz = player.pos[2] - z;
        const d = Math.hypot(dx, dz);
        let look = 0, pitch = 0.25;
        if (d < 9) { look = clamp(angleDiff(yaw, Math.atan2(dx, dz)), -1.0, 1.0); pitch = 0.1; }
        else look = Math.sin(t * 0.3) * 0.2;
        npc.look = damp(npc.look || 0, look, 3, dt);
        npc.pitch = damp(npc.pitch || 0.25, pitch, 3, dt);
        b.head.setEuler(npc.pitch, npc.look, 0);
        b.hatTip.setEuler(Math.sin(t * 1.1) * 0.08, 0, Math.sin(t * 0.8) * 0.06);
      },
    };
    this.list.push(npc);
    this.wizardPos = npc.pos;
    const parts = () => ['keyA', 'keyB', 'keyC'].filter((k) => this.P.items.has(k)).length;
    this.addInteract({
      id: 'wizard', name: 'Vén Barnabás', pos: npc.pos, radius: 3.4, kind: 'talk', focus: [x, w.h(x, z) + 2.2, z],
      talk: () => {
        const st = this.P.stage.main;
        const here = npc.pos;
        if (st === 0) {
          return { lines: [...SCRIPT.wizardIntro, ...SCRIPT.wizardHint.map((l) => g.fill(l, here))], after: () => g.setStage('main', 1) };
        }
        if (st === 1) {
          const n = parts();
          if (n >= 3) {
            return {
              lines: SCRIPT.wizardForge,
              after: () => {
                for (const k of ['keyA', 'keyB', 'keyC']) this.P.items.delete(k);
                g.forgeFx();
                g.giveItem('starKey', 'Csillagkulcs');
                g.setStage('main', 3);
              },
            };
          }
          const missing = [];
          if (!this.P.items.has('keyA')) missing.push(SCRIPT.wizardHint[0]);
          if (!this.P.items.has('keyB')) missing.push(SCRIPT.wizardHint[1]);
          if (!this.P.items.has('keyC')) missing.push(SCRIPT.wizardHint[2]);
          return { lines: [n ? T('Már {0} darab megvan a háromból. Ügyes vagy!', n) : 'Még egy darabot sem találtál? Semmi baj, az erdő nem szalad el.', ...missing.map((l) => g.fill(l, here))] };
        }
        if (st < 5) return { lines: SCRIPT.wizardAfterKey };
        return { lines: SCRIPT.wizardEnd };
      },
    });
    this.addInteract({ id: 'cauldron', name: 'Az üst', pos: c, radius: 2.2, kind: 'look', lines: LINES.cauldron });
  }

  // --------------------------------------------------------------- gnomes on the lake shore
  buildLakeGnomes() {
    const w = this.world, g = this.game;
    const lg = w.anchors.log;
    const t = lg.tangent;
    const face = lg.faceYaw;
    const mk = (off, opts, pose) => {
      const rig = buildGnome(this.ctx, opts);
      const p = [lg.x + t[0] * off, lg.y, lg.z + t[1] * off];
      const npc = this.sitter(rig, p, face + (off > 0 ? -0.2 : 0.15), pose, off);
      return { rig, npc, p };
    };
    const fisher = mk(-0.9, { coat: '#2f3a2a', hat: '#1f3a2e', seed: 7, fishing: true }, 'fish');
    const pointer = mk(0.8, { coat: '#3a2f45', hat: '#23402f', beard: '#d8dbe6', seed: 9, scale: 0.95 }, 'point');
    const tip = new Node('rodTip');
    tip.setPos(0, 1.9, 0);
    fisher.rig.bones.rod.add(tip);
    this.fishTip = tip;
    this.addInteract({
      id: 'fisher', name: 'Horgász Huba', pos: fisher.p, radius: 2.8, kind: 'talk', focus: [fisher.p[0], fisher.p[1] + 0.8, fisher.p[2]],
      talk: () => {
        const s = this.P.stage.flower;
        const has = this.P.items.has('moonflower');
        const thanks = { lines: SCRIPT.fisherThanks, after: () => { this.P.items.delete('moonflower'); g.bonusShards('huba', 3); g.setStage('flower', 2); } };
        if (s < 2 && has) return thanks;
        if (s === 0) return { lines: SCRIPT.fisherAsk, after: () => g.setStage('flower', 1) };
        if (s === 1) return { lines: SCRIPT.fisherRemind };
        // (v9.1) then he tells you about the Lantern of the Deep
        const d = this.P.stage.deep;
        if (d === 0 && !g.mp) return { lines: SCRIPT.fisherDeep, after: () => g.setStage('deep', 1) };
        if (d === 1 && this.P.flags.has('levSeen')) return { lines: SCRIPT.fisherDeepThanks, after: () => { g.bonusShards('mely', 3); g.setStage('deep', 2); } };
        if (d === 1) return { lines: SCRIPT.fisherDeepRemind };
        return null;
      },
      lines: LINES.fisher,
    });
    this.addInteract({ id: 'pointer', name: 'Mutogató Márton', pos: pointer.p, radius: 2.8, kind: 'talk', lines: LINES.pointer, focus: [pointer.p[0], pointer.p[1] + 0.8, pointer.p[2]] });
  }

  // --------------------------------------------------------------- Pöttöm, in the fly agaric grove
  buildPottom() {
    const w = this.world, g = this.game;
    const s = w.L.sites.amanita;
    const rig = buildGnome(this.ctx, { coat: '#28533f', hat: '#c28a2a', beard: '#ecebe4', seed: 12, scale: 0.9 });
    this.scene.add(rig.root);
    const home = w.anchors.pottom;
    const npc = this.walker(rig, { home: [home[0], home[2]], radius: s.r * 0.6, speed: 1.6 });
    this.list.push(npc);
    this.pottom = npc;
    this.addInteract({
      id: 'pottom', name: 'Pöttöm', pos: npc.pos, radius: 2.8, kind: 'talk', moving: true,
      talk: () => {
        const st = this.P.stage.snail;
        const has = this.P.items.has('snail');
        const thanks = { lines: SCRIPT.pottomThanks, after: () => { this.P.items.delete('snail'); g.setStage('snail', 2); g.revealHidden(); } };
        if (st < 2 && has) return thanks;
        if (st === 0) return { lines: SCRIPT.pottomAsk.map((l) => g.fill(l, npc.pos)), after: () => g.setStage('snail', 1) };
        if (st === 1) return { lines: SCRIPT.pottomRemind.map((l) => g.fill(l, npc.pos)) };
        return null;
      },
      lines: LINES.pottom,
    });
  }

  // --------------------------------------------------------------- Gombafalu villagers
  buildVillagers() {
    const w = this.world, g = this.game;
    const v = w.anchors.village;
    const center = [v.x, v.z];
    const avoidWell = (x, z) => Math.hypot(x - v.x, z - v.z) < 3.2;
    const people = [
      { id: 'lamplighter', name: 'Lámpás Lőrinc', opts: { coat: '#5a3a24', hat: '#3a2f6a', seed: 21 }, walk: 12 },
      { id: 'child', name: 'Kis Csenge', opts: { coat: '#6a2f4a', hat: '#e0a02a', beard: '#f0d0c0', seed: 22, scale: 0.72, hatHeight: 0.5 }, walk: 9 },
      { id: 'baker', name: 'Pék Pál', opts: { coat: '#e8e0d0', hat: '#f2f0ea', seed: 23, scale: 1.05 }, door: 2 },
      { id: 'elder', name: 'Öreg Bódog', opts: { coat: '#2a3048', hat: '#4a1f2a', beard: '#f4f4f4', seed: 24, scale: 0.95 }, door: 4 },
    ];
    for (const p of people) {
      const rig = buildGnome(this.ctx, p.opts);
      this.scene.add(rig.root);
      let npc;
      if (p.walk) {
        npc = this.walker(rig, { home: center, radius: p.walk, speed: p.id === 'child' ? 2.2 : 1.3, avoid: avoidWell });
        this.list.push(npc);
      } else {
        const h = v.houses[p.door % v.houses.length];
        const x = h.door[0] + Math.sin(h.yaw) * 0.8, z = h.door[2] + Math.cos(h.yaw) * 0.8;
        npc = this.walker(rig, { home: [x, z], radius: 2.5, speed: 0.9, pause: [5, 12] });
        this.list.push(npc);
      }
      this.addInteract({ id: p.id, name: p.name, pos: npc.pos, radius: 2.8, kind: 'talk', lines: LINES[p.id], moving: true });
    }
    // Mesélő Menyhért sits on a bench by the well and knows where the hidden places are
    const a = 0.5;
    const bx = v.x + Math.cos(a) * 5.2, bz = v.z + Math.sin(a) * 5.2;
    const rig = buildGnome(this.ctx, { coat: '#3a4a7a', hat: '#6a2a8a', beard: '#e8ecf6', seed: 25 });
    const pos = [bx, w.h(bx, bz) + 0.25, bz];
    this.sitter(rig, pos, Math.atan2(v.x - bx, v.z - bz), 'tell', 3);
    this.addInteract({
      id: 'storyteller', name: 'Mesélő Menyhért', pos, radius: 2.8, kind: 'talk', focus: [bx, pos[1] + 0.8, bz],
      talk: () => ({ lines: SCRIPT.storyteller.map((l) => g.fill(l, pos)), after: () => g.P.flags.add('heardStoryteller') }),
    });
    this.addInteract({ id: 'well', name: 'A kút', pos: [v.x, v.y, v.z], radius: 2.6, kind: 'look', lines: LINES.well });
  }

  // --------------------------------------------------------------- (v9.1c) gnomes wandering the whole island
  // a handful of gnomes out and about on their own errands, near the roads all over the island
  buildWanderingGnomes() {
    const w = this.world, T = w.terrain, L = w.L, rng = new RNG(L.seed + 77);
    const who = [
      ['wGaspar', 'Gomba Gáspár'],
      ['wKornel', 'Kóbor Kornél'],
      ['wBerta', 'Bogyó Berta'],
      ['wCsaba', 'Csillagváró Csaba'],
      ['wDenes', 'Dúdoló Dénes'],
      ['wAbel', 'Álmos Ábel'],
      ['wKata', 'Kavics Kata'],
      ['wTivadar', 'Tüske Tivadar'],
    ];
    const coats = ['#3a5a2a', '#5a2f45', '#2f4a6a', '#6a4a2a', '#44306a', '#2a5a5a', '#6a2f2f', '#3f3f5f'];
    const hats = ['#b01e2c', '#c28a2a', '#2f6a3a', '#6a2a8a', '#1f4a8a', '#a8452a', '#8a2a5a', '#d0b060'];
    const beards = ['#ecebe4', '#d8dbe6', '#c8b8a0', '#f4f4f4', '#a89a88'];
    const busy = [[L.spawn.x, L.spawn.z, 45], [L.sites.village.x, L.sites.village.z, 50], [L.sites.castle.x, L.sites.castle.z, 40]];
    const homes = [];
    const pts = [];
    for (const p of T.paths) for (let i = 2; i < p.pts.length - 2; i += 4) pts.push(p.pts[i]);
    for (let k = 0; k < 600 && homes.length < who.length; k++) {
      const q = pts[Math.floor(rng.next() * pts.length)];
      if (!q) break;
      const a = rng.range(0, TAU), d = rng.range(4, 8);
      const x = q[0] + Math.cos(a) * d, z = q[1] + Math.sin(a) * d;
      if (Math.hypot(x, z) > L.borderAt(x, z) - 20 || w.waterDepth(x, z) > -0.3) continue;
      if (busy.some((b) => Math.hypot(x - b[0], z - b[1]) < b[2])) continue;
      if (homes.some((h) => Math.hypot(x - h[0], z - h[1]) < 55)) continue;
      if (w.physics.blocked(x, z, w.h(x, z), 0.4, 1.2, 0.5)) continue;
      homes.push([x, z]);
    }
    homes.forEach((home, i) => {
      const [id, name] = who[i];
      const rig = buildGnome(this.ctx, { coat: coats[i % coats.length], hat: hats[(i * 3) % hats.length], beard: beards[i % beards.length], seed: 60 + i, scale: rng.range(0.88, 1.06) });
      this.scene.add(rig.root);
      const npc = this.walker(rig, { home, radius: 20, speed: rng.range(1.1, 1.6), pause: [3, 9] });
      this.list.push(npc);
      this.addInteract({ id, name, pos: npc.pos, radius: 2.8, kind: 'talk', lines: LINES[id], moving: true });
    });
  }

  // --------------------------------------------------------------- hooded watchers at the blue flame
  buildHooded() {
    const w = this.world, g = this.game;
    const rw = w.anchors.rune;
    const figs = [];
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * TAU + 0.6;
      const x = rw.x + Math.cos(a) * 4.2, z = rw.z + Math.sin(a) * 4.2;
      const rig = buildHooded(this.ctx, i);
      const yaw = Math.atan2(rw.x - x, rw.z - z);
      rig.root.setPos(x, rw.y + 0.15, z);
      rig.root.setRotY(yaw);
      rig.root.setScale(1 + i * 0.05);
      this.scene.add(rig.root);
      w.physics.addCircle(x, z, 0.55);
      figs.push({ rig, yaw, x, z, i });
      this.addInteract({
        id: 'hooded' + i, name: 'Csuklyás alak', pos: [x, rw.y, z], radius: 2.6, kind: 'look',
        talk: () => {
          const total = w.loreSpots.length, read = this.P.lore.size;
          if (this.P.stage.lore >= 2) return { lines: SCRIPT.hoodedAfter };
          if (read >= total) return { name: 'A csuklyások', lines: SCRIPT.hoodedSpeak, after: () => { g.setStage('lore', 2); g.grantAbility('starsight'); } };
          if (read > 0) return { lines: SCRIPT.hoodedWait.map((l) => T(l).replace('{read}', read).replace('{total}', total)) };
          return null;
        },
        lines: LINES.hooded,
      });
    }
    this.list.push({
      update: (dt, t, player) => {
        for (const f of figs) {
          const dx = player.pos[0] - f.x, dz = player.pos[2] - f.z;
          const near = Math.hypot(dx, dz) < 7;
          const ty = near ? f.yaw + clamp(angleDiff(f.yaw, Math.atan2(dx, dz)), -0.7, 0.7) : f.yaw + Math.sin(t * 0.2 + f.i) * 0.05;
          f.cur = damp(f.cur ?? f.yaw, ty, 1.2, dt);
          f.rig.root.setEuler(Math.sin(t * 0.5 + f.i) * 0.015, f.cur, Math.sin(t * 0.4 + f.i * 2) * 0.015);
        }
      },
    });
    const fl = w.runes.world.tp(w.runes.anchors.flame);
    this.addInteract({ id: 'flame', name: 'A Kék Láng', pos: fl, radius: 3.2, kind: 'look', lines: LINES.flame });
  }

  // --------------------------------------------------------------- the astronomer on top of his tower
  buildAstronomer() {
    const w = this.world, g = this.game;
    const T = w.tower;
    const top = w.anchors.towerTop;
    const rig = buildWizard(this.ctx, { robe: '#3a2a62', hat: '#27305e', beard: '#c8cce0', seed: 8 });
    const [x, z] = T.world.tr(T.anchors.top[0] + 0.6, -1.1);
    rig.root.setPos(x, top[1] - 0.02, z);
    const yaw = T.world.yaw + 0.6;
    rig.root.setRotY(yaw);
    rig.root.setScale(0.92);
    this.scene.add(rig.root);
    w.physics.addCircle(x, z, 0.45, { yMin: top[1] - 0.5 });
    const b = rig.bones;
    const npc = {
      pos: [x, top[1], z],
      update: (dt, t, player) => {
        const dx = player.pos[0] - x, dz = player.pos[2] - z;
        const near = Math.hypot(dx, dz) < 6 && Math.abs(player.pos[1] - top[1]) < 3;
        // peeks through the telescope, or turns to the visitor
        const look = near ? clamp(angleDiff(yaw, Math.atan2(dx, dz)), -1.1, 1.1) : 0.4 + Math.sin(t * 0.2) * 0.3;
        npc.look = damp(npc.look || 0, look, 3, dt);
        b.head.setEuler(near ? 0.1 : -0.35, npc.look, 0);
        b.armR.setEuler(near ? -0.3 : -1.3 + Math.sin(t * 0.5) * 0.1, 0, -0.2);
        b.armL.setEuler(near ? -0.2 + Math.sin(t * 2) * 0.1 : -0.9, 0, 0.3);
        b.hatTip.setEuler(Math.sin(t * 1.1) * 0.08, 0, 0);
      },
    };
    this.list.push(npc);
    this.addInteract({
      id: 'astronomer', name: 'Csillagász Cirill', pos: npc.pos, radius: 3.2, kind: 'talk', focus: [x, top[1] + 2, z],
      talk: () => {
        const st = this.P.stage.lens;
        const has = this.P.items.has('lens');
        const thanks = { lines: SCRIPT.astronomerThanks, after: () => { this.P.items.delete('lens'); g.setStage('lens', 2); g.giveItem('keyC', 'Csillagkulcs-darab (a tudásban)'); g.checkKeyParts(); } };
        if (st < 2 && has) return thanks;
        if (st === 0) return { lines: SCRIPT.astronomerAsk.map((l) => g.fill(l, npc.pos)), after: () => g.setStage('lens', 1) };
        if (st === 1) return { lines: SCRIPT.astronomerRemind.map((l) => g.fill(l, npc.pos)) };
        return null;
      },
      lines: LINES.astronomer,
    });
  }

  // --------------------------------------------------------------- the Moon Queen waits at the castle
  buildQueen() {
    const w = this.world, g = this.game;
    const M = this.ctx.M;
    const p = w.anchors.castleDoor;
    const yaw = w.L.sites.castle.yaw;
    const root = new Node('queen');
    const gown = Geometry.lathe(catmullRom([[0.7, 0], [0.62, 0.15], [0.42, 0.7], [0.3, 1.2], [0.26, 1.45], [0.2, 1.6], [0.08, 1.7]], 4), 28);
    gown.deform((q) => {
      const a = Math.atan2(q[2], q[0]);
      const f = 1 + Math.sin(a * 9) * 0.04 * smoothstep(0.8, 0, q[1]);
      return [q[0] * f, q[1], q[2] * f];
    });
    gown.computeNormals();
    gown.paint((q) => {
      const t = smoothstep(0, 1.6, q[1]);
      return [lerp(0.35, 0.8, t), lerp(0.42, 0.85, t), lerp(0.9, 1.1, t), 1];
    });
    gown.paintExtra((q) => [smoothstep(0.3, 0, q[1]) * 0.8]);
    root.add(makeMesh(this.ctx, gown, M.robe, 'queenGown'));
    const head = Geometry.sphere(0.17, 16, 12);
    head.scale(1, 1.12, 1);
    head.translate(0, 1.88, 0.02);
    head.setColor(C('#d8d8f2'), 1);
    root.add(makeMesh(this.ctx, head, M.skin));
    const hair = Geometry.lathe(catmullRom([[0.19, 1.98], [0.2, 1.8], [0.22, 1.5], [0.26, 1.15], [0.2, 1.0]], 3), 18);
    hair.deform((q) => (q[2] > 0.05 && q[1] < 1.95 ? [q[0] * 0.9, q[1], -Math.abs(q[2]) * 0.3 - 0.05] : q));
    hair.setColor(C('#e8f0ff'), 1);
    hair.setExtra([0.6]);
    root.add(makeMesh(this.ctx, hair, M.hair));
    const crown = new Geometry();
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * TAU;
      const s = Geometry.cylinder(0.02, 0.0, 0.18 + (i % 2) * 0.08, 4, 1);
      s.translate(Math.cos(a) * 0.15, 2.02, Math.sin(a) * 0.15);
      crown.append(s);
    }
    const ring = Geometry.torus(0.155, 0.018, 4, 20);
    ring.rotateX(Math.PI / 2);
    ring.translate(0, 2.03, 0);
    crown.append(ring);
    crown.setColor(C('#e8f4ff'), 1);
    crown.setExtra([4]);
    const cm = makeMesh(this.ctx, crown, M.glow);
    cm.castShadow = false;
    root.add(cm);
    root.setPos(p[0], p[1] - 0.02, p[2]);
    root.setRotY(yaw);
    this.scene.add(root);
    w.light([p[0], p[1] + 2.4, p[2]], C('#cfe0ff'), 3.5, 10, 0.03, 20);
    const halo = particleSystem(w.gl, 60, { FIREFLY: 1, STAR: 1 }, (i, r) => ({ p: [p[0] + r.range(-1.5, 1.5), p[1] + r.range(0.3, 2.6), p[2] + r.range(-1.5, 1.5)], params: [r.range(1, 3), 0, 0, 0], size: r.range(0.05, 0.1), speed: r.range(0.3, 0.6), spread: 0.8, color: C('#e0ecff'), intensity: 4 }), { seed: 404 });
    halo.maxDistance = 200;
    this.scene.add(halo);
    w.physics.addCircle(p[0], p[2], 0.6, { yMin: p[1] - 1 });
    this.list.push({ update: (dt, t) => { root.setEuler(0, yaw + Math.sin(t * 0.3) * 0.08, 0); root.position[1] = p[1] - 0.02 + Math.sin(t * 0.9) * 0.03; } });
    this.addInteract({
      id: 'queen', name: 'A Holdkirálynő', pos: p, radius: 3.4, kind: 'talk', focus: [p[0], p[1] + 1.9, p[2]],
      talk: () => {
        if (this.P.stage.main === 4) return { lines: SCRIPT.queen, after: () => { g.setStage('main', 5); g.ending(); } };
        return { lines: LINES.queen };
      },
    });
  }

  // --------------------------------------------------------------- crows that flee and come back
  buildCrows() {
    const w = this.world;
    const perches = [];
    const rw = w.runes;
    for (const k of ['stone0', 'stone3', 'stone5', 'stone7']) if (rw.anchors[k]) perches.push(rw.world.tp(rw.anchors[k]));
    const gw = w.gate.world;
    perches.push(gw.tp([-4.6, 10.2, 1.5]), gw.tp([5.2, 10.2, 0.5]), gw.tp([-12, 6.2, 0.2]));
    const lg = w.anchors.log;
    perches.push([lg.x + lg.tangent[0] * 3.2, lg.y + 0.05, lg.z + lg.tangent[1] * 3.2]);
    for (const r of (w.ruins.anchors.tops || []).slice(0, 2)) perches.push(w.ruins.world.tp(r));
    const crows = [];
    for (const p of perches) {
      const rig = buildCrow(this.ctx);
      rig.root.setPos(p[0], p[1], p[2]);
      this.scene.add(rig.root);
      crows.push({ rig, home: p.slice(), state: 'perch', t: 0, yaw: this.rng.range(0, TAU), dir: [0, 0], seed: this.rng.next() * 10 });
    }
    this.list.push({
      update: (dt, t, player) => {
        for (const c of crows) {
          const b = c.rig.bones;
          const dx = player.pos[0] - c.home[0], dz = player.pos[2] - c.home[2];
          const pd = Math.hypot(dx, dz);
          if (pd > 90 && c.state === 'perch') continue;
          c.t += dt;
          if (c.state === 'perch') {
            b.head.setEuler(0, Math.sin(t * 0.7 + c.seed) * 0.8 * (Math.sin(t * 0.23 + c.seed) > 0 ? 1 : 0.2), 0);
            b.wingL.setEuler(0, 0, 0.1);
            b.wingR.setEuler(0, 0, -0.1);
            b.body.position[1] = 0.16 + Math.max(0, Math.sin(t * 2 + c.seed * 3)) ** 40 * 0.08;
            c.rig.root.setPos(c.home[0], c.home[1], c.home[2]);
            c.rig.root.setRotY(c.yaw);
            if (pd < 4.8 && Math.abs(player.pos[1] - c.home[1]) < 6) {
              c.state = 'flee';
              c.t = 0;
              const a = Math.atan2(-dx, -dz) + this.rng.range(-0.6, 0.6);
              c.dir = [Math.sin(a), Math.cos(a)];
              this.onCrow && this.onCrow(c.home);
            }
          } else if (c.state === 'flee' || c.state === 'return') {
            const T = 4.0;
            const u = c.state === 'flee' ? c.t / T : 1 - c.t / T;
            const dist = u * u * 40 + u * 6;
            const up = Math.sin(Math.min(u, 1) * Math.PI * 0.5) * 18;
            const x = c.home[0] + c.dir[0] * dist, z = c.home[2] + c.dir[1] * dist;
            const y = c.home[1] + up + Math.sin(c.t * 3 + c.seed) * 0.4;
            c.rig.root.setPos(x, y, z);
            const fy = Math.atan2(c.dir[0], c.dir[1]) + (c.state === 'return' ? Math.PI : 0);
            c.rig.root.setEuler(c.state === 'flee' ? -0.3 : 0.2, fy, 0);
            const flap = Math.sin(t * 22 + c.seed) * 0.9;
            b.wingL.setEuler(0, 0, 0.2 + flap);
            b.wingR.setEuler(0, 0, -0.2 - flap);
            if (c.t >= T) {
              if (c.state === 'flee') { c.state = 'away'; c.t = 0; c.rig.root.visible = false; }
              else { c.state = 'perch'; c.t = 0; }
            }
          } else if (c.state === 'away') {
            if (c.t > 14 && pd > 12) { c.state = 'return'; c.t = 0; c.rig.root.visible = true; }
          }
        }
      },
    });
  }

  // --------------------------------------------------------------- Brekus the frog
  buildFrog() {
    const w = this.world;
    const lg = w.anchors.log;
    const lake = w.L.sites.lake;
    const dx = lake.x - lg.x, dz = lake.z - lg.z, dl = Math.hypot(dx, dz);
    let d = 3;
    while (d < 20 && w.waterDepth(lg.x + (dx / dl) * d, lg.z + (dz / dl) * d) < 0.4) d += 0.5;
    const home = [lg.x + (dx / dl) * (d + 2.2), w.L.waterLevel, lg.z + (dz / dl) * (d + 2.2)];
    // Brekus sits on a lily pad out on the water (you can hop over to him)
    const PAD = 1.6;
    const pad = buildLilyPad(this.ctx, 1.0);
    pad.root.setScale(PAD);
    pad.root.setPos(home[0], home[1], home[2]);
    pad.root.setRotY(Math.atan2(-dx, -dz) + 0.6);
    this.scene.add(pad.root);
    w.physics.addSurface({ type: 'disc', x: home[0], z: home[2], r: PAD * 0.92, top: home[1] + 0.03, bottom: home[1] - 0.3 });
    // Brekus himself is solid (you can stand on the pad next to him, not inside him)
    w.physics.addCircle(home[0], home[2], 0.5, { yMin: home[1] - 0.5, yMax: home[1] + 1.1 });
    const rig = buildFrog(this.ctx);
    rig.root.setScale(1.3);
    this.scene.add(rig.root);
    const st = { yaw: 0, croak: 6, hop: 0, sac: 0 };
    this.list.push({
      update: (dt, t, player) => {
        const bob = Math.sin(t * 1.1) * 0.012;
        pad.root.setPos(home[0], home[1] + bob, home[2]);
        // turns to face you, with a little hop when he has to turn a lot
        const want = Math.atan2(player.pos[0] - home[0], player.pos[2] - home[2]);
        const diff = angleDiff(st.yaw, want);
        if (Math.abs(diff) > 0.9 && st.hop <= 0) st.hop = 0.45;
        if (st.hop > 0) { st.hop -= dt; st.yaw += diff * Math.min(1, dt * 7); }
        else st.yaw += diff * Math.min(1, dt * 0.6);
        const hopY = st.hop > 0 ? Math.sin((1 - st.hop / 0.45) * Math.PI) * 0.18 : 0;
        rig.root.setPos(home[0] + Math.sin(st.yaw + Math.PI) * 0.15, home[1] + 0.03 + bob + hopY, home[2] + Math.cos(st.yaw + Math.PI) * 0.15);
        rig.root.setRotY(st.yaw);
        // breathing, and a croak now and then (the throat swells like a balloon)
        const b = rig.bones;
        b.body.scale[1] = 1 + Math.sin(t * 2.1) * 0.015;
        st.croak -= dt;
        if (st.croak <= 0) {
          st.croak = 5 + Math.random() * 6;
          st.sac = 1;
          const a = this.game.audio;
          const pd = Math.hypot(player.pos[0] - home[0], player.pos[2] - home[2]);
          if (a.started && pd < 40) a.croak && a.croak(Math.max(0.15, 1 - pd / 40));
        }
        st.sac = Math.max(0, st.sac - dt * 1.4);
        const sw = 1 + Math.sin(Math.min(1, st.sac) * Math.PI) * 0.9;
        b.throat.setScale(sw, sw * 0.9, sw);
      },
    });
    this.addInteract({ id: 'frog', name: 'Brekus', pos: home, radius: 9, kind: 'talk', lines: LINES.frog });
  }

  // --------------------------------------------------------------- quest items lying in the world
  buildQuestItems() {
    const w = this.world, g = this.game, M = this.ctx.M;
    const item = (id, name, pos, mesh, { verb = 'Felveszem', radius = 2.4, script, has, after, lightCol }) => {
      if (mesh) this.scene.add(mesh);
      const baseY = mesh ? mesh.position[1] : 0;
      const l = lightCol ? w.light([pos[0], pos[1] + 0.8, pos[2]], lightCol, 2.2, 6, 0.05, 6) : null;
      const it = this.addInteract({
        id, name, pos, radius, kind: 'take', verb,
        visible: () => !has(),
        talk: () => ({ lines: script, after: () => { after(); } }),
      });
      this.list.push({
        update: (dt, t) => {
          const vis = !has();
          if (mesh) mesh.visible = vis;
          if (l) l.enabled = vis;
          if (mesh && vis && mesh.spin) { mesh.setEuler(0, t * 0.8, 0); mesh.position[1] = baseY + Math.sin(t * 1.6) * 0.08; }
        },
      });
      return it;
    };
    // the astronomer's lens in the crystal field
    {
      const p = w.anchors.lensSpot;
      const g2 = Geometry.torus(0.22, 0.035, 6, 20);
      const glass = Geometry.disc(0.2, 20);
      glass.rotateX(Math.PI / 2);
      g2.append(glass);
      g2.rotateX(Math.PI / 2);
      g2.setColor(C('#cfe8ff'), 1);
      g2.setExtra([2.2]);
      const m = makeMesh(this.ctx, g2, M.glass, 'lens');
      m.castShadow = false;
      m.spin = true;
      m.setPos(p[0], p[1] + 0.35, p[2]);
      item('lens', 'Csillaglencse', p, m, {
        script: SCRIPT.lens, lightCol: C('#bfe0ff'),
        has: () => this.P.items.has('lens') || this.P.stage.lens >= 2,
        after: () => { g.giveItem('lens', 'Csillaglencse'); if (this.P.stage.lens === 0) g.setStage('lens', 1, true); },
      });
    }
    // key part on the highest floating island
    {
      const p = w.anchors.islandShrine;
      const star = starGeometry(0.34, 0.14, 0.08);
      star.setColor(C('#bfe6ff'), 1);
      star.setExtra([3.5]);
      const m = makeMesh(this.ctx, star, M.glow, 'keyA');
      m.castShadow = false;
      m.spin = true;
      m.setPos(p[0], p[1], p[2]);
      item('keyA', 'Csillagkulcs-darab', [p[0], p[1] - 1.6, p[2]], m, {
        verb: 'Megérintem', script: SCRIPT.keyA, lightCol: C('#bfe6ff'),
        has: () => this.P.flags.has('gotKeyA'),
        after: () => { this.P.flags.add('gotKeyA'); g.giveItem('keyA', 'Csillagkulcs-darab (a magasban)'); g.checkKeyParts(); },
      });
    }
    // key part from the fallen star's heart
    {
      const p = w.anchors.starHeart;
      const ground = [p[0], w.starHeart.world.y, p[2]];
      this.addInteract({
        id: 'keyB', name: 'A csillag szíve', pos: ground, radius: 4.5, kind: 'look', verb: 'Megérintem',
        talk: () => {
          if (!this.P.flags.has('gotKeyB')) return { lines: SCRIPT.keyB, after: () => { this.P.flags.add('gotKeyB'); g.giveItem('keyB', 'Csillagkulcs-darab (a mélyben)'); g.checkKeyParts(); g.flash(0.6); } };
          return { lines: LINES.heart };
        },
      });
    }
    // the moonflower on the waterfall cliff
    {
      const p = w.anchors.moonflower;
      const fl = flora.flower(77, '#f5f1ff');
      fl.setExtra([1.6]);
      const m = makeMesh(this.ctx, fl, M.plants, 'moonflower');
      m.setScale(2.2);
      m.setPos(p[0], p[1] - 0.02, p[2]);
      m.castShadow = false;
      item('moonflower', 'Holdvirág', p, m, {
        verb: 'Leszakítom', script: SCRIPT.flower, lightCol: C('#e8f0ff'),
        has: () => this.P.items.has('moonflower') || this.P.stage.flower >= 2,
        after: () => { g.giveItem('moonflower', 'Holdvirág'); if (this.P.stage.flower === 0) g.setStage('flower', 1, true); },
      });
    }
    // Fénylő Fülöp, Pöttöm's snail, by a small pond
    {
      const L = w.L;
      const ponds = L.lakes.filter((l) => l.id.startsWith('pond'));
      const am = L.sites.amanita;
      ponds.sort((a, b) => Math.hypot(b.x - am.x, b.z - am.z) - Math.hypot(a.x - am.x, a.z - am.z));
      const pond = ponds[Math.min(1, ponds.length - 1)] || L.lakes[0];
      let spot = [pond.x + pond.r + 1.5, pond.z];
      for (let k = 0; k < 24; k++) {
        const a = (k / 24) * TAU;
        const x = pond.x + Math.cos(a) * (pond.r + 1.2), z = pond.z + Math.sin(a) * (pond.r + 1.2);
        if (w.waterDepth(x, z) < -0.25) { spot = [x, z]; break; }
      }
      const pos = [spot[0], w.h(spot[0], spot[1]), spot[1]];
      w.anchors.snailSpot = pos;
      const rig = buildSnail(this.ctx);
      rig.root.setScale(0.1);
      rig.root.setPos(pos[0], pos[1], pos[2]);
      rig.root.setRotY(Math.atan2(pond.x - pos[0], pond.z - pos[2]));
      this.scene.add(rig.root);
      const light = w.light([pos[0], pos[1] + 0.6, pos[2]], C('#9fffd8'), 1.6, 5, 0.1, 4);
      this.fulop = { rig, light, pos };
      this.addInteract({
        id: 'fulop', name: 'Fénylő Fülöp', pos, radius: 2.4, kind: 'take', verb: 'Felveszem',
        visible: () => !this.P.items.has('snail') && this.P.stage.snail < 2,
        talk: () => ({ lines: SCRIPT.snail, after: () => { g.giveItem('snail', 'Fénylő Fülöp (csiga)'); if (this.P.stage.snail === 0) g.setStage('snail', 1, true); } }),
      });
      this.list.push({
        update: (dt, t) => {
          const st = this.P.stage.snail;
          const carried = this.P.items.has('snail');
          rig.root.visible = !carried;
          light.enabled = !carried;
          if (st >= 2 && this.pottom) {
            // back home: follows Pöttöm around
            const pp = this.pottom.pos, sy = this.pottom.st.yaw;
            const tx = pp[0] - Math.sin(sy) * 0.8 + Math.cos(sy) * 0.5, tz = pp[2] - Math.cos(sy) * 0.8 - Math.sin(sy) * 0.5;
            const r = rig.root.position;
            r[0] = damp(r[0], tx, 1.5, dt); r[2] = damp(r[2], tz, 1.5, dt);
            r[1] = this.world.h(r[0], r[2]);
            rig.root.setRotY(sy);
            light.position = [r[0], r[1] + 0.6, r[2]];
          }
          rig.bones.stalkL && rig.bones.stalkL.setEuler(Math.sin(t * 1.3) * 0.2, 0, 0);
          rig.bones.stalkR && rig.bones.stalkR.setEuler(Math.sin(t * 1.1 + 1) * 0.2, 0, 0);
        },
      });
    }
  }

  // --------------------------------------------------------------- the Moon Stag: only lets a quiet visitor come close
  buildStag() {
    const w = this.world, g = this.game, L = w.L;
    const rig = buildStag(this.ctx);
    this.scene.add(rig.root);
    const b = rig.bones;
    // grazing grounds: meadows around quiet places
    const grounds = [];
    for (const id of ['moongarden', 'village', 'glade', 'watcher', 'rune']) {
      const s = L.sites[id];
      for (let k = 0; k < 30; k++) {
        const a = this.rng.range(0, TAU), d = this.rng.range(28, 55);
        const x = s.x + Math.cos(a) * d, z = s.z + Math.sin(a) * d;
        if (Math.hypot(x, z) > L.borderAt(x, z) - 25 || w.waterDepth(x, z) > -0.4) continue;
        if (w.terrain.normalAt(x, z)[1] < 0.9) continue;
        grounds.push([x, z]);
        break;
      }
    }
    if (!grounds.length) grounds.push([L.spawn.x + 30, L.spawn.z]);
    // (v9) after a fright the stag turns up somewhere else on the island, not always at the same meadows:
    // quiet, flat, dry spots near the roads (so a walker can come across it again)
    const roam = [];
    for (let k = 0; k < 1500 && roam.length < 220; k++) {
      const a = this.rng.range(0, TAU), d = Math.sqrt(this.rng.next()) * 320;
      const x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (Math.hypot(x, z) > L.borderAt(x, z) - 28 || w.waterDepth(x, z) > -0.5) continue;
      if (w.terrain.normalAt(x, z)[1] < 0.93) continue;
      const pd = w.terrain.sample(w.terrain.pathDist, x, z);
      if (pd < 5 || pd > 32 || !w.occ.free(x, z, 2.5)) continue;
      const bm = L.biome(x, z);
      if (bm.desert > 0.3 || bm.dead > 0.4 || bm.swamp > 0.5 || bm.crystal > 0.4) continue;
      roam.push([x, z]);
    }
    const st = { gi: 1 % grounds.length, home: null, x: 0, z: 0, yaw: 0, mode: 'graze', t: 0, target: null, speed: 0, phase: 0, fade: 1, seen: false };
    const placeAt = (q) => {
      st.home = q;
      st.x = q[0]; st.z = q[1];
      st.yaw = this.rng.range(0, TAU);
      st.mode = 'graze'; st.t = 0; st.target = null;
    };
    placeAt(grounds[st.gi]);
    const light = w.light([st.x, 2, st.z], C('#9fd8ff'), 1.5, 9, 0.05, 6);
    this.stag = st;
    const npcPos = [st.x, 0, st.z];
    this.addInteract({
      id: 'stag', name: 'Holdszarvas', pos: npcPos, radius: 3.2, kind: 'look', verb: 'Megérintem', moving: true,
      visible: () => st.mode === 'graze' || st.mode === 'walk' || st.mode === 'calm',
      talk: () => {
        if (this.P.stage.stag < 2) return { lines: SCRIPT.stagBless, after: () => { g.setStage('stag', 2); g.grantAbility('moonrun'); g.flash(0.4); } };
        return { lines: ['A Holdszarvas nyugodtan legel melletted. Az agancsa halkan csilingel.'] };
      },
    });
    this.list.push({
      update: (dt, t, player) => {
        const dx = player.pos[0] - st.x, dz = player.pos[2] - st.z;
        const d = Math.hypot(dx, dz);
        const blessed = this.P.stage.stag >= 2;
        const ps = Math.hypot(player.vel[0], player.vel[2]);
        const loud = !player.sneaking && ps > 1.6; // sneaking is quiet, walking is not
        st.t += dt;
        if (!st.seen && d < 38) {
          st.seen = true;
          if (this.P.stage.stag === 0) g.setStage('stag', 1);
        }
        let move = 0;
        if (st.mode === 'flee') {
          move = 9;
          st.yaw += angleDiff(st.yaw, Math.atan2(-dx, -dz)) * (1 - Math.exp(-4 * dt));
          st.fade = Math.max(0, st.fade - dt * 0.45);
          if (st.fade <= 0) {
            // reappear at a random spot elsewhere on the island, out of sight of the player
            const pool = roam.length ? roam : grounds;
            let pick = null;
            for (let k = 0; k < 40 && !pick; k++) {
              const q = pool[Math.floor(Math.random() * pool.length)];
              const dp = Math.hypot(q[0] - player.pos[0], q[1] - player.pos[2]);
              const dh = Math.hypot(q[0] - st.x, q[1] - st.z);
              if (dp > 70 && dp < 280 && dh > 50) pick = q;
            }
            if (!pick) pick = pool.reduce((b, q) => (Math.hypot(q[0] - player.pos[0], q[1] - player.pos[2]) > Math.hypot(b[0] - player.pos[0], b[1] - player.pos[2]) ? q : b), pool[0]);
            placeAt(pick);
            st.fade = 0;
            st.mode = 'appear';
            st.flights = (st.flights || 0) + 1;
          }
        } else if (st.mode === 'appear') {
          st.fade = Math.min(1, st.fade + dt * 0.5);
          if (st.fade >= 1) st.mode = 'graze';
        } else {
          if (!blessed && d < 13 && loud) {
            st.mode = 'flee'; st.t = 0;
            g.audio.flap();
            if (d < 9) g.hint(SCRIPT.stagFled[0]);
          } else if (d < 6 && !loud) {
            st.mode = 'calm';
            st.yaw += angleDiff(st.yaw, Math.atan2(dx, dz)) * (1 - Math.exp(-1.5 * dt));
          } else if (st.mode === 'calm') {
            st.mode = 'graze';
          } else if (st.mode === 'graze') {
            if (st.t > 6 + (st.flights || 0) % 3) {
              st.mode = 'walk'; st.t = 0;
              const a = this.rng.range(0, TAU), r = this.rng.range(3, 14);
              const hx = st.home[0], hz = st.home[1];
              st.target = [hx + Math.cos(a) * r, hz + Math.sin(a) * r];
            }
          } else if (st.mode === 'walk') {
            const tx = st.target[0] - st.x, tz = st.target[1] - st.z;
            if (Math.hypot(tx, tz) < 0.5 || st.t > 12 || w.waterDepth(st.target[0], st.target[1]) > -0.3) { st.mode = 'graze'; st.t = 0; }
            else { st.yaw += angleDiff(st.yaw, Math.atan2(tx, tz)) * (1 - Math.exp(-2 * dt)); move = 1.2; }
          }
        }
        st.speed = damp(st.speed, move, 3, dt);
        if (st.speed > 0.01) {
          let nx = st.x + Math.sin(st.yaw) * st.speed * dt, nz = st.z + Math.cos(st.yaw) * st.speed * dt;
          [nx, nz] = w.collide(nx, nz, 0.7, w.h(nx, nz));
          if (w.waterDepth(nx, nz) < 0.3) { st.x = nx; st.z = nz; }
        }
        const y = w.h(st.x, st.z);
        const gallop = st.mode === 'flee';
        st.phase += dt * (gallop ? 11 : st.speed * 4.2);
        const s = Math.sin(st.phase), c = Math.cos(st.phase);
        const amp = gallop ? 0.9 : clamp(st.speed, 0, 1) * 0.45;
        b.legFL.setEuler(s * amp, 0, 0);
        b.legBR.setEuler(s * amp * (gallop ? 1 : 1), 0, 0);
        b.legFR.setEuler(-s * amp, 0, 0);
        b.legBL.setEuler(-s * amp, 0, 0);
        const graze = st.mode === 'graze' ? smoothstep(0.5, 1.5, st.t) * (Math.sin(st.t * 0.4) > -0.6 ? 1 : 0) : 0;
        st.graze = damp(st.graze || 0, graze, 2, dt);
        b.neck.setEuler(0.2 + st.graze * 1.1 - (st.mode === 'calm' ? 0.2 : 0), 0, 0);
        b.head.setEuler(-st.graze * 0.3 + Math.sin(t * 3) * 0.04 * st.graze, st.mode === 'calm' ? clamp(angleDiff(st.yaw, Math.atan2(dx, dz)), -0.6, 0.6) : 0, 0);
        b.body.position[1] = 1.25 + (gallop ? Math.abs(c) * 0.15 : 0);
        rig.root.setPos(st.x, y - (1 - st.fade) * 0.3, st.z);
        rig.root.setRotY(st.yaw);
        rig.root.visible = st.fade > 0.02;
        const sc = 0.15 + 0.85 * st.fade;
        rig.root.setScale(1, sc, 1);
        light.position = [st.x, y + 3.6, st.z];
        light.intensity = 1.2 * st.fade;
        npcPos[0] = st.x; npcPos[1] = y; npcPos[2] = st.z;
        if (gallop && this.game.trail && Math.random() < 0.6) this.game.trail.emit([st.x + (Math.random() - 0.5), y + 0.4 + Math.random(), st.z + (Math.random() - 0.5)], t, { size: 0.12, life: 1.4, rise: 0.4, spread: 0.6, color: [0.6, 0.85, 1.8], intensity: 2.5 });
      },
    });
  }

  // --------------------------------------------------------------- the giant snail with a house on her back, slowly travelling a road
  buildBigSnail() {
    const w = this.world;
    const paths = w.terrain.paths.filter((p) => p.pts.length > 30);
    if (!paths.length) return;
    const path = paths.reduce((a, b) => (b.pts.length > a.pts.length ? b : a), paths[0]);
    const pts = path.pts;
    const rig = buildSnail(this.ctx);
    rig.root.setScale(0.85);
    this.scene.add(rig.root);
    const light = w.light([0, 0, 0], C('#ffb35c'), 2.6, 9, 0.12, 3);
    // arc length table
    const acc = [0];
    for (let i = 1; i < pts.length; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    const total = acc[acc.length - 1];
    const at = (s) => {
      s = clamp(s, 0, total);
      let lo = 0, hi = acc.length - 1;
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (acc[m] < s) lo = m; else hi = m; }
      const t = (s - acc[lo]) / Math.max(1e-4, acc[hi] - acc[lo]);
      return [lerp(pts[lo][0], pts[hi][0], t), lerp(pts[lo][1], pts[hi][1], t)];
    };
    const st = { s: total * 0.3, dir: 1, x: 0, z: 0, yaw: 0, wait: 0 };
    const pos = [0, 0, 0];
    this.bigSnail = st;
    this.addInteract({ id: 'snailBig', name: 'Csiga Csilla', pos, radius: 4.2, kind: 'look', lines: LINES.snailBig, moving: true });
    this.list.push({
      update: (dt, t, player) => {
        const dp = Math.hypot(player.pos[0] - st.x, player.pos[2] - st.z);
        // stops politely when you are in the way
        const blocked = dp < 4.2;
        if (!blocked) st.s += st.dir * 0.55 * dt;
        if (st.s > total - 2 || st.s < 2) { st.dir *= -1; st.s = clamp(st.s, 2, total - 2); }
        const p = at(st.s), q = at(st.s + st.dir * 1.5);
        // walk on the road's shoulder
        const tx = q[0] - p[0], tz = q[1] - p[1], tl = Math.hypot(tx, tz) || 1;
        const off = (path.width || 3) * 0.5 + 0.2;
        st.x = p[0] - (tz / tl) * off * st.dir;
        st.z = p[1] + (tx / tl) * off * st.dir;
        const yaw = Math.atan2(tx, tz);
        st.yaw += angleDiff(st.yaw, yaw) * (1 - Math.exp(-1.5 * dt));
        const y = w.h(st.x, st.z);
        rig.root.setPos(st.x, y - 0.05, st.z);
        rig.root.setRotY(st.yaw);
        const wob = Math.sin(t * 1.2);
        rig.bones.body.scale[2] = 1 + (blocked ? 0 : wob * 0.04);
        rig.bones.stalkL && rig.bones.stalkL.setEuler(Math.sin(t * 0.9) * 0.2 - (blocked ? 0.3 : 0), 0, 0);
        rig.bones.stalkR && rig.bones.stalkR.setEuler(Math.sin(t * 0.7 + 1) * 0.2 - (blocked ? 0.3 : 0), 0, 0);
        const lp = rig.bones.lamp.worldPosition();
        light.position = lp;
        pos[0] = st.x; pos[1] = y; pos[2] = st.z;
      },
    });
  }

  // --------------------------------------------------------------- glowing star fish leaping out of the water
  buildFish() {
    const w = this.world, L = w.L, g = this.game;
    const body = Geometry.sphere(0.13, 10, 8);
    body.scale(0.6, 0.75, 1.9);
    const tail = Geometry.cylinder(0.0, 0.16, 0.28, 6, 1);
    tail.rotateX(-Math.PI / 2);
    tail.scale(0.35, 1, 1);
    tail.translate(0, 0, -0.26);
    body.append(tail);
    body.setColor(C('#a8fff0'), 1);
    body.setExtra([2.8]);
    const gpu = w.gpu(body);
    // water spots: the lake, the ponds and the calm stretches of the river
    const spots = [];
    const rng = this.rng;
    for (const lk of L.lakes) {
      for (let k = 0; k < (lk.id === 'lake' ? 30 : 5); k++) {
        const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * lk.r * 0.75;
        const x = lk.x + Math.cos(a) * d, z = lk.z + Math.sin(a) * d;
        if (w.waterDepth(x, z) > 0.7) spots.push([x, z]);
      }
    }
    for (const rv of L.rivers) for (let i = 2; i < rv.points.length - 2; i += 3) {
      const p = rv.points[i];
      if (w.waterDepth(p[0], p[1]) > 0.5 && Math.hypot(p[0], p[1]) < L.borderAt(p[0], p[1])) spots.push(p);
    }
    const fish = [];
    for (let i = 0; i < 7; i++) {
      const m = w.meshG(gpu, this.ctx.M.glow, 'fish');
      m.castShadow = false;
      m.visible = false;
      this.scene.add(m);
      fish.push({ m, t: rng.range(1, 6), jump: null });
    }
    const pl = this.game.player;
    this.list.push({
      update: (dt, t) => {
        for (const f of fish) {
          if (f.jump) {
            const j = f.jump;
            j.u += dt / j.dur;
            if (j.u >= 1) {
              f.m.visible = false;
              f.jump = null;
              f.t = rng.range(2, 7);
              if (g.trail) for (let k = 0; k < 10; k++) g.trail.emit([j.b[0] + rng.range(-0.3, 0.3), L.waterLevel + 0.05, j.b[1] + rng.range(-0.3, 0.3)], t, { size: 0.09, life: 0.8, rise: 0.6, spread: 0.6, color: [0.5, 1.4, 1.5], intensity: 2.4 });
              continue;
            }
            const u = j.u;
            const x = lerp(j.a[0], j.b[0], u), z = lerp(j.a[1], j.b[1], u);
            const y = L.waterLevel + Math.sin(u * Math.PI) * j.h - 0.1;
            f.m.setPos(x, y, z);
            f.m.setEuler(-Math.cos(u * Math.PI) * 1.0, j.yaw, 0);
            continue;
          }
          f.t -= dt;
          if (f.t > 0) continue;
          // jump somewhere near the player, so the world feels alive where you are
          const near = spots.filter((p) => Math.hypot(p[0] - pl.pos[0], p[1] - pl.pos[2]) < 55);
          if (!near.length) { f.t = 3; continue; }
          const a = near[Math.floor(rng.next() * near.length)];
          const ang = rng.range(0, TAU), len = rng.range(1.2, 2.6);
          const b = [a[0] + Math.cos(ang) * len, a[1] + Math.sin(ang) * len];
          f.jump = { a, b, u: 0, dur: rng.range(0.7, 1.0), h: rng.range(0.7, 1.4), yaw: Math.atan2(b[0] - a[0], b[1] - a[1]) };
          f.m.visible = true;
          if (g.trail) for (let k = 0; k < 6; k++) g.trail.emit([a[0] + rng.range(-0.2, 0.2), L.waterLevel + 0.05, a[1] + rng.range(-0.2, 0.2)], t, { size: 0.08, life: 0.7, rise: 0.5, spread: 0.4, color: [0.5, 1.4, 1.5], intensity: 2.2 });
        }
      },
    });
  }

  // --------------------------------------------------------------- animated props & look-at points
  buildProps() {
    const w = this.world, g = this.game;
    const wa = w.watcher;
    const eye = wa.anchors.eye, lids = wa.anchors.lids;
    const blink = { t: 3 };
    this.list.push({
      update: (dt, t, player) => {
        const ep = wa.world.tp([0, 4.2, 4.3]);
        const dx = player.pos[0] - ep[0], dy = player.pos[1] + 1 - ep[1], dz = player.pos[2] - ep[2];
        const d = Math.hypot(dx, dz);
        if (d > 120) return;
        const c = Math.cos(wa.world.yaw), s = Math.sin(wa.world.yaw);
        const lx = dx * c - dz * s, lz = dx * s + dz * c;
        let yaw = Math.atan2(lx, lz), pitch = -Math.atan2(dy, Math.hypot(lx, lz));
        if (d > 45) { yaw = Math.sin(t * 0.3) * 0.5; pitch = 0.1; }
        yaw = clamp(yaw, -0.9, 0.9);
        pitch = clamp(pitch, -0.5, 0.5);
        eye.ey = damp(eye.ey ?? 0, yaw, 3, dt);
        eye.ep = damp(eye.ep ?? 0, pitch, 3, dt);
        eye.setEuler(eye.ep, eye.ey, 0);
        blink.t -= dt;
        let close = 0;
        if (blink.t < 0.25) close = Math.sin(clamp(blink.t / 0.25, 0, 1) * Math.PI);
        if (blink.t < 0) blink.t = 3 + Math.random() * 5;
        const open = 1 - close;
        lids.up.setEuler(-0.95 * open - 0.05 + eye.ep * 0.4, 0, 0);
        lids.down.setEuler(0.8 * open + 0.05 + eye.ep * 0.3, 0, 0);
      },
    });
    this.addInteract({ id: 'watcher', name: 'Egyszemű Kő', pos: wa.world.tp([0, 0, 5]), radius: 5, kind: 'look', lines: LINES.watcher });
    const cap = w.pyramid.anchors.capstone;
    this.list.push({ update: (dt, t) => { cap.setEuler(0, t * 0.4, 0); cap.position[1] = 19.6 + Math.sin(t * 0.8) * 0.4; } });
    this.addInteract({ id: 'pyramidTop', name: 'Álompiramis csúcsa', pos: w.anchors.pyramidTop, radius: 4, kind: 'look', lines: LINES.pyramid });
    const runeMesh = w.runes.root.children.find((n) => n.name === 'runes');
    if (runeMesh) this.list.push({ update: (dt, t) => runeMesh.setRotY(t * 0.05) });
    // the castle gate
    this.addInteract({
      id: 'gate', name: 'Kőmarok kapuja', pos: w.gate.world.tp([0, 0, 2.4]), radius: 3.6, kind: 'look',
      talk: () => {
        if (this.P.flags.has('gateOpen')) return { lines: SCRIPT.gateAfter };
        if (this.P.items.has('starKey')) return { lines: SCRIPT.gateOpen, after: () => { this.P.items.delete('starKey'); g.openGate(true); g.setStage('main', 4); } };
        return { lines: SCRIPT.gateLocked };
      },
    });
    this.addInteract({ id: 'moon', name: 'Holdarc', pos: w.moon.world.tp([0, 0, 4.8]), radius: 4.5, kind: 'look', lines: LINES.moon });
    this.addInteract({ id: 'pier', name: 'A móló vége', pos: w.anchors.pierEnd, radius: 2.2, kind: 'look', lines: LINES.pier });
    this.addInteract({ id: 'giant', name: 'Az Alvó Óriás', pos: w.anchors.giantMouth, radius: 5, kind: 'look', lines: LINES.giant });
    this.addInteract({ id: 'ruins', name: 'Feledés romjai', pos: [w.ruins.world.x, w.ruins.world.y, w.ruins.world.z], radius: 4, kind: 'look', lines: LINES.ruins });
    // rune stones
    for (const s of w.loreSpots) {
      this.addInteract({
        id: s.id, name: 'Rúnakő', pos: [s.x, s.y, s.z], radius: 2.4, kind: 'read', verb: 'Elolvasom',
        talk: () => ({ name: 'Rúnakő', lines: [s.text], after: () => g.readLore(s) }),
      });
    }
    // moon gates: wake them up, then travel between them
    for (const gt of w.gates) {
      this.addInteract({
        id: 'gate_' + gt.id, name: 'Holdkapu · ' + gt.name, pos: gt.front, radius: 3.2, kind: 'gate',
        verbFn: () => (this.P.gates.has(gt.id) ? 'Utazás' : 'Felébresztem'),
        talk: () => {
          if (!this.P.gates.has(gt.id)) return { name: 'Holdkapu', lines: ['A kapu köve hideg. Ahogy megérinted, a rúnák egymás után felragyognak.', 'A Holdkapu felébredt. Bármelyik felébresztett kapun át ide utazhatsz.'], after: () => g.activateGate(gt) };
          g.openTravel(gt);
          return { lines: [] };
        },
      });
    }
  }

  update(dt, time, player) {
    for (const n of this.list) n.update(dt, time, player);
    this.creatures.update(dt, time, player);
  }
}

function starGeometry(R, r, depth) {
  const g = new Geometry();
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * TAU + Math.PI / 2;
    const rr = i % 2 === 0 ? R : r;
    pts.push([Math.cos(a) * rr, Math.sin(a) * rr]);
  }
  for (const zs of [1, -1]) {
    const c = g.vert(0, 0, depth * zs, 0, 0, zs);
    const ids = pts.map((p) => g.vert(p[0], p[1], 0, 0, 0, zs));
    for (let i = 0; i < 10; i++) {
      if (zs > 0) g.tri(c, ids[i], ids[(i + 1) % 10]);
      else g.tri(c, ids[(i + 1) % 10], ids[i]);
    }
  }
  g.computeNormals();
  return g;
}
