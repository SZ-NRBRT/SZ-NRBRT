// The player: a small gnome wizard with a glowing staff. Movement, physics, abilities, procedural animation.
import { buildGnome } from '../models/characters.js';
import { buildCrown } from '../models/dragon.js';
import { mergeRig } from '../engine/rig.js';
import { C } from '../models/materials.js';
import { clamp, damp, lerp, angleDiff } from '../engine/math.js';

// (v7 tried a tiny gnome in a giant world; the original size and camera are back since v7.2)
export const PLAYER_SCALE = 1;
// the player gnome is as tall as the gnome villagers (it used to be 8% taller than any of them)
export const GNOME_SIZE = 0.96;
// (v7.1: everything 30% slower: a tiny gnome in a huge world takes its time)
// (v7.2.1: +15% on the v7.1 speeds)
const WALK = 2.0;
const RUN = 5.0;
const MOON_RUN = 7.25;
const SNEAK = 1.05;
const SWIM = 1.95;
const SWIM_FAST = 3.45;      // (the sea is deep and wide: a strong swimmer)
const JUMP = 6.2;
const GRAVITY = 21;
const STEP_UP = 0.6;           // the tower and castle stairs rise ~0.4 m per step
const HEIGHT = 1.25;           // collision body (the gnome is ~1.45 m with its hat)
const FLOAT = 0.5;             // swimming: the hips under the surface, chest and head above it
const SWIM_DEPTH = 0.95;       // (v8) you only swim where the water is deeper than your chest; shallower you wade
const LOOK = { staff: true, coat: '#2b44b8', hat: '#b01e2c', seed: 4 };
// the dream ends here: an invisible wall out at sea, a good way beyond the farthest landmark
export const WORLD_EDGE = 680;

export class Player {
  constructor(world, scene, trail) {
    this.world = world;
    this.scene = scene;
    this.trail = trail;
    const rig = buildGnome(world.ctx, LOOK);
    this.rig = rig;
    this.lookKey = LOOK.coat + LOOK.hat;
    this.root = rig.root;
    this.root.setScale(GNOME_SIZE * PLAYER_SCALE);
    scene.add(this.root);
    this.pos = [0, 0, 0];
    this.vel = [0, 0, 0];
    this.yaw = 0;
    this.visY = 0;
    this.onGround = true;
    this.phase = 0;
    this.speedNorm = 0;
    this.airTime = 0;
    this.landSquash = 0;
    this.hatTip = [0, 0, 0, 0];
    this.prevVel = [0, 0];
    this.idleTime = 0;
    this.lookYaw = 0;
    this.lookTarget = null;
    this.trailTimer = 0;
    this.stepSign = 1;
    this.onStep = null;
    this.onLand = null;
    this.onJump = null;
    this.onBounce = null;
    this.onDoubleJump = null;
    this.frozen = false;
    this.abilities = new Set();
    this.sneaking = false;
    this.gliding = false;
    this.airJumps = 0;
    this.groundSurface = null;
    this.lift = null;   // wind well the player is in (set by skylife each frame)
    this.carry = [0, 0];
    this.carryT = 0;
    this.mount = null;  // { seat, vel, yaw } while riding the ferry whale
    this.light = scene.addLight({ node: rig.bones.orb, color: C('#8fe6ff'), intensity: 1.0, radius: 6.5, priority: 100, flicker: 0.04 });
    this.radius = 0.32;
    this.swimming = false;
    this.slideSide = 1;
    this.splashT = 0;
  }

  // a new coat and hat (multiplayer): rebuild the gnome, keep everything else
  setLook(look) {
    const opts = look ? Object.assign({}, LOOK, { coat: look.coat, hat: look.hat, seed: look.seed ?? 4 }) : LOOK;
    const key = opts.coat + opts.hat;
    if (this.lookKey === key) return;
    this.lookKey = key;
    const old = this.root;
    const rig = buildGnome(this.world.ctx, opts);
    rig.root.setScale(GNOME_SIZE * PLAYER_SCALE);
    rig.root.dynamic = true;
    this.scene.add(rig.root);
    mergeRig(this.world.gl, rig.root);
    this.scene.remove(old);
    this.rig = rig;
    this.root = rig.root;
    this.light.node = rig.bones.orb;
    this.hatTip.fill(0);
    if (this.crownOn) { this.crownNode = null; this.wearCrown(true); }
    this.apply();
  }
  // (v8) the Seven-Headed Dragon's crown, worn on the hat once you have stolen it
  wearCrown(on) {
    if (this.crownNode && this.crownNode.parent) this.crownNode.parent.remove(this.crownNode);
    this.crownNode = null;
    this.crownOn = !!on;
    if (!on) return;
    const n = buildCrown(this.world.ctx, 1);
    n.setPos(0, 0.004, 0);
    n.traverse((m) => { if (m.geometry) m.maxDistance = 90; });
    this.rig.bones.hat.add(n);
    this.crownNode = n;
  }

  spawn(x, z, yaw, y = null) {
    const g = this.world.groundHeight(x, z, y !== null ? y + 0.5 : Infinity);
    this.pos = [x, y !== null ? Math.max(g, y) : g, z];
    this.visY = this.pos[1];
    this.vel = [0, 0, 0];
    this.yaw = yaw;
    this.onGround = true;
    this.apply();
  }

  update(dt, input, camYaw, time) {
    if (this.mount) { this.ride(dt, time); return; }
    const w = this.world;
    const P = w.physics;
    // standing on something that travels (the hill turtle): go along with it
    const mv = this.onGround && this.groundSurface && this.groundSurface.mover && this.groundSurface.delta;
    if (mv) {
      const s = this.groundSurface, c = Math.cos(mv[3]), sn = Math.sin(mv[3]);
      const rx = this.pos[0] - (s.x - mv[0]), rz = this.pos[2] - (s.z - mv[2]);
      this.pos[0] = s.x + rx * c + rz * sn; this.pos[2] = s.z - rx * sn + rz * c;
      this.pos[1] += mv[1];
      this.visY += mv[1];
      this.yaw += mv[3];
    }
    let [mx, my] = this.frozen ? [0, 0] : input.moveVector();
    this.sneaking = !this.frozen && input.sneaking();
    const run = input.running() && !this.sneaking;
    const fx = Math.sin(camYaw), fz = Math.cos(camYaw);
    const rx = -fz, rz = fx;
    let wx = fx * my + rx * mx, wz = fz * my + rz * mx;
    const wl = Math.hypot(wx, wz);
    const moving = wl > 0.05;
    const runSpeed = this.abilities.has('moonrun') ? MOON_RUN : RUN;
    const WL = w.L.waterLevel;
    const floatY = WL - FLOAT;
    const swim = this.swimming;
    const target = moving ? (swim ? (run ? SWIM_FAST : SWIM) : this.sneaking ? SNEAK : run ? runSpeed : WALK) * Math.min(1, wl) : 0;
    if (wl > 1e-3) { wx /= wl; wz /= wl; }
    const depth = WL - this.pos[1];
    const wading = !swim && this.onGround && depth > 0.04 && w.waterDepth(this.pos[0], this.pos[2]) > 0.04;
    const wade = wading ? clamp(1 - Math.max(0, depth - 0.2) * 1.2, 0.55, 1) : 1; // wading slows you down a little
    const accel = swim ? 6 : this.onGround ? (this.groundSurface && this.groundSurface.slide ? 10 : 18) : this.gliding ? 3 : 5;
    let tvx = wx * target * wade, tvz = wz * target * wade;
    // on a slide: whee
    const sl = this.onGround && this.groundSurface && this.groundSurface.slide;
    if (sl) { tvx = sl[0] * 7.5 + wx * 1.5; tvz = sl[1] * 7.5 + wz * 1.5; }
    // just left a wind well at its top: keep drifting towards the landing unless steered
    if (this.carryT > 0) {
      this.carryT = this.onGround ? 0 : this.carryT - dt;
      if (!moving) { tvx = this.carry[0]; tvz = this.carry[1]; }
    }
    this.vel[0] = damp(this.vel[0], tvx, accel * 0.5, dt);
    this.vel[2] = damp(this.vel[2], tvz, accel * 0.5, dt);

    // jump / double jump (from the water too: a kick that gets you up onto the bank)
    const jumpHit = !this.frozen && input.hit('Space');
    if (jumpHit && (this.onGround || swim)) {
      this.vel[1] = swim ? JUMP * 0.8 : JUMP;
      this.onGround = false;
      this.swimming = false;
      this.airJumps = 0;
      this.onJump && this.onJump();
    } else if (jumpHit && !this.onGround && this.abilities.has('doubleJump') && this.airJumps < 1 && this.airTime > 0.08) {
      this.vel[1] = JUMP * 0.95;
      this.airJumps++;
      this.onDoubleJump && this.onDoubleJump();
    }
    // glide: hold jump while falling
    this.gliding = !this.frozen && !this.onGround && !swim && this.abilities.has('glide') && input.down('Space') && this.vel[1] < 0 && this.airTime > 0.25;
    if (this.lift) {
      // wind well: carried up to its top, where it hovers and drifts you out over the landing
      const L = this.lift;
      this.gliding = false;
      this.swimming = false;
      const vyT = clamp((L.y1 - this.pos[1]) * 1.5, -1.2, 13.5);
      this.vel[1] = damp(this.vel[1], vyT, 3.0, dt);
      if (L.exit && this.pos[1] > L.y1 - 2.2) {
        const ex = L.exit[0] - this.pos[0], ez = L.exit[2] - this.pos[2], el = Math.hypot(ex, ez) || 1;
        this.vel[0] = damp(this.vel[0], (ex / el) * 5.5, 2.5, dt);
        this.vel[2] = damp(this.vel[2], (ez / el) * 5.5, 2.5, dt);
        this.carry = [(ex / el) * 5.5, (ez / el) * 5.5];
        this.carryT = 1.6;
      }
      this.onGround = false;
      this.airJumps = 0;
    } else if (swim) {
      // buoyancy: settle at the floating line, bob gently
      this.vel[1] = damp(this.vel[1], (floatY - this.pos[1]) * 5, 5, dt);
    } else {
      this.vel[1] -= GRAVITY * dt;
      if (this.gliding) this.vel[1] = Math.max(this.vel[1], -2.3);
    }

    // horizontal move against walls, steep ground and solid surfaces; slide along what you bump into
    const px = this.pos[0], pz = this.pos[2];
    const y0 = this.pos[1];
    const step = swim ? 1.1 : STEP_UP; // a swimmer can pull itself up a bank
    const tryMove = (x, z) => {
      if (P.blocked(x, z, y0, this.radius * 0.85, HEIGHT, step, px, pz)) return false;
      // steep terrain (only when walking on it)
      const tNow = w.h(px, pz), tNew = w.h(x, z);
      const d = Math.hypot(x - px, z - pz) || 1e-4;
      if (tNew - tNow > 0.05 && (tNew - tNow) / d > 1.7 && y0 < tNew - 0.3 && !(swim && tNew < y0 + step)) return false;
      return true;
    };
    const mdx = this.vel[0] * dt, mdz = this.vel[2] * dt;
    let nx = px + mdx, nz = pz + mdz;
    if ((mdx || mdz) && !tryMove(nx, nz)) {
      // turn the step a little at a time (towards the side that worked last) until it fits:
      // walking into a trunk or a wall glides you around it instead of stopping dead
      let ok = false;
      for (const ang of [0.3, 0.6, 0.9, 1.2, 1.45, 1.5708]) {
        for (const sd of [this.slideSide, -this.slideSide]) {
          const c = Math.cos(ang * sd), sn = Math.sin(ang * sd), k = Math.max(0.45, Math.cos(ang) * 0.95);
          const tx = px + (mdx * c - mdz * sn) * k, tz = pz + (mdx * sn + mdz * c) * k;
          if (tryMove(tx, tz)) { nx = tx; nz = tz; ok = true; this.slideSide = sd; break; }
        }
        if (ok) break;
      }
      if (!ok) { nx = px; nz = pz; }
    }
    [nx, nz] = P.resolve(nx, nz, this.radius, y0, HEIGHT);
    if (P.blocked(nx, nz, y0, this.radius * 0.85, HEIGHT, step, px, pz)) { nx = px; nz = pz; }
    this.vel[0] = (nx - px) / Math.max(dt, 1e-4) * 0.2 + this.vel[0] * 0.8;
    this.vel[2] = (nz - pz) / Math.max(dt, 1e-4) * 0.2 + this.vel[2] * 0.8;
    // the edge of the dream: an invisible wall far out at sea
    const er = Math.hypot(nx, nz);
    if (er > WORLD_EDGE) {
      nx *= WORLD_EDGE / er; nz *= WORLD_EDGE / er;
      const ux = nx / WORLD_EDGE, uz = nz / WORLD_EDGE, vr = this.vel[0] * ux + this.vel[2] * uz;
      if (vr > 0) { this.vel[0] -= vr * ux; this.vel[2] -= vr * uz; }
      this.onEdge && this.onEdge();
    }
    this.pos[0] = nx;
    this.pos[2] = nz;

    // vertical: ceilings, ground, bounce, water
    let ny = this.pos[1] + this.vel[1] * dt;
    if (this.vel[1] > 0) {
      const ceil = P.ceiling(nx, nz, this.pos[1] + HEIGHT - 0.05);
      if (ceil !== null && ny + HEIGHT > ceil) { ny = Math.max(this.pos[1], ceil - HEIGHT); this.vel[1] = Math.min(0, this.vel[1]); }
    }
    const g = P.ground(nx, nz, this.pos[1], step);
    const surf = P.lastGroundSurface;
    const wasGround = this.onGround;
    const deepHere = WL - g > SWIM_DEPTH;
    if (deepHere && ny <= floatY + 0.02 && !this.lift) {
      // in deep water: float instead of sinking to the bed
      if (!swim) {
        if (this.vel[1] < -3 || this.airTime > 0.3) this.onSplash && this.onSplash(Math.min(1, -this.vel[1] / 12));
        this.vel[1] = Math.max(this.vel[1], -1.5) * 0.3;
      }
      this.swimming = true;
      this.onGround = false;
      this.airJumps = 0;
      if (ny < g) ny = g;
    } else if (ny <= g + 0.001) {
      this.swimming = false;
      if (surf && surf.bounce && this.vel[1] <= 0.5) {
        // bounce mushroom: launch! (jump held -> a bit higher)
        ny = g;
        this.vel[1] = surf.bounce + (input.down('Space') ? 1.2 : 0);
        this.onGround = false;
        this.airJumps = 0;
        this.airTime = 0.01;
        this.onBounce && this.onBounce(surf);
      } else {
        if (!wasGround && this.airTime > 0.25) {
          this.landSquash = Math.min(1, this.airTime * 1.2);
          this.onLand && this.onLand(this.airTime);
        }
        ny = g;
        this.vel[1] = 0;
        this.onGround = true;
        this.airJumps = 0;
      }
    } else if (wasGround && this.vel[1] <= 0 && ny - g < 0.45 && !deepHere) {
      ny = g;
      this.vel[1] = 0;
      this.onGround = true;
    } else {
      if (!deepHere || ny > floatY + 0.3) this.swimming = false;
      this.onGround = false;
    }
    this.groundSurface = this.onGround ? surf : null;
    // never fall below the terrain (safety)
    const th = w.h(nx, nz);
    if (ny < th - 0.5) { ny = th; this.vel[1] = 0; this.onGround = true; }
    this.pos[1] = ny;
    this.airTime = this.onGround || this.swimming ? 0 : this.airTime + dt;
    // visual height: smooth step-ups so stairs don't jitter; bob while swimming
    const dy = this.pos[1] - this.visY;
    if (this.swimming) this.visY = damp(this.visY, this.pos[1] + Math.sin(time * 2.6) * 0.04, 10, dt);
    else if (this.onGround && dy > 0 && dy < 1.0) this.visY = damp(this.visY, this.pos[1], 22, dt);
    else this.visY = this.pos[1];
    // ripples around a swimmer (and a wader)
    this.splashT -= dt;
    if ((this.swimming || wading) && this.trail && this.splashT <= 0) {
      const hsp = Math.hypot(this.vel[0], this.vel[2]);
      this.splashT = hsp > 0.5 ? 0.09 : 0.45;
      const a = Math.random() * Math.PI * 2, r = 0.3 + Math.random() * 0.2;
      this.trail.emit([this.pos[0] + Math.cos(a) * r, WL + 0.02, this.pos[2] + Math.sin(a) * r], time, { size: 0.045 + Math.random() * 0.035, life: 0.8, rise: 0.02, spread: 0.2, color: [0.5, 0.85, 1.4], intensity: 0.7 });
    }

    // facing
    const hs = Math.hypot(this.vel[0], this.vel[2]);
    if (hs > 0.3 && moving) {
      const ty = Math.atan2(this.vel[0], this.vel[2]);
      this.yaw += angleDiff(this.yaw, ty) * (1 - Math.exp(-12 * dt));
    }
    this.speedNorm = damp(this.speedNorm, clamp(hs / RUN, 0, 1), 10, dt);
    this.idleTime = hs < 0.2 ? this.idleTime + dt : 0;

    this.animate(dt, time, hs);
    this.apply();

    // staff trail
    this.trailTimer -= dt;
    if (this.trail && this.trailTimer <= 0) {
      const o = this.rig.bones.orb.worldPosition();
      const moon = this.abilities.has('moonrun') && hs > RUN * 0.9;
      this.trail.emit(o, time, { size: 0.045 + Math.random() * 0.03, life: 1.1, rise: 0.15, spread: 0.14, color: moon ? [0.75, 0.85, 1.9] : undefined, intensity: 1.3 });
      this.trailTimer = this.gliding ? 0.02 : hs > 1 ? 0.035 : 0.22;
    }
  }

  // sitting in the ferry whale's saddle: the whale moves us
  ride(dt, time) {
    const m = this.mount;
    this.pos[0] = m.seat[0]; this.pos[1] = m.seat[1]; this.pos[2] = m.seat[2];
    this.visY = this.pos[1];
    this.vel[0] = m.vel[0]; this.vel[1] = m.vel[1]; this.vel[2] = m.vel[2];
    this.yaw += angleDiff(this.yaw, m.yaw) * (1 - Math.exp(-4 * dt));
    this.onGround = true;
    this.gliding = false;
    this.sneaking = false;
    this.lift = null;
    this.airTime = 0;
    this.speedNorm = 0;
    this.idleTime = 0;
    this.animate(dt, time, 0);
    this.apply();
  }

  animate(dt, time, hs) {
    const b = this.rig.bones;
    const sf = clamp(hs / RUN, 0, 1);
    const walkF = clamp(hs / WALK, 0, 1);
    // short legs: quicker steps for the same speed
    if (this.onGround || this.swimming) this.phase += dt * (hs * (this.swimming ? 2.2 : 2.9) + (hs > 0.2 ? 1.5 : 0) + (this.swimming ? 2.2 : 0));
    const ph = this.phase;
    const s = Math.sin(ph);
    const sign = Math.sign(s);
    if (sign !== this.stepSign && hs > 0.8 && (this.onGround || this.swimming)) {
      this.stepSign = sign;
      this.onStep && this.onStep(hs);
    }
    const amp = 0.55 * walkF + 0.35 * sf;
    let legL = s * amp, legR = -s * amp;
    let armL = -s * (0.5 * walkF + 0.4 * sf);
    let armR = s * 0.25 * walkF - 0.35 - 0.2 * sf;
    let lean = 0.06 * walkF + 0.2 * sf;
    let bob = Math.abs(Math.cos(ph)) * (0.025 * walkF + 0.04 * sf);
    let crouch = 0;
    if (this.sneaking && this.onGround) { crouch = 0.08; lean += 0.25; armL = -0.6 - s * 0.2; armR = -0.7; }
    if (this.mount) { legL = -1.45; legR = -1.35; armL = -0.35; armR = -0.55; lean = -0.05; bob = 0; crouch = 0.28; }
    else if (this.swimming) {
      // doggy paddle: arms stroke in turn, legs kick, body leans into the water
      const st = Math.sin(ph), ct = Math.cos(ph);
      armL = -2.2 + st * 1.1; armR = -2.2 - st * 1.1;
      legL = 0.35 + ct * 0.4; legR = 0.35 - ct * 0.4;
      lean = 0.32 + Math.min(0.25, hs * 0.1); bob = 0; crouch = 0;
    }
    else if (!this.onGround) {
      if (this.gliding) { legL = 0.2; legR = 0.35; armL = -2.8; armR = -2.6; lean = 0.25; bob = 0; }
      else { legL = -0.5; legR = 0.4; armL = -1.2; armR = -0.9; lean = -0.05; bob = 0.02; }
    }
    const breathe = Math.sin(time * 2.2) * 0.012;
    b.legL.setEuler(legL, 0, 0);
    b.legR.setEuler(legR, 0, 0);
    b.armL.setEuler(armL, 0, 0.12 + (this.onGround || this.swimming ? 0 : 0.3));
    b.armR.setEuler(armR, 0, -0.12);
    this.landSquash = Math.max(0, this.landSquash - dt * 4);
    const squash = this.landSquash * 0.18;
    b.hips.position[1] = 0.3 + bob - squash * 0.3 - crouch;
    b.torso.setEuler(lean + breathe * 0.5, Math.sin(ph) * 0.08 * walkF, 0);
    b.torso.scale[1] = 1 + breathe - squash;
    let targetLook = 0;
    if (this.lookTarget) {
      const dx = this.lookTarget[0] - this.pos[0], dz = this.lookTarget[2] - this.pos[2];
      targetLook = clamp(angleDiff(this.yaw, Math.atan2(dx, dz)), -0.9, 0.9);
    } else if (this.idleTime > 3) {
      targetLook = Math.sin(time * 0.45) * 0.6 * Math.min(1, (this.idleTime - 3) / 2);
    }
    this.lookYaw = damp(this.lookYaw, targetLook, 5, dt);
    b.head.setEuler(-lean * 0.5 + Math.sin(ph * 2) * 0.03 * walkF, this.lookYaw, Math.sin(ph) * 0.04 * walkF);
    const ax = (this.vel[0] - this.prevVel[0]) / Math.max(dt, 1e-3);
    const az = (this.vel[2] - this.prevVel[1]) / Math.max(dt, 1e-3);
    this.prevVel = [this.vel[0], this.vel[2]];
    const cy = Math.cos(this.yaw), sy = Math.sin(this.yaw);
    const aFwd = ax * sy + az * cy;
    const aSide = ax * cy - az * sy;
    const h = this.hatTip;
    const k = 60, dmp = 7;
    h[1] += (-h[0] * k - h[1] * dmp - aFwd * 0.05 + Math.cos(ph * 2) * 2.0 * walkF - clamp(this.vel[1], -12, 12) * 0.3) * dt;
    h[0] += h[1] * dt;
    h[3] += (-h[2] * k - h[3] * dmp + aSide * 0.05) * dt;
    h[2] += h[3] * dt;
    h[0] = clamp(h[0], -0.8, 0.8);
    h[2] = clamp(h[2], -0.8, 0.8);
    if (!Number.isFinite(h[0] + h[1] + h[2] + h[3])) h.fill(0);
    b.hatTip.setEuler(h[0] - 0.1 * sf, 0, h[2]);
    b.beard.setEuler(clamp(-aFwd * 0.004, -0.2, 0.2) + Math.sin(ph * 2) * 0.03 * walkF, 0, 0);
  }

  apply() {
    this.root.setPos(this.pos[0], this.visY, this.pos[2]);
    this.root.setRotY(this.yaw);
  }

  headPos() {
    return [this.pos[0], this.visY + 0.97 * GNOME_SIZE * PLAYER_SCALE, this.pos[2]];
  }
}
