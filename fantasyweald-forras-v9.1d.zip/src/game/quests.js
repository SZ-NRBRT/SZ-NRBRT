// Player progress (everything that is saved) and the quest book: objectives, tracker lines, journal.
import { ABILITIES } from '../data/dialogue.js';
import { SPECIES } from './creatures.js';
import { T } from '../i18n.js';

export const QUESTS = {
  main: { title: 'A csillagkulcs', main: true, desc: 'Kőmarok kapuja évek óta zárva. Csak a három darabra tört Csillagkulcs nyithatja ki.' },
  lens: { title: 'A csillagász lencséje', desc: 'Csillagász Cirill elhagyta a lencséjét, és nélküle semmit sem talál.' },
  snail: { title: 'Pöttöm csigája', desc: 'Fénylő Fülöp, Pöttöm világító csigája elszökött.' },
  flower: { title: 'Holdvirág', desc: 'Horgász Huba szerint a csillagok nem tudnak ellenállni a holdvirágnak.' },
  stag: { title: 'A Holdszarvas', desc: 'Egy fénylő agancsú szarvas legel a tisztásokon. Csak a csendes vándort engedi közel magához.' },
  lore: { title: 'Az emlékező kövek', desc: 'Rúnakövek szerte az erdőben. Valaki nagyon szeretné, hogy elolvasd őket.' },
  sheep: { title: 'Felhőbárányok', desc: 'Pihe, a felhőpásztor három báránya leszökött a felhők közül az erdőbe.' },
  whale: { title: 'Az égi komp', desc: 'Pihe megtanította, hogyan hívd a bálnát: a felhőharanggal a móló mellett.' },
  deep: { title: 'A Mélység Lámpása', desc: 'Horgász Huba szerint a tengerben él valami, ami akkora, mint egy sziget. Még senki sem látta egészben.' },
};

export const EXTRA_ABILITIES = {
  moonrun: { name: 'Holdléptek', text: 'Futás közben (Shift) sokkal gyorsabb vagy.', lockText: 'A Holdszarvas áldása adja.' },
  starsight: { name: 'Csillagszem', text: 'Az iránytű mutatja a közeli csillagszilánkokat.', lockText: 'Aki minden rúnakövet elolvas, megkaphatja.' },
};

export class Progress {
  // (the save lives in the browser and anybody can edit it: whatever is in there, never crash on it)
  constructor(s = {}) {
    if (!s || typeof s !== 'object') s = {};
    const strs = (a) => new Set(Array.isArray(a) ? a.filter((v) => typeof v === 'string' && v.length < 64).slice(0, 500) : []);
    this.stage = { main: 0, lens: 0, snail: 0, flower: 0, stag: 0, lore: 0, sheep: 0, whale: 0, deep: 0 };
    const st = s.stage && typeof s.stage === 'object' ? s.stage : {};
    for (const k in this.stage) if (Number.isInteger(st[k])) this.stage[k] = Math.max(0, Math.min(k === 'main' ? 5 : 3, st[k]));
    this.items = strs(s.items);
    this.flags = strs(s.flags);
    this.shards = strs(s.shards);
    this.lore = strs(s.lore);
    this.curios = strs(s.curios);
    this.gates = strs(s.gates);
    this.discovered = strs(s.discovered);
    this.creatures = strs(s.creatures); // bestiary
    this.order = Array.isArray(s.order) ? s.order.filter((k) => typeof k === 'string' && k in this.stage) : []; // side quests in the order they were started
  }
  toJSON() {
    return {
      stage: this.stage, items: [...this.items], flags: [...this.flags], shards: [...this.shards], lore: [...this.lore],
      curios: [...this.curios], gates: [...this.gates], discovered: [...this.discovered], order: this.order, creatures: [...this.creatures],
    };
  }
  done(id) {
    return this.stage[id] >= (id === 'main' ? 5 : 2);
  }
}

const ITEM_NAMES = { keyA: 'Kulcsdarab (magasban)', keyB: 'Kulcsdarab (mélyben)', keyC: 'Kulcsdarab (tudásban)', starKey: 'Csillagkulcs', lens: 'Csillaglencse', moonflower: 'Holdvirág', snail: 'Fénylő Fülöp', crown: 'A Hétfejű koronája' };

// current objectives: [{ id, quest, main, text, detail, pos }]
export function objectives(game) {
  const P = game.P, W = game.world, N = game.npcs, S = W.L.sites;
  const out = [];
  const st = P.stage.main;
  const has = (k) => P.items.has(k);
  const q = QUESTS.main;
  if (st === 0) out.push({ id: 'main', quest: q.title, main: true, text: 'Beszélj Vén Barnabással a tisztáson.', pos: N.wizardPos });
  else if (st === 1) {
    const n = ['keyA', 'keyB', 'keyC'].filter(has).length;
    if (n >= 3) out.push({ id: 'main', quest: q.title, main: true, text: 'Vidd vissza a darabokat Barnabásnak.', detail: T('Kulcsdarabok: {0} / 3', 3), pos: N.wizardPos });
    else {
      const next = !P.flags.has('gotKeyA') ? { t: 'A magasban: a lebegő szigetek csúcsán.', p: W.anchors.islandShrine }
        : !P.flags.has('gotKeyB') ? { t: 'A mélyben: a hullócsillag kráterében.', p: W.anchors.starHeart }
        : { t: 'A tudásban: a csillagász tornyában.', p: W.anchors.towerTop };
      const pos = [];
      if (!P.flags.has('gotKeyA')) pos.push(W.anchors.islandShrine);
      if (!P.flags.has('gotKeyB')) pos.push(W.anchors.starHeart);
      if (!has('keyC') && P.stage.lens < 2) pos.push(W.anchors.towerTop);
      out.push({ id: 'main', quest: q.title, main: true, text: 'Keresd meg a Csillagkulcs darabjait.', detail: T('Kulcsdarabok: {0} / 3', n) + ' · ' + T(next.t), pos: pos[0] || next.p, all: pos });
    }
  } else if (st === 3) out.push({ id: 'main', quest: q.title, main: true, text: 'Nyisd ki Kőmarok kapuját a Csillagkulccsal.', pos: W.gate.world.tp([0, 0, 2.4]) });
  else if (st === 4) out.push({ id: 'main', quest: q.title, main: true, text: 'Menj fel a fénylépcsőn a várba.', pos: W.anchors.castleDoor });
  // side quests, most recent first
  const side = [];
  const add = (id, text, pos, detail) => side.push({ id, quest: QUESTS[id].title, text, pos, detail });
  if (P.stage.lens === 1) has('lens') ? add('lens', 'Vidd vissza a lencsét a csillagásznak.', W.anchors.towerTop) : add('lens', 'Keresd meg a lencsét a Kristálymezőn.', W.anchors.lensSpot);
  if (P.stage.snail === 1) has('snail') ? add('snail', 'Vidd vissza Fülöpöt Pöttömnek.', N.pottom && N.pottom.pos) : add('snail', 'Keresd meg Fénylő Fülöpöt egy kis tó partján.', W.anchors.snailSpot);
  if (P.stage.flower === 1) has('moonflower') ? add('flower', 'Vidd el a holdvirágot Horgász Hubának.', [W.anchors.log.x, W.anchors.log.y, W.anchors.log.z]) : add('flower', 'Szedd le a holdvirágot a vízesés tetején.', W.anchors.moonflower);
  if (P.stage.stag === 1) add('stag', 'Közelítsd meg lopakodva a Holdszarvast (C), és érintsd meg.', N.stag ? [N.stag.x, 0, N.stag.z] : null);
  if (P.stage.lore === 1) {
    const total = W.loreSpots.length, read = P.lore.size;
    if (read >= total) add('lore', 'Keresd fel a csuklyásokat a Kék Láng körében.', W.anchors.rune ? [W.anchors.rune.x, W.anchors.rune.y, W.anchors.rune.z] : null);
    else add('lore', 'Olvasd el az erdő rúnaköveit.', null, T('Rúnakövek: {0} / {1}', read, total));
  }
  const sky = game.sky;
  if (P.stage.sheep === 1 && sky) {
    const left = sky.sheep.filter((s) => !P.flags.has(s.flag));
    const n = 3 - left.length;
    if (!left.length) add('sheep', 'Keresd fel Pihét a Felhőkikötőben.', sky.shepherd.pos);
    else add('sheep', 'Keresd meg és simogasd meg a szökött felhőbárányokat.', left[0].pos, T('Bárányok: {0} / 3 · {1}', n, left.map((s) => T(s.where)).join(', ')));
  }
  if (P.stage.whale === 1 && sky && W.sky.bells && W.sky.bells.harbour) add('whale', 'Kongasd meg a felhőharangot, és utazz a bálnával a Felhőkertbe.', W.sky.bells.harbour.base);
  if (P.stage.deep === 1) {
    // (v9.1) the objective marker follows the beast itself, live
    const lev = N.creatures && N.creatures.leviathan;
    if (P.flags.has('levSeen')) add('deep', 'Meséld el Horgász Hubának, mit láttál.', [W.anchors.log.x, W.anchors.log.y, W.anchors.log.z]);
    else add('deep', 'Figyeld a tengert a partról, amíg a Mélység Lámpása kiemelkedik.', lev ? [lev.h.x, W.L.waterLevel, lev.h.z] : null, 'A partról biztonságos nézni. A nyílt vízen ne úszkálj!');
  }
  side.sort((a, b) => P.order.indexOf(b.id) - P.order.indexOf(a.id));
  return out.concat(side);
}

export function journalData(game) {
  const P = game.P, W = game.world;
  const quests = [];
  const obj = objectives(game);
  const steps = (id) => obj.filter((o) => o.id === id).map((o) => ({ text: T(o.text) + (o.detail ? ` (${T(o.detail)})` : ''), ok: false }));
  // main quest
  {
    const st = P.stage.main;
    const s = [];
    s.push({ text: 'Beszélj Vén Barnabással.', ok: st >= 1 });
    if (st >= 1) {
      s.push({ text: 'Kulcsdarab a magasban (lebegő szigetek)', ok: P.flags.has('gotKeyA') });
      s.push({ text: 'Kulcsdarab a mélyben (hullócsillag-kráter)', ok: P.flags.has('gotKeyB') });
      s.push({ text: 'Kulcsdarab a tudásban (csillagász tornya)', ok: P.items.has('keyC') || st >= 3 });
      s.push({ text: 'A Csillagkulcs összekovácsolása', ok: st >= 3 });
    }
    if (st >= 3) s.push({ text: 'Kőmarok kapujának kinyitása', ok: st >= 4 });
    if (st >= 4) s.push({ text: 'Fel a várba, a Holdkirálynőhöz', ok: st >= 5 });
    quests.push({ title: QUESTS.main.title, main: true, desc: QUESTS.main.desc, steps: s, done: st >= 5 });
  }
  for (const id of ['lens', 'snail', 'flower', 'stag', 'lore', 'sheep', 'whale', 'deep']) {
    const st = P.stage[id];
    if (st === 0) continue;
    quests.push({ title: QUESTS[id].title, desc: QUESTS[id].desc, steps: st >= 2 ? [] : steps(id), done: st >= 2 });
  }
  quests.sort((a, b) => (a.done - b.done) || (b.main - a.main));
  const places = W.regions.map((r) => ({ name: r.name, blurb: r.blurb, known: P.discovered.has(r.id), hidden: r.hidden }));
  const abil = ABILITIES.map((a) => ({ name: a.name, has: game.player.abilities.has(a.id), text: a.text, lockText: T('{0} csillagszilánknál nyílik meg.', a.need) }));
  for (const id in EXTRA_ABILITIES) abil.push({ ...EXTRA_ABILITIES[id], has: game.player.abilities.has(id) });
  const collection = {
    shards: P.shards.size, shardTotal: game.shardTotal,
    lore: P.lore.size, loreTotal: W.loreSpots.length,
    curios: P.curios.size, curioTotal: W.curiosities.length,
    gates: P.gates.size, gateTotal: W.gates.length,
    abilities: abil,
    items: [...P.items].map((k) => ITEM_NAMES[k] || k),
    curioNames: W.curiosities.filter((c) => P.curios.has(c.id)).map((c) => ({ name: c.name, blurb: c.blurb })),
    loreTexts: W.loreSpots.filter((s) => P.lore.has(s.id)).map((s) => s.text),
    creatures: SPECIES.filter((s) => P.creatures.has(s.id)).map((s) => ({ name: s.name, blurb: s.blurb })),
    creatureTotal: SPECIES.length,
  };
  return { quests, places, collection };
}
