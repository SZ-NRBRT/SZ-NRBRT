// (v8) Ash Isle, the realm of the Seven-Headed Dragon (Hétfejű). The dragon sleeps coiled around its hoard,
// seven heads resting on the warm ash. Noise stirs it: a running gnome wakes it fast, a walking one slowly,
// a sneaking one hardly at all. When a head lifts to sniff the air, freeze. Its servants, the ember imps
// (Parázsmanók), patrol the island; if one of them spots you it shrieks, the dragon wakes, and the imps
// come for you with their little pitchforks. Awake, the heads rise, track you and take turns breathing
// fire; hide behind the obsidian or get off the island. Caught, you are thrown back into the sea.
// On top of the hoard lies the dragon's crown. Take it and make it to the water, and it is yours.
import { buildDragon, buildImp, buildCrown, NECKS, NECK_SEGS, SEG_LEN } from '../models/dragon.js';
import { FireEmitter } from '../world/fx.js';
import { RNG, clamp, damp, angleDiff, TAU, lerp, smoothstep } from '../engine/math.js';
import { C } from '../models/materials.js';
import { T } from '../i18n.js';

const hyp = (x, z) => Math.sqrt(x * x + z * z);
const SPEED = 24;          // fire: how fast the flames fly (m/s)
const RANGE = 23;          // ...and how far they reach
const IMP_WALK = 1.5;
const IMP_CHASE = 3.9;     // the gnome walks at 2.3 and runs at 5.75: running gets you away
const IMP_SEE = 12;
const IMP_SEE_SNEAK = 5;
const SLEEP_P = [0.62, -0.26, -0.2, -0.12, -0.04, 0, 0];      // relative pitch of each neck segment, asleep
const AWAKE_P = [-0.95, -0.25, 0.1, 0.25, 0.3, 0.3, 0.25];    // ...and raised, the heads high above the hoard

export class Realm {
  constructor(cr) {
    this.cr = cr;
    this.game = cr.game;
    this.world = cr.world;
    this.scene = cr.scene;
    const I = (this.isle = this.world.ashIsle);
    if (!I) return;
    this.rng = new RNG(4242);
    this.state = 'sleep';
    this.alert = 0;
    this.t = 0;
    this.lost = 0;
    this.nextBreath = 2;
    this.snore = 3;
    this.carrying = false;
    this.exposure = 0;
    this.stirred = [];
    this.fire = new FireEmitter(cr.ctx.gl, 900);
    this.scene.add(this.fire.mesh);
    this.buildDragon();
    this.buildImps();
    this.buildCrown();
    cr.list.push({ update: (dt, t, player) => this.update(dt, t, player) });
    cr.watch.push({ id: 'dragon', range: 55, points: () => [[I.lair[0], I.lairY, I.lair[1]]] });
    cr.watch.push({ id: 'imp', range: 16, points: () => this.imps.map((m) => [m.x, m.y, m.z]) });
  }

  // ---------------------------------------------------------------- the dragon
  buildDragon() {
    const I = this.isle, P = this.world.physics;
    const rig = buildDragon(this.cr.ctx);
    this.rig = rig;
    rig.root.traverse((n) => { if (n.geometry) { n.maxDistance = 480; n.shadowDistance = 90; } });
    const rootY = I.lairY - 0.35;
    rig.root.setPos(I.lair[0], rootY, I.lair[1]);
    rig.root.setRotY(I.face);
    this.scene.add(rig.root);
    rig.root.traverse((n) => { if (n.name === 'dragonBody') this.bodyMesh = n; });
    this.rootY = rootY;
    const cf = Math.cos(I.face), sf = Math.sin(I.face);
    this.toW = (lx, lz) => [I.lair[0] + lx * cf + lz * sf, I.lair[1] - lx * sf + lz * cf];
    // colliders: the body, the curled tail (you can't walk through a dragon)
    for (const lz of [-9, -5.5, -2, 1.5]) P.addCircle(...this.toW(0, lz), 4.3, { yMin: rootY - 1, yMax: rootY + 6.5 });
    const tail = [[0, -10.6], [2.5, -15], [7.5, -17.5], [12.5, -15], [15, -9.5], [14.5, -3.5], [12, 0.5]];
    tail.forEach(([lx, lz], i) => {
      const r = 1.9 * (1 - i / 6) + 0.35;
      P.addCircle(...this.toW(lx, lz), r, { yMin: rootY - 1, yMax: rootY + 0.6 + r * 1.6 });
    });
    // a quiet red glow from inside its mouths when awake, and a light that follows the fire
    this.mouthLight = this.scene.addLight({ color: C('#ff7a2a'), intensity: 0, radius: 22, flicker: 0.35, priority: 6, enabled: false, position: [0, 0, 0] });
    this.eyeLight = this.scene.addLight({ color: C('#ffae3a'), intensity: 0, radius: 18, flicker: 0.1, priority: 5, enabled: false, position: [I.lair[0], rootY + 9, I.lair[1]] });
    // the necks: current and target angles for every joint, eased between poses
    this.necks = rig.bones.necks.map((n, i) => {
      const cur = { psi: 0, p: SLEEP_P.slice(), s: new Array(NECK_SEGS).fill(0), h: 0, hy: 0, jaw: 0 };
      // asleep the necks fan out in front and to the left (the right flank, where the hoard is, stays open)
      const sleepFan = lerp(-1.55, 0.85, i / (NECKS - 1));
      const vary = { rise: [0.1, -0.12, 0.18, -0.05, 0.2, -0.15, 0.06][i], lean: [0.12, -0.06, 0.2, 0, -0.1, 0.16, -0.14][i] };
      return { ...n, i, head: rig.bones.heads[i], jaw: rig.bones.jaws[i], cur, tgt: JSON.parse(JSON.stringify(cur)), breath: null, look: 0, curl: (i % 2 ? 1 : -1) * (0.6 + (i % 3) * 0.2), eyes: null, sleepFan, vary, cols: [] };
    });
    for (const nk of this.necks) nk.eyes = nk.head.children.filter((n) => n.name === 'dragonEye');
    // asleep, each head must rest on the ground: solve the first bend so that it does
    this.bodyY = 2.7;
    for (const nk of this.necks) {
      nk.sleepA = this.solveSleep(nk);
      this.sleepPose(nk, nk.cur, 0);
      Object.assign(nk.tgt, JSON.parse(JSON.stringify(nk.cur)));
      this.applyNeck(nk);
    }
    // the sleeping necks lie across the ash: you have to go round them (their colliders switch off when they rise)
    rig.root.updateWorld(null, true);
    for (const nk of this.necks) {
      for (let k = 2; k < NECK_SEGS; k++) {
        const m = nk.segs[k].world;
        const s = Math.hypot(m[8], m[9], m[10]) || 1;
        const x = m[12] + (m[8] / s) * SEG_LEN * 0.5, y = m[13] + (m[9] / s) * SEG_LEN * 0.5, z = m[14] + (m[10] / s) * SEG_LEN * 0.5;
        const r = lerp(1.05, 0.5, (k + 0.5) / NECK_SEGS) * nk.big;
        const c = P.addCircle(x, z, r * 0.95, { yMin: y - r - 1, yMax: y + r * 0.9 });
        c.sleepMax = c.yMax;
        nk.cols.push(c);
      }
      const hp = nk.head.worldPosition();
      const c = P.addCircle(hp[0], hp[2], 0.9 * nk.big, { yMin: hp[1] - 2, yMax: hp[1] + 0.6 });
      c.sleepMax = c.yMax;
      nk.cols.push(c);
    }
    this.neckSolid = true;
  }
  setNeckColliders(on) {
    if (this.neckSolid === on) return;
    this.neckSolid = on;
    for (const nk of this.necks) for (const c of nk.cols) c.yMax = on ? c.sleepMax : -1e9;
  }
  // base of a neck in world space (x, y, z) and its heading
  neckBase(nk) {
    const b = nk.base.position;
    const lx = b[0], ly = b[1] + this.bodyY, lz = b[2] - 2;
    const [wx, wz] = this.toW(lx, lz);
    return [wx, this.rootY + ly, wz];
  }
  // planar forward kinematics of a neck: where the head ends up (distance ahead, height) for these pitches
  fk(p, scaleFirst = 1) {
    let A = 0, u = 0, v = 0;
    for (let k = 0; k < NECK_SEGS; k++) {
      A += p[k] * (k === 0 ? scaleFirst : 1);
      u += Math.cos(A) * SEG_LEN;
      v -= Math.sin(A) * SEG_LEN;
    }
    return { u, v, A };
  }
  solveSleep(nk) {
    const I = this.isle;
    const base = this.neckBase(nk);
    const yaw = I.face + nk.sleepFan;
    let lo = 0.2, hi = 2.6;
    for (let it = 0; it < 18; it++) {
      const k = (lo + hi) / 2;
      const f = this.fk(SLEEP_P, k);
      const hx = base[0] + Math.sin(yaw) * f.u, hz = base[2] + Math.cos(yaw) * f.u;
      const want = I.ground(hx, hz) + 0.62 * nk.big;
      if (base[1] + f.v > want) lo = k; else hi = k;
    }
    return (lo + hi) / 2;
  }
  sleepPose(nk, o, t) {
    const breath = Math.sin(t * 0.55 + nk.i * 0.9);
    for (let k = 0; k < NECK_SEGS; k++) {
      o.p[k] = SLEEP_P[k] * (k === 0 ? nk.sleepA : 1) + (k === 1 ? breath * 0.015 : 0);
      o.s[k] = nk.curl * 0.12 * Math.sin(k * 0.9 + nk.i);
    }
    o.psi = nk.sleepFan - nk.fan;
    const A = this.fk(o.p).A;
    o.h = -A + 0.06 + breath * 0.02;
    o.hy = nk.curl * 0.15;
    o.jaw = 0.02;
  }
  awakePose(nk, o, t, target, rise = 1) {
    const I = this.isle;
    for (let k = 0; k < NECK_SEGS; k++) {
      o.p[k] = lerp(SLEEP_P[k] * (k === 0 ? nk.sleepA : 1), AWAKE_P[k] * (k === 0 ? 1 + (nk.big - 1) * 0.5 : 1), rise);
      o.s[k] = Math.sin(t * 0.9 + nk.i * 1.7 + k * 0.6) * 0.05 * rise;
    }
    // every neck its own way: some high, some low and leaning in, like a nest of snakes
    const v = nk.vary;
    o.p[0] += v.rise * rise;
    o.p[2] += v.lean * rise;
    o.p[4] -= v.lean * 0.6 * rise;
    const base = this.neckBase(nk);
    const f = this.fk(o.p);
    // the heads spread out like a hand, and all of them turn towards you
    let yawRel = nk.fan * 1.5 + Math.sin(t * 0.4 + nk.i * 2.1) * 0.2;
    let h = -f.A + 0.25, hy = 0;
    if (target) {
      const aim = clamp(angleDiff(0, Math.atan2(target[0] - base[0], target[2] - base[2]) - I.face), -1.5, 1.5);
      yawRel = lerp(nk.fan * 1.5, aim, 0.38) + Math.sin(t * 0.5 + nk.i * 2.1) * 0.08;
      const hx = base[0] + Math.sin(I.face + yawRel) * f.u, hz = base[2] + Math.cos(I.face + yawRel) * f.u;
      const dx = target[0] - hx, dz = target[2] - hz;
      hy = clamp(angleDiff(yawRel, Math.atan2(dx, dz) - I.face), -0.9, 0.9);
      h = Math.atan2(base[1] + f.v - target[1], Math.max(1.5, hyp(dx, dz))) - f.A;
    }
    o.psi = yawRel - nk.fan;
    o.h = clamp(h, -0.9, 1.3);
    o.hy = hy;
    o.jaw = 0.12 + Math.max(0, Math.sin(t * 1.3 + nk.i)) * 0.12;
  }
  applyNeck(nk) {
    const c = nk.cur;
    nk.base.setEuler(0, nk.fan + c.psi, 0);
    for (let k = 0; k < NECK_SEGS; k++) nk.segs[k].setEuler(c.p[k], c.s[k], 0);
    nk.head.setEuler(c.h, c.hy, 0);
    nk.jaw.setEuler(c.jaw, 0, 0);
  }
  easeNeck(nk, rate, dt) {
    const c = nk.cur, g = nk.tgt;
    c.psi = damp(c.psi, g.psi, rate, dt);
    for (let k = 0; k < NECK_SEGS; k++) { c.p[k] = damp(c.p[k], g.p[k], rate, dt); c.s[k] = damp(c.s[k], g.s[k], rate, dt); }
    c.h = damp(c.h, g.h, rate * 1.5, dt);
    c.hy = damp(c.hy, g.hy, rate, dt);
    c.jaw = damp(c.jaw, g.jaw, 8, dt);
  }
  // mouth position and facing (from last frame's world matrix)
  mouth(nk) {
    const m = nk.head.world;
    const s = Math.hypot(m[8], m[9], m[10]) || 1;
    const f = [m[8] / s, m[9] / s, m[10] / s];
    const p = [m[12] + m[8] * 2.9 - m[4] * 0.1, m[13] + m[9] * 2.9 - m[5] * 0.1, m[14] + m[10] * 2.9 - m[6] * 0.1];
    return { p, f };
  }

  // ---------------------------------------------------------------- imps
  buildImps() {
    const I = this.isle;
    this.imps = [];
    for (let i = 0; i < 7; i++) {
      const rig = buildImp(this.cr.ctx, 30 + i);
      this.cr.add(rig, 90);
      const r = 24 + (i % 4) * 7 + this.rng.range(-2, 2);
      const a0 = (i / 7) * TAU;
      const dir = i % 2 ? 1 : -1;
      const route = [];
      for (let k = 0; k < 6; k++) {
        const a = a0 + dir * (k / 6) * TAU;
        const rr = Math.min(r + Math.sin(k * 2.3 + i) * 5, I.coast(a) - 12);
        route.push(I.toWorld(Math.cos(a) * rr, Math.sin(a) * rr));
      }
      const [x, z] = route[0];
      const light = this.scene.addLight({ node: rig.bones.body, color: C('#ff6a2a'), intensity: 0.7, radius: 4, flicker: 0.35, priority: 2, enabled: false });
      this.imps.push({ rig, route, wp: 1, x, z, y: I.ground(x, z), yaw: 0, state: 'patrol', t: 0, speed: 0, phase: this.rng.range(0, 10), wait: 0, cool: 0, light, jump: 0, look: 0 });
    }
  }
  hitsCircle(x, z, y, r) {
    const list = this.world.physics.colliders.query(x, z);
    for (let i = 0; i < list.length; i++) {
      const c = list[i];
      if (c.type !== 'circle' || y > c.yMax || y + 0.8 < c.yMin) continue;
      if (hyp(x - c.x, z - c.z) < c.r + r) return true;
    }
    return false;
  }
  // can this eye see that point? (obsidian, ruins, bones and ridges hide you)
  clearLine(a, b, from = 0.12, to = 0.92) {
    const P = this.world.physics;
    const n = Math.max(4, Math.ceil(hyp(b[0] - a[0], b[2] - a[2]) / 1.2));
    for (let i = 0; i <= n; i++) {
      const u = lerp(from, to, i / n);
      const x = lerp(a[0], b[0], u), y = lerp(a[1], b[1], u), z = lerp(a[2], b[2], u);
      if (y < this.isle.ground(x, z) + 0.05) return false;
      if (P.pointSolid(x, y, z, 0)) return false;
    }
    return true;
  }

  // ---------------------------------------------------------------- the crown on the hoard
  buildCrown() {
    const I = this.isle, g = this.game, ctx = this.cr.ctx;
    const node = buildCrown(ctx, 1.6);
    node.setPos(I.hoard[0], I.hoardY + 0.05, I.hoard[1]);
    node.traverse((n) => { if (n.geometry) n.maxDistance = 160; });
    this.scene.add(node);
    this.crown = node;
    this.crownLight = this.world.light([I.hoard[0], I.hoardY + 1.2, I.hoard[1]], C('#ffd070'), 1.6, 7, 0.05, 5);
    const npcs = this.cr.npcs;
    npcs.addInteract({
      id: 'crown', name: 'A Hétfejű koronája', pos: [I.hoard[0], I.hoardY - 0.4, I.hoard[1]], radius: 4.6, kind: 'take', verb: 'Elveszem',
      visible: () => !this.carrying && !g.P.items.has('crown'),
      talk: () => ({ lines: ['Hét ága van, mindegyiken egy parázsló kő. Olyan nehéz, mintha egy egész birodalom volna.', 'Ahogy felemeled, a hét fej egyszerre nyitja ki a szemét.'], after: () => this.takeCrown() }),
    });
  }
  takeCrown() {
    this.carrying = true;
    this.wake(true);
    this.game.ui.toast('Felébredt a Hétfejű!', { sub: 'Fuss a koronával a tengerig! Az obszidián mögé nem lát be a tűz.', gold: true });
  }
  crownSecured() {
    const g = this.game;
    this.carrying = false;
    g.P.flags.add('crown');
    g.giveItem('crown', 'A Hétfejű koronája');
    if (g.player.wearCrown) g.player.wearCrown(true);
    setTimeout(() => g.ui.toast('A korona a tiéd!', { sub: 'Ezentúl a sapkádon viseled. A sárkány még sokáig keresni fogja…', gold: true }), 1600);
  }

  // ---------------------------------------------------------------- waking and sleeping
  wake(loud = false) {
    const g = this.game;
    if (this.state === 'awake') return;
    this.state = 'awake';
    this.alert = 1.2;
    this.t = 0;
    this.lost = 0;
    this.nextBreath = 2.2;
    if (g.audio.started) g.audio.dragon('roar', loud ? 1 : 0.85);
    g.follow.shake = Math.max(g.follow.shake, 0.9);
    if (!this.carrying && (!this.wakeToast || g.time - this.wakeToast > 25)) {
      this.wakeToast = g.time;
      g.ui.toast('A Hétfejű felébredt!', { sub: 'Bújj az obszidián mögé, vagy fuss a vízig!' });
    }
    for (const m of this.imps) if (m.state === 'patrol') { m.state = 'alarm'; m.t = 0; }
  }
  alarm(amount) {
    this.alert = Math.min(1.5, this.alert + amount);
  }

  update(dt, t, pl) {
    const I = this.isle;
    if (!I) return;
    const g = this.game, W = this.world;
    const dxC = pl.pos[0] - I.x, dzC = pl.pos[2] - I.z;
    const dC = hyp(dxC, dzC);
    const wasNear = this.near;
    this.near = dC < 500; // (the dragon is drawn up to 480 m)
    if (!this.near) {
      // far away (a moon gate, the way home...): the realm goes quiet, lights off, and a crown carried
      // off the island this way is yours
      if (wasNear) {
        if (this.carrying) this.crownSecured();
        this.state = 'sleep';
        this.alert = 0;
        this.stirred = [];
        for (const nk of this.necks) nk.breath = null;
        for (const m of this.imps) { if (m.state !== 'patrol') { m.state = 'return'; m.t = 0; } m.light.enabled = false; }
        this.mouthLight.enabled = false;
        this.eyeLight.enabled = false;
        this.setNeckColliders(true);
        // and it is asleep when you come back into sight: necks down, wings folded, eyes shut, embers cool
        for (const nk of this.necks) {
          this.sleepPose(nk, nk.cur, t);
          Object.assign(nk.tgt, JSON.parse(JSON.stringify(nk.cur)));
          this.applyNeck(nk);
          nk.look = 0.08;
          for (const e of nk.eyes || []) e.setScale(1, 0.08, 1);
        }
        this.wingOpen = 0;
        this.rig.bones.wingL.setEuler(0, 0, 0);
        this.rig.bones.wingR.setEuler(0, 0, 0);
        this.ember = 0;
        const M = this.cr.ctx.M;
        if (M.dragonSkin) M.dragonSkin.uniforms.uEmber = 0;
      }
      this.fire.mesh.visible = false;
      return;
    }
    this.fire.mesh.visible = true;
    this.t += dt;
    const [plx, plz] = I.toLocal(pl.pos[0], pl.pos[2]);
    const onIsle = !pl.swimming && hyp(plx, plz) < I.coast(Math.atan2(plz, plx)) - 1;
    const active = g.state === 'play' && !g.realmBusy && !pl.mount;
    const sp = hyp(pl.vel[0], pl.vel[2]);
    const target = [pl.pos[0], pl.pos[1] + 0.7, pl.pos[2]];
    const hx = this.toW(0, 7);
    const dL = hyp(pl.pos[0] - hx[0], pl.pos[2] - hx[1]);
    // the crown: once you are off the island with it, it is yours
    if (this.carrying && (!onIsle && (pl.swimming || hyp(plx, plz) > I.R + 4))) this.crownSecured();
    this.crown.visible = !this.carrying && !g.P.items.has('crown');
    this.crownLight.enabled = this.crown.visible;
    if (this.crown.visible) { this.crown.setEuler(0, t * 0.35, 0); }
    // ------------------------------------------------ noise and alertness
    let noise = 0;
    if (active && onIsle) {
      if (pl.sneaking) noise = dL < 9 ? 0.03 : 0;
      else if (sp > 3.2) noise = dL < 55 ? 0.12 + 0.5 * (1 - dL / 55) : 0;
      else if (sp > 0.3) noise = dL < 30 ? 0.04 + 0.2 * (1 - dL / 30) : 0;
      if (!pl.onGround && !pl.swimming && !pl.sneaking && dL < 30) noise += 0.08;
    }
    if (this.state === 'sleep' || this.state === 'stir') {
      // a lifted head sniffing the air: anything moving close to it is noticed
      if (this.state === 'stir' && active && onIsle && sp > 0.3 && dL < 26) noise += pl.sneaking ? 0.12 : 0.35;
      this.alert = noise > 0 ? this.alert + noise * dt : Math.max(0, this.alert - dt * (sp < 0.1 ? 0.07 : 0.04));
      if (this.state === 'sleep' && this.alert > 0.45) {
        this.state = 'stir';
        this.t = 0;
        this.stirred = [3, this.rng.int(0, NECKS - 1)].filter((v, i, a) => a.indexOf(v) === i);
        if (g.audio.started) g.audio.dragon('growl', 0.8);
        if (!this.stirToast || g.time - this.stirToast > 20) {
          this.stirToast = g.time;
          g.ui.toast('Az egyik fej felemelkedett…', { sub: 'Ne mozdulj! Ha megnyugszik, lopakodva mehetsz tovább.' });
        }
      } else if (this.state === 'stir' && this.alert < 0.25) { this.state = 'sleep'; this.stirred = []; }
      if (this.alert >= 1) this.wake();
    } else if (this.state === 'awake') {
      const visible = active && onIsle && dL < 60;
      this.lost = visible ? 0 : this.lost + dt;
      if (this.lost > (this.carrying ? 30 : 9)) { this.state = 'settle'; this.t = 0; this.alert = 0.3; }
    } else if (this.state === 'settle') {
      if (this.t > 4) { this.state = 'sleep'; this.t = 0; }
    }
    // ------------------------------------------------ necks
    const awake = this.state === 'awake';
    let breathing = 0;
    for (const nk of this.necks) if (nk.breath) breathing++;
    if (awake && active && onIsle) {
      this.nextBreath -= dt;
      if (this.nextBreath <= 0 && breathing < 2 && dL < 44) {
        const free = this.necks.filter((q) => !q.breath);
        const nk = free[this.rng.int(0, free.length - 1)];
        nk.breath = { phase: 'wind', t: 0 };
        this.nextBreath = this.rng.range(1.8, 3.2);
      }
    }
    let lightAt = null, lightK = 0, worldFresh = false;
    for (const nk of this.necks) {
      const b = nk.breath;
      if (awake || (b && b.phase !== 'cool')) {
        this.awakePose(nk, nk.tgt, t, target, 1);
      } else if (this.state === 'stir' && this.stirred.includes(nk.i)) {
        this.awakePose(nk, nk.tgt, t, null, 0.55);
        nk.tgt.psi = Math.sin(this.t * 0.6 + nk.i) * 0.7;
        nk.tgt.h += Math.sin(this.t * 0.9) * 0.15;
        nk.tgt.jaw = 0.05;
      } else this.sleepPose(nk, nk.tgt, t);
      let rate = awake ? 2.2 : this.state === 'settle' ? 0.7 : 1.4;
      if (b) {
        b.t += dt;
        if (b.phase === 'wind') {
          // rear back, jaws open, a glow in the throat
          nk.tgt.p[0] -= 0.14;
          nk.tgt.h -= 0.18;
          nk.tgt.jaw = 0.55;
          rate = 3;
          lightAt = this.mouth(nk).p; lightK = Math.max(lightK, b.t / 0.9);
          if (b.t > 0.9) {
            b.phase = 'fire'; b.t = 0; b.hit = 0;
            if (g.audio.started) g.audio.dragon('fire', clamp(1.3 - dL / 60, 0.3, 1));
          }
        } else if (b.phase === 'fire') {
          nk.tgt.jaw = 0.85;
          rate = 1.8; // it sweeps after you, a little late: standing or walking you burn, running sideways you get away
          const { p, f } = this.mouth(nk);
          lightAt = [p[0] + f[0] * 6, p[1] + f[1] * 6, p[2] + f[2] * 6]; lightK = 1.6;
          const n = Math.ceil(dt * 260);
          for (let i = 0; i < n; i++) {
            const j = 0.09;
            const vx = f[0] + (Math.random() - 0.5) * j * 2, vy = f[1] + (Math.random() - 0.5) * j * 2, vz = f[2] + (Math.random() - 0.5) * j * 2;
            const s = SPEED * (0.85 + Math.random() * 0.3);
            this.fire.emit([p[0] + f[0] * Math.random() * 0.6, p[1] + f[1] * Math.random() * 0.6, p[2] + f[2] * Math.random() * 0.6], [vx * s, vy * s, vz * s], g.time, { size: 0.8 + Math.random() * 0.8, life: 0.85 + Math.random() * 0.25, rise: 1.0, spread: 1.2, color: [1, 1, 1], intensity: 2.0 });
          }
          // does it reach you?
          if (active && !g.realmBusy) {
            const front = Math.min(RANGE, b.t * SPEED * 0.8);
            const d = [target[0] - p[0], target[1] - p[1], target[2] - p[2]];
            const along = d[0] * f[0] + d[1] * f[1] + d[2] * f[2];
            if (along > 0 && along < front) {
              const perp = hyp(hyp(d[0] - f[0] * along, d[1] - f[1] * along), d[2] - f[2] * along);
              if (perp < 0.55 + along * 0.09 && this.clearLine(p, target, 0.1, 0.95)) {
                this.exposure += dt;
                if (this.exposure > 0.35) this.caught('fire');
              }
            }
          }
          if (b.t > 1.9) { b.phase = 'cool'; b.t = 0; }
        } else if (b.phase === 'cool') {
          nk.tgt.jaw = 0.3;
          if (b.t > 0.7) nk.breath = null;
        }
      }
      this.easeNeck(nk, rate, dt);
      this.applyNeck(nk);
      if (!worldFresh && dC < 250) { this.rig.root.updateWorld(null, false); worldFresh = true; }
      // eyes: shut asleep, burning awake
      if (nk.eyes) {
        const open = awake || (b && b.phase !== 'cool') || (this.state === 'stir' && this.stirred.includes(nk.i)) ? 1 : 0.08;
        nk.look = damp(nk.look, open, 4, dt);
        for (const e of nk.eyes) e.setScale(1, Math.max(0.05, nk.look), 1);
      }
    }
    this.exposure = Math.max(0, this.exposure - dt * 0.5);
    // the creases between its scales glow hotter when it is awake, hottest while it breathes fire
    const M = this.cr.ctx.M;
    this.ember = damp(this.ember || 0, breathing > 0 ? 0.6 : awake ? 0.25 : this.state === 'stir' ? 0.1 : 0, 2, dt);
    if (M.dragonSkin) M.dragonSkin.uniforms.uEmber = this.ember;
    // lights
    this.mouthLight.enabled = !!lightAt;
    if (lightAt) {
      this.mouthLight.position = lightAt;
      this.mouthLight.intensity = 1.2 + lightK * 2.4;
    }
    const eyeK = awake ? 1 : this.state === 'stir' ? 0.4 : 0;
    this.eyeLight.enabled = eyeK > 0.05 && dC < 200;
    this.eyeLight.intensity = eyeK * 1.3;
    // wings half open when it is awake; the sleeping necks are in your way, the raised ones are not
    this.wingOpen = damp(this.wingOpen || 0, awake ? 1 : 0, awake ? 1.5 : 0.6, dt);
    const wo = this.wingOpen, wf = Math.sin(t * 1.8) * 0.08 * wo;
    const wb = this.rig.bones;
    wb.wingL.setEuler(-0.1 * wo, 0.35 * wo, 0.8 * wo + wf);
    wb.wingR.setEuler(-0.1 * wo, -0.35 * wo, -0.8 * wo - wf);
    this.setNeckColliders(this.state === 'sleep' || (this.state === 'stir' && this.alert < 0.8));
    // breathing body, snoring, embers from the nostrils while asleep
    const br = Math.sin(t * 0.55);
    if (this.bodyMesh) this.bodyMesh.setScale(1, 1 + br * 0.025, 1 + br * 0.012);
    if (this.state === 'sleep' && dC < 140) {
      this.snore -= dt;
      if (this.snore <= 0) {
        this.snore = this.rng.range(4.5, 7);
        if (g.audio.started && dC < 90) g.audio.dragon('snore', clamp(1.1 - dL / 70, 0.15, 0.8));
        for (const nk of this.necks) {
          if (this.rng.next() < 0.5) continue;
          const { p, f } = this.mouth(nk);
          for (let i = 0; i < 6; i++) this.fire.emit([p[0], p[1] + 0.2, p[2]], [f[0] * 1.2 + (Math.random() - 0.5) * 0.6, 0.8 + Math.random() * 0.6, f[2] * 1.2 + (Math.random() - 0.5) * 0.6], g.time, { size: 0.12, life: 1.6, rise: 0.6, spread: 0.3, color: [0.9, 0.5, 0.4], intensity: 1.4 });
        }
      }
    }
    this.updateImps(dt, t, pl, active, onIsle, sp);
    this.fire.flush();
  }

  updateImps(dt, t, pl, active, onIsle, sp) {
    const I = this.isle, g = this.game, W = this.world;
    for (const m of this.imps) {
      const dx = pl.pos[0] - m.x, dz = pl.pos[2] - m.z, pd = hyp(dx, dz);
      const far = hyp(g.cam.position[0] - m.x, g.cam.position[2] - m.z) > 120;
      m.rig.root.visible = !far;
      m.light.enabled = !far && pd < 70;
      m.t += dt;
      m.cool -= dt;
      let want = null, speed = 0;
      if (m.state === 'patrol') {
        const w = m.route[m.wp];
        const tx = w[0] - m.x, tz = w[1] - m.z;
        if (hyp(tx, tz) < 1) { m.wp = (m.wp + 1) % m.route.length; m.wait = this.rng.range(0.5, 2.5); }
        if (m.wait > 0) { m.wait -= dt; m.look += dt; want = m.yaw + Math.sin(m.look * 1.5) * 0.8; }
        else { want = Math.atan2(tx, tz); speed = IMP_WALK; }
        // look out for gnomes
        if (active && onIsle && m.cool <= 0 && pd < IMP_SEE) {
          const fwd = (Math.sin(m.yaw) * dx + Math.cos(m.yaw) * dz) / Math.max(0.01, pd);
          const range = pl.sneaking ? (sp < 0.1 ? 3.2 : IMP_SEE_SNEAK) : IMP_SEE;
          if ((fwd > 0.5 && pd < range) || (pd < 2.4 && !pl.sneaking)) {
            if (this.clearLine([m.x, m.y + 0.8, m.z], [pl.pos[0], pl.pos[1] + 0.6, pl.pos[2]], 0.08, 0.95)) {
              m.state = 'alarm'; m.t = 0;
              this.alarm(0.65);
              this.wake(); // the shriek wakes its master
              if (g.audio.started) g.audio.dragon('imp', clamp(1.2 - pd / 30, 0.4, 1));
              if (!this.impToast || g.time - this.impToast > 18) {
                this.impToast = g.time;
                g.ui.toast('Egy Parázsmanó észrevett!', { sub: 'Visítva ébreszti a gazdáját… Fuss!' });
              }
            }
          }
        }
      } else if (m.state === 'alarm') {
        want = Math.atan2(dx, dz);
        m.jump = Math.max(m.jump, 1);
        if (m.t > 0.7) { m.state = 'chase'; m.t = 0; }
      } else if (m.state === 'chase') {
        want = Math.atan2(dx, dz);
        speed = IMP_CHASE;
        if (!active || !onIsle || m.t > 10) { m.state = 'jeer'; m.t = 0; }
        else if (pd < 0.85 && Math.abs(pl.pos[1] - m.y) < 1.6) { m.state = 'jeer'; m.t = 0; this.caught('imp'); }
      } else if (m.state === 'jeer') {
        // hopping up and down at the edge of the water, shaking the fork
        want = Math.atan2(dx, dz);
        m.jump = Math.max(m.jump, 0.6 * Math.abs(Math.sin(m.t * 6)));
        if (m.t > 2.5) { m.state = 'return'; m.t = 0; m.cool = 6; }
      } else if (m.state === 'return') {
        const w = m.route[m.wp];
        want = Math.atan2(w[0] - m.x, w[1] - m.z);
        speed = IMP_WALK * 1.4;
        if (hyp(w[0] - m.x, w[1] - m.z) < 1.2 || m.t > 25) { m.state = 'patrol'; m.t = 0; }
      }
      if (want !== null) m.yaw += angleDiff(m.yaw, want) * Math.min(1, dt * (m.state === 'chase' ? 7 : 3));
      m.speed = damp(m.speed, speed, 5, dt);
      if (m.speed > 0.02) {
        const step = m.speed * dt;
        let moved = false;
        for (const off of [0, 0.6, -0.6, 1.2, -1.2]) {
          const a = m.yaw + off;
          const nx = m.x + Math.sin(a) * step, nz = m.z + Math.cos(a) * step;
          const [lx, lz] = I.toLocal(nx, nz);
          if (hyp(lx, lz) > I.coast(Math.atan2(lz, lx)) - 5) continue; // imps hate water
          if (W.physics.blocked(nx, nz, m.y, 0.3, 1.0, 0.6, m.x, m.z) || this.hitsCircle(nx, nz, m.y, 0.3)) continue;
          m.x = nx; m.z = nz; moved = true;
          break;
        }
        m.stuck = moved ? 0 : (m.stuck || 0) + dt;
        if (m.stuck > 2 && m.state === 'patrol') { m.wp = (m.wp + 1) % m.route.length; m.stuck = 0; }
        if (m.stuck > 2 && m.state === 'return') { m.state = 'patrol'; m.stuck = 0; }
      }
      if (far) continue;
      m.phase += dt * (6 + m.speed * 3);
      m.jump = damp(m.jump, 0, 3, dt);
      const hop = Math.abs(Math.sin(m.phase * 0.5)) * 0.12 * Math.min(1, m.speed) + m.jump * 0.9;
      m.y = I.ground(m.x, m.z);
      m.rig.root.setPos(m.x, m.y + 0.02 + hop, m.z);
      m.rig.root.setRotY(m.yaw);
      const b = m.rig.bones;
      const flap = Math.sin(m.phase * 3.2) * (0.5 + m.jump * 0.5) + 0.2;
      b.wingL.setEuler(0, -0.3, flap);
      b.wingR.setEuler(0, 0.3, -flap);
      const sw = Math.sin(m.phase) * Math.min(1, m.speed);
      b.legL.setEuler(sw * 0.7, 0, 0);
      b.legR.setEuler(-sw * 0.7, 0, 0);
      const angry = m.state === 'chase' || m.state === 'alarm' || m.state === 'jeer';
      b.arm.setEuler(angry ? -0.6 + Math.sin(m.t * 12) * 0.35 : Math.sin(m.phase * 0.5) * 0.1, 0, 0);
      b.body.setEuler(angry ? 0.25 : 0.05, 0, Math.sin(m.phase * 0.5) * 0.08);
      b.armL.setEuler(angry ? -1.2 + Math.sin(m.t * 9) * 0.5 : Math.sin(m.phase * 0.5 + 1) * 0.15, 0, angry ? -0.4 : 0);
      b.tail.setEuler(Math.sin(m.phase * 0.3) * 0.15, Math.sin(m.phase * 0.45) * 0.5, 0);
      const lookAround = m.state === 'patrol' && m.wait > 0 ? Math.sin(m.look * 1.3) * 0.7 : 0;
      b.head.setEuler(angry ? -0.15 : 0.05, lookAround, angry ? Math.sin(m.t * 14) * 0.12 : 0);
      m.light.intensity = angry ? 1.4 : 0.6;
    }
  }

  // ---------------------------------------------------------------- caught: thrown back into the sea
  caught(how) {
    const g = this.game, I = this.isle;
    if (g.realmBusy) return;
    g.realmBusy = true;
    this.exposure = 0;
    const lostCrown = this.carrying;
    this.carrying = false;
    if (g.audio.started) g.audio.mumus('catch');
    g.follow.shake = 1;
    g.ui.fade(true);
    if (g.talk) { g.ui.closeDialogue(); g.talk = null; }
    g.state = 'travel';
    for (const nk of this.necks) nk.breath = null;
    setTimeout(() => {
      // out in the water, in front of the gate that faces the forest island
      const a = 1.9, r = I.coast(a) + 12;
      const [x, z] = I.toWorld(Math.cos(a) * r, Math.sin(a) * r);
      g.player.spawn(x, z, Math.atan2(g.layout.spawn.x - x, g.layout.spawn.z - z));
      g.follow.yaw = g.player.yaw;
      g.follow.snap(g.player);
      if (g.state === 'travel') g.state = 'play';
      this.state = 'settle';
      this.t = 0;
      this.alert = 0.2;
      for (const m of this.imps) if (m.state !== 'patrol') { m.state = 'return'; m.t = 0; m.cool = 8; }
      setTimeout(() => {
        g.ui.fade(false);
        const sub = lostCrown ? T(' A korona visszagurult a kincshalomra.') : '';
        if (how === 'fire') g.ui.toast('Megperzselt a Hétfejű lángja!', { sub: T('Egy hamufelhő a tengerbe sodort.') + sub });
        else g.ui.toast('A Parázsmanók elkaptak…', { sub: T('…és visítva a tengerbe hajítottak.') + sub });
        g.realmBusy = false;
      }, 450);
    }, 1100);
  }
}
