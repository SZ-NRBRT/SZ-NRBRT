// Life in the sky: the wind wells that lift you, Pihe the cloud shepherd and her runaway cloud sheep,
// the cloud bells, and the ferry whale that carries you between the Cloud Harbour and the Sky Garden.
import { buildShepherd, buildCloudSheep } from '../models/creatures.js';
import { RNG, clamp, damp, lerp, angleDiff, TAU, smoothstep } from '../engine/math.js';
import { C } from '../models/materials.js';
import { LINES, SCRIPT } from '../data/dialogue.js';
import { T } from '../i18n.js';

const hyp = (x, z) => Math.sqrt(x * x + z * z);
const SEAT = [0, 4.67, 2.4]; // saddle seat in the whale's local space

// rotate v by quaternion q (x, y, z, w)
function qrot(q, v, out) {
  const [x, y, z, w] = q;
  const tx = 2 * (y * v[2] - z * v[1]), ty = 2 * (z * v[0] - x * v[2]), tz = 2 * (x * v[1] - y * v[0]);
  out[0] = v[0] + w * tx + (y * tz - z * ty);
  out[1] = v[1] + w * ty + (z * tx - x * tz);
  out[2] = v[2] + w * tz + (x * ty - y * tx);
  return out;
}

export class SkyLife {
  constructor(game) {
    this.game = game;
    this.world = game.world;
    this.npcs = game.npcs;
    this.scene = game.scene;
    this.ctx = this.world.ctx;
    this.sky = this.world.sky;
    this.rng = new RNG(this.world.L.seed + 4242);
    this.liftSound = 0;
    this.buildShepherd();
    this.buildSheep();
    this.buildFlockMother();
    this.buildBells();
    this.ferry = new Ferry(this);
    this.npcs.creatures.watch.push({ id: 'sheep', range: 12, points: () => this.sheep.map((s) => s.pos) });
  }
  get P() { return this.game.P; }

  // ------------------------------------------------------------ Pihe
  buildShepherd() {
    const W = this.world, H = this.sky.harbour, g = this.game;
    const pen = this.sky.pen;
    const rig = buildShepherd(this.ctx);
    // beside the pen, facing the island centre
    const a = Math.atan2(H.x - pen[0], H.z - pen[2]);
    const px = pen[0] + Math.sin(a + 0.9) * 3.6, pz = pen[2] + Math.cos(a + 0.9) * 3.6;
    const py = H.isl.top(px, pz) ?? H.y + 0.3;
    rig.root.setPos(px, py - 0.02, pz);
    const yaw = Math.atan2(H.x - px, H.z - pz);
    rig.root.setRotY(yaw);
    rig.root.traverse((n) => { if (n.geometry) n.maxDistance = 120; });
    this.scene.add(rig.root);
    W.physics.addCircle(px, pz, 0.4, { yMin: py - 1, yMax: py + 1.8 });
    this.shepherd = { rig, pos: [px, py, pz], yaw, look: 0 };
    this.npcs.addInteract({
      id: 'shepherd', name: 'Pihe, a felhőpásztor', pos: [px, py, pz], radius: 3.2, kind: 'talk', focus: [px, py + 1.5, pz],
      talk: () => {
        const P = this.P;
        const n = this.returned();
        if (!P.flags.has('metPihe') && n >= 3) {
          return { lines: [SCRIPT.shepherdAsk[0], 'Várj… a báránykáim! Mind a három itthon van! Te küldted haza őket?', ...SCRIPT.shepherdThanks.slice(1)], after: () => { P.flags.add('metPihe'); this.finishSheep(); } };
        }
        if (!P.flags.has('metPihe')) {
          const lines = SCRIPT.shepherdAsk.slice();
          if (n > 0 && n < 3) lines.push(T('Várj… {0} már hazatalált? Akkor te már segítettél! Már csak {1} hiányzik.', n, 3 - n));
          return { lines, after: () => { P.flags.add('metPihe'); g.setStage('sheep', 1); } };
        }
        if (P.stage.sheep < 2 && n >= 3) return { lines: SCRIPT.shepherdThanks, after: () => this.finishSheep() };
        if (P.stage.sheep < 2) {
          const where = this.sheep.filter((s) => !P.flags.has(s.flag)).map((s) => T(s.where)).join(', ') + '.';
          return { lines: SCRIPT.shepherdRemind.map((l) => T(l).replace('{left}', String(3 - n)).replace('{where}', where)) };
        }
        return null;
      },
      lines: LINES.shepherd,
    });
  }
  finishSheep() {
    const g = this.game, P = this.P;
    if (P.stage.sheep === 0) P.stage.sheep = 1;
    g.setStage('sheep', 2);
    P.flags.add('bellTaught');
    g.bonusShards('sheep', 3);
    setTimeout(() => g.setStage('whale', 1), 2400);
  }
  returned() {
    return this.sheep.filter((s) => this.P.flags.has(s.flag)).length;
  }

  // ------------------------------------------------------------ the three runaway sheep
  buildSheep() {
    const W = this.world, S = W.L.sites;
    const homes = [
      { site: S.lake, r: S.lake.lakeR + 8, where: 'a Csillagtó partján' },
      { site: S.moongarden, r: 16, where: 'a Holdarc-kertben' },
      { site: S.mushroom, r: 34, where: 'a Kéklő Gombaerdőben' },
    ];
    const pen = this.sky.pen;
    this.sheep = homes.map((h, i) => {
      const rng = this.rng;
      let spot = null;
      for (let k = 0; k < 60 && !spot; k++) {
        const a = rng.range(0, TAU), d = h.r * rng.range(0.7, 1.05);
        const x = h.site.x + Math.cos(a) * d, z = h.site.z + Math.sin(a) * d;
        if (W.waterDepth(x, z) > -0.3) continue;
        const gy = W.h(x, z);
        if (W.physics.ground(x, z, gy + 0.3) > gy + 0.3) continue;
        if (W.physics.blocked(x, z, gy, 0.5, 1.0, 0.5)) continue;
        spot = [x, z];
      }
      spot = spot || [h.site.x + 6, h.site.z + 6];
      const rig = buildCloudSheep(this.ctx, 60 + i);
      rig.root.traverse((n) => { if (n.geometry) n.maxDistance = 140; });
      this.scene.add(rig.root);
      const pa = (i / 3) * TAU + 0.6;
      const penSpot = [pen[0] + Math.cos(pa) * 1.2, pen[1], pen[2] + Math.sin(pa) * 1.2];
      const s = {
        rig, i, flag: 'sheep' + i, where: h.where, home: [spot[0], W.h(spot[0], spot[1]), spot[1]], penSpot,
        pos: [spot[0], W.h(spot[0], spot[1]), spot[1]], yaw: rng.range(0, TAU), phase: rng.range(0, 10), wander: 0, target: null,
        flight: null, graze: 0,
      };
      if (this.P.flags.has(s.flag)) { s.pos = penSpot.slice(); s.home = penSpot.slice(); }
      const it = this.npcs.addInteract({
        id: 'sheep' + i, name: 'Felhőbárány', pos: s.pos.slice(), radius: 2.6, kind: 'look', verb: 'Megsimogatom', moving: true,
        visible: () => !s.flight,
        talk: () => {
          if (this.P.flags.has(s.flag)) return { lines: LINES.sheepPen };
          return { lines: SCRIPT.sheepFound, after: () => this.sendHome(s) };
        },
      });
      s.it = it;
      return s;
    });
  }
  sendHome(s) {
    const g = this.game, P = this.P;
    P.flags.add(s.flag);
    if (P.stage.sheep === 0) g.setStage('sheep', 1, true);
    const n = this.returned();
    g.ui.toast(T('Felhőbárány hazaszállt ({0} / 3)', n), { sub: n >= 3 ? 'Mind hazatalált. Keresd fel Pihét a Felhőkikötőben!' : 'Pihe a Felhőkikötőben várja a többit.' });
    g.audio.chime([784, 1046.5, 1318.5, 1568], 0.05, 0.09, 1.2);
    g.burst([s.pos[0], s.pos[1] + 0.4, s.pos[2]], 18, [1.4, 1.4, 1.9], 1.4);
    g.refreshHud();
    g.persist();
    const from = s.pos.slice(), to = s.penSpot.slice();
    const d = hyp(to[0] - from[0], to[2] - from[2]);
    s.flight = { t: 0, T: clamp(d / 22, 5, 12), from, to, peak: Math.max(from[1], to[1]) + 18 + d * 0.05 };
    s.home = to.slice();
  }

  // ------------------------------------------------------------ the flock mother, asleep in the garden
  buildFlockMother() {
    const W = this.world, m = this.sky.flockMother;
    if (!m) return;
    const rig = buildCloudSheep(this.ctx, 99, '#d4cce8');
    rig.root.setScale(3.4);
    rig.root.setPos(m[0], m[1] - 0.72, m[2]);
    rig.root.setRotY(m[3]);
    rig.root.traverse((n) => { if (n.geometry) n.maxDistance = 260; });
    // lying down: legs tucked, head resting
    for (const k of ['legFL', 'legFR', 'legBL', 'legBR']) rig.bones[k].setEuler(k.includes('F') ? 1.45 : -1.45, 0, 0);
    this.scene.add(rig.root);
    W.physics.addCircle(m[0], m[2], 1.7, { yMin: m[1] - 1, yMax: m[1] + 3 });
    this.mother = { rig, pos: m, seed: 3 };
    this.npcs.addInteract({ id: 'flockMother', name: 'Bárányfelhő-anyó', pos: [m[0], m[1], m[2]], radius: 4.2, kind: 'look', lines: LINES.flockMother, focus: [m[0], m[1] + 1.8, m[2]] });
  }

  // ------------------------------------------------------------ the cloud bells
  buildBells() {
    const bells = this.sky.bells || {};
    this.bells = bells;
    for (const id of Object.keys(bells)) {
      const b = bells[id];
      b.swing = 0;
      b.phase = 0;
      this.npcs.addInteract({
        id: 'bell_' + id, name: 'Felhőharang', pos: [b.base[0], b.base[1], b.base[2]], radius: 2.6, kind: 'look', verb: 'Megkongatom',
        talk: () => {
          const P = this.P;
          if (!P.flags.has('bellTaught')) { this.ring(b, 0.3); return { lines: SCRIPT.bellMute }; }
          const f = this.ferry;
          if (f.state === 'docked' && f.dock === id) return { lines: SCRIPT.bellHere };
          if (f.state === 'ride') return { lines: SCRIPT.bellWait };
          this.ring(b, 1);
          f.call(id);
          return { lines: SCRIPT.bellRing };
        },
      });
    }
  }
  ring(b, k) {
    b.swing = Math.max(b.swing, k);
    const a = this.game.audio;
    if (a.started) { k > 0.5 ? a.bell() : a.chime([220], 0.03, 0, 0.8); }
  }

  // ------------------------------------------------------------ per frame (before the player moves)
  update(dt, t) {
    const g = this.game, pl = g.player, P = this.P;
    // wind wells
    let lift = null;
    for (const u of this.sky.updrafts) {
      const on = !u.active || P.flags.has(u.active);
      if (u.fx.visible !== on) {
        u.fx.visible = on;
        if (on && g.state === 'play' && this.ready) {
          g.ui.toast('Felébredt egy szélkút', { sub: 'A lebegő szigetek csúcsán felfelé fúj a szél — a Felhőkert felé.' });
          g.audio.gust(0.7);
        }
      }
      if (!on || g.state !== 'play' || pl.mount) continue;
      const d = hyp(pl.pos[0] - u.x, pl.pos[2] - u.z);
      if (d < u.r + 0.15 && pl.pos[1] > u.y0 - 1.2 && pl.pos[1] < u.y1 + 1.5) lift = u;
    }
    if (lift && !pl.lift && g.audio.started && t - this.liftSound > 2) { g.audio.gust(1); this.liftSound = t; }
    pl.lift = lift;
    this.ready = true;
    this.ferry.update(dt, t);
    // Pihe: wings breathe, antennae sway, head follows you
    const sh = this.shepherd;
    if (sh) {
      const b = sh.rig.bones;
      const dx = pl.pos[0] - sh.pos[0], dz = pl.pos[2] - sh.pos[2];
      const near = hyp(dx, dz) < 9;
      sh.look = damp(sh.look, near ? clamp(angleDiff(sh.yaw, Math.atan2(dx, dz)), -1, 1) : Math.sin(t * 0.3) * 0.4, 3, dt);
      b.head.setEuler(-0.08 + Math.sin(t * 0.7) * 0.03, sh.look, Math.sin(t * 0.5) * 0.06);
      const flap = Math.sin(t * 1.1) * 0.12 + (Math.sin(t * 0.37) > 0.92 ? Math.sin(t * 9) * 0.25 : 0);
      b.wingL.setEuler(0, -0.35 - flap, 0);
      b.wingR.setEuler(0, 0.35 + flap, 0);
      b.armR.setEuler(-0.35 + Math.sin(t * 0.8) * 0.03, 0, -0.08);
      b.armL.setEuler(-0.1 + Math.sin(t * 0.9 + 1) * 0.04, 0, 0.12);
      b.crook.setEuler(0.35, 0, 0.08);
      b.body.setEuler(0, 0, Math.sin(t * 0.6) * 0.02);
    }
    // sheep
    for (const s of this.sheep) this.updateSheep(s, dt, t, pl);
    // the flock mother breathes
    if (this.mother) {
      const b = this.mother.rig.bones;
      const br = Math.sin(t * 0.45);
      b.body.setScale(1 + br * 0.025, 1 + br * 0.04, 1 + br * 0.02);
      b.head.setEuler(0.35 + br * 0.03, 0.2, 0.15);
    }
    // bells swing out after a strike
    for (const id in this.bells) {
      const b = this.bells[id];
      if (b.swing <= 0.001) continue;
      b.phase += dt * 5.5;
      b.swing = Math.max(0, b.swing - dt * 0.35);
      b.node.setEuler(Math.sin(b.phase) * 0.35 * b.swing, b.yaw, 0);
    }
  }

  updateSheep(s, dt, t, pl) {
    const W = this.world, b = s.rig.bones;
    let walk = 0;
    if (s.flight) {
      // flying home: a high, lazy arc with a spin
      const f = s.flight;
      f.t += dt;
      const u = clamp(f.t / f.T, 0, 1);
      const e = u * u * (3 - 2 * u);
      s.pos[0] = lerp(f.from[0], f.to[0], e);
      s.pos[2] = lerp(f.from[2], f.to[2], e);
      const base = lerp(f.from[1], f.to[1], e);
      s.pos[1] = base + Math.sin(u * Math.PI) * (f.peak - Math.max(f.from[1], f.to[1]));
      s.yaw += dt * 2.5 * (1 - u);
      if (u >= 1) s.flight = null;
      if (Math.random() < dt * 20) this.game.trail.emit([s.pos[0], s.pos[1] + 0.5, s.pos[2]], this.game.time, { size: 0.14, life: 1.4, rise: -0.2, spread: 0.5, color: [1.2, 1.2, 1.7], intensity: 1.6 });
    } else {
      const inPen = this.P.flags.has(s.flag);
      const dxp = pl.pos[0] - s.pos[0], dzp = pl.pos[2] - s.pos[2];
      const pd = hyp(dxp, dzp);
      if (pd > 120) { s.rig.root.visible = false; s.it.pos[1] = -1000; return; }
      s.rig.root.visible = true;
      // wander a little around home, graze, look at you when you come close
      const R = inPen ? 1.1 : 5;
      if (!s.target) {
        s.wander -= dt;
        if (s.wander <= 0) {
          const a = this.rng.range(0, TAU), d = this.rng.range(0, R);
          const x = s.home[0] + Math.cos(a) * d, z = s.home[2] + Math.sin(a) * d;
          if (inPen || (W.waterDepth(x, z) < -0.3 && !W.physics.blocked(x, z, W.h(x, z), 0.35, 0.9, 0.4))) s.target = [x, z];
          s.wander = this.rng.range(2, 6);
          s.graze = this.rng.chance(0.5) ? this.rng.range(1.5, 3) : 0;
        }
      } else {
        const tx = s.target[0] - s.pos[0], tz = s.target[1] - s.pos[2], td = hyp(tx, tz);
        if (td < 0.15) s.target = null;
        else {
          s.yaw += angleDiff(s.yaw, Math.atan2(tx, tz)) * Math.min(1, dt * 3);
          const sp = 0.55 * dt;
          s.pos[0] += Math.sin(s.yaw) * sp;
          s.pos[2] += Math.cos(s.yaw) * sp;
          walk = 1;
        }
      }
      s.graze = Math.max(0, s.graze - dt);
      const gy = inPen ? s.home[1] : W.h(s.pos[0], s.pos[2]);
      s.pos[1] = gy;
      if (pd < 6 && !walk) s.yaw += angleDiff(s.yaw, Math.atan2(dxp, dzp)) * Math.min(1, dt * 1.5);
    }
    s.phase += dt * (walk ? 7 : 1.5);
    const hover = s.flight ? 0 : 0.05 + Math.sin(t * 1.3 + s.i) * 0.04;
    s.rig.root.setPos(s.pos[0], s.pos[1] + hover, s.pos[2]);
    s.rig.root.setRotY(s.yaw);
    const sw = Math.sin(s.phase) * walk;
    b.legFL.setEuler(sw * 0.5, 0, 0); b.legBR.setEuler(sw * 0.5, 0, 0);
    b.legFR.setEuler(-sw * 0.5, 0, 0); b.legBL.setEuler(-sw * 0.5, 0, 0);
    const graze = s.graze > 0 && !walk && !s.flight ? 1 : 0;
    b.head.setEuler(0.7 * graze + Math.sin(t * 6) * 0.04 * graze, Math.sin(t * 0.5 + s.i) * 0.3 * (1 - graze), 0);
    b.body.setScale(1 + Math.sin(t * 2 + s.i) * 0.02, 1 + Math.sin(t * 2 + s.i + 1) * 0.03, 1);
    s.it.pos[0] = s.pos[0]; s.it.pos[1] = s.pos[1]; s.it.pos[2] = s.pos[2];
  }

  // where to put the player in a save made while riding
  savePos() {
    const f = this.ferry;
    const d = this.sky.docks[f.from || 'harbour'];
    return d ? d.mount : null;
  }
}

// ---------------------------------------------------------------- the ferry whale
class Ferry {
  constructor(life) {
    this.life = life;
    this.game = life.game;
    this.world = life.world;
    this.wh = life.npcs.creatures.whales[0];
    this.state = 'wild';
    this.dock = null;   // dock id it is heading to / waiting at
    this.from = null;
    this.vel = [0, 0, 0];
    this.speed = 0;
    this.yaw = 0; this.pitch = 0; this.roll = 0;
    this.wait = 0;
    this.path = [];
    this.tmp = [0, 0, 0];
    this.seatW = [0, 0, 0];
    const docks = this.world.sky.docks;
    for (const id of Object.keys(docks)) {
      const d = docks[id];
      // where the whale's root must be so that its saddle meets the seat
      const h = d.heading;
      d.root = [d.seat[0] - Math.sin(h) * SEAT[2], d.seat[1] - SEAT[1], d.seat[2] - Math.cos(h) * SEAT[2]];
      d.approach = [d.root[0] - Math.sin(h) * 46, d.root[1] + 2, d.root[2] - Math.cos(h) * 46];
      life.npcs.addInteract({
        id: 'ride_' + id, name: 'Égi bálna', pos: d.mount, radius: 3.2, kind: 'look', verb: 'Felszállok',
        visible: () => this.state === 'docked' && this.dock === id && !this.game.player.mount,
        talk: () => ({ lines: SCRIPT.mount, after: () => this.board(id) }),
      });
    }
    // scenic route from the harbour to the garden, and a quicker one back
    const S = this.world.L.sites;
    const H = docks.harbour, G = docks.garden;
    const ahead = (d, k, up) => [d.root[0] + Math.sin(d.heading) * k, d.root[1] + up, d.root[2] + Math.cos(d.heading) * k];
    this.routes = {
      harbour: this.safe([ahead(H, 60, 8), [S.lake.x, 72, S.lake.z], [S.glade.x - 20, 78, S.glade.z - 10], [S.rune.x, 84, S.rune.z - 40], [S.tower.x - 20, 90, S.tower.z + 10], [S.moongarden.x, 94, S.moongarden.z], [G.approach[0], G.approach[1] + 16, G.approach[2]], G.approach], H.root),
      garden: this.safe([ahead(G, 60, 4), [S.mushroom.x, 86, S.mushroom.z - 30], [S.village.x + 10, 70, S.village.z + 30], [H.approach[0], H.approach[1] + 18, H.approach[2]], H.approach], G.root),
    };
  }

  // insert waypoints high above any sky island that a leg would cut through
  safe(path, start) {
    const isles = [this.world.sky.harbour, this.world.sky.garden];
    const out = [];
    let a = start;
    for (const b of path) {
      for (const I of isles) {
        const vx = b[0] - a[0], vz = b[2] - a[2], l2 = vx * vx + vz * vz || 1;
        const u = clamp(((I.x - a[0]) * vx + (I.z - a[2]) * vz) / l2, 0, 1);
        const cx = a[0] + vx * u, cz = a[2] + vz * u, cy = lerp(a[1], b[1], u);
        if (u > 0.02 && u < 0.98 && hyp(cx - I.x, cz - I.z) < I.R + 16 && cy < I.y + 22 && cy > I.y - 40) out.push([cx, I.y + 32, cz]);
      }
      out.push(b);
      a = b;
    }
    return out;
  }

  // the whale's current pose drives its rig; while it's ours, the creature code leaves it alone
  take() {
    const wh = this.wh;
    if (wh.override) return;
    wh.override = () => {};
    // carry on in the direction it was swimming on its round
    const a = this.game.time * wh.w + wh.ph;
    this.yaw = Math.atan2(-Math.sin(a) * wh.w, Math.cos(a) * wh.w);
    this.speed = 9;
  }
  release() {
    this.wh.override = null;
    this.state = 'wild';
    this.dock = null;
  }

  call(id) {
    this.take();
    this.dock = id;
    const d = this.world.sky.docks[id];
    this.path = this.safe([[d.approach[0], d.approach[1] + 24, d.approach[2]], d.approach], this.wh.pos);
    this.state = 'toDock';
    this.final = null;
  }
  board(id) {
    const pl = this.game.player;
    this.from = id;
    this.dock = id === 'harbour' ? 'garden' : 'harbour';
    this.path = this.routes[id].map((p) => p.slice());
    this.state = 'ride';
    this.final = null;
    this.speed = 0;
    pl.mount = { seat: this.seatW, vel: this.vel, yaw: this.yaw };
    this.placeSeat();
    pl.pos[0] = this.seatW[0]; pl.pos[1] = this.seatW[1]; pl.pos[2] = this.seatW[2];
    this.game.follow.rideDist = this.game.follow.targetDist;
    this.game.follow.targetDist = 9;
    const a = this.game.audio;
    if (a.started) a.whale(1);
  }
  dismount(jump) {
    const pl = this.game.player, f = this.game.follow;
    if (!pl.mount) return;
    pl.mount = null;
    if (f.rideDist) { f.targetDist = f.rideDist; f.rideDist = null; }
    if (jump) {
      pl.vel[0] = this.vel[0]; pl.vel[1] = 6.5; pl.vel[2] = this.vel[2];
      pl.onGround = false;
    }
  }

  placeSeat() {
    const r = this.wh.rig.root;
    qrot(r.quaternion, SEAT, this.tmp);
    this.seatW[0] = r.position[0] + this.tmp[0];
    this.seatW[1] = r.position[1] + this.tmp[1];
    this.seatW[2] = r.position[2] + this.tmp[2];
  }

  // fly forward, turning towards the target (a whale doesn't slide sideways)
  steer(target, maxSpeed, dt, arrive) {
    const wh = this.wh, p = wh.pos;
    const dx = target[0] - p[0], dy = target[1] - p[1], dz = target[2] - p[2];
    const dh = hyp(dx, dz);
    const want = Math.atan2(dx, dz);
    const turn = clamp(angleDiff(this.yaw, want), -1, 1);
    const rate = 0.42;
    const dyaw = clamp(turn * 1.4, -rate, rate) * dt;
    this.yaw += dyaw;
    this.roll = damp(this.roll, clamp(-dyaw / Math.max(dt, 1e-3) * 0.5, -0.16, 0.16), 2, dt);
    const sp = arrive ? Math.min(maxSpeed, 2 + dh * 0.22) : maxSpeed;
    this.speed = damp(this.speed, sp * (1 - Math.min(0.6, Math.abs(turn) * 0.35)), 0.7, dt);
    const vy = clamp(dy * 0.5, -4, 4);
    this.vel[0] = Math.sin(this.yaw) * this.speed;
    this.vel[2] = Math.cos(this.yaw) * this.speed;
    this.vel[1] = damp(this.vel[1], vy, 1.2, dt);
    p[0] += this.vel[0] * dt; p[1] += this.vel[1] * dt; p[2] += this.vel[2] * dt;
    this.pitch = damp(this.pitch, clamp(-Math.atan2(this.vel[1], Math.max(3, this.speed)), -0.2, 0.2), 1.5, dt);
    return Math.hypot(dx, dy, dz);
  }

  apply() {
    const wh = this.wh;
    wh.rig.root.setPos(wh.pos[0], wh.pos[1], wh.pos[2]);
    wh.rig.root.setEuler(this.pitch, this.yaw, this.roll);
    this.placeSeat();
  }

  update(dt, t) {
    const pl = this.game.player, wh = this.wh;
    if (this.state === 'wild') return;
    const docks = this.world.sky.docks;
    if (this.state === 'toDock' || this.state === 'ride') {
      if (this.final) {
        // last stretch: glide exactly into the berth
        const f = this.final;
        f.t += dt;
        const u = clamp(f.t / f.T, 0, 1), e = u * u * (3 - 2 * u);
        const d = docks[this.dock];
        wh.pos[0] = lerp(f.p[0], d.root[0], e); wh.pos[1] = lerp(f.p[1], d.root[1], e); wh.pos[2] = lerp(f.p[2], d.root[2], e);
        this.yaw = f.yaw + angleDiff(f.yaw, d.heading) * e;
        this.pitch = damp(this.pitch, 0, 2, dt);
        this.roll = damp(this.roll, 0, 2, dt);
        this.vel[0] = (d.root[0] - f.p[0]) / f.T * (6 * u * (1 - u));
        this.vel[1] = 0;
        this.vel[2] = (d.root[2] - f.p[2]) / f.T * (6 * u * (1 - u));
        if (u >= 1) this.arrive();
      } else {
        const last = this.path.length === 1;
        const target = this.path[0];
        const dist = this.steer(target, this.state === 'ride' ? 13 : 16, dt, last);
        if (dist < (last ? 10 : 30)) {
          if (last) {
            const d = docks[this.dock];
            this.final = { t: 0, T: clamp(Math.hypot(d.root[0] - wh.pos[0], d.root[2] - wh.pos[2]) / 5.5, 4, 12), p: wh.pos.slice(), yaw: this.yaw };
          } else this.path.shift();
        }
      }
      this.apply();
    } else if (this.state === 'docked') {
      // bob gently at the berth; leave if nobody comes
      const d = docks[this.dock];
      wh.pos[0] = d.root[0]; wh.pos[1] = d.root[1] + Math.sin(t * 0.6) * 0.12; wh.pos[2] = d.root[2];
      this.yaw = d.heading;
      this.vel[0] = this.vel[1] = this.vel[2] = 0;
      this.apply();
      const far = hyp(pl.pos[0] - d.root[0], pl.pos[2] - d.root[2]) > 70;
      this.wait += dt;
      if (this.wait > 150 || (far && this.wait > 40)) {
        this.state = 'leaving';
        this.path = [[wh.pos[0] + Math.sin(this.yaw) * 60, wh.pos[1] + 25, wh.pos[2] + Math.cos(this.yaw) * 60]];
        this.speed = 0;
      }
    } else if (this.state === 'leaving') {
      // back to its old round: head for where the circuit is now, then let go
      const target = this.path.length ? this.path[0] : this.circuitPos(t);
      const dist = this.steer(target, 16, dt, false);
      if (this.path.length && dist < 25) this.path.shift();
      else if (!this.path.length && dist < 14) this.release();
      this.apply();
    }
    if (pl.mount) {
      pl.mount.yaw = this.yaw;
      if (this.game.state === 'play' && this.game.input.hit('Space')) this.dismount(true);
    }
  }
  circuitPos(t) {
    const wh = this.wh;
    const a = t * wh.w + wh.ph;
    return [wh.c[0] + Math.cos(a) * wh.r, wh.h + Math.sin(t * 0.07 + wh.ph) * 6, wh.c[1] + Math.sin(a) * wh.r];
  }
  arrive() {
    const g = this.game, pl = g.player;
    this.final = null;
    this.state = 'docked';
    this.wait = 0;
    this.speed = 0;
    if (pl.mount) {
      // hop off onto the pier
      const d = this.world.sky.docks[this.dock];
      this.dismount(false);
      pl.spawn(d.mount[0], d.mount[2], d.heading - Math.PI / 2 + Math.PI, d.deckY);
      g.follow.yaw = pl.yaw;
      if (this.dock === 'garden' && g.P.stage.whale < 2) g.setStage('whale', 2);
      if (g.audio.started) g.audio.whale(0.8);
    }
  }
}
