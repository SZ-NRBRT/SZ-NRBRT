// The strange walkers of the ground: colossi crossing land and sea, the hill turtle ambling along the shore
// (you can ride it: a gust on its flank lifts you onto the garden on its back), TV-headed wanderers on the
// roads (gone since v7.2), giant plush bunnies, eye-flowers walking on their roots and little paper lanterns that follow you.
import { buildColossus, buildHillTurtle, buildPlushBunny, buildEyeFlower, buildLampling } from '../models/wanderers.js';
import { RNG, clamp, damp, lerp, angleDiff, TAU } from '../engine/math.js';
import { C } from '../models/materials.js';
import { LINES } from '../data/dialogue.js';
import { SEA_FLOOR } from '../world/terrain.js';
import { particleSystem } from '../world/fx.js';

const hyp = (x, z) => Math.sqrt(x * x + z * z);

export class Wanderers {
  constructor(cr) {
    this.cr = cr;
    this.game = cr.game;
    this.world = cr.world;
    this.scene = cr.scene;
    this.ctx = cr.ctx;
    this.npcs = cr.npcs;
    this.rng = new RNG(this.world.L.seed + 2024);
    this.pushers = [];   // moving bodies that shove the player aside: { x, z, r, y0, y1 }
    this.buildColossi();
    this.buildTurtle();
    this.buildPlushies();
    this.buildEyeFlowers();
    this.buildLamplings();
  }
  ground(x, z) {
    return Math.max(this.world.h(x, z), SEA_FLOOR);
  }

  // ------------------------------------------------------------ colossi: slow giants walking in great circles
  buildColossi() {
    const specs = [{ r: 390, w: 0.0062, ph: 0.4, H: 52 }, { r: 470, w: -0.0053, ph: 2.6, H: 46 }, { r: 560, w: 0.0045, ph: 4.4, H: 58 }];
    const all = specs.map((sp, i) => {
      const rig = buildColossus(this.ctx, 30 + i, sp.H);
      rig.root.traverse((n) => { if (n.geometry) { n.maxDistance = 1800; n.castShadow = false; } });
      this.scene.add(rig.root);
      const light = this.scene.addLight({ node: rig.bones.lamp, color: C('#ffc88a'), intensity: 2.8, radius: 22, flicker: 0.08, priority: 2 });
      return { rig, ...sp, light, phase: 0, pos: [0, 0, 0] };
    });
    this.colossi = all;
    this.cr.list.push({
      update: (dt, t) => {
        for (const c of all) {
          const a = t * c.w + c.ph;
          const x = Math.cos(a) * c.r, z = Math.sin(a) * c.r;
          const yaw = Math.atan2(-Math.sin(a) * c.w, Math.cos(a) * c.w);
          const g = this.ground(x, z);
          c.phase += dt * Math.abs(c.w) * c.r / (c.H * 0.55) * Math.PI;
          const sw = Math.sin(c.phase);
          c.pos[0] = x; c.pos[1] = g + c.H; c.pos[2] = z;
          c.rig.root.setPos(x, g - Math.abs(Math.cos(c.phase)) * 1.2, z);
          c.rig.root.setRotY(yaw);
          const b = c.rig.bones;
          b.legL.setEuler(sw * 0.3, 0, 0);
          b.legR.setEuler(-sw * 0.3, 0, 0);
          b.hips.setEuler(0.03, 0, Math.sin(c.phase * 0.5) * 0.03);
          b.lantern.setEuler(Math.sin(t * 0.5 + c.ph) * 0.12, 0, Math.cos(t * 0.37 + c.ph) * 0.1);
        }
      },
    });
    this.cr.watch.push({ id: 'colossus', range: 170, points: () => all.map((c) => [c.pos[0], 0, c.pos[2]]) });
  }

  // ------------------------------------------------------------ the hill turtle, walking along the shore
  buildTurtle() {
    const W = this.world, P = W.physics;
    const rig = buildHillTurtle(this.ctx, 7);
    rig.root.traverse((n) => { if (n.geometry) n.maxDistance = 900; });
    this.scene.add(rig.root);
    const light = this.scene.addLight({ node: rig.bones.lamp, color: C('#ffc070'), intensity: 2.2, radius: 12, flicker: 0.1, priority: 3 });
    const { R, SH, Y0 } = rig;
    // walkable shell: a dome that goes where the turtle goes (a physics "mover")
    const prof = [[0, Y0 + SH], [R * 0.55, Y0 + SH * 0.9], [R * 0.86, Y0 + SH * 0.55], [R * 0.97, Y0 + 1.4]];
    const domeAt = (d) => {
      if (d > prof[3][0]) return null;
      for (let i = 1; i < prof.length; i++) {
        if (d <= prof[i][0]) {
          const u = (d - prof[i - 1][0]) / (prof[i][0] - prof[i - 1][0]);
          return lerp(prof[i - 1][1], prof[i][1], u * u * (3 - 2 * u) * 0.35 + u * 0.65);
        }
      }
      return null;
    };
    const T = { rig, R, x: 0, z: 0, y: 0, yaw: 0, phase: 0, pos: [0, 0, 0] };
    const shell = P.addMover({
      type: 'fn', x: 0, z: 0, r: R, top: 0, bottom: 0,
      topFn: (lx, lz) => { const h = domeAt(Math.hypot(lx, lz)); return h === null ? null : T.y + h; },
      delta: [0, 0, 0, 0],
    });
    const house = P.addMover({ type: 'box', x: 0, z: 0, hx: 1.15, hz: 1.05, yaw: 0, top: 0, bottom: 0, delta: shell.delta });
    // a gust on the turtle's flank carries you up onto its back
    // (its streaks are drawn around the origin and moved with uOrigin)
    const h = 16;
    const fx = particleSystem(W.gl, 60, { SWIRL: 1 }, (i, rr) => ({
      p: [0, 0, 0], seed: rr.next(), params: [0.5, 1.3, 0.82, 1.5], size: rr.range(0.35, 0.6), life: h / rr.range(7, 10), speed: h, spread: rr.range(1.2, 3),
      color: C(rr.pick(['#bfe8ff', '#d8ccff', '#f4f2ff'])), intensity: rr.range(1.0, 1.5),
    }), { bounds: 'none', seed: 404 });
    fx.maxDistance = 260;
    this.scene.add(fx);
    const gust = { id: 'turtle', x: 0, z: 0, y0: 0, y1: 0, r: 1.5, exit: [0, 0, 0], active: null, fx };
    if (W.sky) W.sky.updrafts.push(gust);
    const speed = 0.75, RAD = 318;
    const w = speed / RAD;
    this.turtle = T;
    // (v9.1c) only its legs and the lower rim shove you: above the rim the walkable shell takes over (before, the
    // shove reached above the rim - an invisible wall when you jumped on, and it pushed you off the edge)
    this.pushers.push({ get x() { return T.x; }, get z() { return T.z; }, r: R * 1.02, get y0() { return T.y - 1; }, get y1() { return T.y + Y0 + 1.1; } });
    const walker = {
      update: (dt, t) => {
        const a = t * w + 1.3;
        const x = Math.cos(a) * RAD, z = Math.sin(a) * RAD;
        const yaw = Math.atan2(-Math.sin(a), Math.cos(a));
        // on the beach it walks; where the shore drops into the deep sea it swims, shell above the waves
        const y = Math.max(this.ground(x, z) - 0.3, W.L.waterLevel - 1.6);
        const dyaw = angleDiff(T.yaw, yaw);
        shell.delta[0] = x - T.x; shell.delta[1] = y - T.y; shell.delta[2] = z - T.z; shell.delta[3] = T.x || T.z ? dyaw : 0;
        T.x = x; T.z = z; T.y = y; T.yaw = yaw;
        T.pos[0] = x; T.pos[1] = y; T.pos[2] = z;
        shell.x = x; shell.z = z; shell.yaw = yaw; shell.top = y + Y0 + SH; shell.bottom = y + 1;
        shell.cx = x; shell.cz = z;
        // the little house moves with the shell
        const c = Math.cos(yaw), s = Math.sin(yaw);
        const hx = 2.2, hz = -1.5;
        house.x = x + hx * c + hz * s; house.z = z - hx * s + hz * c; house.yaw = yaw;
        house.top = y + Y0 + SH - 0.5 + 1.8; house.bottom = y + Y0 + SH - 0.6;
        gust.x = x + (R * 1.18) * c; gust.z = z - (R * 1.18) * s;
        gust.y0 = this.ground(gust.x, gust.z) - 1; gust.y1 = y + Y0 + SH + 2.2;
        gust.exit[0] = x; gust.exit[1] = y + Y0 + SH; gust.exit[2] = z;
        fx.material.uniforms.uOrigin = [gust.x, gust.y0, gust.z];
        rig.root.setPos(x, y, z);
        rig.root.setRotY(yaw);
        T.phase += dt * 0.9;
        const b = rig.bones, sw = Math.sin(T.phase);
        b.legFL.setEuler(sw * 0.18, 0, 0); b.legBR.setEuler(sw * 0.18, 0, 0);
        b.legFR.setEuler(-sw * 0.18, 0, 0); b.legBL.setEuler(-sw * 0.18, 0, 0);
        b.body.setEuler(0, 0, Math.sin(T.phase * 2) * 0.008);
        b.neck.setEuler(0.08 + Math.sin(t * 0.21) * 0.06, Math.sin(t * 0.13) * 0.25, 0);
        b.head.setEuler(Math.sin(t * 0.3) * 0.05, 0, 0);
      },
    };
    this.cr.list.push(walker);
    // put the shell where the turtle really is right away (it used to sit at the world's centre until the
    // first frame, and the player spawned on top of it, eight metres up)
    walker.update(0, 0);
    this.cr.watch.push({ id: 'turtle', range: 60, points: () => [[T.x, 0, T.z]] });
    this.npcs.addInteract({ id: 'turtle', name: 'Dombteknős', pos: T.pos, radius: R + 3, kind: 'look', lines: LINES.turtle, moving: true, visible: () => this.game.player.pos[1] < T.y + 4 });
  }

  // ------------------------------------------------------------ giant plush bunnies wandering the roads
  buildPlushies() {
    const W = this.world, T = W.terrain;
    const all = [];
    const routes = [['glade', 'village'], ['glade', 'rune'], ['moongarden', 'tower'], ['village', 'amanita'], ['glade', 'moongarden'], ['rune', 'lake']];
    routes.forEach(([a, b], i) => {
      const p = T.paths.find((q) => (q.from === a && q.to === b) || (q.from === b && q.to === a));
      if (!p) return;
      const side = i % 2 ? 1 : -1;
      const path = p.pts.map((q, k) => {
        const nq = p.pts[Math.min(p.pts.length - 1, k + 1)], pq = p.pts[Math.max(0, k - 1)];
        const dx = nq[0] - pq[0], dz = nq[1] - pq[1], l = hyp(dx, dz) || 1;
        const off = (p.width || 3) / 2 + 0.9;
        return [q[0] - (dz / l) * off * side, q[1] + (dx / l) * off * side];
      });
      const len = [0];
      for (let k = 1; k < path.length; k++) len.push(len[k - 1] + hyp(path[k][0] - path[k - 1][0], path[k][1] - path[k - 1][1]));
      const rig = buildPlushBunny(this.ctx, 60 + i);
      rig.root.traverse((n) => { if (n.geometry) n.maxDistance = 120; });
      const sc = this.rng.range(1.0, 1.25);
      rig.root.setScale(sc);
      this.scene.add(rig.root);
      const c = { rig, sc, path, len, total: len[len.length - 1], s: this.rng.range(0, len[len.length - 1]), dir: this.rng.sign(), x: 0, z: 0, yaw: 0, phase: this.rng.range(0, 6), stop: 0, look: 0, wave: 0, pos: [0, 0, 0] };
      all.push(c);
      // (v9.1c) its body shoves you aside, but the top of its head is a little travelling platform you can ride
      this.pushers.push({ get x() { return c.x; }, get z() { return c.z; }, r: 0.45 * sc, get y0() { return c.pos[1] - 0.5; }, get y1() { return c.pos[1] + 1.35 * sc; } });
      c.head = this.world.physics.addMover({ type: 'disc', x: 0, z: 0, r: 0.36 * sc, top: -100, bottom: -Infinity, delta: [0, 0, 0, 0] });
      this.npcs.addInteract({ id: 'plush' + i, name: 'Plüssnyuszi', pos: c.pos, radius: 2.6, kind: 'look', verb: 'Megölelem', lines: LINES.plush, idx: (i * 2) % LINES.plush.length, moving: true });
    });
    const at = (c, s) => {
      s = clamp(s, 0, c.total);
      let k = 1;
      while (k < c.len.length - 1 && c.len[k] < s) k++;
      const u = (s - c.len[k - 1]) / Math.max(1e-4, c.len[k] - c.len[k - 1]);
      const a = c.path[k - 1], b = c.path[k];
      return [lerp(a[0], b[0], u), lerp(a[1], b[1], u), Math.atan2(b[0] - a[0], b[1] - a[1])];
    };
    this.cr.list.push({
      update: (dt, t, player) => {
        for (const c of all) {
          const pd = hyp(player.pos[0] - c.x, player.pos[2] - c.z);
          const riding = player.groundSurface === c.head;
          const near = pd < 6 && !riding; // (someone riding on its head: it happily keeps walking)
          c.stop = damp(c.stop, near ? 1 : 0, 3, dt);
          const speed = 0.75 * c.sc * (1 - c.stop);
          c.s += speed * dt * c.dir;
          if (c.s > c.total - 1) c.dir = -1;
          if (c.s < 1) c.dir = 1;
          const [x, z, yaw] = at(c, c.s);
          c.x = x; c.z = z;
          const g = W.h(x, z);
          c.pos[0] = x; c.pos[1] = g; c.pos[2] = z;
          // the head platform travels with it (the delta carries whoever stands there)
          {
            const hd = c.head, top = g + c.sc * (c.rig.bones.hips.position[1] + 1.15);
            hd.delta[0] = hd.top > -50 ? x - hd.x : 0; hd.delta[1] = hd.top > -50 ? top - hd.top : 0; hd.delta[2] = hd.top > -50 ? z - hd.z : 0;
            hd.x = x; hd.z = z; hd.top = top;
          }
          if (pd > 140) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = true;
          const want = near ? Math.atan2(player.pos[0] - x, player.pos[2] - z) : yaw + (c.dir < 0 ? Math.PI : 0);
          c.yaw += angleDiff(c.yaw, want) * Math.min(1, dt * 2);
          c.phase += speed * dt * 4.2;
          const b = c.rig.bones, sw = Math.sin(c.phase) * (1 - c.stop);
          c.rig.root.setPos(x, g, z);
          c.rig.root.setRotY(c.yaw);
          // a soft, heavy waddle; the ears bounce
          b.legL.setEuler(sw * 0.45, 0, 0);
          b.legR.setEuler(-sw * 0.45, 0, 0);
          b.hips.position[1] = 0.46 + Math.abs(Math.cos(c.phase)) * 0.04 * (1 - c.stop);
          b.hips.setEuler(0, 0, Math.cos(c.phase) * 0.07 * (1 - c.stop));
          // near you it stops, tilts its head and looks at you with its button eyes, and waves now and then
          b.head.setEuler(near ? 0.12 : Math.sin(t * 0.4 + c.len[1]) * 0.04, 0, near ? 0.22 + Math.sin(t * 0.8) * 0.05 : Math.sin(c.phase) * 0.05);
          c.wave = near ? c.wave + dt : 0;
          const waving = near && (c.wave % 6) < 2.2;
          b.armL.setEuler(-sw * 0.35 - (waving ? 2.5 : 0), 0, 0.25 + (waving ? Math.sin(t * 7) * 0.3 : 0));
          b.armR.setEuler(sw * 0.35, 0, -0.25);
          b.earL.setEuler(1.05 + Math.sin(c.phase * 2) * 0.12 * (1 - c.stop), 0, -0.12);
          b.earR.setEuler(0.1 + Math.sin(c.phase * 2 + 1) * 0.1 * (1 - c.stop), 0, 0.12);
        }
      },
    });
    this.plushies = all;
    this.cr.watch.push({ id: 'plush', range: 16, points: () => all.map((c) => c.pos) });
  }

  // ------------------------------------------------------------ eye-flowers, in little patches
  buildEyeFlowers() {
    const W = this.world, S = W.L.sites;
    const patches = [[S.moongarden, 30, 4], [S.glade, 38, 3], [S.pyramid, 46, 3], [S.watcher, 28, 3], [S.lake, S.lake.lakeR + 18, 4], [S.amanita, 26, 3]];
    const all = [];
    patches.forEach(([s, r, n], hi) => {
      if (!s) return;
      const a0 = this.rng.range(0, TAU);
      const home = this.cr.freeSpot(s.x + Math.cos(a0) * r, s.z + Math.sin(a0) * r, 12) || [s.x + Math.cos(a0) * r, s.z + Math.sin(a0) * r];
      for (let i = 0; i < n; i++) {
        const p = this.cr.freeSpot(home[0], home[1], 6) || [home[0] + i * 1.5, home[1]];
        const rig = buildEyeFlower(this.ctx, 700 + hi * 10 + i);
        const sc = this.rng.range(0.9, 1.3);
        rig.root.traverse((m) => { if (m.geometry) { m.maxDistance = 110; m.castShadow = m.geometry.bounds.radius > 0.2; } });
        rig.root.setScale(sc);
        this.scene.add(rig.root);
        const c = { rig, sc, home, x: p[0], z: p[1], yaw: this.rng.range(0, TAU), speed: 0, target: null, wait: this.rng.range(0, 4), phase: this.rng.range(0, 10), blink: this.rng.range(1, 5), lid: 0, look: [0, 0], pos: [p[0], W.h(p[0], p[1]), p[1]] };
        all.push(c);
        // you can't walk through the stem and the root bulb
        this.pushers.push({ get x() { return c.x; }, get z() { return c.z; }, r: 0.3 * sc, get y0() { return c.pos[1] - 0.5; }, get y1() { return c.pos[1] + 1.9 * sc; } });
        const it = this.npcs.addInteract({ id: 'eyeflower' + all.length, name: 'Szemvirág', pos: c.pos, radius: 2.2 * sc, kind: 'look', lines: LINES.eyeflower, idx: (all.length * 2) % LINES.eyeflower.length, moving: true });
        Object.defineProperty(it, 'focus', { get: () => [c.x, c.pos[1] + 1.55 * c.sc, c.z] });
      }
    });
    this.eyeFlowers = all;
    this.cr.list.push({
      update: (dt, t, player) => {
        for (const c of all) {
          const dxp = player.pos[0] - c.x, dzp = player.pos[2] - c.z, pd = hyp(dxp, dzp);
          if (pd > 120) { c.rig.root.visible = false; continue; }
          c.rig.root.visible = true;
          let sp = 0, want = null;
          const watching = pd < 9 * c.sc;
          if (pd < 3.5 * c.sc) {
            // you are close: it stands still and stares
            want = Math.atan2(dxp, dzp) * 0.35 + c.yaw * 0.65;
          } else if (!c.target) {
            c.wait -= dt;
            if (c.wait <= 0) { c.target = this.cr.freeSpot(c.home[0], c.home[1], 10, 6); c.wait = this.rng.range(2, 6); }
          } else {
            const tx = c.target[0] - c.x, tz = c.target[1] - c.z;
            if (hyp(tx, tz) < 0.4) c.target = null;
            else { want = Math.atan2(tx, tz); sp = 0.45 * c.sc; }
          }
          if (want !== null) c.yaw += angleDiff(c.yaw, want) * Math.min(1, dt * 1.8);
          c.speed = damp(c.speed, sp, 3, dt);
          const nx = c.x + Math.sin(c.yaw) * c.speed * dt, nz = c.z + Math.cos(c.yaw) * c.speed * dt;
          if (c.speed > 0.05 && (W.waterDepth(nx, nz) > -0.25 || hyp(nx - c.home[0], nz - c.home[1]) > 14 || W.physics.blocked(nx, nz, W.h(c.x, c.z), 0.25 * c.sc, 1.2, 0.4, c.x, c.z))) { c.target = null; c.speed = 0; c.wait = 1; }
          else { c.x = nx; c.z = nz; }
          const y = W.h(c.x, c.z);
          c.pos[0] = c.x; c.pos[1] = y; c.pos[2] = c.z;
          c.rig.root.setPos(c.x, y, c.z);
          c.rig.root.setRotY(c.yaw);
          if (pd > 70) continue;
          const b = c.rig.bones;
          const walk = Math.min(1, c.speed * 3);
          c.phase += dt * (c.speed * 7 + 0.3);
          const sw = Math.sin(c.phase) * walk;
          b.legL.setEuler(sw * 0.6, 0, 0);
          b.legR.setEuler(-sw * 0.6, 0, 0);
          b.body.position[1] = 0.32 + Math.abs(Math.cos(c.phase)) * 0.04 * walk;
          b.body.setEuler(0, 0, Math.cos(c.phase) * 0.06 * walk);
          // the head sways; the eye follows you (within what an eye can turn)
          let ly = 0, lp = 0;
          if (watching) {
            const hy = c.pos[1] + 1.55 * c.sc;
            ly = clamp(angleDiff(c.yaw, Math.atan2(dxp, dzp)), -1.1, 1.1);
            lp = clamp(Math.atan2(hy - (player.pos[1] + 1.0), pd), -0.5, 0.6);
          }
          c.look[0] = damp(c.look[0], ly, 4, dt);
          c.look[1] = damp(c.look[1], lp, 4, dt);
          b.head.setEuler(Math.sin(t * 0.7 + c.home[0]) * 0.06 + c.look[1] * 0.3, c.look[0] * 0.45, Math.sin(t * 0.5 + c.phase) * 0.08);
          b.eye.setEuler(c.look[1] * 0.7, c.look[0] * 0.55, 0);
          // blinks now and then (slowly, like something that has all the time in the world)
          c.blink -= dt;
          if (c.blink <= 0) { c.lid = 1; c.blink = this.rng.range(2.5, 6); }
          c.lid = Math.max(0, c.lid - dt * 2.2);
          const closed = Math.sin(Math.min(1, c.lid) * Math.PI);
          b.lid.setEuler(-2.0 + closed * 2.0, 0, 0);
        }
      },
    });
    this.cr.watch.push({ id: 'eyeflower', range: 14, points: () => all.map((c) => [c.x, 0, c.z]) });
  }

  // ------------------------------------------------------------ paper lanterns that follow you a while
  buildLamplings() {
    const W = this.world, S = W.L.sites;
    const homes = [S.village, S.rune, S.swamp, S.amanita];
    const groups = [];
    homes.forEach((s, gi) => {
      const a0 = this.rng.range(0, TAU);
      const home = this.cr.freeSpot(s.x + Math.cos(a0) * (s.r + 4), s.z + Math.sin(a0) * (s.r + 4), 8) || [s.x, s.z];
      const members = [];
      for (let i = 0; i < 4; i++) {
        const rig = buildLampling(this.ctx, 800 + gi * 10 + i);
        rig.root.traverse((m) => { if (m.geometry) { m.maxDistance = 90; m.castShadow = false; } });
        this.scene.add(rig.root);
        members.push({ rig, x: home[0] + this.rng.range(-2, 2), z: home[1] + this.rng.range(-2, 2), yaw: this.rng.range(0, TAU), phase: this.rng.range(0, 10), speed: 0, off: [this.rng.range(-1.2, 1.2), this.rng.range(-1.2, 1.2)] });
      }
      const light = W.light([home[0], W.h(home[0], home[1]) + 0.6, home[1]], C('#ffb870'), 1.2, 6, 0.15, 2);
      groups.push({ home, members, light, follow: 0 });
    });
    this.lamplings = groups;
    this.cr.list.push({
      update: (dt, t, player) => {
        for (const g of groups) {
          const dh = hyp(player.pos[0] - g.home[0], player.pos[2] - g.home[1]);
          if (dh > 120) { for (const m of g.members) m.rig.root.visible = false; g.light.enabled = false; continue; }
          g.light.enabled = true;
          // curious: they tag along when you come close, and go home when you wander off
          const c0 = g.members[0];
          const dp = hyp(player.pos[0] - c0.x, player.pos[2] - c0.z);
          if (dp < 6 && !player.mount) g.follow = 1;
          if (dh > 30 || player.mount || player.pos[1] > W.h(player.pos[0], player.pos[2]) + 3) g.follow = 0;
          let cx = 0, cz = 0;
          for (const m of g.members) {
            m.rig.root.visible = true;
            const tx = g.follow ? player.pos[0] + m.off[0] - Math.sin(player.yaw) * 1.2 : g.home[0] + m.off[0] * 1.8 + Math.sin(t * 0.3 + m.phase) * 1.5;
            const tz = g.follow ? player.pos[2] + m.off[1] - Math.cos(player.yaw) * 1.2 : g.home[1] + m.off[1] * 1.8 + Math.cos(t * 0.27 + m.phase) * 1.5;
            const dx = tx - m.x, dz = tz - m.z, d = hyp(dx, dz);
            const want = d > 0.4 ? Math.min(g.follow ? 4.5 : 0.8, d * 1.5) : 0;
            m.speed = damp(m.speed, want, 4, dt);
            if (d > 0.05) m.yaw += angleDiff(m.yaw, Math.atan2(dx, dz)) * Math.min(1, dt * 5);
            const nx = m.x + Math.sin(m.yaw) * m.speed * dt, nz = m.z + Math.cos(m.yaw) * m.speed * dt;
            if (W.waterDepth(nx, nz) < 0.15) { m.x = nx; m.z = nz; }
            m.phase += dt * (2 + m.speed * 12);
            const y = W.physics.ground(m.x, m.z, W.h(m.x, m.z) + 0.5, 0.5);
            const hop = Math.abs(Math.sin(m.phase)) * 0.05 * Math.min(1, m.speed);
            m.rig.root.setPos(m.x, y + hop, m.z);
            m.rig.root.setRotY(m.yaw);
            const b = m.rig.bones, sw = Math.sin(m.phase) * Math.min(1, m.speed);
            b.legL.setEuler(sw * 0.8, 0, 0);
            b.legR.setEuler(-sw * 0.8, 0, 0);
            b.body.setEuler(Math.sin(t * 2 + m.phase) * 0.06, 0, sw * 0.1);
            cx += m.x; cz += m.z;
          }
          cx /= g.members.length; cz /= g.members.length;
          g.light.position = [cx, W.h(cx, cz) + 0.6, cz];
        }
      },
    });
    this.cr.watch.push({ id: 'lampling', range: 12, points: () => groups.map((g) => [g.members[0].x, 0, g.members[0].z]) });
  }

  // push the player out of the moving giants (called after the player moved)
  shove(pl) {
    for (const p of this.pushers) {
      if (pl.pos[1] > p.y1 || pl.pos[1] < p.y0) continue;
      const dx = pl.pos[0] - p.x, dz = pl.pos[2] - p.z, d = hyp(dx, dz);
      if (d < p.r + pl.radius && d > 1e-4) {
        const k = (p.r + pl.radius) / d;
        pl.pos[0] = p.x + dx * k; pl.pos[2] = p.z + dz * k;
      }
    }
  }
}
