// (v8) Two languages: English (the default) and Hungarian (the language the game was written in).
// Every string in the code is Hungarian; T() looks it up in the English dictionary when the game runs in
// English. T('Rúnakő {0} / {1}', a, b) translates the template first, then fills in {0}, {1}...
// The choice is remembered in the browser; ?lang=hu or ?lang=en in the address overrides it.
import { EN, EN_PATTERNS } from './data/en.js';

const KEY = 'takeyourtime.lang';
const HU_CHARS = /[áéíóöőúüűÁÉÍÓÖŐÚÜŰ]/;

function detect() {
  try {
    const q = new URLSearchParams(location.search).get('lang');
    if (q === 'en' || q === 'hu') return q;
  } catch (e) { /* no location */ }
  try {
    const s = localStorage.getItem(KEY);
    if (s === 'en' || s === 'hu') return s;
  } catch (e) { /* storage blocked */ }
  return 'en';
}

let lang = detect();
const listeners = [];
export const misses = new Set();

export function getLang() {
  return lang;
}
export function setLang(l) {
  if (l !== 'en' && l !== 'hu') return;
  try { localStorage.setItem(KEY, l); } catch (e) { /* storage blocked */ }
  if (l === lang) return;
  lang = l;
  try { document.documentElement.lang = l; } catch (e) { /* no document */ }
  for (const fn of listeners) fn(l);
}
export function onLang(fn) {
  listeners.push(fn);
}

export function T(s, ...args) {
  if (typeof s !== 'string') return s;
  let out = s;
  if (lang === 'en' && s) {
    const hit = EN[s];
    if (hit !== undefined) out = hit;
    else {
      let found = false;
      for (const [re, fn] of EN_PATTERNS) {
        const m = re.exec(s);
        if (m) { out = fn(m, T); found = true; break; }
      }
      if (!found && HU_CHARS.test(s)) misses.add(s);
    }
  }
  if (args.length) out = out.replace(/\{(\d+)\}/g, (m, i) => (args[i] !== undefined ? String(args[i]) : m));
  return out;
}

// static page text: translate every text node and a few attributes, remembering the Hungarian originals
const orig = new WeakMap();
const ATTRS = ['placeholder', 'aria-label', 'title'];
export function translateDOM(root) {
  if (!root) return;
  const walk = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const texts = [];
  while (walk.nextNode()) texts.push(walk.currentNode);
  for (const n of texts) {
    const pe = n.parentElement;
    if (!pe || pe.closest('[data-noi18n],script,style,noscript,textarea')) continue;
    if (!orig.has(n)) orig.set(n, n.nodeValue);
    const o = orig.get(n);
    const trimmed = o.trim();
    if (!trimmed) continue;
    const tr = T(trimmed);
    n.nodeValue = o.replace(trimmed, tr);
  }
  for (const el of root.querySelectorAll('[placeholder],[aria-label],[title]')) {
    if (el.closest('[data-noi18n]')) continue;
    let o = orig.get(el);
    if (!o) {
      o = {};
      for (const a of ATTRS) if (el.hasAttribute(a)) o[a] = el.getAttribute(a);
      orig.set(el, o);
    }
    for (const a in o) el.setAttribute(a, T(o[a]));
  }
}
