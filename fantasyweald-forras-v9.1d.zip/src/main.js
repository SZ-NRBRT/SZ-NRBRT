// Álomrengeteg — entry point.
import { createContext } from './engine/gl.js';
import { Geometry } from './engine/geometry.js';
import { Material, Mesh, GpuGeometry } from './engine/scene.js';
import { Game } from './game/game.js';
import { T, translateDOM, getLang, setLang, onLang, misses } from './i18n.js';
import { LINES, SCRIPT, ABILITIES } from './data/dialogue.js';
import { LORE } from './data/lore.js';
import { SPECIES } from './game/creatures.js';
import { QUESTS, EXTRA_ABILITIES } from './game/quests.js';

const canvas = document.getElementById('game');
// (v8) language: English by default, Hungarian on request; the switch is on the title screen and in settings
const uiRoot = document.getElementById('ui');
const markLang = () => {
  document.documentElement.lang = getLang();
  for (const b of document.querySelectorAll('.lang-switch button')) b.setAttribute('aria-pressed', String(b.dataset.lang === getLang()));
  canvas.setAttribute('aria-label', T('FantasyWeald játéktér'));
};
translateDOM(uiRoot);
markLang();
for (const b of document.querySelectorAll('.lang-switch button')) b.addEventListener('click', () => setLang(b.dataset.lang));
// (v9.1) no selecting or dragging page text / links / images (typing fields excepted), no context menu on the game
{
  const typing = (t) => { const el = t && t.nodeType === 1 ? t : t && t.parentElement; return !!(el && el.closest && el.closest('input, textarea, [contenteditable="true"]')); };
  document.addEventListener('selectstart', (e) => { if (!typing(e.target)) e.preventDefault(); });
  document.addEventListener('dragstart', (e) => { if (!typing(e.target)) e.preventDefault(); });
  document.addEventListener('contextmenu', (e) => { if (!typing(e.target)) e.preventDefault(); });
}
const gl = createContext(canvas);

function fail(msg) {
  const t = document.getElementById('loadText');
  if (t) t.textContent = T(msg);
  const bar = document.querySelector('.load-bar');
  if (bar) bar.style.display = 'none';
}

if (!gl) {
  fail('Ez a böngésző nem támogatja a WebGL 2-t. Próbáld meg egy friss Chrome, Edge, Firefox vagy Safari böngészőben.');
} else {
  const game = new Game(gl, canvas);
  window.__game = game;
  // (for the test harness: translation coverage)
  window.__dbg = { Geometry, Material, Mesh, GpuGeometry };
  window.__i18n = { T, misses, setLang, getLang, data: { LINES, SCRIPT, ABILITIES, LORE, SPECIES, QUESTS, EXTRA_ABILITIES } };
  onLang(() => {
    translateDOM(uiRoot);
    markLang();
    try { game.relang(); } catch (e) { console.error(e); }
  });
  canvas.addEventListener('webglcontextlost', (e) => {
    e.preventDefault();
    fail('A grafikus kártya kapcsolata megszakadt. Töltsd újra az oldalt.');
    document.getElementById('loading').hidden = false;
  });
  game.init().catch((e) => {
    console.error(e);
    fail(T('Hiba történt betöltés közben: ') + (e && e.message ? e.message : e));
  });
  // debug helpers used by the test harness
  game.debugView = (x, z, yaw, pitch = 0.25, dist = 5, y = null) => {
    game.player.spawn(x, z, yaw, y);
    game.follow.yaw = yaw;
    game.follow.pitch = pitch;
    game.follow.targetDist = dist;
    game.follow.snap(game.player);
  };
  game.step = (n = 1, dt = 1 / 30) => { for (let i = 0; i < n; i++) game.frame(dt, i === n - 1); };
}
