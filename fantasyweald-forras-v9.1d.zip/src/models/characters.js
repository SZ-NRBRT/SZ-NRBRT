// Rigged characters built from primitives. Each builder returns { root, bones, parts }.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep } from '../engine/math.js';
import { C } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

export function makeMesh(ctx, geo, mat, name = '') {
  const m = new Mesh(new GpuGeometry(ctx.gl, geo), mat, name);
  return m;
}

function ellipsoid(rx, ry, rz, ws = 12, hs = 8) {
  const g = Geometry.sphere(1, ws, hs);
  g.scale(rx, ry, rz);
  return g;
}

// Hat as two parts: base cone and floppy tip (separate node so it can sway)
function hatParts(baseR, height, color, { brim = 0, tipFrac = 0.45, curl = 0.25 } = {}) {
  const hb = height * (1 - tipFrac);
  const prof = catmullRom([[baseR * 1.02, -0.02], [baseR, 0.03], [baseR * 0.82, hb * 0.35], [baseR * 0.6, hb * 0.75], [baseR * 0.48, hb]], 3);
  const base = Geometry.lathe(prof, 20);
  base.displace((p) => noise.n3(p[0] * 9, p[1] * 5, p[2] * 9) * baseR * 0.04, true);
  base.setColor(color, 1);
  // folded band
  const band = Geometry.torus(baseR * 1.0, baseR * 0.09, 6, 20);
  band.translate(0, 0.01, 0);
  band.setColor(mix3(color, [0, 0, 0], 0.25), 0.8);
  base.append(band);
  if (brim > 0) {
    const b = Geometry.lathe([[baseR * 0.95, 0.0], [brim, -0.02], [brim * 1.02, -0.035], [brim * 0.9, -0.03], [baseR * 0.9, -0.01]], 28);
    b.deform((p) => {
      const a = Math.atan2(p[2], p[0]);
      return [p[0], p[1] + Math.sin(a * 2 + 0.5) * 0.02 * brim, p[2]];
    });
    b.computeNormals();
    b.setColor(mix3(color, [0, 0, 0], 0.1), 0.9);
    base.append(b);
  }
  const th = height * tipFrac;
  const tipProf = [];
  for (let j = 0; j <= 8; j++) {
    const t = j / 8;
    tipProf.push([baseR * 0.48 * (1 - t) + 0.004, t * th]);
  }
  const tip = Geometry.lathe(tipProf, 14);
  tip.deform((p) => {
    const t = p[1] / th;
    return [p[0], p[1] - t * t * curl * th * 0.5, p[2] - t * t * curl * th];
  });
  tip.computeNormals();
  tip.setColor(color, 1);
  return { base, tip, tipY: hb };
}

// ------------------------------------------------------------------ gnome
// Gnome folk size (v7 tried 0.4: tiny gnomes in a giant world; back to the original since v7.2).
export const GNOME = 1;

export function buildGnome(ctx, opts = {}) {
  const {
    coat = '#2b44b8', hat = '#b3202a', beard = '#e6e9f2', skin = '#d9a38b', boots = '#3a2a24',
    belt = '#4a3326', hatHeight = 0.62, staff = false, seed = 1, scale = 1, fishing = false,
  } = opts;
  const M = ctx.M;
  const root = new Node('gnome');
  const inner = new Node('scale');
  inner.setScale(scale * GNOME);
  root.add(inner);
  const bones = {};
  const hips = new Node('hips'); hips.setPos(0, 0.3, 0); inner.add(hips); bones.hips = hips;
  const torso = new Node('torso'); torso.setPos(0, 0, 0); hips.add(torso); bones.torso = torso;

  // coat (lathe skirt + chest)
  const coatProf = catmullRom([[0.25, -0.13], [0.24, -0.08], [0.2, 0.05], [0.17, 0.18], [0.15, 0.27], [0.1, 0.34], [0.04, 0.37]], 3);
  const coatG = Geometry.lathe(coatProf, 20);
  coatG.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const fold = 1 + Math.sin(a * 7 + seed) * 0.04 * smoothstep(0.1, -0.13, p[1]);
    // (v9) sloping shoulders: the top of the coat widens sideways and runs down over the sleeves
    const sh = 1 + 0.46 * smoothstep(0.17, 0.3, p[1]);
    return [p[0] * fold * sh, p[1] - 0.012 * smoothstep(0.24, 0.34, p[1]) * Math.abs(Math.cos(a)), p[2] * fold * 0.92];
  });
  coatG.computeNormals();
  coatG.paint((p) => mix3(C(coat, 0.55), C(coat), smoothstep(-0.13, 0.2, p[1])).concat([smoothstep(-0.15, 0.1, p[1]) * 0.4 + 0.6]));
  // coat buttons
  for (let i = 0; i < 3; i++) {
    const b = ellipsoid(0.014, 0.014, 0.01, 6, 4);
    b.translate(0, 0.02 + i * 0.07, 0.19 - i * 0.022);
    b.setColor(C('#d9b45a'), 1);
    b.setExtra([0.3]);
    coatG.append(b);
  }
  torso.add(makeMesh(ctx, coatG, M.cloth, 'coat'));
  // belt
  const beltG = Geometry.torus(0.19, 0.025, 6, 22);
  beltG.scale(1, 1, 0.92);
  beltG.translate(0, 0.06, 0);
  beltG.setColor(C(belt), 0.9);
  const buckle = Geometry.box(0.07, 0.055, 0.02);
  buckle.translate(0, 0.06, 0.18);
  buckle.setColor(C('#d8b050'), 1);
  buckle.setExtra([0.25]);
  beltG.append(buckle);
  torso.add(makeMesh(ctx, beltG, M.wood, 'belt'));

  // head
  const head = new Node('head'); head.setPos(0, 0.44, 0.0); torso.add(head); bones.head = head;
  const headG = ellipsoid(0.13, 0.125, 0.125, 16, 12);
  const nose = ellipsoid(0.052, 0.05, 0.058, 10, 8);
  nose.translate(0, -0.015, 0.125);
  const earL = Geometry.cylinder(0.0, 0.035, 0.09, 6, 1);
  earL.rotateZ(Math.PI / 2 + 0.3); earL.translate(0.12, 0.01, -0.01);
  const earR = Geometry.cylinder(0.0, 0.035, 0.09, 6, 1);
  earR.rotateZ(-Math.PI / 2 - 0.3); earR.translate(-0.12, 0.01, -0.01);
  headG.append(nose); headG.append(earL); headG.append(earR);
  headG.paint((p) => {
    const cheek = Math.exp(-((p[0] * p[0] + (p[1] + 0.02) ** 2) * 40)) * 0.25;
    const noseRed = p[2] > 0.12 ? 0.3 : 0;
    return mix3(C(skin), C('#e0707a'), cheek + noseRed).concat([1]);
  });
  head.add(makeMesh(ctx, headG, M.skin, 'head'));
  // eyes
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = ellipsoid(0.02, 0.024, 0.014, 8, 6);
    e.translate(s * 0.046, 0.028, 0.118);
    e.setColor([0.01, 0.01, 0.02], 1);
    eyes.append(e);
    const hl = ellipsoid(0.005, 0.005, 0.004, 5, 4);
    hl.translate(s * 0.046 + 0.007, 0.036, 0.13);
    hl.setColor([1, 1, 1], 1);
    hl.setExtra([1.5]);
    eyes.append(hl);
  }
  head.add(makeMesh(ctx, eyes, M.glowSoft, 'eyes'));
  // beard + brows + moustache
  const beardProf = catmullRom([[0.0, -0.37], [0.03, -0.33], [0.09, -0.22], [0.13, -0.1], [0.135, -0.02], [0.12, 0.02]], 3);
  const beardG = Geometry.lathe(beardProf, 18);
  beardG.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    // push to front, flatten back
    const front = Math.max(0, Math.sin(a)) ;
    const k = 0.55 + 0.45 * front;
    const wave = Math.sin(p[1] * 40 + a * 3) * 0.006;
    const drop = Math.max(0, -p[1]);
    // hang forward over the coat as it gets longer
    return [p[0] * (0.95 + wave * 3), p[1], p[2] * k + 0.045 + drop * 0.42 + wave];
  });
  beardG.computeNormals();
  beardG.paint((p) => mix3(C(beard, 0.75), C(beard), smoothstep(-0.37, -0.1, p[1])).concat([1]));
  for (const s of [-1, 1]) {
    const brow = ellipsoid(0.035, 0.014, 0.018, 8, 5);
    brow.rotateZ(s * -0.25);
    brow.translate(s * 0.05, 0.06, 0.1);
    brow.setColor(C(beard), 1);
    beardG.append(brow);
    const mous = ellipsoid(0.055, 0.02, 0.025, 8, 5);
    mous.rotateZ(s * 0.35);
    mous.translate(s * 0.045, -0.055, 0.115);
    mous.setColor(C(beard), 1);
    beardG.append(mous);
  }
  const beardNode = new Node('beard');
  head.add(beardNode);
  beardNode.add(makeMesh(ctx, beardG, M.hair, 'beard'));
  bones.beard = beardNode;

  // hat
  const hp = hatParts(0.142, hatHeight, C(hat), { tipFrac: 0.5, curl: 0.35 });
  const hatNode = new Node('hat'); hatNode.setPos(0, 0.055, -0.01); hatNode.setEuler(-0.08, 0, 0); head.add(hatNode);
  hatNode.add(makeMesh(ctx, hp.base, M.cloth, 'hat'));
  const tipNode = new Node('hatTip'); tipNode.setPos(0, hp.tipY, 0); hatNode.add(tipNode);
  tipNode.add(makeMesh(ctx, hp.tip, M.cloth, 'hatTip'));
  bones.hat = hatNode; bones.hatTip = tipNode;

  // arms
  for (const s of [-1, 1]) {
    const sh = new Node(s < 0 ? 'armR' : 'armL');
    sh.setPos(s * 0.155, 0.29, 0);
    torso.add(sh);
    // (v9) the sleeve is closed on top, but low and slim: its top tucks in under the coat's shoulder
    const arm = Geometry.lathe(catmullRom([[0.05, -0.235], [0.07, -0.23], [0.065, -0.21], [0.052, -0.13], [0.052, -0.05], [0.05, 0.0], [0.043, 0.028], [0.026, 0.044], [0.0, 0.05]], 2), 10);
    arm.rotateZ(s * 0.12);
    arm.paint((p) => mix3(C(coat, 0.7), C(coat), smoothstep(-0.25, 0, p[1])).concat([1]));
    const hand = ellipsoid(0.042, 0.048, 0.04, 8, 6);
    hand.translate(s * 0.025, -0.26, 0.01);
    hand.setColor(C(skin), 1);
    sh.add(makeMesh(ctx, arm, M.cloth));
    sh.add(makeMesh(ctx, hand, M.skin));
    if (s < 0) bones.armR = sh; else bones.armL = sh;
  }

  // legs + boots
  for (const s of [-1, 1]) {
    const leg = new Node(s < 0 ? 'legR' : 'legL');
    leg.setPos(s * 0.085, -0.08, 0);
    hips.add(leg);
    const lg = Geometry.cylinder(0.045, 0.05, 0.16, 8, 1);
    lg.translate(0, -0.2, 0);
    lg.setColor(C('#2a2230'), 0.7);
    const boot = ellipsoid(0.06, 0.05, 0.095, 10, 6);
    boot.translate(0, -0.19, 0.03);
    boot.deform((p) => [p[0], Math.max(p[1], -0.215), p[2]]);
    boot.setColor(C(boots), 0.9);
    const tip = Geometry.cylinder(0.0, 0.035, 0.07, 6, 1);
    tip.rotateX(Math.PI / 2 - 0.5); tip.translate(0, -0.18, 0.1);
    tip.setColor(C(boots), 0.9);
    lg.append(boot); lg.append(tip);
    leg.add(makeMesh(ctx, lg, M.wood));
    if (s < 0) bones.legR = leg; else bones.legL = leg;
  }

  // staff
  if (staff) {
    const st = new Node('staff');
    st.setPos(-0.02, -0.265, 0.03);
    bones.armR.add(st);
    const pts = [];
    for (let i = 0; i <= 8; i++) {
      const t = i / 8;
      pts.push([Math.sin(t * 5) * 0.012, -0.35 + t * 1.25, Math.cos(t * 4) * 0.01]);
    }
    const sg = Geometry.tube(pts, (t) => 0.022 * (1 - t * 0.3), 7, { capStart: true });
    // crooked claw holding the orb
    for (let k = 0; k < 4; k++) {
      const a = (k / 4) * TAU;
      const cp = [];
      for (let i = 0; i <= 4; i++) {
        const t = i / 4;
        cp.push([Math.cos(a) * 0.05 * Math.sin(t * 2.6), 0.9 + t * 0.14, Math.sin(a) * 0.05 * Math.sin(t * 2.6)]);
      }
      sg.append(Geometry.tube(cp, (t) => 0.012 * (1 - t * 0.6), 5));
    }
    sg.displace((p) => noise.n3(p[0] * 30, p[1] * 12, p[2] * 30) * 0.004, true);
    sg.setColor(C('#4a3526'), 1);
    st.add(makeMesh(ctx, sg, M.wood, 'staff'));
    const orb = ellipsoid(0.055, 0.055, 0.055, 14, 10);
    orb.translate(0, 0.99, 0);
    orb.setColor(C('#a8ecff'), 1);
    orb.setExtra([2.2]);
    const orbNode = new Node('orb');
    st.add(orbNode);
    orbNode.add(makeMesh(ctx, orb, M.glass, 'orb'));
    const orbLight = new Node('orbLight');
    orbLight.setPos(0, 0.99, 0);
    st.add(orbLight);
    bones.staff = st;
    bones.orb = orbLight;
  }
  if (fishing) {
    const rod = new Node('rod');
    rod.setPos(0, -0.26, 0.03);
    rod.setEuler(-0.9, 0, 0);
    bones.armL.add(rod);
    const rg = Geometry.cylinder(0.006, 0.014, 1.9, 5, 1);
    rg.setColor(C('#5a4636'), 1);
    rod.add(makeMesh(ctx, rg, M.wood));
    bones.rod = rod;
  }
  return { root, bones, height: (0.3 + 0.44 + 0.13 + hatHeight * 0.8) * scale * GNOME };
}

// ------------------------------------------------------------------ tall wizard
export function buildWizard(ctx, opts = {}) {
  const { robe = '#27326f', hat = '#1f2553', beard = '#e2e6f3', skin = '#c9937f', seed = 3 } = opts;
  const M = ctx.M;
  const root = new Node('wizard');
  const bones = {};
  const body = new Node('body'); root.add(body); bones.body = body;
  const robeProf = catmullRom([[0.48, 0.0], [0.44, 0.1], [0.36, 0.5], [0.3, 0.9], [0.28, 1.2], [0.27, 1.45], [0.22, 1.58], [0.1, 1.65]], 4);
  const robeG = Geometry.lathe(robeProf, 28);
  robeG.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const fold = 1 + Math.sin(a * 9 + seed) * 0.05 * smoothstep(1.0, 0.0, p[1]) + noise.n2(a * 2, p[1] * 2) * 0.03;
    return [p[0] * fold, p[1], p[2] * fold * 0.9];
  });
  robeG.computeNormals();
  robeG.paint((p) => mix3(C(robe, 0.45), C(robe), smoothstep(0.0, 0.8, p[1])).concat([smoothstep(-0.1, 0.5, p[1]) * 0.4 + 0.6]));
  // rope belt
  const beltG = Geometry.torus(0.29, 0.03, 6, 24);
  beltG.scale(1, 1, 0.9);
  beltG.translate(0, 1.05, 0);
  beltG.setColor(C('#6e5a43'), 1);
  robeG.append(beltG);
  body.add(makeMesh(ctx, robeG, M.robe, 'robe'));

  const head = new Node('head'); head.setPos(0, 1.82, 0.02); body.add(head); bones.head = head;
  const headG = ellipsoid(0.17, 0.2, 0.17, 16, 12);
  const nose = Geometry.lathe([[0.05, 0], [0.045, 0.06], [0.03, 0.12], [0.0, 0.14]], 8);
  nose.rotateX(Math.PI / 2 + 0.35);
  nose.translate(0, 0.0, 0.14);
  headG.append(nose);
  headG.setColor(C(skin), 1);
  head.add(makeMesh(ctx, headG, M.skin, 'head'));
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = ellipsoid(0.022, 0.026, 0.012, 8, 6);
    e.translate(s * 0.065, 0.05, 0.155);
    e.setColor(C('#cfe3ff'), 1);
    e.setExtra([0.6]);
    eyes.append(e);
    const pu = ellipsoid(0.01, 0.012, 0.006, 6, 4);
    pu.translate(s * 0.065, 0.05, 0.166);
    pu.setColor([0.0, 0.0, 0.0], 1);
    eyes.append(pu);
  }
  head.add(makeMesh(ctx, eyes, M.glowSoft));
  const beardProf = catmullRom([[0.0, -1.05], [0.05, -0.95], [0.14, -0.65], [0.19, -0.35], [0.2, -0.1], [0.17, 0.02]], 4);
  const beardG = Geometry.lathe(beardProf, 20);
  beardG.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const k = 0.5 + 0.5 * Math.max(0, Math.sin(a));
    const strand = Math.sin(a * 11 + p[1] * 6) * 0.012;
    const drop = Math.max(0, -p[1]);
    return [p[0] * (1 + strand * 2), p[1], p[2] * k + 0.07 + drop * 0.22 + strand];
  });
  beardG.computeNormals();
  beardG.paint((p) => mix3(C(beard, 0.7), C(beard), smoothstep(-1.0, -0.2, p[1])).concat([1]));
  for (const s of [-1, 1]) {
    const brow = ellipsoid(0.06, 0.022, 0.03, 8, 5);
    brow.rotateZ(s * -0.35);
    brow.translate(s * 0.07, 0.1, 0.14);
    brow.setColor(C(beard), 1);
    beardG.append(brow);
  }
  // long hair at the back
  const hairG = Geometry.lathe(catmullRom([[0.05, -0.75], [0.16, -0.5], [0.2, -0.2], [0.19, 0.05], [0.12, 0.14]], 3), 16);
  hairG.deform((p) => [p[0], p[1], p[2] * 0.8 - 0.05]);
  hairG.computeNormals();
  hairG.setColor(C(beard, 0.85), 1);
  beardG.append(hairG);
  head.add(makeMesh(ctx, beardG, M.hair, 'beard'));
  const hp = hatParts(0.21, 1.0, C(hat), { brim: 0.52, tipFrac: 0.5, curl: 0.5 });
  const hatNode = new Node('hat'); hatNode.setPos(0, 0.12, -0.02); hatNode.setEuler(-0.1, 0, 0.05); head.add(hatNode);
  hatNode.add(makeMesh(ctx, hp.base, M.robe, 'hat'));
  const tipNode = new Node('hatTip'); tipNode.setPos(0, hp.tipY, 0); hatNode.add(tipNode);
  tipNode.add(makeMesh(ctx, hp.tip, M.robe));
  bones.hat = hatNode; bones.hatTip = tipNode;
  // arms (big sleeves)
  for (const s of [-1, 1]) {
    const sh = new Node(s < 0 ? 'armR' : 'armL');
    sh.setPos(s * 0.28, 1.52, 0.02);
    body.add(sh);
    const sl = Geometry.lathe(catmullRom([[0.12, -0.61], [0.18, -0.6], [0.17, -0.55], [0.11, -0.35], [0.09, -0.1], [0.085, 0.04], [0.07, 0.075], [0.04, 0.1], [0.0, 0.108]], 3), 12);
    sl.paint((p) => mix3(C(robe, 0.6), C(robe), smoothstep(-0.6, 0, p[1])).concat([1]));
    const hand = ellipsoid(0.07, 0.08, 0.06, 8, 6);
    hand.translate(0, -0.66, 0.02);
    hand.setColor(C(skin), 1);
    sh.add(makeMesh(ctx, sl, M.robe));
    sh.add(makeMesh(ctx, hand, M.skin));
    if (s < 0) bones.armR = sh; else bones.armL = sh;
  }
  return { root, bones, height: 2.9 };
}

// ------------------------------------------------------------------ hooded watcher (rune circle)
export function buildHooded(ctx, seed = 1) {
  const M = ctx.M;
  const root = new Node('hooded');
  const g = Geometry.lathe(catmullRom([[0.55, 0], [0.5, 0.2], [0.4, 0.8], [0.33, 1.3], [0.3, 1.55], [0.26, 1.75], [0.12, 1.95], [0.0, 2.02]], 4), 24);
  g.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const f = 1 + Math.sin(a * 8 + seed) * 0.05 * smoothstep(1.2, 0, p[1]);
    return [p[0] * f, p[1], p[2] * f];
  });
  g.computeNormals();
  g.paint((p) => mix3(C('#0b0c14'), C('#262a44'), smoothstep(0, 1.8, p[1])).concat([0.8]));
  // hood opening (dark disc)
  const face = ellipsoid(0.17, 0.2, 0.06, 12, 8);
  face.translate(0, 1.62, 0.25);
  face.setColor([0.0, 0.0, 0.0], 1);
  root.add(makeMesh(ctx, g, M.cloth));
  const f = makeMesh(ctx, face, M.glow);
  root.add(f);
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = ellipsoid(0.02, 0.012, 0.01, 6, 4);
    e.translate(s * 0.06, 1.66, 0.31);
    e.setColor(C('#8fd0ff'), 1);
    e.setExtra([3.0]);
    eyes.append(e);
  }
  root.add(makeMesh(ctx, eyes, M.glow));
  return { root, bones: {} };
}

// ------------------------------------------------------------------ crow
export function buildCrow(ctx) {
  const M = ctx.M;
  const root = new Node('crow');
  const bones = {};
  const body = new Node('body'); body.setPos(0, 0.16, 0); root.add(body); bones.body = body;
  const bg = ellipsoid(0.09, 0.08, 0.16, 10, 8);
  bg.rotateX(0.35);
  const tail = Geometry.box(0.08, 0.015, 0.16);
  tail.rotateX(0.5);
  tail.translate(0, -0.03, -0.18);
  bg.append(tail);
  bg.setColor(C('#15151f'), 1);
  body.add(makeMesh(ctx, bg, M.cloth));
  const head = new Node('head'); head.setPos(0, 0.09, 0.12); body.add(head); bones.head = head;
  const hg = ellipsoid(0.055, 0.055, 0.065, 10, 8);
  hg.setColor(C('#17171f'), 1);
  const beak = Geometry.cylinder(0.0, 0.022, 0.08, 6, 1);
  beak.rotateX(Math.PI / 2);
  beak.translate(0, -0.01, 0.05);
  beak.setColor(C('#2c2c34'), 1);
  hg.append(beak);
  head.add(makeMesh(ctx, hg, M.metal));
  const eye = new Geometry();
  for (const s of [-1, 1]) {
    const e = ellipsoid(0.01, 0.01, 0.01, 6, 4);
    e.translate(s * 0.04, 0.015, 0.035);
    e.setColor(C('#ffd070'), 1);
    e.setExtra([2.0]);
    eye.append(e);
  }
  head.add(makeMesh(ctx, eye, M.glow));
  for (const s of [-1, 1]) {
    const w = new Node(s < 0 ? 'wingR' : 'wingL');
    w.setPos(s * 0.07, 0.03, 0.02);
    body.add(w);
    const wg = new Geometry();
    wg.color = C('#101018');
    const pts = [[0, 0, 0.08], [0.1, 0.005, 0.07], [0.26, 0, 0.0], [0.22, 0, -0.08], [0.12, 0, -0.12], [0, 0, -0.1]];
    const ids = pts.map((p) => wg.vert(p[0] * s, p[1], p[2], 0, 1, 0));
    for (let i = 1; i < ids.length - 1; i++) wg.tri(ids[0], ids[i + (s < 0 ? 1 : 0)], ids[i + (s < 0 ? 0 : 1)]);
    wg.computeNormals();
    w.add(makeMesh(ctx, wg, M.clothDS));
    if (s < 0) bones.wingR = w; else bones.wingL = w;
  }
  const legs = new Geometry();
  for (const s of [-1, 1]) {
    const l = Geometry.cylinder(0.006, 0.006, 0.1, 4, 1);
    l.translate(s * 0.03, 0.0, 0.0);
    l.setColor(C('#222'), 1);
    legs.append(l);
  }
  root.add(makeMesh(ctx, legs, M.metal));
  return { root, bones };
}

// ------------------------------------------------------------------ Brekus, the big pond frog, on his lily pad
// A whole frog (v7.2: it used to be just a head in the water): a squat spotted body sitting up, folded
// hind legs with webbed feet, little hands, bulging golden eyes, a wide mouth and a throat that swells
// when he croaks. He sits on a lily pad with a water-lily flower.
export function buildFrog(ctx) {
  const M = ctx.M;
  const root = new Node('frog');
  const bones = {};
  const back = C('#4a8a44'), dark = C('#26502c'), belly = C('#dcd49c');
  const skin = (p, n) => {
    const spot = smoothstep(0.25, 0.45, noise.n3(p[0] * 7 + 3, p[1] * 7, p[2] * 7));
    const under = smoothstep(0.1, -0.35, n[1]) + smoothstep(0.35, 0.9, n[2]) * smoothstep(0.55, 0.3, p[1]) * 0.8;
    return mix3(mix3(back, dark, spot * 0.7), belly, Math.min(1, under)).concat([1]);
  };
  const body = new Node('body');
  body.setPos(0, 0.03, 0);
  root.add(body);
  bones.body = body;
  // body: sitting up, wide haunches
  const bg = ellipsoid(0.32, 0.25, 0.4, 18, 12);
  bg.deform((p) => [p[0] * (1 + Math.max(0, -p[2]) * 0.4), p[1], p[2]]);
  bg.rotateX(-0.5);
  bg.translate(0, 0.27, -0.04);
  // head: broad and flat, a wide mouth line, nostrils
  const hg = ellipsoid(0.3, 0.16, 0.27, 18, 10);
  hg.translate(0, 0.56, 0.2);
  bg.append(hg);
  bg.computeNormals();
  bg.paint(skin);
  const lines = new Geometry();
  const mouth = [];
  for (let i = 0; i <= 10; i++) { const a = 0.12 * Math.PI + (i / 10) * 0.76 * Math.PI; mouth.push([Math.cos(a) * 0.285, 0.52 - Math.sin(a) * 0.01, 0.2 + Math.sin(a) * 0.255]); }
  lines.append(Geometry.tube(mouth, () => 0.01, 4, { capEnd: true }));
  for (const s of [-1, 1]) { const n = ellipsoid(0.014, 0.01, 0.01, 5, 4); n.translate(s * 0.05, 0.62, 0.44); lines.append(n); }
  lines.setColor(C('#16261a'), 1);
  bg.append(lines);
  // front legs with splayed fingers, folded hind legs with long webbed feet
  const limbs = new Geometry();
  for (const s of [-1, 1]) {
    limbs.append(Geometry.tube([[s * 0.17, 0.38, 0.22], [s * 0.22, 0.2, 0.3], [s * 0.24, 0.03, 0.36]], (t) => 0.05 - t * 0.015, 6, { capEnd: true }));
    for (const a of [-0.5, -0.15, 0.2, 0.55]) {
      const tip = [s * 0.24 + Math.sin(a + s * 0.3) * 0.09, 0.02, 0.36 + Math.cos(a + s * 0.3) * 0.09];
      limbs.append(Geometry.tube([[s * 0.24, 0.03, 0.36], tip], () => 0.014, 4, { capEnd: true }));
      const tb = ellipsoid(0.022, 0.016, 0.022, 6, 4);
      tb.translate(tip[0], tip[1], tip[2]);
      limbs.append(tb);
    }
    const thigh = ellipsoid(0.13, 0.11, 0.25, 12, 8);
    thigh.rotateY(s * -0.45);
    thigh.translate(s * 0.3, 0.14, -0.08);
    limbs.append(thigh);
    limbs.append(Geometry.tube([[s * 0.42, 0.12, 0.1], [s * 0.4, 0.07, -0.1], [s * 0.3, 0.05, -0.3]], (t) => 0.06 - t * 0.02, 6, { capEnd: true }));
    // webbed foot pointing forward and out
    const ankle = [s * 0.3, 0.035, -0.3];
    const toes = [[s * 0.62, 0.02, -0.05], [s * 0.58, 0.02, 0.06], [s * 0.48, 0.02, 0.13]];
    for (const tp of toes) {
      limbs.append(Geometry.tube([ankle, tp], () => 0.016, 4, { capEnd: true }));
      const tb = ellipsoid(0.024, 0.016, 0.024, 6, 4);
      tb.translate(tp[0], tp[1], tp[2]);
      limbs.append(tb);
    }
    const web = new Geometry();
    const a0 = web.vert(ankle[0], ankle[1], ankle[2]);
    const tv = toes.map((tp) => web.vert(tp[0], tp[1] - 0.004, tp[2]));
    for (let k = 0; k < 2; k++) { if (s > 0) web.tri(a0, tv[k + 1], tv[k]); else web.tri(a0, tv[k], tv[k + 1]); }
    web.computeNormals();
    limbs.append(web);
  }
  limbs.paint(skin);
  body.add(makeMesh(ctx, bg, M.glossy, 'frogBody'));
  body.add(makeMesh(ctx, limbs, M.glossyDS, 'frogLimbs'));
  // the throat that swells when he croaks
  const throat = new Node('throat');
  throat.setPos(0, 0.45, 0.32);
  body.add(throat);
  bones.throat = throat;
  const tg = ellipsoid(0.14, 0.1, 0.1, 12, 8);
  tg.setColor(C('#efe6b8'), 1);
  throat.add(makeMesh(ctx, tg, M.glossy, 'frogThroat'));
  // bulging golden eyes with a slit pupil
  const eyes = new Geometry();
  const lids = new Geometry();
  for (const s of [-1, 1]) {
    const lid = ellipsoid(0.11, 0.1, 0.11, 12, 8);
    lid.translate(s * 0.15, 0.68, 0.24);
    lids.append(lid);
    const e = ellipsoid(0.085, 0.085, 0.07, 12, 8);
    e.translate(s * 0.16, 0.7, 0.3);
    e.setColor(C('#e8c860'), 1);
    e.setExtra([0.9]);
    eyes.append(e);
    const pp = ellipsoid(0.05, 0.018, 0.02, 8, 4);
    pp.translate(s * 0.165, 0.7, 0.365);
    pp.setColor([0, 0, 0], 1);
    eyes.append(pp);
  }
  lids.paint(skin);
  body.add(makeMesh(ctx, lids, M.glossy, 'frogLids'));
  body.add(makeMesh(ctx, eyes, M.glowSoft, 'frogEyes'));
  return { root, bones };
}

// the lily pad Brekus sits on (with a water lily beside him)
export function buildLilyPad(ctx, R = 1.0) {
  const M = ctx.M;
  const root = new Node('lilypad');
  const g = new Geometry();
  const n = 36, notch = 0.22;
  const top = [g.vert(0, 0, 0, 0, 1, 0)], bot = [g.vert(0, -0.04, 0, 0, -1, 0)];
  for (let i = 0; i <= n; i++) {
    const a = notch + (i / n) * (TAU - 2 * notch);
    const r = R * (1 + Math.sin(a * 5) * 0.015);
    top.push(g.vert(Math.cos(a) * r, 0.01, Math.sin(a) * r, 0, 1, 0));
    bot.push(g.vert(Math.cos(a) * r, -0.04, Math.sin(a) * r, 0, -1, 0));
  }
  for (let i = 1; i <= n; i++) {
    g.tri(top[0], top[i + 1], top[i]);
    g.tri(bot[0], bot[i], bot[i + 1]);
    g.quad(top[i], top[i + 1], bot[i + 1], bot[i]);
  }
  g.computeNormals();
  g.paint((p) => {
    const a = Math.atan2(p[2], p[0]), r = Math.hypot(p[0], p[2]) / R;
    const vein = Math.pow(Math.abs(Math.sin(a * 7)), 12) * 0.25;
    return mix3(C('#2f6a34'), C('#5a9a48'), smoothstep(0.1, 0.95, r) * 0.6 + vein).concat([1]);
  });
  root.add(makeMesh(ctx, g, M.glossy, 'lilyPad'));
  // a water lily: pale pink petals around a golden heart
  const fl = new Geometry();
  for (let ring = 0; ring < 2; ring++) {
    const k = ring ? 7 : 9;
    for (let i = 0; i < k; i++) {
      const pg = ellipsoid(0.07, 0.025, 0.2 - ring * 0.05, 8, 5);
      pg.translate(0, 0, 0.14 - ring * 0.03);
      pg.rotateX(-0.45 - ring * 0.45);
      pg.rotateY((i / k) * TAU + ring * 0.3);
      fl.append(pg);
    }
  }
  fl.paint((p) => mix3(C('#fff4f8'), C('#f090b8'), smoothstep(0.05, 0.2, Math.hypot(p[0], p[2]))).concat([1]));
  const heart = ellipsoid(0.05, 0.035, 0.05, 8, 6);
  heart.translate(0, 0.04, 0);
  heart.setColor(C('#ffd060'), 1);
  heart.setExtra([0.8]);
  fl.append(heart);
  fl.translate(-R * 0.55, 0.03, -R * 0.45);
  root.add(makeMesh(ctx, fl, M.glowSoft, 'waterLily'));
  return { root };
}

// ------------------------------------------------------------------ the moon stag (a spirit animal)
export function buildStag(ctx) {
  const M = ctx.M;
  const root = new Node('stag');
  const bones = {};
  const body = new Node('body');
  body.setPos(0, 1.25, 0);
  root.add(body);
  bones.body = body;
  const coatTop = C('#5c6cb8'), coatBelly = C('#aab8e8'), rumpC = C('#d4dcf8');
  const coat = (p, belly = -0.1) => {
    const t = smoothstep(belly + 0.25, belly - 0.2, p[1]);
    return mix3(coatTop, coatBelly, t);
  };
  // body: a deep, narrow barrel (high withers, tucked belly, round rump)
  const bpts = [], brad = [];
  for (let i = 0; i <= 10; i++) {
    const t = i / 10;
    const zz = -0.82 + t * 1.62;
    bpts.push([0, 0.02 + Math.sin(t * Math.PI) * 0.03 + t * t * 0.1, zz]);
    brad.push(0.2 + Math.sin(Math.pow(t, 0.8) * Math.PI) * 0.22 + (t > 0.75 ? (t - 0.75) * 0.25 : 0));
  }
  const bg = Geometry.tube(bpts, (t) => brad[Math.min(10, Math.round(t * 10))], 16, { capStart: true, capEnd: true });
  bg.deform((p) => [p[0] * 0.72, p[1] < 0 ? p[1] * 0.92 : p[1], p[2]]);
  bg.computeNormals();
  bg.paint((p) => {
    let c = coat(p, 0.0);
    if (p[2] < -0.62 && p[1] > -0.2) c = mix3(c, rumpC, 0.75);             // pale rump patch
    // a fawn's dappled spots that never faded: faintly glowing
    const sp = Math.sin(p[2] * 17) * Math.sin(p[0] * 21 + p[2] * 3) > 0.72 && p[1] > 0.1 ? 1 : 0;
    return mix3(c, C('#ffffff'), sp * 0.5).concat([1]);
  });
  bg.paintExtra((p) => [Math.sin(p[2] * 17) * Math.sin(p[0] * 21 + p[2] * 3) > 0.72 && p[1] > 0.1 ? 0.7 : 0.08]);
  const tail = ellipsoid(0.07, 0.13, 0.06, 8, 6);
  tail.rotateX(-0.5);
  tail.translate(0, 0.12, -0.88);
  tail.setColor(rumpC, 1);
  tail.setExtra([0.15]);
  bg.append(tail);
  body.add(makeMesh(ctx, bg, M.cloth, 'stagBody'));
  // neck: thick at the shoulders, slender under the jaw, carried proudly
  const neck = new Node('neck');
  neck.setPos(0, 0.22, 0.74);
  body.add(neck);
  bones.neck = neck;
  const ng = Geometry.tube([[0, -0.05, -0.06], [0, 0.3, 0.1], [0, 0.62, 0.22], [0, 0.8, 0.26]], (t) => 0.24 - t * 0.13, 12, { capStart: true, capEnd: false });
  ng.deform((p) => [p[0] * 0.78, p[1], p[2]]);
  ng.computeNormals();
  ng.paint((p) => coat(p, 0.3).concat([1]));
  ng.setExtra([0.08]);
  neck.add(makeMesh(ctx, ng, M.cloth));
  const head = new Node('head');
  head.setPos(0, 0.8, 0.28);
  neck.add(head);
  bones.head = head;
  // head: a wedge from a broad brow to a narrow muzzle
  const hg = Geometry.tube([[0, 0.02, -0.12], [0, 0.0, 0.08], [0, -0.05, 0.28], [0, -0.08, 0.4]], (t) => 0.13 - t * 0.075, 12, { capStart: true, capEnd: true });
  hg.deform((p) => [p[0] * (0.85 + (p[1] > 0 ? 0.1 : 0)), p[1], p[2]]);
  hg.computeNormals();
  hg.paint((p) => (p[2] > 0.3 ? C('#2a2a44') : mix3(coatTop, coatBelly, smoothstep(0.02, -0.08, p[1]))).concat([1]));
  hg.setExtra([0.08]);
  // leaf-shaped ears, tipped outwards
  for (const s of [-1, 1]) {
    const ear = ellipsoid(0.055, 0.13, 0.025, 8, 6);
    ear.translate(0, 0.1, 0);
    ear.rotateZ(s * -1.05);
    ear.rotateY(s * 0.3);
    ear.translate(s * 0.09, 0.07, -0.08);
    ear.setColor(coatTop, 1);
    hg.append(ear);
    const inner = ellipsoid(0.03, 0.09, 0.012, 6, 4);
    inner.translate(0, 0.1, 0.012);
    inner.rotateZ(s * -1.05);
    inner.rotateY(s * 0.3);
    inner.translate(s * 0.09, 0.07, -0.07);
    inner.setColor(C('#ffd8f0'), 1);
    inner.setExtra([0.6]);
    hg.append(inner);
  }
  head.add(makeMesh(ctx, hg, M.cloth));
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = ellipsoid(0.03, 0.034, 0.02, 8, 6);
    e.translate(s * 0.095, 0.035, 0.06);
    e.setColor(C('#1a2048'), 1);
    e.setExtra([0.5]);
    eyes.append(e);
    const hl = ellipsoid(0.01, 0.01, 0.006, 5, 4);
    hl.translate(s * 0.105, 0.045, 0.075);
    hl.setColor(C('#dffbff'), 1);
    hl.setExtra([3]);
    eyes.append(hl);
  }
  head.add(makeMesh(ctx, eyes, M.glow));
  // antlers: a crown of light, the same on both sides (a main beam sweeping up and back, with tines)
  const ant = new Geometry();
  for (const s of [-1, 1]) {
    const beam = catmullRom([[s * 0.06, 0.09, -0.06], [s * 0.22, 0.3, -0.12], [s * 0.32, 0.58, -0.08], [s * 0.3, 0.86, 0.02], [s * 0.2, 1.05, 0.1]], 4);
    ant.append(Geometry.tube(beam, (t) => 0.034 * (1 - t * 0.65), 6, { capEnd: true }));
    const tines = [[0.18, [0.05, 0.28, 0.3], 0.28], [0.42, [0.12, 0.36, 0.22], 0.3], [0.62, [-0.05, 0.3, 0.26], 0.26], [0.8, [0.14, 0.24, 0.12], 0.2]];
    for (const [f, d, len] of tines) {
      const k = Math.min(beam.length - 1, Math.round(f * (beam.length - 1)));
      const b0 = beam[k];
      const dl = Math.hypot(d[0], d[1], d[2]);
      const tip = [b0[0] + s * (d[0] / dl) * len, b0[1] + (d[1] / dl) * len, b0[2] + (d[2] / dl) * len];
      const mid = [(b0[0] + tip[0]) / 2 + s * 0.02, (b0[1] + tip[1]) / 2 + 0.03, (b0[2] + tip[2]) / 2];
      ant.append(Geometry.tube([b0, mid, tip], (t) => 0.022 * (1 - t * 0.7), 5, { capEnd: true }));
    }
  }
  ant.setColor(C('#bff4ff'), 1);
  ant.setExtra([2.4]);
  head.add(makeMesh(ctx, ant, M.glow, 'antlers'));
  // legs: long and fine, the hind ones with the backward-bending hock, dark hooves
  for (const [name, x, z] of [['legFL', 0.17, 0.52], ['legFR', -0.17, 0.52], ['legBL', 0.16, -0.58], ['legBR', -0.16, -0.58]]) {
    const leg = new Node(name);
    leg.setPos(x, -0.12, z);
    body.add(leg);
    const front = z > 0;
    const pts = front
      ? [[0, 0.08, 0], [0, -0.35, 0.02], [0, -0.62, 0.0], [0, -0.9, 0.02], [0, -1.08, 0.04]]
      : [[0, 0.12, 0.02], [0, -0.3, -0.1], [0, -0.55, -0.18], [0, -0.82, -0.1], [0, -1.08, -0.04]];
    const lg = Geometry.tube(pts, (t) => (front ? 0.085 : 0.11) * (1 - t * 0.62), 8, { capStart: true, capEnd: false });
    lg.paint((p) => coat(p, -0.4).concat([1]));
    const hoof = ellipsoid(0.045, 0.04, 0.06, 8, 5);
    hoof.translate(0, -1.1, pts[4][2] + 0.01);
    hoof.setColor(C('#2a2440'), 1);
    lg.append(hoof);
    lg.setExtra([0.06]);
    leg.add(makeMesh(ctx, lg, M.cloth));
    bones[name] = leg;
  }
  return { root, bones };
}

// ------------------------------------------------------------------ the wandering giant snail with a house on her shell
export function buildSnail(ctx) {
  const M = ctx.M;
  const root = new Node('snail');
  const bones = {};
  const body = new Node('snailBody');
  root.add(body);
  bones.body = body;
  const pts = [];
  for (let i = 0; i <= 12; i++) {
    const t = i / 12;
    pts.push([0, 0.55 + Math.sin(t * Math.PI) * 0.1 + (t > 0.85 ? (t - 0.85) * 3 : 0), -2.6 + t * 5.4]);
  }
  const bg = Geometry.tube(pts, (t) => (0.35 + 0.55 * Math.sin(Math.min(1, t * 1.3) * Math.PI * 0.6)) * (t > 0.9 ? 1 - (t - 0.9) * 4 : 1), 14, { capEnd: true, capStart: true });
  bg.deform((p) => [p[0] * 1.25, Math.max(p[1], 0.05), p[2]]);
  bg.computeNormals();
  bg.paint((p) => mix3(C('#3a5a66'), C('#8ab8b8'), smoothstep(0.1, 1.1, p[1])).concat([1]));
  bg.paintExtra((p) => [0.12 * smoothstep(0.3, 1.2, p[1])]);
  body.add(makeMesh(ctx, bg, M.skin, 'snailBody'));
  // eye stalks
  for (const s of [-1, 1]) {
    const stalk = new Node(s < 0 ? 'stalkR' : 'stalkL');
    stalk.setPos(s * 0.25, 1.35, 2.75);
    body.add(stalk);
    const sg = Geometry.tube([[0, 0, 0], [s * 0.1, 0.45, 0.1], [s * 0.18, 0.9, 0.05]], (t) => 0.07 - t * 0.03, 6);
    sg.setColor(C('#6a9a9a'), 1);
    stalk.add(makeMesh(ctx, sg, M.skin));
    const e = ellipsoid(0.12, 0.12, 0.12, 8, 6);
    e.translate(s * 0.18, 0.98, 0.05);
    e.setColor(C('#d8ffe8'), 1);
    e.setExtra([2.2]);
    stalk.add(makeMesh(ctx, e, M.glowSoft));
    bones[s < 0 ? 'stalkR' : 'stalkL'] = stalk;
  }
  // spiral shell (a tube winding inwards in the XY plane)
  const shell = new Geometry();
  const sp = [];
  const turns = 2.3;
  for (let i = 0; i <= 60; i++) {
    const t = i / 60;
    const a = t * turns * TAU;
    const rr = 2.0 * (1 - t * 0.78);
    sp.push([0, 2.35 + Math.sin(a) * rr, -0.5 + Math.cos(a) * rr]);
  }
  shell.append(Geometry.tube(sp, (t) => 0.95 * (1 - t * 0.75), 14, { capEnd: true, capStart: true }));
  shell.deform((p) => [p[0] * 1.15, p[1], p[2]]);
  shell.computeNormals();
  shell.paint((p) => {
    const band = Math.abs(Math.sin(Math.atan2(p[1] - 2.35, p[2] + 0.5) * 3 + Math.hypot(p[1] - 2.35, p[2] + 0.5) * 3));
    return mix3(C('#4a2f5a'), C('#b07a9a'), band).concat([1]);
  });
  shell.paintExtra((p) => {
    const band = Math.abs(Math.sin(Math.atan2(p[1] - 2.35, p[2] + 0.5) * 3 + Math.hypot(p[1] - 2.35, p[2] + 0.5) * 3));
    return [band > 0.95 ? 0.9 : 0.0];
  });
  body.add(makeMesh(ctx, shell, M.stoneFine, 'shell'));
  // a tiny house riding on top
  const house = new Geometry();
  const walls = Geometry.box(1.3, 1.0, 1.1, { y0: 0 });
  walls.setColor(C('#6a5a70'), 1);
  house.append(walls);
  const roof = Geometry.lathe([[1.1, 1.0], [0.05, 1.8]], 4, { phase: Math.PI / 4, capBottom: true });
  roof.scale(0.85, 1, 0.75);
  roof.setColor(C('#2a2e55'), 1);
  house.append(roof);
  const chim = Geometry.box(0.22, 0.6, 0.22, { y0: 1.2 });
  chim.translate(0.35, 0, -0.2);
  chim.setColor(C('#3a3a48'), 1);
  house.append(chim);
  house.translate(0, 4.0, -0.5);
  body.add(makeMesh(ctx, house, M.plaster, 'snailHouse'));
  const win = new Geometry();
  for (const [x, z, ry] of [[0.66, -0.5, Math.PI / 2], [-0.66, -0.5, -Math.PI / 2], [0, 0.06, 0]]) {
    const w = Geometry.box(0.3, 0.32, 0.04);
    w.rotateY(ry);
    w.translate(x, 4.55, z);
    win.append(w);
  }
  win.setColor(C('#ffb35c'), 1);
  win.setExtra([2.4]);
  body.add(makeMesh(ctx, win, M.glowSoft));
  const chimney = new Node('snailChimney');
  chimney.setPos(0.35, 5.9, -0.7);
  body.add(chimney);
  bones.chimney = chimney;
  const lamp = new Node('snailLamp');
  lamp.setPos(0, 4.6, 0.3);
  body.add(lamp);
  bones.lamp = lamp;
  return { root, bones };
}
