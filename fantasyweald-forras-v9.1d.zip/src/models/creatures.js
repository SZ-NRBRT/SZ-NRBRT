// The dream creatures that make the world feel alive: mushroom folk, moon rabbits, stilt walkers,
// dream cats, owls, sky koi, sky whales and moon moths. Every rig returns { root, bones } like the
// characters; the parts that share a material are later merged into one skinned mesh per creature.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep } from '../engine/math.js';
import { C } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const mesh = (ctx, g, mat, name = '') => new Mesh(new GpuGeometry(ctx.gl, g), mat, name);
function egg(rx, ry, rz, ws = 12, hs = 8) {
  const g = Geometry.sphere(1, ws, hs);
  g.scale(rx, ry, rz);
  return g;
}
function bone(name, parent, x = 0, y = 0, z = 0) {
  const n = new Node(name);
  n.setPos(x, y, z);
  parent.add(n);
  return n;
}
// two glowing eyes with dark pupils (one mesh)
function eyes(sep, y, z, r, iris, { pupil = 0.45, glow = 2.2, squash = 1 } = {}) {
  const g = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(r, r * squash, r * 0.6, 10, 8);
    e.translate(s * sep, y, z);
    e.setColor(iris, 1);
    e.setExtra([glow]);
    g.append(e);
    const p = egg(r * pupil, r * pupil * 1.25 * squash, r * 0.3, 8, 6);
    p.translate(s * sep, y, z + r * 0.45);
    p.setColor([0.004, 0.004, 0.01], 1);
    p.setExtra([0]);
    g.append(p);
    const hl = egg(r * 0.18, r * 0.18, r * 0.1, 5, 4);
    hl.translate(s * sep + r * 0.25, y + r * 0.3, z + r * 0.55);
    hl.setColor([1, 1, 1], 1);
    hl.setExtra([3]);
    g.append(hl);
  }
  return g;
}

// ------------------------------------------------------------------ mushroom folk (Pöfetegek)
// Knee-high walking mushrooms. When they notice you they squat and pretend to be ordinary mushrooms.
export function buildMushroomFolk(ctx, seed = 1, kind = 0) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('shroomling');
  const bones = {};
  const scale = rng.range(0.85, 1.2);
  const inner = bone('scale', root);
  inner.setScale(scale);
  const body = bone('body', inner, 0, 0.14, 0);
  bones.body = body;
  // stem-body: a plump lathe with a pale belly
  const prof = catmullRom([[0.07, -0.02], [0.105, 0.03], [0.11, 0.12], [0.095, 0.2], [0.08, 0.24]], 2);
  const st = Geometry.lathe(prof, 14, { capBottom: true });
  st.paint((p) => mix3(C('#8d93b8'), C('#e6e4f4'), smoothstep(-0.02, 0.2, p[1])).concat([smoothstep(-0.05, 0.15, p[1]) * 0.4 + 0.6]));
  st.displace((p) => noise.n3(p[0] * 30 + seed, p[1] * 20, p[2] * 30) * 0.006);
  body.add(mesh(ctx, st, M.stem, 'shroomBody'));
  // cap
  const capN = bone('cap', body, 0, 0.23, 0);
  bones.cap = capN;
  const R = rng.range(0.17, 0.24);
  const h = R * rng.range(0.6, 0.85);
  const capProf = catmullRom([[R * 0.45, -0.01], [R * 0.95, 0.0], [R, h * 0.18], [R * 0.85, h * 0.6], [R * 0.5, h * 0.92], [0, h]], 3);
  const cap = Geometry.lathe(capProf, 20);
  cap.deform((p) => [p[0], p[1] + Math.sin(Math.atan2(p[2], p[0]) * 3 + seed) * 0.006, p[2]]);
  cap.computeNormals();
  const cols = [['#1d3f86', '#3d7fd0'], ['#b3101c', '#e02230'], ['#4b2a8a', '#8a5ad8']][kind % 3];
  cap.paint((p) => mix3(C(cols[0]), C(cols[1]), smoothstep(0.3, 1.0, Math.hypot(p[0], p[2]) / R)).concat([1]));
  cap.paintExtra((p) => [0, 0, p[1] > h * 0.1 ? 1 : 0]);
  capN.add(mesh(ctx, cap, kind % 3 === 1 ? M.amanitaCap : M.giantCap, 'shroomCap'));
  // face: big dark eyes that glow faintly, and a tiny mouth
  const eyeN = bone('eyes', body, 0, 0.16, 0.085);
  bones.eyes = eyeN;
  const e = eyes(0.038, 0, 0.012, 0.026, C(kind % 3 === 1 ? '#ffd9a0' : '#a8e8ff'), { pupil: 0.62, glow: 1.2, squash: 1.2 });
  eyeN.add(mesh(ctx, e, M.glowSoft, 'shroomEyes'));
  // stubby legs and arms
  for (const s of [-1, 1]) {
    const leg = bone(s < 0 ? 'legR' : 'legL', inner, s * 0.05, 0.14, 0);
    const lg = Geometry.cylinder(0.028, 0.034, 0.14, 7, 1);
    lg.translate(0, -0.14, 0);
    const foot = egg(0.04, 0.025, 0.055, 8, 6);
    foot.translate(0, -0.14, 0.015);
    lg.append(foot);
    lg.setColor(C('#7c82a8'), 1);
    leg.add(mesh(ctx, lg, M.stem));
    if (s < 0) bones.legR = leg; else bones.legL = leg;
    const arm = bone(s < 0 ? 'armR' : 'armL', body, s * 0.1, 0.13, 0);
    const ag = egg(0.022, 0.06, 0.022, 6, 5);
    ag.translate(0, -0.05, 0);
    ag.setColor(C('#cfd0e6'), 1);
    arm.add(mesh(ctx, ag, M.stem));
    if (s < 0) bones.armR = arm; else bones.armL = arm;
  }
  return { root, bones, scale };
}

// ------------------------------------------------------------------ moon rabbit (Holdnyúl)
export function buildMoonRabbit(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('rabbit');
  const bones = {};
  const body = bone('body', root, 0, 0.17, 0);
  bones.body = body;
  const fur = C(rng.pick(['#bcb4e0', '#b0bce0', '#c8b8e4']));
  const bg = egg(0.13, 0.12, 0.2, 14, 10);
  bg.translate(0, 0, -0.02);
  const haunch = egg(0.12, 0.11, 0.12, 12, 8);
  haunch.translate(0, -0.03, -0.1);
  bg.append(haunch);
  bg.paint((p) => mix3(mix3(fur, [0.3, 0.32, 0.5], 0.35), fur, smoothstep(-0.12, 0.08, p[1])).concat([1]));
  const tail = egg(0.05, 0.05, 0.05, 8, 6);
  tail.translate(0, 0.03, -0.21);
  tail.setColor(C('#f0eaff'), 1);
  tail.setExtra([0.35]);
  bg.append(tail);
  body.add(mesh(ctx, bg, M.cloth, 'rabbitBody'));
  const head = bone('head', body, 0, 0.1, 0.14);
  bones.head = head;
  const hg = egg(0.085, 0.08, 0.1, 12, 8);
  hg.paint(() => fur.concat([1]));
  const nose = egg(0.015, 0.012, 0.012, 6, 4);
  nose.translate(0, -0.01, 0.1);
  nose.setColor(C('#ff9ec8'), 1);
  hg.append(nose);
  head.add(mesh(ctx, hg, M.cloth));
  head.add(mesh(ctx, eyes(0.05, 0.02, 0.06, 0.02, C('#ff8ad8'), { pupil: 0.5, glow: 1.8 }), M.glowSoft));
  for (const s of [-1, 1]) {
    const ear = bone(s < 0 ? 'earR' : 'earL', head, s * 0.035, 0.06, -0.01);
    const eg = egg(0.028, 0.13, 0.012, 8, 8);
    eg.translate(0, 0.12, 0);
    eg.paint((p) => fur.concat([1]));
    const inner = egg(0.016, 0.1, 0.006, 6, 6);
    inner.translate(0, 0.12, 0.009);
    inner.setColor(C('#ffb0e0'), 1);
    inner.setExtra([0.8]);
    eg.append(inner);
    ear.setEuler(-0.25, 0, s * -0.18);
    ear.add(mesh(ctx, eg, M.glowSoft));
    if (s < 0) bones.earR = ear; else bones.earL = ear;
  }
  for (const s of [-1, 1]) {
    const leg = bone(s < 0 ? 'legR' : 'legL', body, s * 0.08, -0.06, -0.08);
    const lg = egg(0.04, 0.03, 0.1, 8, 6);
    lg.translate(0, -0.08, 0.04);
    lg.paint(() => fur.concat([0.8]));
    leg.add(mesh(ctx, lg, M.cloth));
    if (s < 0) bones.legR = leg; else bones.legL = leg;
  }
  return { root, bones };
}

// ------------------------------------------------------------------ stilt walker (Gólyalábú vándor)
// A small hooded lantern-bearer riding on two impossibly long, thin legs.
export function buildStiltWalker(ctx, seed = 1) {
  const M = ctx.M;
  const root = new Node('stilt');
  const bones = {};
  const H = 4.6; // hip height
  const hips = bone('hips', root, 0, H, 0);
  bones.hips = hips;
  // hooded body: a cloak cone with a round pale face
  const cloak = Geometry.lathe(catmullRom([[0.4, -0.12], [0.48, 0.0], [0.42, 0.25], [0.32, 0.75], [0.2, 1.1], [0.02, 1.25]], 3), 18);
  cloak.displace((p) => noise.n3(p[0] * 6 + seed, p[1] * 4, p[2] * 6) * 0.03);
  cloak.paint((p) => mix3(C('#1a1d3a'), C('#3a3f78'), smoothstep(-0.1, 1.1, p[1])).concat([1]));
  hips.add(mesh(ctx, cloak, M.robe, 'stiltCloak'));
  const face = egg(0.17, 0.2, 0.08, 14, 10);
  face.translate(0, 0.78, 0.26);
  face.setColor(C('#d8dcf0'), 1);
  face.setExtra([0.12]);
  hips.add(mesh(ctx, face, M.plaster));
  const eg = eyes(0.065, 0.8, 0.33, 0.035, C('#fff0b0'), { pupil: 0.0, glow: 3.2 });
  hips.add(mesh(ctx, eg, M.glow));
  // legs: thigh + shin per side, thin and dark, with small feet
  for (const s of [-1, 1]) {
    const thigh = bone(s < 0 ? 'thighR' : 'thighL', hips, s * 0.18, 0, 0);
    const tg = Geometry.cylinder(0.045, 0.06, H * 0.52, 7, 1);
    tg.translate(0, -H * 0.52, 0);
    tg.setColor(C('#20202c'), 1);
    thigh.add(mesh(ctx, tg, M.wood));
    const shin = bone(s < 0 ? 'shinR' : 'shinL', thigh, 0, -H * 0.52, 0);
    const sg = Geometry.cylinder(0.03, 0.045, H * 0.5, 7, 1);
    sg.translate(0, -H * 0.5, 0);
    const knee = egg(0.07, 0.07, 0.07, 8, 6);
    sg.append(knee);
    const foot = egg(0.06, 0.035, 0.12, 8, 6);
    foot.translate(0, -H * 0.5, 0.05);
    sg.append(foot);
    sg.setColor(C('#20202c'), 1);
    shin.add(mesh(ctx, sg, M.wood));
    bones[s < 0 ? 'thighR' : 'thighL'] = thigh;
    bones[s < 0 ? 'shinR' : 'shinL'] = shin;
  }
  // a long arm holding a lantern out in front
  const arm = bone('arm', hips, 0.25, 0.55, 0.15);
  bones.arm = arm;
  const ag = Geometry.cylinder(0.02, 0.025, 1.1, 5, 1);
  ag.rotateX(Math.PI / 2 - 0.5);
  ag.translate(0, 0.25, 0.45);
  ag.setColor(C('#2a2a38'), 1);
  arm.add(mesh(ctx, ag, M.wood));
  const lan = bone('lantern', arm, 0, 0.45, 0.95);
  bones.lantern = lan;
  const lg = Geometry.lathe([[0.001, -0.22], [0.1, -0.2], [0.12, -0.05], [0.1, 0.02], [0.03, 0.06], [0.001, 0.07]], 10);
  lg.setColor(C('#ffcf7a'), 1);
  lg.setExtra([3.2]);
  lan.add(mesh(ctx, lg, M.glow));
  const lamp = bone('lamp', lan, 0, -0.08, 0);
  bones.lamp = lamp;
  return { root, bones, hipH: H };
}

// ------------------------------------------------------------------ dream cat (Álommacska)
export function buildDreamCat(ctx, seed = 1, fur = '#1c1c2e') {
  const M = ctx.M;
  const root = new Node('cat');
  const bones = {};
  const body = bone('body', root, 0, 0, 0);
  bones.body = body;
  // sitting body (pear shape) + front legs
  const bg = Geometry.lathe(catmullRom([[0.001, 0.0], [0.13, 0.02], [0.16, 0.1], [0.13, 0.22], [0.09, 0.3], [0.001, 0.33]], 3), 14);
  bg.scale(1, 1, 1.15);
  bg.translate(0, 0, -0.04);
  for (const s of [-1, 1]) {
    const leg = Geometry.cylinder(0.025, 0.03, 0.22, 6, 1);
    leg.translate(s * 0.05, 0.0, 0.09);
    bg.append(leg);
  }
  bg.paint((p) => mix3(C(fur), mix3(C(fur), [0.35, 0.35, 0.6], 0.4), smoothstep(0.0, 0.3, p[1])).concat([1]));
  body.add(mesh(ctx, bg, M.hair, 'catBody'));
  const head = bone('head', body, 0, 0.36, 0.04);
  bones.head = head;
  const hg = egg(0.085, 0.075, 0.075, 12, 8);
  for (const s of [-1, 1]) {
    const ear = Geometry.cylinder(0.0, 0.035, 0.07, 4, 1);
    ear.translate(s * 0.05, 0.05, -0.01);
    hg.append(ear);
  }
  hg.paint(() => C(fur).concat([1]));
  head.add(mesh(ctx, hg, M.hair));
  head.add(mesh(ctx, eyes(0.034, 0.012, 0.058, 0.022, C('#c8ff6a'), { pupil: 0.3, glow: 3.0, squash: 1.1 }), M.glow));
  // tail: three segments that curl and sway
  let parent = body;
  const tl = [];
  for (let i = 0; i < 3; i++) {
    const seg = bone('tail' + i, parent, 0, i === 0 ? 0.03 : 0.0, i === 0 ? -0.2 : -0.12);
    const tg = Geometry.cylinder(0.018 - i * 0.003, 0.022 - i * 0.003, 0.13, 5, 1);
    tg.rotateX(Math.PI / 2);
    tg.translate(0, 0, -0.06);
    tg.paint(() => C(fur).concat([1]));
    seg.add(mesh(ctx, tg, M.hair));
    tl.push(seg);
    parent = seg;
  }
  bones.tail = tl;
  return { root, bones };
}

// ------------------------------------------------------------------ owl (Álombagoly)
export function buildOwl(ctx, seed = 1) {
  const M = ctx.M;
  const root = new Node('owl');
  const bones = {};
  const body = bone('body', root, 0, 0, 0);
  bones.body = body;
  const bg = egg(0.13, 0.19, 0.12, 12, 10);
  bg.translate(0, 0.17, 0);
  bg.paint((p) => mix3(C('#2c2a3e'), C('#6a6490'), smoothstep(0.05, 0.3, p[1]) * (p[2] > 0.05 ? 1.2 : 0.8)).concat([1]));
  body.add(mesh(ctx, bg, M.hair, 'owlBody'));
  const head = bone('head', body, 0, 0.36, 0);
  bones.head = head;
  const hg = egg(0.11, 0.095, 0.1, 12, 10);
  for (const s of [-1, 1]) {
    const tuft = Geometry.cylinder(0.0, 0.03, 0.08, 4, 1);
    tuft.rotateZ(s * -0.35);
    tuft.translate(s * 0.07, 0.08, 0);
    hg.append(tuft);
  }
  hg.paint((p) => mix3(C('#3a3656'), C('#7a74a8'), smoothstep(-0.05, 0.08, p[1])).concat([1]));
  head.add(mesh(ctx, hg, M.hair));
  // big eye discs + beak
  const eyeN = bone('eyes', head, 0, 0.0, 0.0);
  bones.eyes = eyeN;
  const eg = eyes(0.045, 0.01, 0.075, 0.034, C('#ffc24a'), { pupil: 0.5, glow: 3.4 });
  const beak = Geometry.cylinder(0.0, 0.014, 0.04, 4, 1);
  beak.rotateX(Math.PI / 2 + 0.6);
  beak.translate(0, -0.02, 0.1);
  beak.setColor(C('#c8a060'), 1);
  beak.setExtra([0]);
  eg.append(beak);
  eyeN.add(mesh(ctx, eg, M.glow));
  for (const s of [-1, 1]) {
    const w = bone(s < 0 ? 'wingR' : 'wingL', body, s * 0.12, 0.25, -0.01);
    const wg = egg(0.03, 0.15, 0.09, 8, 6);
    wg.translate(0, -0.08, 0);
    wg.paint(() => C('#262338').concat([1]));
    w.add(mesh(ctx, wg, M.hair));
    if (s < 0) bones.wingR = w; else bones.wingL = w;
  }
  return { root, bones };
}

// ------------------------------------------------------------------ sky koi (Égi ponty)
export function buildSkyKoi(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('koi');
  const bones = {};
  const body = bone('body', root);
  bones.body = body;
  const L = rng.range(0.9, 1.3);
  const prof = [];
  for (let j = 0; j <= 10; j++) {
    const t = j / 10;
    prof.push([Math.sin(Math.pow(t, 0.8) * Math.PI) * 0.16 * L * (1 - t * 0.35) + 0.002, (t - 0.55) * L]);
  }
  const bg = Geometry.lathe(prof, 12);
  bg.rotateX(Math.PI / 2); // along +z
  bg.scale(0.8, 1, 1);
  const palette = [['#ff7a2a', '#fff2e0'], ['#ffd24a', '#ffffff'], ['#ff4a6a', '#fff0f4'], ['#8ab8ff', '#ffffff']][rng.int(0, 3)];
  const pa = C(palette[0]), pb = C(palette[1]);
  bg.paint((p) => {
    const n = noise.n3(p[0] * 6 + seed, p[1] * 6, p[2] * 5);
    return (n > 0.1 ? pa : pb).concat([1]);
  });
  bg.paintExtra((p) => [0.9 + (noise.n3(p[0] * 6 + seed, p[1] * 6, p[2] * 5) > 0.1 ? 0.6 : 0)]);
  body.add(mesh(ctx, bg, M.glowSoft, 'koiBody'));
  const fins = new Geometry();
  for (const s of [-1, 1]) {
    const f = egg(0.12 * L, 0.012, 0.08 * L, 8, 4);
    f.rotateZ(s * 0.5);
    f.translate(s * 0.12 * L, -0.03, 0.12 * L);
    fins.append(f);
  }
  const dorsal = egg(0.01, 0.08 * L, 0.2 * L, 4, 6);
  dorsal.translate(0, 0.13 * L, 0);
  fins.append(dorsal);
  fins.setColor(pb, 1);
  fins.setExtra([1.3]);
  body.add(mesh(ctx, fins, M.glowSoft));
  body.add(mesh(ctx, eyes(0.07 * L, 0.03, 0.34 * L, 0.018, [0.02, 0.02, 0.03], { pupil: 0.0, glow: 0 }), M.glowSoft));
  const tail = bone('tail', body, 0, 0, -0.5 * L);
  bones.tail = tail;
  const tg = new Geometry();
  const pts = [[0, 0, 0], [0.0, 0.22, -0.3], [0, 0.05, -0.22], [0, -0.05, -0.22], [0, -0.22, -0.3]];
  const ids = pts.map((p) => tg.vert(p[0], p[1] * L, p[2] * L, 1, 0, 0, 0.5, 0.5));
  tg.tri(ids[0], ids[1], ids[2]); tg.tri(ids[0], ids[2], ids[3]); tg.tri(ids[0], ids[3], ids[4]);
  tg.tri(ids[0], ids[2], ids[1]); tg.tri(ids[0], ids[3], ids[2]); tg.tri(ids[0], ids[4], ids[3]);
  tg.setColor(pb, 1);
  tg.setExtra([1.6]);
  tail.add(mesh(ctx, tg, M.glowSoft));
  return { root, bones, length: L };
}

// ------------------------------------------------------------------ sky whales: see skywhale.js (v9.1d)
export { buildSkyWhale, whaleSaddle } from './skywhale.js';

// ------------------------------------------------------------------ moon moths: GPU-animated swarms
// (the butterfly shader flies them in loops; these are just bigger, paler and slower)
export function moths(gl, count, center, { radius = 2.5, height = 1.2, seed = 9 } = {}) {
  const g = new Geometry();
  const w = 0.2, h = 0.17;
  for (const s of [-1, 1]) {
    const a = g.vert(0, 0, -h, 0, 1, 0, 0, -1);
    const b = g.vert(s * w, 0, -h, 0, 1, 0, 1, -1);
    const c = g.vert(s * w, 0, h, 0, 1, 0, 1, 1);
    const d = g.vert(0, 0, h, 0, 1, 0, 0, 1);
    g.quad(a, b, c, d);
  }
  const geo = new GpuGeometry(gl, g);
  const rng = new RNG(seed);
  const data = new Float32Array(count * 20);
  for (let i = 0; i < count; i++) {
    const o = i * 20;
    data[o] = center[0] + rng.range(-0.4, 0.4);
    data[o + 1] = center[1] + rng.range(-0.2, 0.4);
    data[o + 2] = center[2] + rng.range(-0.4, 0.4);
    data[o + 3] = rng.next();
    data[o + 4] = radius * rng.range(0.4, 1.0);
    data[o + 5] = height * rng.range(0.3, 0.8);
    data[o + 6] = rng.range(0.35, 0.8) * rng.sign();
    data[o + 7] = rng.range(9, 13);
    const col = C(rng.pick(['#c8b8ff', '#a8c8ff', '#ffd8b0']));
    data[o + 16] = col[0] * 0.9; data[o + 17] = col[1] * 0.85; data[o + 18] = col[2]; data[o + 19] = rng.range(0.32, 0.55);
  }
  const mat = new Material({ kind: 'butterfly', transparent: true, blend: 'additive', depthWrite: false, castShadow: false, cull: 'none', renderOrder: 11 });
  const m = new Mesh(geo, mat, 'moths');
  m.setInstances(data, count);
  m.boundsWorld = [center[0], center[1] + height, center[2], radius * 2 + height * 2 + 1];
  m.castShadow = false;
  m.maxDistance = 90;
  return m;
}

// ------------------------------------------------------------------ Pihe, the cloud shepherd (Felhőpásztor)
// A tall, soft moth-girl with feathery antennae, big dusty wings and a shepherd's crook with a lantern.
export function buildShepherd(ctx, seed = 3) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('shepherd');
  const bones = {};
  const body = bone('body', root, 0, 0, 0);
  bones.body = body;
  // robe: a long bell of pale lavender, darker at the hem
  const robe = Geometry.lathe(catmullRom([[0.4, -0.02], [0.44, 0.02], [0.36, 0.25], [0.27, 0.7], [0.22, 1.1], [0.17, 1.3], [0.02, 1.36]], 3), 20);
  robe.deform((p) => [p[0], p[1], p[2] * 0.85]);
  robe.computeNormals();
  robe.paint((p) => mix3(C('#35306a'), C('#8a84c4'), smoothstep(0.05, 0.9, p[1])).concat([smoothstep(-0.05, 0.4, p[1]) * 0.35 + 0.65]));
  body.add(mesh(ctx, robe, M.cloth, 'shepherdRobe'));
  // fluffy moth collar
  const fur = new Geometry();
  for (let i = 0; i < 14; i++) {
    const a = (i / 14) * TAU;
    const f = egg(0.09, 0.07, 0.08, 7, 5);
    f.translate(Math.cos(a) * 0.19, 1.3 + Math.sin(a * 3) * 0.01, Math.sin(a) * 0.16);
    fur.append(f);
  }
  const fl = egg(0.2, 0.08, 0.17, 10, 6);
  fl.translate(0, 1.33, 0);
  fur.append(fl);
  fur.setColor(C('#c8c0e2'), 1);
  body.add(mesh(ctx, fur, M.cloth));
  // head
  const head = bone('head', body, 0, 1.42, 0.01);
  bones.head = head;
  const hg = egg(0.13, 0.14, 0.12, 14, 10);
  hg.translate(0, 0.08, 0);
  hg.paint((p) => mix3(C('#8a92c4'), C('#aeb6e0'), smoothstep(0.0, 0.2, p[1])).concat([1]));
  const hood = egg(0.15, 0.13, 0.14, 12, 8);
  hood.translate(0, 0.14, -0.03);
  hood.deform((p) => [p[0], Math.max(p[1], 0.1), p[2]]);
  hood.setColor(C('#bcb4dc'), 1);
  hg.append(hood);
  head.add(mesh(ctx, hg, M.skin, 'shepherdHead'));
  // big moth eyes: dark and glossy with a starry glint
  const eg = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(0.052, 0.062, 0.03, 12, 8);
    e.translate(s * 0.058, 0.075, 0.1);
    e.setColor(C('#141430'), 1);
    e.setExtra([0.25]);
    eg.append(e);
    const g1 = egg(0.013, 0.013, 0.006, 5, 4);
    g1.translate(s * 0.058 + 0.018, 0.1, 0.128);
    g1.setColor([1, 1, 1], 1);
    g1.setExtra([3]);
    eg.append(g1);
  }
  head.add(mesh(ctx, eg, M.glowSoft));
  // feathery antennae
  const ant = new Geometry();
  for (const s of [-1, 1]) {
    const pts = catmullRom([[s * 0.05, 0.2, 0.05], [s * 0.1, 0.34, 0.08], [s * 0.2, 0.46, 0.04], [s * 0.3, 0.5, -0.02]], 4);
    ant.append(Geometry.tube(pts, () => 0.008, 4, { capEnd: true }));
    for (let k = 2; k < pts.length - 1; k++) {
      const p = pts[k];
      for (const side of [-1, 1]) {
        const barb = Geometry.tube([[p[0], p[1], p[2]], [p[0] + s * 0.02, p[1] + side * 0.05, p[2] + 0.02]], () => 0.004, 3, { capEnd: false });
        ant.append(barb);
      }
    }
  }
  ant.setColor(C('#e8c878'), 1);
  ant.setExtra([0.4]);
  head.add(mesh(ctx, ant, M.glowSoft));
  // wings: two dusty fans with eye spots, hinged at the back
  for (const s of [-1, 1]) {
    const wing = bone(s < 0 ? 'wingR' : 'wingL', body, s * 0.08, 1.2, -0.14);
    const wg = new Geometry();
    const c = wg.vert(0, 0, 0, 0, 0, -1, 0, 0);
    const ring = [];
    const N = 12;
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      const a = lerp(-1.25, 1.35, t);
      const r = (0.62 + 0.18 * Math.sin(t * Math.PI * 2 + 0.4)) * (t < 0.5 ? 1 : 0.85);
      ring.push(wg.vert(s * Math.cos(a) * r, Math.sin(a) * r * 0.9, -0.02 * Math.abs(Math.sin(a)), 0, 0, -1, t, 1));
    }
    for (let i = 0; i < N; i++) {
      if (s > 0) wg.tri(c, ring[i + 1], ring[i]); else wg.tri(c, ring[i], ring[i + 1]);
    }
    wg.paint((p) => {
      const d = Math.hypot(Math.abs(p[0]) - 0.36, p[1] - 0.1);
      const spot = d < 0.07 ? 1 : 0;
      const ringC = d < 0.11 ? 1 : 0;
      let col = mix3(C('#6a5ea8'), C('#b4ace0'), smoothstep(0.1, 0.6, Math.hypot(p[0], p[1])));
      if (ringC) col = C('#4a3a7a');
      if (spot) col = C('#9fe8ff');
      return col.concat([1]);
    });
    wg.paintExtra((p) => [Math.hypot(Math.abs(p[0]) - 0.36, p[1] - 0.1) < 0.07 ? 1.6 : 0.08]);
    wg.computeNormals();
    wing.add(mesh(ctx, wg, M.clothDS, 'shepherdWing'));
    bones[s < 0 ? 'wingR' : 'wingL'] = wing;
  }
  // arms: the right one holds a crook with a lantern
  for (const s of [-1, 1]) {
    const arm = bone(s < 0 ? 'armR' : 'armL', body, s * 0.2, 1.26, 0.02);
    const ag = Geometry.cylinder(0.035, 0.05, 0.5, 7, 1);
    ag.translate(0, -0.25, 0);
    const hand = egg(0.04, 0.045, 0.04, 6, 5);
    hand.translate(0, -0.5, 0.01);
    hand.setColor(C('#aab2dc'), 1);
    ag.paint(() => C('#7a74b4').concat([1]));
    ag.append(hand);
    arm.add(mesh(ctx, ag, M.cloth));
    bones[s < 0 ? 'armR' : 'armL'] = arm;
  }
  const crook = bone('crook', bones.armR, 0, -0.5, 0.05);
  bones.crook = crook;
  const cpts = catmullRom([[0, -0.9, 0], [0, 0.4, 0], [0, 0.95, 0], [0.04, 1.08, 0], [0.16, 1.12, 0], [0.24, 1.05, 0], [0.25, 0.95, 0]], 4);
  const cg = Geometry.tube(cpts, () => 0.018, 5, { capEnd: true });
  cg.setColor(C('#7a6048'), 1);
  crook.add(mesh(ctx, cg, M.wood));
  const lg = egg(0.06, 0.08, 0.06, 8, 6);
  lg.translate(0.25, 0.84, 0);
  lg.setColor(C('#bfe8ff'), 1);
  lg.setExtra([1.8]);
  crook.add(mesh(ctx, lg, M.glow));
  bones.lamp = bone('lamp', crook, 0.25, 0.84, 0);
  void rng;
  return { root, bones };
}

// ------------------------------------------------------------------ cloud sheep (Felhőbárány)
// (v9.1d) rebuilt: a proper little sheep made of cloud - a rounded body of soft woolly puffs (darker in the
// creases), a charcoal face with a pale muzzle and nose, floppy ears, big gentle eyes, a woolly topknot, slim
// legs with fleece cuffs and little hooves, a puff of a tail and a tiny golden bell on a ribbon.
export function buildCloudSheep(ctx, seed = 1, fluff = null) {
  const M = ctx.M;
  if (!M.fleece) M.fleece = new Material({ uniforms: { uRough: 0.95, uDetail: [6, 0.05, 0.22, 4], uGlitter: [16, 0.03, 0.25], uRim: 0.8, uWrap: 0.6, uFill: 0.4, uGlowStrength: 1 } });
  const rng = new RNG(seed);
  const root = new Node('sheep');
  const bones = {};
  const body = bone('body', root, 0, 0.42, 0);
  bones.body = body;
  const col = C(fluff || rng.pick(['#ddd6f0', '#d2dcf2', '#ead8ee']));
  const shade = mix3(col, C('#5a5a9a'), 0.45);
  // ---- the fleece: a core with a coat of puffs spread evenly over it (fewer underneath)
  const RX = 0.27, RY = 0.23, RZ = 0.36;
  const g = new Geometry();
  const core = Geometry.icosphere(1, 3);
  core.scale(RX, RY, RZ);
  g.append(core);
  const NP = 30;
  for (let i = 0; i < NP; i++) {
    const y = 1 - (2 * (i + 0.5)) / NP, rr = Math.sqrt(1 - y * y), a = i * 2.39996 + seed;
    const d = [Math.cos(a) * rr, y, Math.sin(a) * rr];
    if (d[1] < -0.6) continue;
    const r = rng.range(0.12, 0.15) * (d[1] < -0.2 ? 0.8 : 1);
    const pf = Geometry.icosphere(1, 3);
    pf.scale(r, r * 0.92, r);
    pf.translate(d[0] * RX * 0.8, d[1] * RY * 0.8, d[2] * RZ * 0.8);
    g.append(pf);
  }
  g.computeNormals();
  g.displace((p) => noise.n3(p[0] * 9 + seed, p[1] * 9, p[2] * 9) * 0.006, true);
  g.paint((p) => {
    // soft cloud shading: the top catches the moonlight, the belly and the deepest creases sink into blue
    const e = Math.hypot(p[0] / RX, p[1] / RY, p[2] / RZ);
    const crease = 1 - smoothstep(0.95, 1.2, e);
    const under = smoothstep(0.05, -0.22, p[1]);
    const c = mix3(col, shade, Math.min(1, crease * 0.3 + under * 0.45));
    return c.concat([0.78 + 0.22 * (1 - crease) * (1 - under * 0.5)]);
  });
  // a puff of a tail
  const tl = Geometry.icosphere(1, 2);
  tl.scale(0.07, 0.065, 0.06);
  tl.translate(0, 0.08, -RZ - 0.04);
  tl.paint(() => col.concat([0.9]));
  g.append(tl);
  body.add(mesh(ctx, g, M.fleece, 'sheepFleece'));
  // ---- the head
  const head = bone('head', body, 0, 0.08, 0.36);
  bones.head = head;
  const face = C('#4a4368'), muzzleC = C('#6a6290');
  const hg = new Geometry();
  // a long gentle sheep face: the skull tapers into a soft muzzle
  const skull = Geometry.lathe([[0, -0.1], [0.05, -0.085], [0.072, -0.03], [0.078, 0.03], [0.068, 0.08], [0.04, 0.11], [0, 0.118]], 18, {});
  skull.rotateX(Math.PI / 2);
  skull.scale(1, 1.05, 1);
  skull.translate(0, 0.0, 0.1);
  hg.append(skull);
  const muz = egg(0.05, 0.048, 0.06, 14, 10);
  muz.translate(0, -0.03, 0.17);
  hg.append(muz);
  hg.computeNormals();
  hg.paint((p) => mix3(face, muzzleC, smoothstep(0.12, 0.2, p[2])).concat([smoothstep(-0.08, 0.04, p[1]) * 0.25 + 0.75]));
  const nose = egg(0.02, 0.013, 0.01, 10, 6);
  nose.rotateX(-0.3);
  nose.translate(0, -0.018, 0.226);
  nose.setColor(C('#b884ac'), 1);
  hg.append(nose);
  const mouth = Geometry.torus(0.014, 0.0035, 4, 10, Math.PI);
  mouth.rotateX(Math.PI / 2);
  mouth.translate(0, -0.052, 0.214);
  mouth.setColor(C('#231e36'), 1);
  hg.append(mouth);
  // floppy ears, dark outside, pink inside
  for (const s of [-1, 1]) {
    const ear = egg(0.07, 0.03, 0.018, 12, 6);
    const inner = egg(0.05, 0.018, 0.008, 10, 4);
    inner.translate(s * 0.006, 0, 0.012);
    ear.setColor(face, 1);
    inner.setColor(C('#d6a2c6'), 1);
    ear.append(inner);
    ear.translate(s * 0.06, 0, 0);
    ear.rotateZ(-0.45 * s);
    ear.rotateY(0.3 * s);
    ear.translate(s * 0.06, 0.045, 0.06);
    hg.append(ear);
  }
  head.add(mesh(ctx, hg, M.skin, 'sheepHead'));
  // a woolly topknot
  const tk = new Geometry();
  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * TAU;
    const t = Geometry.icosphere(1, 2);
    const r = k === 0 ? 0.05 : 0.038;
    t.scale(r, r * 0.9, r);
    t.translate(k === 0 ? 0 : Math.cos(a) * 0.045, 0.08 + (k === 0 ? 0.02 : 0), 0.06 + (k === 0 ? 0 : Math.sin(a) * 0.04));
    tk.append(t);
  }
  tk.paint(() => col.concat([0.9]));
  head.add(mesh(ctx, tk, M.fleece, 'sheepTopknot'));
  head.add(mesh(ctx, eyes(0.064, 0.032, 0.122, 0.021, C('#bfe6ff'), { pupil: 0.62, glow: 1.1 }), M.glowSoft));
  // a ribbon with a tiny golden bell
  const bellG = new Geometry();
  const rib = Geometry.torus(0.075, 0.012, 6, 18);
  rib.rotateX(0.35);
  rib.translate(0, -0.06, -0.03);
  rib.setColor(C('#4a6ad8'), 1);
  bellG.append(rib);
  const bell = Geometry.lathe([[0.0, 0.0], [0.022, 0.004], [0.02, 0.02], [0.014, 0.036], [0.0, 0.04]], 10, { capBottom: true });
  bell.rotateX(Math.PI);
  bell.translate(0, -0.1, 0.035);
  bell.setColor(C('#e8c060'), 1);
  bellG.append(bell);
  head.add(mesh(ctx, bellG, M.glossy, 'sheepBell'));
  // ---- legs: slim, dark, with a woolly cuff at the top and little pale hooves
  for (const [n, x, z] of [['legFL', 0.12, 0.2], ['legFR', -0.12, 0.2], ['legBL', 0.12, -0.2], ['legBR', -0.12, -0.2]]) {
    const leg = bone(n, body, x, -0.1, z);
    const lg = Geometry.cylinder(0.026, 0.03, 0.3, 8, 2);
    lg.translate(0, -0.3, 0);
    lg.setColor(face, 1);
    const hoof = egg(0.03, 0.022, 0.036, 10, 6);
    hoof.translate(0, -0.31, 0.006);
    hoof.setColor(C('#8a86a8'), 1);
    lg.append(hoof);
    leg.add(mesh(ctx, lg, M.skin));
    const cuff = Geometry.icosphere(1, 2);
    cuff.scale(0.058, 0.05, 0.058);
    cuff.translate(0, -0.035, 0);
    cuff.paint(() => mix3(col, shade, 0.2).concat([0.85]));
    leg.add(mesh(ctx, cuff, M.fleece));
    bones[n] = leg;
  }
  return { root, bones };
}

