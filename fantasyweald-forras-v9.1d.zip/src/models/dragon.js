// The Seven-Headed Dragon (Hétfejű sárkány, straight out of the Hungarian folk tales) and its ember imps.
// (v8) Sculpted from lofted cross-sections: a heavy scaled body with a ridge of jagged dorsal blades,
// folded bat wings with finger bones and a membrane, clawed legs, a curled tail with a spade, and seven
// long necks (chains of bones the game bends to make them sleep, rise, sway, track you and breathe
// fire), each ending in a horned head with brow ridges, slit-pupil ember eyes, rows of fangs and a jaw
// that opens onto a glowing throat. The skin uses the SCALES shader: domed scales whose creases smoulder
// on the belly and throat.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep, clamp } from '../engine/math.js';
import { C } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const mesh = (ctx, g, mat, name = '') => new Mesh(new GpuGeometry(ctx.gl, g), mat, name);
const spow = (v, p) => Math.sign(v) * Math.pow(Math.abs(v), p);
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const lerp3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

// smooth piecewise profile through [z, value] keys
function prof(z, keys) {
  if (z <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (z <= keys[i][0]) {
      const [z0, v0] = keys[i - 1], [z1, v1] = keys[i];
      const u = (z - z0) / (z1 - z0);
      return v0 + (v1 - v0) * u * u * (3 - 2 * u);
    }
  }
  return keys[keys.length - 1][1];
}
function bone(name, parent, x = 0, y = 0, z = 0) {
  const n = new Node(name);
  n.setPos(x, y, z);
  parent.add(n);
  return n;
}

// Loft: sweep a cross-section along a path. shape(t, a) returns the [side, up] offset of the point at
// angle a on the ring at t (0..1 along the path). Frames are parallel-transported from the up hint.
// uv = (a / 2pi, t), so painters can find where a vertex sits.
export function loft(path, radial, shape, { up = [0, 1, 0], capStart = false, capEnd = false } = {}) {
  const g = new Geometry();
  const n = path.length;
  const T = [];
  for (let i = 0; i < n; i++) T.push(norm(sub(path[Math.min(n - 1, i + 1)], path[Math.max(0, i - 1)])));
  let u = norm(sub(up, mul(T[0], dot(up, T[0]))));
  const rings = [];
  for (let i = 0; i < n; i++) {
    if (i > 0) u = norm(sub(u, mul(T[i], dot(u, T[i]))));
    const S = norm(cross(u, T[i]));
    const U = cross(T[i], S);
    u = U;
    const t = i / (n - 1), p = path[i], ring = [];
    for (let j = 0; j < radial; j++) {
      const a = (j / radial) * TAU;
      const [x, y] = shape(t, a, i);
      ring.push(g.vert(p[0] + S[0] * x + U[0] * y, p[1] + S[1] * x + U[1] * y, p[2] + S[2] * x + U[2] * y, 0, 1, 0, j / radial, t));
    }
    rings.push(ring);
  }
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < radial; j++) {
      const j2 = (j + 1) % radial;
      g.quad(rings[i][j], rings[i][j2], rings[i + 1][j2], rings[i + 1][j]);
    }
  }
  const cap = (ring, t, end) => {
    let cx = 0, cy = 0, cz = 0;
    for (const v of ring) { cx += g.p[v * 3]; cy += g.p[v * 3 + 1]; cz += g.p[v * 3 + 2]; }
    const c = g.vert(cx / ring.length, cy / ring.length, cz / ring.length, 0, 1, 0, 0.5, t);
    for (let j = 0; j < radial; j++) {
      const j2 = (j + 1) % radial;
      if (end) g.tri(c, ring[j], ring[j2]); else g.tri(c, ring[j2], ring[j]);
    }
  };
  if (capStart) cap(rings[0], 0, false);
  if (capEnd) cap(rings[n - 1], 1, true);
  g.computeNormals();
  return g;
}
// a round tapering horn / claw / tooth along a curve, with growth rings
function horn(pts, r0, r1 = 0.004, { radial = 8, ridges = 0, samples = 4, flat = 1 } = {}) {
  const path = pts.length > 2 ? catmullRom(pts, samples) : [pts[0], lerp3(pts[0], pts[1], 0.33), lerp3(pts[0], pts[1], 0.66), pts[1]];
  return loft(path, radial, (t, a) => {
    const r = lerp(r0, r1, Math.pow(t, 0.85)) * (1 + (ridges ? Math.sin(t * ridges * TAU) * 0.06 * (1 - t) : 0));
    return [Math.cos(a) * r * flat, Math.sin(a) * r];
  }, { capStart: true });
}
// a jagged blade (dorsal plate, tail spade): rises from the base along +y, swept back towards -z
function blade(len, h, th, sweep = 0.4, hook = 0.25) {
  const path = [];
  for (let i = 0; i <= 6; i++) { const t = i / 6; path.push([0, t * h, -sweep * h * t * t]); }
  return loft(path, 8, (t, a) => {
    const w = th * 0.5 * (1 - t * 0.85);
    const s = Math.sin(a);
    const len2 = len * 0.5 * Math.pow(1 - t, 0.8) * (s > 0 ? 1 : 1 - hook * Math.sin(t * Math.PI));
    return [Math.cos(a) * w, s * len2];
  }, { up: [0, 0, 1], capStart: true });
}

export const NECKS = 7;
export const NECK_SEGS = 7;
export const SEG_LEN = 1.75;

// ------------------------------------------------------------------ materials
function dragonMaterials(M) {
  if (!M.dragonSkin) {
    M.dragonSkin = new Material({
      defines: { SCALES: 1 },
      uniforms: { uRough: 0.5, uDetail: [0, 0, 0, 0], uGlitter: [0, 0, 0], uRim: 0.28, uWrap: 0.2, uFill: 0.14, uScales: [3.0, 0.14, 0.045, 0.45], uEmberColor: C('#ff4a12', 1.2), uEmber: 0 },
    });
    M.dragonHorn = new Material({ uniforms: { uRough: 0.34, uDetail: [7, 0.18, 0.2, 2], uGlitter: [0, 0, 0], uRim: 0.25, uWrap: 0.2, uFill: 0.12 } });
    // the imps have finer scales and a plain leathery wing
    M.impSkin = new Material({
      defines: { SCALES: 1 },
      uniforms: { uRough: 0.55, uDetail: [0, 0, 0, 0], uGlitter: [0, 0, 0], uRim: 0.4, uWrap: 0.3, uFill: 0.25, uScales: [9.0, 0.12, 0.012, 0.5], uEmberColor: C('#ff5a1a', 1.2), uEmber: 0 },
    });
    M.impWing = new Material({ cull: 'none', uniforms: { uRough: 0.8, uDetail: [14, 0.2, 0.05, 4], uRim: 0.45, uWrap: 0.5, uFill: 0.25, uGlitter: [0, 0, 0] } });
    M.dragonWing = new Material({ cull: 'none', defines: { SCALES: 1 }, uniforms: { uRough: 0.75, uDetail: [0, 0, 0, 0], uRim: 0.4, uWrap: 0.5, uFill: 0.25, uGlitter: [0, 0, 0], uScales: [9.0, 0.05, 0.01, 0.0], uEmberColor: C('#ff4a12'), uEmber: 0 } });
  }
  return { skinM: M.dragonSkin, hornM: M.dragonHorn, wingM: M.dragonWing, impM: M.impSkin, impWingM: M.impWing };
}
const SKIN_TOP = C('#0d090c'), SKIN_SIDE = C('#2c0c10'), SKIN_BELLY = C('#4e2414'), SPINE = C('#08060a');
const skinColor = (p, n, k = 0) => {
  const b = noise.n3(p[0] * 0.45 + k, p[1] * 0.45, p[2] * 0.45) * 0.5 + 0.5;
  const under = smoothstep(0.05, -0.55, n[1]);
  return mix3(mix3(SKIN_TOP, SKIN_SIDE, b * 0.55 + smoothstep(0.7, -0.1, n[1]) * 0.45), SKIN_BELLY, under);
};
// horn/claw colour: pale bone at the root, darkening to black at the tip (uv.y = t along the horn)
const hornPaint = (g, c0 = '#6a5a46', c1 = '#0a0706') => g.paint((p, n, i) => mix3(C(c0), C(c1), smoothstep(0.1, 0.95, g.uv[i * 2 + 1])).concat([1]));
const bladePaint = (g) => g.paint((p, n, i) => mix3(SPINE, C('#3a1210'), smoothstep(0.6, 1, g.uv[i * 2 + 1]) * 0.8).concat([1]));

// ------------------------------------------------------------------ one bat wing (dragon and imp)
// An arm, a wrist with a thumb claw, fingers fanning out behind it and a membrane sagging between them.
// Coordinates relative to the shoulder.
function buildWing(sx, { elbow, wrist, tips, hip, r = 0.35, scallop = 0.5, bulge = 0.25, col0 = '#2a070b', col1 = '#6a1a16', boneCol = SKIN_TOP }) {
  const bones = new Geometry();
  bones.append(horn([[0, 0, 0], elbow], r, r * 0.7, { radial: 8 }));
  bones.append(horn([elbow, wrist], r * 0.72, r * 0.5, { radial: 8 }));
  for (const tp of tips) {
    const mid = lerp3(wrist, tp, 0.5);
    mid[1] += r * 0.8;
    bones.append(horn([wrist, mid, tp], r * 0.45, r * 0.06, { radial: 6 }));
  }
  const kn = Geometry.sphere(r * 0.75, 8, 6);
  kn.translate(wrist[0], wrist[1], wrist[2]);
  bones.append(kn);
  bones.setColor(boneCol, 1);
  const claw = horn([add(wrist, [0, r * 0.4, 0]), add(wrist, [sx * r * 0.6, r * 2.2, r * 1.2]), add(wrist, [sx * r * 0.5, r * 2.6, r * 2.4])], r * 0.35, 0.004, { radial: 6 });
  hornPaint(claw, '#5a4a3a', '#0a0808');
  bones.append(claw);
  // membrane panels: wrist -> finger k -> finger k+1, and the arm panel back to the hip
  const mem = new Geometry();
  const out0 = norm(cross(sub(tips[0], wrist), sub(tips[tips.length - 1], wrist)));
  const outS = dot(out0, [sx, 0, 0]) < 0 ? mul(out0, -1) : out0;
  const panel = (A, B0, B1, inward) => {
    const N = 7, M2 = 6;
    const span = Math.hypot(...sub(B1, B0));
    const grid = [];
    for (let i = 0; i <= N; i++) {
      const row = [];
      for (let j = 0; j <= M2; j++) {
        const u = i / N, v = j / M2;
        const edge = add(lerp3(B0, B1, v), mul(inward, Math.sin(v * Math.PI) * scallop));
        const p = add(lerp3(A, edge, u), mul(outS, Math.sin(u * Math.PI) * Math.sin(v * Math.PI) * bulge * span * 0.15));
        row.push(mem.vert(p[0], p[1], p[2], 0, 1, 0, v, u));
      }
      grid.push(row);
    }
    for (let i = 0; i < N; i++) for (let j = 0; j < M2; j++) mem.quad(grid[i][j], grid[i][j + 1], grid[i + 1][j + 1], grid[i + 1][j]);
  };
  for (let k = 0; k < tips.length - 1; k++) panel(wrist, tips[k], tips[k + 1], norm(sub(wrist, lerp3(tips[k], tips[k + 1], 0.5))));
  if (hip) {
    const last = tips[tips.length - 1];
    panel(wrist, last, hip, norm(sub(wrist, lerp3(last, hip, 0.5))));
    panel([0, 0, 0], wrist, hip, [0, 0, 0]);
  }
  mem.computeNormals();
  // veins along the fingers, darker near the bones, warmer at the thin trailing edge
  mem.paint((p, n, i) => {
    const v = mem.uv[i * 2], u = mem.uv[i * 2 + 1];
    const vein = Math.max(smoothstep(0.12, 0, v), smoothstep(0.88, 1, v)) * 0.6 + smoothstep(0.03, 0, Math.abs(Math.sin(v * 9 + u * 3)) * 0.1) * 0.25;
    return mix3(mix3(C(col0), C(col1), smoothstep(0.35, 1, u)), boneCol, vein).concat([1]);
  });
  return { bones, mem };
}

// ------------------------------------------------------------------ the dragon
export function buildDragon(ctx, seed = 7) {
  const M = ctx.M;
  const { skinM, hornM, wingM } = dragonMaterials(M);
  const rng = new RNG(seed);
  const root = new Node('dragon');
  const bones = { necks: [], heads: [], jaws: [] };
  const body = bone('body', root, 0, 2.7, -2);
  bones.body = body;
  const TOPK = [[-8.4, 1.5], [-5.5, 2.2], [-1.5, 2.0], [2.5, 2.3], [5.6, 2.0], [6.8, 1.6]];
  const SPY = [[-8.4, 0.3], [-5.5, 1.0], [-1.5, 0.9], [2.5, 1.2], [5.6, 1.1], [6.8, 0.9]];

  // ---- the body: a heavy, deep-chested barrel lying on its belly
  const spine = catmullRom([[0, 0.3, -8.4], [0, 1.0, -5.5], [0, 0.9, -1.5], [0, 1.2, 2.5], [0, 1.1, 5.6], [0, 0.9, 6.8]], 5);
  const bodyG = loft(spine, 30, (t, a) => {
    const z = lerp(-8.4, 6.8, t);
    const w = prof(z, [[-8.4, 1.7], [-6.2, 3.3], [-4.2, 3.9], [-1.5, 4.1], [2.0, 4.0], [4.5, 3.6], [6.2, 3.2], [6.8, 2.6]]);
    const top = prof(z, TOPK);
    const bot = prof(z, [[-8.4, 1.6], [-6, 3.0], [-1.5, 3.2], [3, 3.35], [6.8, 2.0]]);
    const c = Math.cos(a), s = Math.sin(a);
    let x = spow(c, 0.8) * w;
    let y = s > 0 ? spow(s, 0.9) * top : spow(s, 0.7) * bot;
    // muscle bulges at the shoulders and the haunches, a raised ridge along the spine
    x *= 1 + 0.08 * Math.exp(-(((z - 3.6) / 1.6) ** 2)) * Math.abs(c) + 0.1 * Math.exp(-(((z + 4.6) / 1.8) ** 2)) * Math.abs(c);
    y += 0.25 * Math.pow(Math.max(0, s), 24);
    // the belly flattens where it lies on the ash
    const spineY = prof(z, SPY);
    return [x, Math.max(y, -2.28 - spineY)];
  }, { capStart: true, capEnd: true });
  bodyG.paint((p, n) => skinColor(p, n).concat([0.9]));
  bodyG.paintExtra((p, n) => [0, 0, smoothstep(-0.2, -0.7, n[1]) * 0.9, 0]);
  body.add(mesh(ctx, bodyG, skinM, 'dragonBody'));
  // dorsal blades down the spine: big over the shoulders, jagged, black
  const plates = new Geometry();
  for (let i = 0; i < 17; i++) {
    const z = -8 + i * 0.86;
    const h = 0.7 + Math.sin(clamp((i + 1) / 16, 0, 1) * Math.PI) * 1.9 + rng.range(-0.2, 0.2);
    const topY = prof(z, TOPK) + prof(z, SPY);
    const b = blade(1.1 + h * 0.25, h, 0.16, 0.45, 0.35);
    b.rotateZ(rng.range(-0.08, 0.08));
    b.translate(0, topY - 0.15, z);
    plates.append(b);
    if (i % 2 === 0 && i > 1 && i < 15) {
      for (const sx of [-1, 1]) {
        const b2 = blade(0.6, h * 0.35, 0.1, 0.5, 0.3);
        b2.rotateZ(sx * 0.5);
        b2.translate(sx * 0.9, topY - 0.35, z + 0.3);
        plates.append(b2);
      }
    }
  }
  bladePaint(plates);
  body.add(mesh(ctx, plates, hornM, 'dragonPlates'));

  // ---- legs lying folded under it, with long black claws
  const legs = new Geometry();
  const claws = new Geometry();
  const foot = (wx, wz, sx, size) => {
    for (let k = 0; k < 4; k++) {
      const spread = (k - 1.5) * 0.32 * sx;
      const len = size * (k === 0 || k === 3 ? 0.75 : 1);
      const a = [wx, -2.15, wz];
      const tip = [wx + Math.sin(spread) * len * 1.3, -2.3, wz + Math.cos(spread) * len * 1.3];
      const knuck = [lerp(a[0], tip[0], 0.55), -1.98, lerp(a[2], tip[2], 0.55)];
      legs.append(horn([a, knuck, tip], 0.22 * size, 0.13 * size, { radial: 7 }));
      const c = horn([tip, [tip[0] + Math.sin(spread) * 0.3 * size, -2.28, tip[2] + 0.35 * size], [tip[0] + Math.sin(spread) * 0.45 * size, -2.62, tip[2] + 0.5 * size]], 0.12 * size, 0.004, { radial: 6 });
      hornPaint(c, '#2a2220', '#050404');
      claws.append(c);
    }
  };
  for (const sx of [-1, 1]) {
    const sh = [sx * 3.1, -0.3, 3.4], el = [sx * 4.4, -1.8, 2.2], wr = [sx * 4.3, -2.1, 5.0];
    legs.append(loft(catmullRom([sh, [sx * 4.0, -1.0, 2.9], el], 3), 12, (t, a) => { const r = lerp(1.25, 0.72, t); return [Math.cos(a) * r, Math.sin(a) * r * 1.1]; }, { capStart: true }));
    legs.append(loft(catmullRom([el, [sx * 4.45, -2.0, 3.6], wr], 3), 10, (t, a) => { const r = lerp(0.72, 0.45, t) * (1 + 0.15 * Math.sin(t * Math.PI)); return [Math.cos(a) * r, Math.sin(a) * r]; }, { capEnd: true }));
    foot(wr[0], wr[2], sx, 1.0);
    const hp = [sx * 3.2, 0.2, -4.6], kn = [sx * 4.3, -1.6, -2.6], an = [sx * 4.2, -2.1, -5.4];
    legs.append(loft(catmullRom([hp, [sx * 3.9, -0.6, -3.6], kn], 3), 14, (t, a) => { const r = lerp(1.75, 0.8, t) * (1 + 0.12 * Math.sin(t * Math.PI)); return [Math.cos(a) * r, Math.sin(a) * r * 1.15]; }, { capStart: true }));
    legs.append(loft(catmullRom([kn, [sx * 4.4, -2.0, -4.0], an], 3), 10, (t, a) => { const r = lerp(0.8, 0.45, t); return [Math.cos(a) * r, Math.sin(a) * r]; }, { capEnd: true }));
    foot(an[0], an[2], sx, 1.1);
    const spur = horn([[an[0], -2.0, an[2]], [an[0] + sx * 0.2, -1.9, an[2] - 0.7]], 0.14, 0.004);
    hornPaint(spur, '#3a2e2a', '#050404');
    claws.append(spur);
  }
  legs.paint((p, n) => skinColor(p, n, 3).concat([0.9]));
  legs.paintExtra((p, n) => [0, 0.2, smoothstep(-0.3, -0.8, n[1]) * 0.6, 0]);
  body.add(mesh(ctx, legs, skinM, 'dragonLegs'));
  body.add(mesh(ctx, claws, hornM, 'dragonClaws'));

  // ---- folded wings, each on its own shoulder bone (they half open when it wakes)
  for (const sx of [-1, 1]) {
    const wb = bone(sx < 0 ? 'wingR' : 'wingL', body, sx * 2.9, 2.0, 3.0);
    bones[sx < 0 ? 'wingR' : 'wingL'] = wb;
    const w = buildWing(sx, {
      elbow: [sx * 0.9, 1.6, -2.6], wrist: [sx * 1.5, 3.3, 0.5],
      tips: [[sx * 2.9, 1.9, -7.2], [sx * 3.0, 0.4, -9.6], [sx * 2.6, -0.8, -10.9], [sx * 1.9, -1.6, -9.2]],
      hip: [sx * 1.1, -0.9, -7.2], r: 0.36, scallop: 0.9, bulge: 0.35,
    });
    wb.add(mesh(ctx, w.bones, skinM, 'wingBones'));
    wb.add(mesh(ctx, w.mem, wingM, 'wingSkin'));
  }

  // ---- the tail: curled round the hoard, a row of blades, ending in a barbed spade
  const tailCtrl = [[0, 0.5, -8.0], [1.8, 0.0, -12.2], [6.5, -0.6, -15.3], [11.8, -1.0, -13.4], [14.6, -1.3, -8.2], [14.4, -1.5, -2.6], [12.2, -1.6, 1.4]];
  const tailPath = catmullRom(tailCtrl, 6);
  const tailR = (t) => lerp(1.75, 0.14, Math.pow(t, 0.8));
  const tail = loft(tailPath, 14, (t, a) => {
    const r = tailR(t), s = Math.sin(a);
    return [Math.cos(a) * r * 1.05, s > 0 ? s * r + 0.12 * r * Math.pow(s, 16) : s * r * 0.8];
  }, { capStart: true, capEnd: true });
  tail.paint((p, n) => skinColor(p, n, 7).concat([0.9]));
  tail.paintExtra((p, n) => [0, 0.3, smoothstep(-0.2, -0.7, n[1]) * 0.7, 0]);
  body.add(mesh(ctx, tail, skinM, 'dragonTail'));
  const tailBl = new Geometry();
  for (let i = 1; i < 16; i++) {
    const u = i / 16;
    const k = Math.floor(u * (tailPath.length - 1));
    const p = tailPath[k], q = tailPath[Math.min(tailPath.length - 1, k + 1)];
    const r = tailR(u);
    const b = blade(0.3 + r * 0.5, 0.25 + r * 0.7, 0.08 + r * 0.05, 0.5, 0.3);
    b.rotateY(Math.atan2(p[0] - q[0], p[2] - q[2]));
    b.translate(p[0], p[1] + r * 0.92, p[2]);
    tailBl.append(b);
  }
  const tipP = tailPath[tailPath.length - 1], preP = tailPath[tailPath.length - 4];
  const tipYaw = Math.atan2(tipP[0] - preP[0], tipP[2] - preP[2]);
  for (const [roll, sc] of [[Math.PI / 2, 1], [-Math.PI / 2, 1], [0, 0.6]]) {
    const b = blade(0.9 * sc, 1.3 * sc, 0.08, -0.6, 0.5);
    b.rotateX(Math.PI / 2);
    b.rotateZ(roll);
    b.rotateY(tipYaw);
    b.translate(tipP[0], tipP[1], tipP[2]);
    tailBl.append(b);
  }
  bladePaint(tailBl);
  body.add(mesh(ctx, tailBl, hornM, 'dragonTailBlades'));

  // ---- seven necks, seven heads
  for (let i = 0; i < NECKS; i++) {
    const fan = lerp(-0.95, 0.95, i / (NECKS - 1));
    const base = bone('neck' + i, body, Math.sin(fan) * 2.9, 1.1 + Math.cos(fan * 2) * 0.3, 6.2 + Math.cos(fan) * 0.4);
    base.setEuler(0, fan, 0);
    const segs = [];
    let parent = base;
    const big = i === 3 ? 1.2 : rng.range(0.88, 1.03);
    for (let k = 0; k < NECK_SEGS; k++) {
      const seg = bone('n' + i + '_' + k, parent, 0, 0, k === 0 ? 0 : SEG_LEN);
      seg.add(mesh(ctx, neckSegment(k, big, i), skinM, 'neck'));
      const sp = blade(0.5 * big, (0.75 - k * 0.07) * big, 0.1, 0.5, 0.3);
      sp.translate(0, lerp(1.05, 0.5, (k + 0.4) / NECK_SEGS) * big * 1.02 - 0.08, SEG_LEN * 0.45);
      bladePaint(sp);
      seg.add(mesh(ctx, sp, hornM, 'neckBlade'));
      segs.push(seg);
      parent = seg;
    }
    bones.necks.push({ base, segs, fan, big });
    const head = bone('head' + i, parent, 0, 0, SEG_LEN);
    head.setScale(big);
    const jaw = bone('jaw' + i, head, 0, -0.25, 0.5);
    buildHead(ctx, head, jaw, new RNG(seed * 31 + i * 7), i === 3, { skinM, hornM });
    bones.heads.push(head);
    bones.jaws.push(jaw);
  }
  return { root, bones };
}

// one neck segment: an oval tube (a little flatter underneath), with bronze belly scutes whose creases glow
function neckSegment(k, big, i) {
  const r0 = lerp(1.05, 0.5, k / NECK_SEGS) * big, r1 = lerp(1.05, 0.5, (k + 1) / NECK_SEGS) * big;
  const path = [];
  for (let s = 0; s <= 6; s++) path.push([0, 0, -0.22 + (s / 6) * (SEG_LEN + 0.44)]);
  const g = loft(path, 16, (t, a) => {
    const r = lerp(r0, r1, t) * (1 + 0.05 * Math.sin(t * Math.PI));
    const c = Math.cos(a), s = Math.sin(a);
    return [c * r * 1.04, s > 0 ? s * r * 1.02 : spow(s, 0.8) * r * 0.9];
  });
  g.paint((p, n) => {
    const belly = smoothstep(-0.35, -0.8, n[1]);
    const f = ((p[2] + 0.22) / 0.34) % 1;
    const band = smoothstep(0.1, 0.0, Math.min(f, 1 - f));
    const c = skinColor([p[0], p[1], p[2] + k * 2 + i * 13], n, i);
    return mix3(c, mix3(SKIN_BELLY, C('#140806'), band * 0.8), belly).concat([0.92]);
  });
  g.paintExtra((p, n) => [0, 0.4, smoothstep(-0.55, -0.92, n[1]) * 0.65, 0]);
  return g;
}

// a dragon head in head space: +z forward, the mouth line at y = -0.12, about 3.1 m long
function buildHead(ctx, head, jaw, rng, crown, { skinM, hornM }) {
  const M = ctx.M;
  const Z0 = -0.4, Z1 = 3.15;
  const W = [[-0.4, 0.6], [0.3, 0.72], [1.05, 0.8], [1.6, 0.62], [2.3, 0.44], [2.85, 0.36], [3.15, 0.18]];
  const TOP = [[-0.4, 0.52], [0.25, 0.74], [0.8, 0.66], [1.15, 0.7], [1.7, 0.48], [2.4, 0.4], [2.8, 0.38], [3.15, 0.16]];
  const BOT = [[-0.4, 0.5], [0.3, 0.3], [0.9, 0.14], [3.15, 0.1]];
  const bump = (z, zc, zw, a, ac, aw) => Math.exp(-(((z - zc) / zw) ** 2)) * (Math.exp(-(((a - ac) / aw) ** 2)) + Math.exp(-(((a - (Math.PI - ac)) / aw) ** 2)));
  const path = [];
  for (let s = 0; s <= 30; s++) path.push([0, -0.12, lerp(Z0, Z1, s / 30)]);
  const skull = loft(path, 22, (t, a) => {
    const z = lerp(Z0, Z1, t);
    const c = Math.cos(a), s = Math.sin(a);
    const w = prof(z, W), top = prof(z, TOP), bot = prof(z, BOT);
    let x = spow(c, 0.7) * w;
    let y = s > 0 ? spow(s, 0.75) * top : spow(s, 1.6) * bot;
    // brow ridges over the eyes, a crest on the crown, cheekbones, nostril bumps, eye sockets
    const brow = bump(z, 1.12, 0.32, a, 0.75, 0.35);
    y += brow * 0.2;
    x += Math.sign(c) * brow * 0.1;
    y += Math.exp(-(((z - 0.2) / 0.5) ** 2)) * Math.pow(Math.max(0, s), 18) * 0.22;
    x += Math.sign(c) * Math.exp(-(((z - 0.75) / 0.4) ** 2)) * Math.exp(-((Math.abs(s) / 0.35) ** 2)) * 0.12;
    y += bump(z, 2.85, 0.16, a, 1.1, 0.3) * 0.08;
    x -= Math.sign(c) * bump(z, 1.12, 0.2, a, 0.35, 0.22) * 0.1;
    return [x, y];
  }, { capStart: true, capEnd: true });
  const palate = (p, n) => p[1] < -0.08 && n[1] < -0.6 && p[2] > 0.5;
  skull.paint((p, n) => (palate(p, n) ? C('#4a0806') : skinColor(p, n, 11)).concat([0.9]));
  skull.paintExtra((p, n) => (palate(p, n) ? [0.25, 1, 0, 0] : [0, 1, smoothstep(-0.3, -0.8, n[1]) * 0.5, 0]));
  head.add(mesh(ctx, skull, skinM, 'dragonHead'));
  // ---- the lower jaw: a U-shaped shell whose flat top is the floor of the mouth
  const JW = [[-0.45, 0.5], [0.2, 0.64], [1.0, 0.5], [2.0, 0.34], [2.6, 0.2]];
  const jpath = [];
  for (let s = 0; s <= 22; s++) jpath.push([0, 0.13, lerp(-0.45, 2.6, s / 22)]);
  const jawG = loft(jpath, 18, (t, a) => {
    const z = lerp(-0.45, 2.6, t);
    const w = prof(z, JW);
    const d = prof(z, [[-0.45, 0.25], [0.3, 0.46], [1.4, 0.3], [2.6, 0.2]]);
    const c = Math.cos(a), s = Math.sin(a);
    return [spow(c, 0.7) * w, s > 0 ? s * 0.03 : spow(s, 0.8) * d];
  }, { capStart: true, capEnd: true });
  jawG.paint((p, n) => (n[1] > 0.6 ? C('#4a0806') : skinColor(p, n, 5)).concat([0.9]));
  jawG.paintExtra((p, n) => (n[1] > 0.6 ? [0.3, 1, 0, 0] : [0, 1, smoothstep(-0.2, -0.8, n[1]) * 0.8, 0]));
  const tongue = horn([[0, 0.14, -0.2], [0, 0.18, 0.9], [0, 0.16, 1.8], [0, 0.2, 2.35]], 0.16, 0.05, { radial: 8, flat: 1.5 });
  for (const sx of [-1, 1]) tongue.append(horn([[0, 0.2, 2.3], [sx * 0.12, 0.22, 2.6]], 0.05, 0.005, { radial: 5 }));
  tongue.setColor(C('#5a0c10'), 1);
  tongue.setExtra([0.2, 1, 0, 0]);
  jawG.append(tongue);
  jaw.add(mesh(ctx, jawG, skinM, 'dragonJaw'));
  // ---- teeth: fangs in the upper jaw pointing down, lower teeth pointing up
  const teeth = new Geometry();
  for (let k = 0; k < 9; k++) {
    const z = lerp(1.25, 2.95, k / 8);
    const w = prof(z, W) * 0.86;
    const fang = k === 7;
    const len = fang ? 0.42 : 0.14 + rng.range(0, 0.1);
    for (const sx of [-1, 1]) teeth.append(horn([[sx * w, -0.1, z], [sx * w * 0.97, -0.12 - len * 0.6, z - 0.02], [sx * w * 0.95, -0.12 - len, z - len * 0.25]], fang ? 0.07 : 0.04, 0.003, { radial: 6 }));
  }
  teeth.setColor(C('#d4c6a4'), 1);
  head.add(mesh(ctx, teeth, hornM, 'dragonTeeth'));
  const lteeth = new Geometry();
  for (let k = 0; k < 8; k++) {
    const z = lerp(0.85, 2.4, k / 7);
    const w = prof(z, JW) * 0.85;
    const len = k === 6 ? 0.34 : 0.1 + rng.range(0, 0.08);
    for (const sx of [-1, 1]) lteeth.append(horn([[sx * w, 0.13, z], [sx * w * 0.97, 0.13 + len * 0.6, z + 0.02], [sx * w * 0.95, 0.13 + len, z + len * 0.2]], k === 6 ? 0.06 : 0.035, 0.003, { radial: 6 }));
  }
  lteeth.setColor(C('#d4c6a4'), 1);
  jaw.add(mesh(ctx, lteeth, hornM, 'dragonTeethLow'));
  // ---- horns: a great swept-back pair that curls, a lower pair, brow spikes, a nose horn, a jaw frill
  const horns = new Geometry();
  const hl = crown ? 1.35 : rng.range(0.85, 1.15), curl = rng.range(-0.3, 0.4);
  for (const sx of [-1, 1]) {
    horns.append(horn([[sx * 0.4, 0.6, 0.35], [sx * 0.62, 0.95, -0.3 * hl], [sx * 0.82, 1.2 * hl, -1.1 * hl], [sx * 0.78, (1.05 + curl * 0.4) * hl, -1.9 * hl], [sx * 0.55, (0.62 + curl) * hl, -2.35 * hl]], 0.22, 0.01, { radial: 9, ridges: 9, samples: 5 }));
    horns.append(horn([[sx * 0.7, 0.18, 0.35], [sx * 0.98, 0.05, -0.35], [sx * 1.12, -0.25, -0.95]], 0.13, 0.006, { radial: 7, ridges: 5 }));
    for (let k = 0; k < 3; k++) {
      const z = 1.3 - k * 0.22;
      horns.append(horn([[sx * (0.55 + k * 0.05), 0.72 - k * 0.02, z], [sx * (0.68 + k * 0.06), 0.9 - k * 0.03, z - 0.3]], 0.05, 0.003, { radial: 5 }));
    }
    for (let k = 0; k < 4; k++) {
      const z = 0.25 - k * 0.2;
      horns.append(horn([[sx * (0.62 - k * 0.03), -0.2 - k * 0.06, z], [sx * (0.95 + k * 0.08), -0.35 - k * 0.1, z - 0.45]], 0.07, 0.003, { radial: 5 }));
    }
    if (crown) horns.append(horn([[sx * 0.2, 0.74, 0.6], [sx * 0.28, 1.25, 0.45], [sx * 0.24, 1.55, 0.1]], 0.09, 0.004, { radial: 6, ridges: 4 }));
  }
  horns.append(horn([[0, 0.42, 2.35], [0, 0.66, 2.45], [0, 0.78, 2.3]], 0.09, 0.004, { radial: 6 }));
  hornPaint(horns);
  head.add(mesh(ctx, horns, hornM, 'dragonHorns'));
  // ---- eyes: molten gold with a black slit, sunk under the brow (each on its own node, so it can blink)
  for (const sx of [-1, 1]) {
    const z = 1.12, a = sx > 0 ? 0.35 : Math.PI - 0.35;
    const x = spow(Math.cos(a), 0.7) * prof(z, W) - sx * 0.15, y = -0.12 + spow(Math.sin(a), 0.75) * prof(z, TOP) + 0.02;
    const eye = bone('dragonEye', head, x, y, z);
    const ball = Geometry.sphere(0.15, 12, 8);
    ball.scale(0.75, 1, 1.25);
    ball.setColor(C('#ffb020'), 1);
    ball.setExtra([2.4]);
    const slit = Geometry.box(0.035, 0.2, 0.05);
    slit.translate(sx * 0.09, 0, 0.03);
    slit.setColor(C('#050202'), 1);
    slit.setExtra([0]);
    ball.append(slit);
    ball.rotateY(sx * 0.35);
    const em = mesh(ctx, ball, M.glow, 'dragonEyeBall');
    em.castShadow = false;
    eye.add(em);
  }
  // nostrils: dark pits with a glow deep inside
  const nos = new Geometry();
  for (const sx of [-1, 1]) {
    const n = Geometry.sphere(0.06, 8, 6);
    n.scale(1, 0.6, 1.4);
    n.translate(sx * 0.2, 0.26, 2.92);
    nos.append(n);
  }
  nos.setColor(C('#2a0604'), 1);
  nos.setExtra([0.5]);
  const nm = mesh(ctx, nos, M.glow, 'dragonNostrils');
  nm.castShadow = false;
  head.add(nm);
}

// ------------------------------------------------------------------ ember imps (Parázsmanók)
// The dragon's servants, knee-high to a man: soot-black scaly skin cracked with glowing embers, a big
// head with long pointed ears, curled horns, a hooked nose and a grin full of needle teeth, huge
// yellow eyes, bat wings, a spade tail, backward-bending legs. Some carry a barbed pitchfork, some a
// lantern full of live coals.
export function buildImp(ctx, seed = 1) {
  const M = ctx.M;
  const { impM: skinM, hornM, impWingM: wingM } = dragonMaterials(M);
  const rng = new RNG(seed);
  const root = new Node('imp');
  const bones = {};
  const lantern = seed % 3 === 2;
  const ember = C(rng.pick(['#ff6a1e', '#ff4a2a', '#ff8a2a']));
  const skin = (p, n) => mix3(C('#0e0a0c'), C('#2a1414'), smoothstep(-0.2, 0.9, n[1]) * 0.4 + (noise.n3(p[0] * 9, p[1] * 9, p[2] * 9) * 0.5 + 0.5) * 0.3);
  const emberMask = (p) => smoothstep(0.2, 0.65, noise.n3(p[0] * 16 + seed, p[1] * 16, p[2] * 16)) * 0.7;
  const finish = (g, emb = true) => {
    g.paint((p, n) => skin(p, n).concat([0.95]));
    g.paintExtra((p) => [0, 1, emb ? emberMask(p) : 0, 0]);
    return g;
  };
  const body = bone('body', root, 0, 0.5, 0);
  bones.body = body;
  // torso: hunched, pot-bellied, ribs showing
  const torso = loft(catmullRom([[0, -0.12, -0.02], [0, 0.05, 0.02], [0, 0.2, 0.0], [0, 0.32, -0.05]], 4), 14, (t, a) => {
    const c = Math.cos(a), s = Math.sin(a);
    const w = prof(t, [[0, 0.11], [0.25, 0.12], [0.5, 0.1], [0.8, 0.16], [0.92, 0.15], [1, 0.07]]);
    const fwd = prof(t, [[0, 0.09], [0.3, 0.12], [0.55, 0.08], [0.8, 0.1], [1, 0.06]]);
    const back = prof(t, [[0, 0.08], [0.5, 0.09], [0.85, 0.11], [1, 0.06]]);
    const rib = t > 0.5 && t < 0.85 && s > 0 ? Math.sin(t * 60) * 0.006 : 0;
    return [c * w, (s > 0 ? s * fwd : s * back) + rib];
  }, { up: [0, 0, 1], capStart: true, capEnd: true });
  body.add(mesh(ctx, finish(torso), skinM, 'impTorso'));
  // head: a big skull, heavy brow, hooked nose, long ears
  const headN = bone('head', body, 0, 0.36, 0.0);
  bones.head = headN;
  const hp = [];
  for (let s = 0; s <= 14; s++) hp.push([0, 0.1, lerp(-0.14, 0.17, s / 14)]);
  const hg = loft(hp, 16, (t, a) => {
    const z = lerp(-0.14, 0.17, t);
    const c = Math.cos(a), s = Math.sin(a);
    const w = prof(z, [[-0.14, 0.06], [-0.08, 0.13], [0.03, 0.14], [0.1, 0.1], [0.17, 0.03]]);
    const top = prof(z, [[-0.14, 0.05], [-0.06, 0.13], [0.04, 0.11], [0.11, 0.05], [0.17, 0.02]]);
    const bot = prof(z, [[-0.14, 0.05], [0.0, 0.1], [0.1, 0.1], [0.14, 0.06], [0.17, 0.02]]);
    let y = s > 0 ? s * top : s * bot;
    y += Math.exp(-(((z - 0.07) / 0.03) ** 2)) * Math.exp(-(((a - Math.PI / 2) / 0.9) ** 2)) * 0.03;
    return [c * w, y];
  }, { capStart: true, capEnd: true });
  finish(hg, false);
  const nose = finish(horn([[0, 0.12, 0.15], [0, 0.1, 0.21], [0, 0.04, 0.23]], 0.028, 0.006, { radial: 6 }), false);
  hg.append(nose);
  for (const sx of [-1, 1]) {
    const ear = loft(catmullRom([[sx * 0.11, 0.13, -0.02], [sx * 0.18, 0.17, -0.05], [sx * 0.25, 0.22, -0.09], [sx * 0.29, 0.27, -0.13]], 3), 8, (t, a) => [Math.cos(a) * 0.036 * Math.pow(1 - t, 0.9) + 0.001, Math.sin(a) * 0.006], { up: [0, 0, 1], capStart: true });
    finish(ear, false);
    ear.paint((p, n, i) => (n[2] > 0.3 ? C('#4a1210') : null));
    hg.append(ear);
  }
  headN.add(mesh(ctx, hg, skinM, 'impHead'));
  const hornsG = new Geometry();
  for (const sx of [-1, 1]) hornsG.append(horn([[sx * 0.06, 0.2, 0.02], [sx * 0.11, 0.3, -0.02], [sx * 0.16, 0.33, -0.1], [sx * 0.17, 0.28, -0.16]], 0.028, 0.003, { radial: 6, ridges: 5 }));
  hornPaint(hornsG, '#6a5a48', '#0c0808');
  headN.add(mesh(ctx, hornsG, hornM, 'impHorns'));
  // glowing bits: eyes with pupils, the grin, needle teeth
  const glow = new Geometry();
  for (const sx of [-1, 1]) {
    const e = Geometry.sphere(0.034, 10, 8);
    e.scale(1, 0.8, 0.6);
    e.translate(sx * 0.06, 0.13, 0.135);
    e.setColor(C('#ffb020'), 1);
    e.setExtra([0.85]);
    glow.append(e);
    const pup = Geometry.box(0.01, 0.045, 0.012);
    pup.translate(sx * 0.06, 0.13, 0.156);
    pup.setColor(C('#050202'), 1);
    pup.setExtra([0]);
    glow.append(pup);
  }
  const grin = horn([[-0.08, 0.06, 0.1], [-0.04, 0.035, 0.135], [0.04, 0.035, 0.135], [0.08, 0.06, 0.1]], 0.012, 0.012, { radial: 5, samples: 4 });
  grin.setColor(ember, 1);
  grin.setExtra([0.6]);
  glow.append(grin);
  for (let k = 0; k < 6; k++) {
    const x = lerp(-0.05, 0.05, k / 5);
    const tt = horn([[x, 0.05, 0.138], [x, 0.03, 0.14]], 0.006, 0.001, { radial: 4 });
    tt.setColor(C('#e8dcc0'), 1);
    tt.setExtra([0.3]);
    glow.append(tt);
  }
  const gm = mesh(ctx, glow, M.glow, 'impGlow');
  gm.castShadow = false;
  headN.add(gm);
  // wings: little bat wings, half open
  for (const sx of [-1, 1]) {
    const w = bone(sx < 0 ? 'wingR' : 'wingL', body, sx * 0.08, 0.26, -0.08);
    const wg = buildWing(sx, {
      elbow: [sx * 0.12, 0.12, -0.08], wrist: [sx * 0.26, 0.22, -0.05],
      tips: [[sx * 0.55, 0.12, -0.12], [sx * 0.52, -0.06, -0.14], [sx * 0.36, -0.16, -0.12]],
      hip: [sx * 0.06, -0.18, -0.06], r: 0.012, scallop: 0.05, bulge: 0.3, col0: '#240808', col1: '#6a1a12', boneCol: C('#140c0c'),
    });
    w.add(mesh(ctx, wg.bones, skinM, 'impWingBones'));
    w.add(mesh(ctx, wg.mem, wingM, 'impWing'));
    bones[sx < 0 ? 'wingR' : 'wingL'] = w;
  }
  // legs: backward-bending, clawed feet
  for (const sx of [-1, 1]) {
    const leg = bone(sx < 0 ? 'legR' : 'legL', body, sx * 0.08, -0.12, 0);
    const lg = new Geometry();
    lg.append(loft(catmullRom([[0, 0, 0], [0, -0.1, 0.07], [0, -0.2, 0.05]], 3), 8, (t, a) => { const r = lerp(0.055, 0.03, t); return [Math.cos(a) * r, Math.sin(a) * r]; }, { up: [0, 0, 1], capStart: true }));
    lg.append(loft(catmullRom([[0, -0.2, 0.05], [0, -0.28, -0.01], [0, -0.36, 0.0]], 3), 6, (t, a) => { const r = lerp(0.028, 0.02, t); return [Math.cos(a) * r, Math.sin(a) * r]; }, { up: [0, 0, 1] }));
    finish(lg);
    for (let k = -1; k <= 1; k++) {
      const c = horn([[k * 0.018, -0.37, 0.0], [k * 0.025, -0.38, 0.05], [k * 0.03, -0.4, 0.075]], 0.012, 0.002, { radial: 5 });
      hornPaint(c, '#2a2220', '#050404');
      lg.append(c);
    }
    leg.add(mesh(ctx, lg, skinM, 'impLeg'));
    bones[sx < 0 ? 'legR' : 'legL'] = leg;
  }
  // arms: long and thin, three clawed fingers
  const armGeo = (sx) => {
    const g = new Geometry();
    g.append(loft(catmullRom([[0, 0, 0], [sx * 0.04, -0.1, 0.02], [sx * 0.05, -0.2, 0.05]], 3), 7, (t, a) => { const r = lerp(0.03, 0.022, t); return [Math.cos(a) * r, Math.sin(a) * r]; }, { up: [0, 0, 1], capStart: true }));
    g.append(loft(catmullRom([[sx * 0.05, -0.2, 0.05], [sx * 0.04, -0.26, 0.12], [sx * 0.03, -0.28, 0.18]], 3), 6, (t, a) => { const r = lerp(0.022, 0.018, t); return [Math.cos(a) * r, Math.sin(a) * r]; }));
    finish(g);
    for (let k = -1; k <= 1; k++) {
      const f = horn([[sx * 0.03 + k * 0.012, -0.28, 0.18], [sx * 0.03 + k * 0.02, -0.3, 0.23], [sx * 0.03 + k * 0.022, -0.34, 0.25]], 0.009, 0.002, { radial: 4 });
      hornPaint(f, '#2a2220', '#050404');
      g.append(f);
    }
    return g;
  };
  const arm = bone('arm', body, 0.15, 0.27, 0.02);
  arm.add(mesh(ctx, armGeo(1), skinM, 'impArm'));
  bones.arm = arm;
  const armL = bone('armL', body, -0.15, 0.27, 0.02);
  armL.add(mesh(ctx, armGeo(-1), skinM, 'impArmL'));
  bones.armL = armL;
  // the tail: thin, whip-like, a spade at the end
  const tailN = bone('tail', body, 0, -0.1, -0.12);
  bones.tail = tailN;
  const tg = finish(loft(catmullRom([[0, 0, 0], [0, -0.12, -0.18], [0.04, -0.05, -0.36], [0.08, 0.12, -0.45], [0.1, 0.24, -0.42]], 4), 6, (t, a) => { const r = lerp(0.03, 0.01, t); return [Math.cos(a) * r, Math.sin(a) * r]; }, { capStart: true }));
  const spade = blade(0.08, 0.1, 0.012, 0.0, 0.5);
  spade.rotateX(-0.3);
  spade.translate(0.1, 0.22, -0.42);
  spade.setColor(C('#0e0a0c'), 1);
  tg.append(spade);
  tailN.add(mesh(ctx, tg, skinM, 'impTail'));
  // what it carries: a barbed pitchfork, or a lantern full of live coals
  const tool = new Geometry();
  const toolGlow = new Geometry();
  if (!lantern) {
    const shaft = Geometry.cylinder(0.014, 0.016, 1.0, 6, 1);
    shaft.translate(0, -0.55, 0);
    shaft.setColor(C('#3a2618'), 1);
    tool.append(shaft);
    for (let k = 0; k < 3; k++) {
      const band = Geometry.cylinder(0.019, 0.019, 0.025, 6, 1);
      band.translate(0, -0.5 + k * 0.35, 0);
      band.setColor(C('#6a5a48'), 1);
      tool.append(band);
    }
    const bar = horn([[-0.07, 0.45, 0], [0, 0.43, 0], [0.07, 0.45, 0]], 0.01, 0.01, { radial: 5 });
    bar.setColor(C('#2a2424'), 1);
    tool.append(bar);
    for (const dx of [-0.07, 0, 0.07]) {
      const tine = horn([[dx, 0.45, 0], [dx * 1.1, 0.58, 0], [dx * 1.15, 0.66, 0.01]], 0.009, 0.001, { radial: 4 });
      tine.setColor(C('#2a2424'), 1);
      tool.append(tine);
      const barb = horn([[dx * 1.1, 0.6, 0], [dx * 1.1 + (dx >= 0 ? 0.018 : -0.018), 0.56, 0]], 0.005, 0.001, { radial: 4 });
      barb.setColor(C('#2a2424'), 1);
      tool.append(barb);
      const hot = Geometry.sphere(0.012, 5, 4);
      hot.translate(dx * 1.15, 0.65, 0.01);
      toolGlow.append(hot);
    }
  } else {
    const pole = Geometry.cylinder(0.012, 0.014, 0.55, 6, 1);
    pole.translate(0, -0.1, 0);
    pole.setColor(C('#3a2618'), 1);
    tool.append(pole);
    const hook = horn([[0, 0.45, 0], [0, 0.5, 0.05], [0, 0.46, 0.1], [0, 0.4, 0.1]], 0.008, 0.008, { radial: 4 });
    hook.setColor(C('#2a2424'), 1);
    tool.append(hook);
    const cage = new Geometry();
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * TAU;
      cage.append(horn([[Math.cos(a) * 0.05, 0.36, 0.1 + Math.sin(a) * 0.05], [Math.cos(a) * 0.065, 0.28, 0.1 + Math.sin(a) * 0.065], [Math.cos(a) * 0.05, 0.2, 0.1 + Math.sin(a) * 0.05]], 0.005, 0.005, { radial: 4 }));
    }
    const lid = Geometry.cylinder(0.02, 0.07, 0.04, 8, 1);
    lid.translate(0, 0.36, 0.1);
    cage.append(lid);
    cage.setColor(C('#1e1a1a'), 1);
    tool.append(cage);
    for (let k = 0; k < 5; k++) {
      const coal = Geometry.icosphere(0.025, 0);
      coal.translate(rng.range(-0.025, 0.025), 0.23 + rng.range(0, 0.06), 0.1 + rng.range(-0.025, 0.025));
      toolGlow.append(coal);
    }
  }
  toolGlow.setColor(C('#ff7a2a'), 1);
  toolGlow.setExtra([2.2]);
  const hand = bone('tool', arm, 0.03, -0.3, 0.2);
  hand.add(mesh(ctx, tool, M.metal, 'impTool'));
  const tgm = mesh(ctx, toolGlow, M.glow, 'impToolGlow');
  tgm.castShadow = false;
  hand.add(tgm);
  bones.tool = hand;
  bones.lantern = lantern;
  return { root, bones };
}

// ------------------------------------------------------------------ the dragon's crown
// A band of dark gold with seven points (one for every head), an ember stone on each. On the hoard it is
// big (s = 1.6); on the gnome's hat it is small.
export function buildCrown(ctx, s = 1) {
  const M = ctx.M;
  const node = new Node('crown');
  const gold = new Geometry();
  const R = 0.16 * s, H = 0.07 * s;
  const band = Geometry.lathe([[R * 0.98, 0], [R * 1.05, H * 0.15], [R * 1.05, H * 0.85], [R * 0.98, H], [R * 0.92, H], [R * 0.9, 0]], 28, { capTop: false, capBottom: false });
  gold.append(band);
  const gems = new Geometry();
  for (let k = 0; k < 7; k++) {
    const a = (k / 7) * TAU;
    const pt = Geometry.cylinder(0.004 * s, 0.03 * s, 0.1 * s, 4, 1);
    pt.rotateX(0.12);
    pt.rotateY(a);
    pt.translate(Math.sin(a) * R, H * 0.9, Math.cos(a) * R);
    gold.append(pt);
    const gem = Geometry.sphere(0.016 * s, 6, 4);
    gem.translate(Math.sin(a) * R * 1.07, H * 0.5, Math.cos(a) * R * 1.07);
    gems.append(gem);
    const tipGem = Geometry.sphere(0.012 * s, 6, 4);
    tipGem.translate(Math.sin(a) * R * 1.02, H * 0.9 + 0.1 * s, Math.cos(a) * R * 1.02);
    gems.append(tipGem);
  }
  gold.computeNormals();
  gold.paint((p) => mix3(C('#7a4a12'), C('#e8b858'), smoothstep(0, H + 0.1 * s, p[1])).concat([1]));
  gems.setColor(C('#ff5a2a'), 1);
  gems.setExtra([1.8]);
  node.add(mesh(ctx, gold, M.glossy, 'crownGold'));
  const gm = mesh(ctx, gems, M.glow, 'crownGems');
  gm.castShadow = false;
  node.add(gm);
  return node;
}
