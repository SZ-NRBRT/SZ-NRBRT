// Things that stand in the endless shallow dream sea: doors to nowhere, stairs that end in the air,
// street lamps, giant furniture, an old television, arches and broken columns, a rubber duck, a beach
// ball, a bed you can bounce on, a grandfather clock... Geometry and physics in local space (y = 0 is the
// sea floor); world/dreamsea.js places them.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep } from '../engine/math.js';
import { C } from './materials.js';
import { lantern } from './structures.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
export const PASTELS = ['#f2a7c8', '#9fd8f0', '#b8f0c8', '#d0b8f8', '#ffe29a', '#ffb89a', '#a8b8ff'];

function box(w, h, d, x, y, z, col, ao = 1) {
  const b = Geometry.box(w, h, d, { y0: 0 });
  b.translate(x, y, z);
  b.setColor(C(col), ao);
  return b;
}
function out() {
  return { parts: {}, colliders: [], surfaces: [], lights: [], anchors: {}, radius: 3 };
}
function add(o, mat, g) {
  (o.parts[mat] = o.parts[mat] || new Geometry()).append(g);
}

// ------------------------------------------------------------------ a door standing in the water
// glow: warm light spills out of the gap (it leads somewhere)
export function dreamDoor(seed = 1, { color = null, open = 0.55, glow = true } = {}) {
  const rng = new RNG(seed);
  const o = out();
  const col = color || rng.pick(PASTELS);
  const W = 1.5, H = 3.1, T = 0.28;
  add(o, 'wood', box(0.26, H + 0.25, T, -W / 2 - 0.13, 0, 0, '#e8e0d8', 0.9));
  add(o, 'wood', box(0.26, H + 0.25, T, W / 2 + 0.13, 0, 0, '#e8e0d8', 0.9));
  add(o, 'wood', box(W + 0.52, 0.28, T + 0.04, 0, H + 0.1, 0, '#e8e0d8', 0.9));
  // the door leaf, hinged on the left post, standing open
  const leaf = new Geometry();
  leaf.append(box(W - 0.04, H - 0.04, 0.09, (W - 0.04) / 2, 0.02, 0, col, 1));
  for (const y of [0.55, 1.75]) leaf.append(box(W * 0.62, 0.9, 0.03, W * 0.5 - 0.02, y, 0.06, col, 0.8));
  const knob = Geometry.sphere(0.07, 8, 6);
  knob.translate(W - 0.22, 1.5, 0.1);
  knob.setColor(C('#d8b060'), 1);
  leaf.append(knob);
  leaf.rotateY(-open * 1.6);
  leaf.translate(-W / 2, 0, 0.02);
  add(o, 'wood', leaf);
  if (glow) {
    // light from the other side, filling the doorway
    const lg = Geometry.quadXY(W, H);
    lg.translate(0, 0, -0.02);
    lg.paint((p) => mix3(C('#ffe6b0'), C('#ffb46a'), p[1] / H).concat([1]));
    lg.setExtra([1.4]);
    add(o, 'glowSoft', lg);
    o.lights.push({ pos: [0, 1.4, 0.8], color: C('#ffc88a'), intensity: 1.6, radius: 7 });
  }
  o.colliders.push({ type: 'circle', x: -W / 2 - 0.13, z: 0, r: 0.2 }, { type: 'circle', x: W / 2 + 0.13, z: 0, r: 0.2 });
  // the open leaf
  const ex = -W / 2 + Math.cos(open * 1.6) * W, ez = Math.sin(open * 1.6) * W;
  o.colliders.push({ type: 'seg', ax: -W / 2, az: 0, bx: ex, bz: ez, r: 0.07 });
  o.anchors.doorway = { x: 0, z: 0, hw: W / 2 - 0.1, h: H };
  o.radius = 2.4;
  return o;
}

// ------------------------------------------------------------------ stairs that end in the air
export function dreamStairs(seed = 1, { steps = 14, rise = 0.34, run = 0.62, width = 1.8 } = {}) {
  const rng = new RNG(seed);
  const o = out();
  const col = rng.pick(['#f0ece6', '#e6e0f0', '#f2e2e0']);
  for (let i = 0; i < steps; i++) {
    const top = (i + 1) * rise;
    const z = i * run;
    add(o, 'plaster', box(width, top, run + 0.02, 0, 0, z + run / 2, col, 0.85));
    o.surfaces.push({ type: 'box', x: 0, z: z + run / 2, hx: width / 2, hz: run / 2, top, bottom: -1 });
  }
  // a thin rail and a lamp at the very top
  const topY = steps * rise, endZ = steps * run;
  const rail = new Geometry();
  const pts = [];
  // (v9.1d) the rail runs 85 cm over the steps and its posts stand on them (they used to hang in the air)
  const stepTop = (z) => (Math.min(steps - 1, Math.max(0, Math.floor(z / run))) + 1) * rise;
  for (let i = 0; i <= 8; i++) pts.push([width / 2 - 0.07, rise + 0.85 + (i / 8) * (topY - rise), (i / 8) * (endZ - run) + run * 0.5]);
  rail.append(Geometry.tube(pts, () => 0.03, 5, { capEnd: true }));
  for (let i = 0; i <= 8; i += 2) {
    const p = pts[i];
    const b = stepTop(p[2]);
    const post = Geometry.cylinder(0.025, 0.025, p[1] - b + 0.02, 5, 1);
    post.translate(p[0], b - 0.02, p[2]);
    rail.append(post);
  }
  rail.setColor(C('#6a6070'), 1);
  add(o, 'metal', rail);
  const lan = lantern();
  lan.translate(-width / 2 + 0.2, topY + 1.42, endZ - 0.3);
  add(o, 'metal', lan.frame);
  add(o, 'glowSoft', lan.glass);
  const pole = Geometry.cylinder(0.03, 0.04, 1.2, 6, 1);
  pole.translate(-width / 2 + 0.2, topY, endZ - 0.3);
  pole.setColor(C('#3a3440'), 1);
  add(o, 'metal', pole);
  o.lights.push({ pos: [-width / 2 + 0.2, topY + 1.4, endZ - 0.3], color: C('#ffd08a'), intensity: 1.6, radius: 7 });
  o.anchors.top = [0, topY, endZ - run / 2];
  o.radius = endZ * 0.6 + 2;
  return o;
}

// ------------------------------------------------------------------ an old street lamp
export function dreamLamp(seed = 1, { h = 4.4 } = {}) {
  const o = out();
  const g = new Geometry();
  // (cylinders are built upwards from y = 0: the post stands on the ground, not half its height above it)
  const post = Geometry.cylinder(0.07, 0.12, h, 8, 1);
  g.append(post);
  const base = Geometry.cylinder(0.2, 0.26, 0.4, 8, 1);
  g.append(base);
  const arm = Geometry.tube(catmullRom([[0, h - 0.1, 0], [0.25, h + 0.25, 0], [0.7, h + 0.25, 0], [0.9, h + 0.05, 0]], 4), () => 0.04, 5);
  g.append(arm);
  g.setColor(C('#2c2a34'), 1);
  add(o, 'metal', g);
  const shade = Geometry.cylinder(0.05, 0.32, 0.26, 10, 1);
  shade.translate(0.9, h - 0.08, 0);
  shade.setColor(C('#3a3844'), 1);
  add(o, 'metal', shade);
  const bulb = Geometry.sphere(0.13, 10, 8);
  bulb.translate(0.9, h - 0.26, 0);
  bulb.setColor(C('#fff0c8'), 1);
  bulb.setExtra([3.2]);
  add(o, 'glow', bulb);
  o.lights.push({ pos: [0.9, h - 0.5, 0], color: C('#ffd9a0'), intensity: 2.2, radius: 10 });
  o.colliders.push({ type: 'circle', x: 0, z: 0, r: 0.25 });
  o.radius = 1.5;
  return o;
}

// ------------------------------------------------------------------ a giant chair
export function dreamChair(seed = 1) {
  const rng = new RNG(seed);
  const o = out();
  const col = rng.pick(['#c89a78', '#b88ab8', '#8ab0c8', '#d8c090']);
  const S = 1.0;
  for (const [x, z] of [[-0.45, -0.45], [0.45, -0.45], [-0.45, 0.45], [0.45, 0.45]]) {
    add(o, 'wood', box(0.1 * S, 1.0 * S, 0.1 * S, x * S, 0, z * S, col, 0.8));
    o.colliders.push({ type: 'circle', x: x * S, z: z * S, r: 0.08, yMax: 1.0 });
  }
  add(o, 'wood', box(1.05 * S, 0.1 * S, 1.05 * S, 0, 1.0 * S, 0, col, 1));
  add(o, 'wood', box(1.05 * S, 1.1 * S, 0.09 * S, 0, 1.1 * S, -0.48 * S, col, 1));
  for (const x of [-0.3, 0, 0.3]) add(o, 'wood', box(0.07, 0.8, 0.05, x, 1.1, -0.42, col, 0.8));
  o.surfaces.push({ type: 'box', x: 0, z: 0, hx: 0.52, hz: 0.52, top: 1.1, bottom: 1.0 });
  o.radius = 1.4;
  return o;
}

// ------------------------------------------------------------------ an old television, still showing something
export function dreamTV(seed = 1) {
  const rng = new RNG(seed);
  const o = out();
  const body = Geometry.roundedBox(1.2, 0.95, 0.95, 3, 0.1);
  body.translate(0, 0.62, 0);
  body.setColor(C(rng.pick(['#d8ccb0', '#c8c0d8', '#b8c8c0'])), 0.9);
  add(o, 'plaster', body);
  const legs = new Geometry();
  for (const [x, z] of [[-0.45, -0.3], [0.45, -0.3], [-0.45, 0.3], [0.45, 0.3]]) {
    const l = Geometry.cylinder(0.025, 0.02, 0.18, 5, 1);
    l.translate(x, 0, z);
    legs.append(l);
  }
  const ears = Geometry.tube([[0, 1.1, -0.1], [-0.35, 1.8, -0.15]], () => 0.012, 4, { capEnd: true });
  ears.append(Geometry.tube([[0, 1.1, -0.1], [0.4, 1.75, -0.1]], () => 0.012, 4, { capEnd: true }));
  legs.append(ears);
  legs.setColor(C('#3a3440'), 1);
  add(o, 'metal', legs);
  const scr = Geometry.roundedBox(0.86, 0.66, 0.05, 2, 0.08);
  scr.translate(-0.08, 0.63, 0.475);
  const tone = rng.pick([['#6af0ff', '#f08ad8'], ['#9dffb0', '#6a8aff'], ['#ffd08a', '#ff8ab8']]);
  scr.paint((p) => mix3(C(tone[0]), C(tone[1]), smoothstep(0.35, 0.95, p[1]) * 0.8 + noise.n2(p[0] * 30, p[1] * 30) * 0.2).concat([1]));
  scr.setExtra([1.8]);
  add(o, 'glowSoft', scr);
  const knobs = new Geometry();
  for (const y of [0.85, 0.6]) {
    const k = Geometry.cylinder(0.05, 0.05, 0.05, 8, 1);
    k.rotateX(Math.PI / 2);
    k.translate(0.47, y, 0.48);
    knobs.append(k);
  }
  knobs.setColor(C('#4a4050'), 1);
  add(o, 'metal', knobs);
  o.lights.push({ pos: [0, 0.7, 1.1], color: C(tone[0]), intensity: 1.2, radius: 5 });
  o.colliders.push({ type: 'circle', x: 0, z: 0, r: 0.7, yMax: 1.1 });
  o.surfaces.push({ type: 'box', x: 0, z: 0, hx: 0.58, hz: 0.46, top: 1.1, bottom: 0.15 });
  o.radius = 1.4;
  return o;
}

// ------------------------------------------------------------------ a row of pastel arches
export function dreamArches(seed = 1, { n = 4, span = 3.2, h = 4.6 } = {}) {
  const rng = new RNG(seed);
  const o = out();
  const col = rng.pick(['#f4c8c0', '#f8dcc0', '#e8d0f0', '#c8e0f0']);
  const g = new Geometry();
  for (let i = 0; i <= n; i++) {
    const x = (i - n / 2) * span;
    g.append(box(0.55, h, 0.55, x, 0, 0, col, 0.85));
    o.colliders.push({ type: 'circle', x, z: 0, r: 0.38 });
    if (i < n) {
      const arc = Geometry.torus(span / 2 - 0.27, 0.22, 6, 14, Math.PI);
      arc.rotateX(-Math.PI / 2);
      arc.scale(1, 1, 1.25);
      arc.translate(x + span / 2, h, 0);
      arc.setColor(C(col), 1);
      g.append(arc);
    }
  }
  g.append(box(n * span + 0.8, 0.35, 0.7, 0, h + span / 2 - 0.1, 0, col, 1));
  add(o, 'plaster', g);
  o.radius = n * span * 0.6;
  return o;
}

// ------------------------------------------------------------------ broken classical columns
export function dreamColumns(seed = 1) {
  const rng = new RNG(seed);
  const o = out();
  const g = new Geometry();
  const n = rng.int(3, 6);
  for (let i = 0; i < n; i++) {
    const a = rng.range(0, TAU), d = rng.range(0.5, 4.5);
    const x = Math.cos(a) * d, z = Math.sin(a) * d;
    const h = rng.chance(0.4) ? rng.range(1.0, 3.0) : 6.5;
    const col = Geometry.lathe(catmullRom([[0.62, 0], [0.62, 0.25], [0.48, 0.35], [0.44, h * 0.5], [0.4, h - 0.3], [0.52, h - 0.15], [0.6, h]], 2), 14, { capTop: true });
    col.deform((p) => {
      const ang = Math.atan2(p[2], p[0]);
      const fl = 1 - 0.05 * Math.max(0, Math.cos(ang * 12)) * (p[1] > 0.4 && p[1] < h - 0.3 ? 1 : 0);
      return [p[0] * fl, p[1], p[2] * fl];
    });
    col.computeNormals();
    col.translate(x, 0, z);
    col.setColor(C('#e8e4ee'), 0.9);
    g.append(col);
    o.colliders.push({ type: 'circle', x, z, r: 0.55, yMax: h });
    if (h < 4) o.surfaces.push({ type: 'disc', x, z, r: 0.5, top: h, bottom: 0 });
  }
  // one fallen drum lying in the water
  const drum = Geometry.cylinder(0.45, 0.45, 1.6, 12, 1);
  drum.rotateZ(Math.PI / 2);
  drum.translate(rng.range(-3, 3), 0.35, rng.range(-3, 3));
  drum.setColor(C('#dcd8e4'), 0.9);
  g.append(drum);
  add(o, 'stone', g);
  o.radius = 6;
  return o;
}

// ------------------------------------------------------------------ a giant rubber duck
export function dreamDuck(seed = 1) {
  const o = out();
  const body = Geometry.sphere(1, 18, 12);
  body.scale(1.3, 0.85, 1.7);
  body.translate(0, 0.55, 0);
  const tail = Geometry.sphere(0.5, 10, 8);
  tail.scale(1, 0.8, 1.3);
  tail.translate(0, 1.05, -1.45);
  body.append(tail);
  const head = Geometry.sphere(0.72, 16, 12);
  head.translate(0, 1.95, 0.95);
  body.append(head);
  body.setColor(C('#ffd23a'), 1);
  add(o, 'glossy', body);
  const beak = Geometry.sphere(0.3, 10, 8);
  beak.scale(1.2, 0.5, 1.2);
  beak.translate(0, 1.82, 1.62);
  beak.setColor(C('#ff8a2a'), 1);
  add(o, 'glossy', beak);
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = Geometry.sphere(0.1, 8, 6);
    e.translate(s * 0.33, 2.15, 1.55);
    e.setColor(C('#1a1a24'), 1);
    eyes.append(e);
  }
  add(o, 'glossy', eyes);
  o.colliders.push({ type: 'circle', x: 0, z: 0, r: 1.3, yMax: 2.5 });
  o.surfaces.push({ type: 'disc', x: 0, z: -0.2, r: 1.0, top: 1.38, dome: 0.3, bottom: 0.2 });
  o.radius = 2.4;
  return o;
}

// ------------------------------------------------------------------ a beach ball
export function dreamBall(seed = 1) {
  const o = out();
  const R = 1.4;
  const b = Geometry.sphere(R, 20, 14);
  const cols = ['#ff6a7a', '#fff2e0', '#6ac8ff', '#fff2e0', '#ffd23a', '#fff2e0'].map((c) => C(c));
  b.paint((p) => {
    if (Math.abs(p[1]) > R * 0.9) return C('#f4f0e8').concat([1]);
    const a = (Math.atan2(p[2], p[0]) + Math.PI) / TAU;
    return cols[Math.floor(a * 6) % 6].concat([1]);
  });
  b.translate(0, R * 0.85, 0);
  add(o, 'glossy', b);
  o.colliders.push({ type: 'circle', x: 0, z: 0, r: R * 0.95 });
  o.surfaces.push({ type: 'disc', x: 0, z: 0, r: R * 0.55, top: R * 1.85, dome: 0.5, bottom: R * 0.3 });
  o.radius = 2;
  return o;
}

// ------------------------------------------------------------------ a bed (the mattress bounces you up)
export function dreamBed(seed = 1) {
  const rng = new RNG(seed);
  const o = out();
  const col = rng.pick(PASTELS);
  const frame = new Geometry();
  frame.append(box(1.7, 0.35, 2.3, 0, 0.2, 0, '#c8a888', 0.8));
  frame.append(box(1.8, 1.3, 0.12, 0, 0, -1.2, '#b89878', 0.9));
  frame.append(box(1.8, 0.8, 0.12, 0, 0, 1.2, '#b89878', 0.9));
  for (const [x, z] of [[-0.8, -1.1], [0.8, -1.1], [-0.8, 1.1], [0.8, 1.1]]) frame.append(box(0.1, 0.25, 0.1, x, 0, z, '#8a6a50', 0.8));
  add(o, 'wood', frame);
  const soft = new Geometry();
  const mat = Geometry.roundedBox(1.62, 0.3, 2.2, 3, 0.12);
  mat.translate(0, 0.7, 0);
  mat.setColor(C('#f4f0f8'), 1);
  soft.append(mat);
  const blanket = Geometry.roundedBox(1.7, 0.1, 1.4, 3, 0.05);
  blanket.translate(0, 0.86, 0.35);
  blanket.setColor(C(col), 1);
  soft.append(blanket);
  for (const x of [-0.4, 0.4]) {
    const p = Geometry.sphere(1, 10, 8);
    p.scale(0.36, 0.13, 0.24);
    p.translate(x, 0.95, -0.85);
    p.setColor(C('#fff8f0'), 1);
    soft.append(p);
  }
  add(o, 'cloth', soft);
  o.colliders.push({ type: 'seg', ax: -0.9, az: -1.2, bx: 0.9, bz: -1.2, r: 0.1, yMax: 1.3 });
  o.colliders.push({ type: 'seg', ax: -0.9, az: 1.2, bx: 0.9, bz: 1.2, r: 0.1, yMax: 0.8 });
  o.surfaces.push({ type: 'box', x: 0, z: 0, hx: 0.8, hz: 1.08, top: 0.88, bottom: 0.2, bounce: 11, tag: 'bed' });
  o.radius = 1.8;
  return o;
}

// ------------------------------------------------------------------ a grandfather clock
export function dreamClock(seed = 1) {
  const o = out();
  const body = new Geometry();
  body.append(box(0.9, 0.35, 0.55, 0, 0, 0, '#5a3a2a', 0.8));
  body.append(box(0.7, 2.0, 0.45, 0, 0.35, 0, '#6a4632', 0.9));
  body.append(box(0.9, 1.0, 0.55, 0, 2.35, 0, '#5a3a2a', 1));
  const crown = Geometry.box(0.95, 0.18, 0.6, { y0: 0 });
  crown.translate(0, 3.35, 0);
  crown.setColor(C('#4a2e20'), 1);
  body.append(crown);
  add(o, 'wood', body);
  const face = Geometry.cylinder(0.33, 0.33, 0.04, 20, 1);
  face.rotateX(Math.PI / 2);
  face.translate(0, 2.85, 0.28);
  face.setColor(C('#fff4d8'), 1);
  face.setExtra([1.2]);
  add(o, 'glowSoft', face);
  const hands = new Geometry();
  hands.append(box(0.03, 0.26, 0.02, 0, 2.85, 0.31, '#1a1418'));
  const h2 = Geometry.box(0.03, 0.2, 0.02, { y0: 0 });
  h2.rotateZ(-2.1);
  h2.translate(0, 2.85, 0.31);
  h2.setColor(C('#1a1418'), 1);
  hands.append(h2);
  const pend = Geometry.cylinder(0.14, 0.14, 0.03, 14, 1);
  pend.rotateX(Math.PI / 2);
  pend.translate(0, 0.9, 0.23);
  pend.setColor(C('#d8b060'), 1);
  hands.append(pend);
  add(o, 'metal', hands);
  o.colliders.push({ type: 'circle', x: 0, z: 0, r: 0.5, yMax: 3.5 });
  o.radius = 1.2;
  return o;
}
