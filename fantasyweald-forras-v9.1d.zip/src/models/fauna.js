// (v9) Five new kinds of forest folk, each built from code like everything else:
//   Csillagsün (star hedgehog)  - cute: crystal quills that twinkle; curls into a glowing ball when startled
//   Lepkeróka (moth fox)        - cute: a small fox with soft moth wings on its back
//   Ködrája (mist ray)          - neutral: (v9.1b) a manta ray swimming through the air; it sifts bad dreams out of it
//   Gyökérpók (root spider)     - dark: a knot of living roots on eight legs, lurking like an old stump
//   Csendes (the silent one)    - dark: a tall antlered shade with a porcelain mask; it only moves when unseen
// Every rig returns { root, bones } like the other creatures; parts that share a material are merged later.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep, clamp, vnorm, vcross, vlen, mat4 } from '../engine/math.js';
import { C } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const mesh = (ctx, g, mat, name = '') => new Mesh(new GpuGeometry(ctx.gl, g), mat, name);
function egg(rx, ry, rz, ws = 12, hs = 8) {
  const g = Geometry.sphere(1, ws, hs);
  g.scale(rx, ry, rz);
  return g;
}
function bone(name, parent, x = 0, y = 0, z = 0) {
  const n = new Node(name);
  n.setPos(x, y, z);
  parent.add(n);
  return n;
}
// rotation (and optional translation) that turns +Y into `dir`
function alignMatrix(dir, pos = null) {
  const d = vnorm(dir);
  const m = mat4.create();
  let ax = vcross([0, 1, 0], d);
  const s = vlen(ax), c = d[1];
  if (s < 1e-6) {
    if (c < 0) { m[5] = -1; m[10] = -1; }
  } else {
    ax = [ax[0] / s, ax[1] / s, ax[2] / s];
    const t = 1 - c, [x, y, z] = ax;
    m[0] = t * x * x + c; m[1] = t * x * y + s * z; m[2] = t * x * z - s * y;
    m[4] = t * x * y - s * z; m[5] = t * y * y + c; m[6] = t * y * z + s * x;
    m[8] = t * x * z + s * y; m[9] = t * y * z - s * x; m[10] = t * z * z + c;
  }
  if (pos) { m[12] = pos[0]; m[13] = pos[1]; m[14] = pos[2]; }
  return m;
}
// a lathe profile [[r, z]...] turned to run along +z
function latheZ(profile, radial = 14, opts = {}) {
  const g = Geometry.lathe(profile, radial, opts);
  g.rotateX(Math.PI / 2);
  return g;
}
// two glowing eyes with pupils and highlights; `slit` makes cat-like pupils
function eyePair(sep, y, z, r, iris, { pupil = 0.5, glow = 2, slit = false, squash = 1, toe = 0.25 } = {}) {
  const g = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(r, r * squash, r * 0.62, 12, 9);
    const p = slit ? egg(r * 0.2, r * 0.78 * squash, r * 0.3, 8, 6) : egg(r * pupil, r * pupil * squash, r * 0.3, 8, 6);
    p.translate(0, 0, r * 0.47);
    const hl = egg(r * 0.2, r * 0.2, r * 0.1, 6, 4);
    hl.translate(r * 0.3, r * 0.34, r * 0.56);
    e.setColor(iris, 1); e.setExtra([glow]);
    p.setColor([0.003, 0.003, 0.008], 1); p.setExtra([0]);
    hl.setColor([1, 1, 1], 1); hl.setExtra([3]);
    const one = new Geometry();
    one.append(e); one.append(p); one.append(hl);
    one.rotateY(s * toe);
    one.translate(s * sep, y, z);
    g.append(one);
  }
  return g;
}
function fluff(g, amt, freq, seed) {
  g.computeNormals();
  g.displace((p) => noise.n3(p[0] * freq + seed, p[1] * freq, p[2] * freq) * amt + Math.abs(noise.n3(p[0] * freq * 2.3, p[1] * freq * 2.3 + seed, p[2] * freq * 2.3)) * amt * 0.8, true);
  return g;
}

// ------------------------------------------------------------------ materials
export function faunaMaterials(M) {
  if (!M.mothWing) {
    // soft wing membrane: seen from both sides, a little glitter like moth dust
    M.mothWing = new Material({ cull: 'none', uniforms: { uRough: 0.55, uDetail: [0, 0, 0, 0], uGlitter: [26, 0.14, 1.1], uRim: 0.7, uWrap: 0.75, uFill: 0.45, uGlowStrength: 1.0 } });
    // a hide like a night sky: tiny slowly breathing stars on its dark parts
    M.bakuHide = new Material({
      defines: { SPOTS: 1 },
      uniforms: { uRough: 0.75, uDetail: [1.6, 0.1, 0.12, 5], uGlitter: [16, 0.05, 0.4], uRim: 0.65, uWrap: 0.5, uFill: 0.55, uSpots: [5.0, 0.2, 3.6, 0.0], uSpotColor: C('#dcebff', 1.0), uSpotGlowPulse: 0.8 },
    });
    // soft fur that doesn't glare in the lantern light
    M.fur = new Material({ uniforms: { uRough: 0.8, uDetail: [14.0, 0.1, 0.2, 3], uGlitter: [30, 0.04, 0.4], uRim: 0.75, uWrap: 0.6, uFill: 0.5 } });
    // the silent ones' rags: dark, dull, seen from both sides
    M.shade = new Material({ cull: 'none', uniforms: { uRough: 0.95, uDetail: [1.4, 0.14, 0.3, 4], uGlitter: [0, 0, 0], uRim: 0.4, uWrap: 0.35, uFill: 0.12 } });
    // porcelain masks
    M.porcelain = new Material({ uniforms: { uRough: 0.3, uDetail: [5, 0.08, 0.05, 1], uGlitter: [30, 0.05, 0.4], uRim: 0.7, uWrap: 0.4, uFill: 0.35 } });
  }
  return M;
}

// ================================================================== Csillagsün: the star hedgehog
export function buildStarHog(ctx, seed = 1) {
  const M = faunaMaterials(ctx.M);
  const rng = new RNG(seed);
  const root = new Node('starhog');
  const bones = {};
  const pal = rng.pick([
    { back: '#29255a', belly: '#b9aed6', face: '#cdbfdf', a: '#1a1640', b: '#a8ecff', blush: '#ff8fb8' },
    { back: '#352452', belly: '#c8b2cf', face: '#d9c3d9', a: '#26153e', b: '#e6bcff', blush: '#ff94b4' },
    { back: '#1e2d52', belly: '#aebcd8', face: '#c3cee4', a: '#11203a', b: '#b8ffe9', blush: '#ff9ab8' },
  ]);
  const scale = rng.range(0.92, 1.12);
  const inner = bone('scale', root);
  inner.setScale(scale);
  const body = bone('body', inner, 0, 0.125, 0);
  bones.body = body;
  // round body, flat belly
  const bg = egg(0.145, 0.118, 0.19, 18, 12);
  bg.deform((p) => [p[0], p[1] < 0 ? p[1] * 0.75 : p[1], p[2]]);
  bg.computeNormals();
  bg.paint((p) => mix3(C(pal.belly), C(pal.back), smoothstep(-0.03, 0.05, p[1] - p[2] * 0.12)).concat([smoothstep(-0.1, 0.06, p[1]) * 0.35 + 0.65]));
  fluff(bg, 0.004, 40, seed);
  body.add(mesh(ctx, bg, M.fur, 'hogBody'));
  // crystal quills swept back over the whole back; their tips hold a little light
  const quills = new Geometry(), stars = new Geometry();
  const NF = 460;
  let count = 0;
  for (let i = 0; i < NF && count < 150; i++) {
    const k = i + 0.5;
    const phi = Math.acos(1 - (2 * k) / NF), th = Math.PI * (1 + Math.sqrt(5)) * k;
    const nx = Math.cos(th) * Math.sin(phi), ny = Math.cos(phi), nz = Math.sin(th) * Math.sin(phi);
    if (ny < -0.08 || nz > 0.5 - ny * 0.2) continue; // the back and sides, not the face or belly
    const base = [nx * 0.14, ny * 0.114 * (ny < 0 ? 0.75 : 1), nz * 0.185];
    let dir = vnorm([nx * 0.75, ny + 0.2, nz - 0.95]);
    dir = vnorm([dir[0] + rng.range(-0.14, 0.14), dir[1] + rng.range(-0.08, 0.12), dir[2] + rng.range(-0.1, 0.1)]);
    const len = rng.range(0.07, 0.105) * (0.75 + 0.35 * clamp(ny + 0.3, 0, 1));
    const q = Geometry.cylinder(0, 0.0105, len, 5, 1, { capBottom: false });
    q.paint((p) => mix3(C(pal.a), C(pal.b), smoothstep(len * 0.3, len, p[1])).concat([1]));
    q.paintExtra((p) => [smoothstep(len * 0.55, len, p[1]) * 1.4]);
    q.applyMatrix(alignMatrix(dir, base));
    quills.append(q);
    if (count % 2 === 0) {
      const st = Geometry.icosphere(0.0065, 0);
      st.translate(base[0] + dir[0] * len * 1.02, base[1] + dir[1] * len * 1.02, base[2] + dir[2] * len * 1.02);
      st.setColor(C(pal.b), 1);
      st.setExtra([2.2]);
      stars.append(st);
    }
    count++;
  }
  const qn = bone('quills', body);
  bones.quills = qn;
  qn.add(mesh(ctx, quills, M.crystal, 'hogQuills'));
  const glow = bone('glow', qn);
  glow.add(mesh(ctx, stars, M.glow, 'hogStars'));
  glow.visible = false;
  bones.glow = glow;
  // head: round face, pointed snout, button nose, big shiny eyes, round ears, rosy cheeks
  const head = bone('head', body, 0, 0.0, 0.14);
  bones.head = head;
  const hg = egg(0.085, 0.078, 0.08, 16, 12);
  hg.translate(0, 0.012, 0.01);
  const snout = latheZ(catmullRom([[0.058, 0], [0.05, 0.04], [0.034, 0.08], [0.018, 0.11], [0.0, 0.12]], 2), 12);
  snout.scale(1, 0.82, 1);
  snout.translate(0, -0.008, 0.045);
  hg.append(snout);
  hg.computeNormals();
  hg.paint((p) => {
    const cheek = Math.exp(-(((Math.abs(p[0]) - 0.052) ** 2) + (p[1] + 0.01) ** 2 + (p[2] - 0.055) ** 2) * 1400);
    const top = smoothstep(0.02, 0.07, p[1] - p[2] * 0.35);
    return mix3(mix3(C(pal.face), C(pal.back), top * 0.8), C(pal.blush), cheek * 0.8).concat([1]);
  });
  const ears = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(0.026, 0.028, 0.012, 10, 6);
    const ei = egg(0.017, 0.019, 0.006, 8, 5);
    ei.translate(0, -0.002, 0.008);
    ei.setColor(C(pal.blush), 1);
    e.setColor(C(pal.face), 1);
    e.append(ei);
    e.rotateY(s * 0.5);
    e.rotateZ(s * -0.35);
    e.translate(s * 0.058, 0.066, -0.01);
    ears.append(e);
  }
  hg.append(ears);
  head.add(mesh(ctx, hg, M.fur, 'hogHead'));
  const nose = egg(0.017, 0.013, 0.013, 10, 8);
  nose.translate(0, -0.005, 0.165);
  nose.setColor(C('#0a0810'), 1);
  const hl = egg(0.005, 0.004, 0.003, 5, 4);
  hl.translate(0.005, 0.002, 0.177);
  hl.setColor([1, 1, 1], 1);
  hl.setExtra([2]);
  nose.append(hl);
  head.add(mesh(ctx, nose, M.glossy, 'hogNose'));
  const eyesN = bone('eyes', head, 0, 0.028, 0.072);
  bones.eyes = eyesN;
  eyesN.add(mesh(ctx, eyePair(0.036, 0, 0, 0.018, C('#1a1030'), { pupil: 0.75, glow: 0.4, toe: 0.45 }), M.glowSoft, 'hogEyes'));
  // stubby legs with pink paws
  for (const [nm, x, z] of [['legFL', 0.07, 0.08], ['legFR', -0.07, 0.08], ['legBL', 0.075, -0.09], ['legBR', -0.075, -0.09]]) {
    const leg = bone(nm, body, x, -0.07, z);
    const lg = egg(0.028, 0.045, 0.03, 8, 6);
    lg.translate(0, -0.03, 0);
    const paw = egg(0.026, 0.014, 0.032, 8, 5);
    paw.translate(0, -0.066, 0.01);
    lg.setColor(C(pal.back), 0.8);
    paw.setColor(C(pal.blush), 1);
    lg.append(paw);
    leg.add(mesh(ctx, lg, M.fur));
    bones[nm] = leg;
  }
  // a tiny tail
  const tail = egg(0.02, 0.018, 0.03, 8, 5);
  tail.translate(0, 0.01, -0.19);
  tail.setColor(C(pal.back), 1);
  body.add(mesh(ctx, tail, M.fur));
  return { root, bones, scale, pal };
}

// ================================================================== Lepkeróka: the moth fox
function mothWing(R, a0, a1, pal, rng, hind) {
  // a fan of 24 x 10 vertices, painted with veins, an eye-spot and a glowing edge
  const g = new Geometry();
  const I = 24, J = 10;
  const shape = (u) => R * (0.5 + 0.5 * Math.pow(Math.sin(Math.PI * clamp(u * 0.92 + 0.04, 0, 1)), 0.55)) * (hind ? 1 - u * 0.25 : 0.9 + u * 0.1);
  const dirAt = (u) => { const a = lerp(a0, a1, u); return [Math.cos(a), Math.sin(a)]; };
  const eu = 0.52, ev = hind ? 0.58 : 0.64;
  const ed = dirAt(eu), er = shape(eu) * ev;
  const eye = [ed[0] * er, ed[1] * er];
  const eyeR = R * (hind ? 0.2 : 0.17);
  const col = (x, z, u, v) => {
    let c = mix3(C(pal.wingRoot), C(pal.wing), smoothstep(0.05, 0.75, v));
    let glow = 0;
    // veins
    const vein = 1 - smoothstep(0.02, 0.06, Math.abs(((u * 5 + 0.5) % 1) - 0.5));
    c = mix3(c, C(pal.vein), vein * smoothstep(0.15, 0.4, v) * 0.7);
    // eye-spot
    const d = Math.hypot(x - eye[0], z - eye[1]) / eyeR;
    if (d < 1.15) {
      const ring = smoothstep(1.15, 0.95, d);
      c = mix3(c, C(pal.vein), ring);
      const iris = smoothstep(0.78, 0.6, d);
      c = mix3(c, C(pal.spot), iris);
      glow = iris * 1.3;
      const pupil = smoothstep(0.34, 0.24, d);
      c = mix3(c, C('#1a1030'), pupil);
      glow *= 1 - pupil;
    }
    // pale scalloped edge with glowing dots
    const edge = smoothstep(0.82, 0.93, v);
    c = mix3(c, C(pal.edge), edge);
    const dots = edge * (Math.sin(u * Math.PI * 14) > 0.55 ? 1 : 0);
    glow = Math.max(glow, dots * 0.8);
    return { c, glow };
  };
  const center = g.vert(0, 0, 0, 0, 1, 0);
  const cc = col(0, 0, 0.5, 0);
  g.c.splice(center * 4, 4, cc.c[0], cc.c[1], cc.c[2], 1);
  const rows = [];
  for (let j = 1; j <= J; j++) {
    const v = j / J, row = [];
    for (let i = 0; i <= I; i++) {
      const u = i / I, d = dirAt(u), r = shape(u) * v * (1 - 0.06 * Math.sin(u * Math.PI * 7) * smoothstep(0.85, 1, v));
      const x = d[0] * r, z = d[1] * r;
      const y = Math.sin(v * Math.PI) * 0.012 * R * 3;
      const k = g.vert(x, y, z, 0, 1, 0);
      const cv = col(x, z, u, v);
      g.c[k * 4] = cv.c[0]; g.c[k * 4 + 1] = cv.c[1]; g.c[k * 4 + 2] = cv.c[2]; g.c[k * 4 + 3] = 1;
      g.e[k * 4] = cv.glow;
      row.push(k);
    }
    rows.push(row);
  }
  for (let i = 0; i < I; i++) g.tri(center, rows[0][i + 1], rows[0][i]);
  for (let j = 0; j < J - 1; j++) for (let i = 0; i < I; i++) g.quad(rows[j][i], rows[j][i + 1], rows[j + 1][i + 1], rows[j + 1][i]);
  g.computeNormals();
  return g;
}

export function buildMothFox(ctx, seed = 1) {
  const M = faunaMaterials(ctx.M);
  const rng = new RNG(seed);
  const root = new Node('mothfox');
  const bones = {};
  const pal = rng.pick([
    { fur: '#6c66bf', chest: '#cfc6ee', sock: '#221f4e', ear: '#ff9fc6', wingRoot: '#231c4c', wing: '#5a4fb4', vein: '#140f33', spot: '#7fe6ff', edge: '#c9bbf2', eye: '#ffd36a' },
    { fur: '#a57cc0', chest: '#e6cfe6', sock: '#381f4c', ear: '#ffabd0', wingRoot: '#311a46', wing: '#9a63b2', vein: '#210f32', spot: '#ffe08a', edge: '#ecd6ee', eye: '#9ff0ff' },
    { fur: '#628fbc', chest: '#cfe2f0', sock: '#182e4c', ear: '#ffb0c8', wingRoot: '#122846', wing: '#3f7ea6', vein: '#0a182c', spot: '#ffb4ec', edge: '#cfeaf8', eye: '#ffcf7a' },
  ]);
  const scale = rng.range(0.9, 1.08);
  const inner = bone('scale', root);
  inner.setScale(scale);
  const body = bone('body', inner, 0, 0.33, 0);
  bones.body = body;
  // lean torso with a deep chest and a round haunch
  const torso = latheZ(catmullRom([[0.0, -0.3], [0.06, -0.285], [0.1, -0.23], [0.112, -0.15], [0.1, -0.05], [0.094, 0.04], [0.108, 0.13], [0.11, 0.2], [0.088, 0.255], [0.0, 0.28]], 2), 16);
  torso.deform((p) => [p[0] * 0.84, p[1] > 0 ? p[1] * 0.92 : p[1] * 1.06, p[2]]);
  const chest = egg(0.075, 0.095, 0.07, 12, 9);
  chest.translate(0, -0.035, 0.19);
  torso.append(chest);
  const neck = Geometry.tube([[0, 0.02, 0.17], [0, 0.1, 0.25], [0, 0.17, 0.3]], [0.07, 0.062, 0.055], 12, { capStart: true, capEnd: true });
  torso.append(neck);
  fluff(torso, 0.006, 26, seed);
  torso.paint((p, n) => {
    const under = smoothstep(0.0, -0.06, p[1] - p[2] * 0.25) + smoothstep(0.1, 0.22, p[2]) * smoothstep(0.02, -0.06, p[1] - 0.06);
    return mix3(C(pal.fur), C(pal.chest), clamp(under, 0, 1)).concat([smoothstep(-0.12, 0.05, p[1]) * 0.35 + 0.65]);
  });
  body.add(mesh(ctx, torso, M.fur, 'foxBody'));
  // head
  const head = bone('head', body, 0, 0.2, 0.31);
  bones.head = head;
  const hg = egg(0.082, 0.072, 0.082, 16, 12);
  const muzzle = latheZ(catmullRom([[0.05, 0], [0.043, 0.045], [0.03, 0.09], [0.015, 0.12], [0.0, 0.128]], 2), 12);
  muzzle.scale(1, 0.78, 1);
  muzzle.translate(0, -0.028, 0.05);
  hg.append(muzzle);
  for (const s of [-1, 1]) {
    const ch = egg(0.048, 0.034, 0.042, 10, 7);
    ch.deform((p) => [p[0] + Math.max(0, p[0] * s) * 0.8 * s * smoothstep(-0.01, 0.03, -p[1]), p[1], p[2]]);
    ch.translate(s * 0.052, -0.035, 0.012);
    hg.append(ch);
  }
  hg.computeNormals();
  hg.paint((p) => {
    const white = smoothstep(-0.005, -0.03, p[1] - Math.abs(p[0]) * 0.2) + smoothstep(0.045, 0.07, Math.abs(p[0])) * smoothstep(0.0, -0.03, p[1]);
    return mix3(C(pal.fur), C(pal.chest), clamp(white, 0, 1)).concat([1]);
  });
  // a small glowing crescent on the brow
  const mark = egg(0.014, 0.01, 0.004, 8, 5);
  mark.rotateX(-0.9);
  mark.translate(0, 0.05, 0.062);
  mark.setColor(C(pal.spot), 1);
  mark.setExtra([2.4]);
  hg.append(mark);
  head.add(mesh(ctx, hg, M.fur, 'foxHead'));
  const nose = egg(0.017, 0.013, 0.013, 10, 8);
  nose.translate(0, -0.02, 0.178);
  nose.setColor(C('#0b0812'), 1);
  head.add(mesh(ctx, nose, M.glossy, 'foxNose'));
  const eyesN = bone('eyes', head, 0, 0.01, 0.066);
  bones.eyes = eyesN;
  eyesN.add(mesh(ctx, eyePair(0.038, 0, 0, 0.019, C(pal.eye), { glow: 1.3, slit: true, squash: 0.85, toe: 0.4 }), M.glowSoft, 'foxEyes'));
  // big ears
  for (const s of [-1, 1]) {
    const ear = bone(s < 0 ? 'earR' : 'earL', head, s * 0.045, 0.05, -0.012);
    const e = Geometry.lathe(catmullRom([[0.046, 0], [0.038, 0.06], [0.018, 0.12], [0.0, 0.15]], 2), 12, { capBottom: true });
    e.scale(1, 1, 0.42);
    e.paint((p) => mix3(C(pal.fur), C(pal.sock), smoothstep(0.1, 0.15, p[1])).concat([1]));
    const ei = Geometry.lathe(catmullRom([[0.034, 0.005], [0.028, 0.055], [0.012, 0.11], [0.0, 0.13]], 2), 10);
    ei.scale(1, 1, 0.2);
    ei.translate(0, 0, 0.012);
    ei.setColor(C(pal.ear), 1);
    e.append(ei);
    e.rotateZ(s * -0.32);
    ear.add(mesh(ctx, e, M.fur));
    bones[s < 0 ? 'earR' : 'earL'] = ear;
  }
  // legs: slim, with dark socks
  const legs = [['legFL', 0.058, -0.05, 0.15, false], ['legFR', -0.058, -0.05, 0.15, false], ['legBL', 0.064, -0.035, -0.17, true], ['legBR', -0.064, -0.035, -0.17, true]];
  for (const [nm, x, y, z, hind] of legs) {
    const leg = bone(nm, body, x, y, z);
    const pts = hind ? [[0, 0.02, 0], [0, -0.09, -0.045], [0, -0.19, -0.01], [0, -0.28, 0.0]] : [[0, 0.02, 0], [0, -0.12, 0.012], [0, -0.23, 0.004], [0, -0.28, 0.012]];
    const lg = Geometry.tube(pts, hind ? [0.052, 0.036, 0.022, 0.019] : [0.04, 0.028, 0.021, 0.019], 9, { capStart: true, capEnd: true });
    const paw = egg(0.024, 0.016, 0.034, 9, 6);
    paw.translate(0, -0.288, 0.022);
    lg.append(paw);
    lg.paint((p) => mix3(C(pal.sock), C(pal.fur), smoothstep(-0.2, -0.1, p[1])).concat([1]));
    leg.add(mesh(ctx, lg, M.fur));
    bones[nm] = leg;
  }
  // big bushy tail with a glowing tip
  const tailN = bone('tail', body, 0, 0.04, -0.27);
  bones.tail = tailN;
  const tpts = [[0, 0, 0], [0, 0.05, -0.09], [0, 0.085, -0.2], [0, 0.08, -0.32], [0, 0.045, -0.42], [0, 0.02, -0.46]];
  const tg = Geometry.tube(tpts, (t) => [0.03, 0.065, 0.085, 0.078, 0.05, 0.012][Math.round(t * 5)], 12, { capStart: true, capEnd: true });
  fluff(tg, 0.012, 22, seed + 3);
  tg.paint((p) => mix3(C(pal.fur), C(pal.chest), smoothstep(-0.3, -0.38, p[2])).concat([1]));
  tg.paintExtra((p) => [smoothstep(-0.34, -0.45, p[2]) * 0.9]);
  tailN.add(mesh(ctx, tg, M.fur, 'foxTail'));
  // moth wings on the shoulders: fore and hind wing on each side, folded up over the back at rest
  for (const s of [-1, 1]) {
    const w = bone(s < 0 ? 'wingR' : 'wingL', body, s * 0.035, 0.09, 0.07);
    const fore = mothWing(0.34, 0.66, -0.26, pal, rng, false);
    const hindW = mothWing(0.24, -0.34, -1.3, pal, rng, true);
    fore.append(hindW);
    if (s < 0) fore.scale(-1, 1, 1);
    w.add(mesh(ctx, fore, M.mothWing, 'foxWing'));
    bones[s < 0 ? 'wingR' : 'wingL'] = w;
  }
  return { root, bones, scale, pal };
}

// ================================================================== Ködrája: the mist ray
// (v9.1b) replaces the dream-eater: a manta ray that swims through the air between the trees. Its wings ripple
// in slow waves (the FLAP shader moves the one smooth mesh), its back is a night sky with small constellations,
// the underside pearl-pale; curled horn-fins by the mouth, a long whip of a tail with a glowing tip. It sifts
// bad dreams out of the air like a manta sifting plankton.
const RAY_SPAN = 1.45; // half wingspan (model metres)
function rayOutline(u) {
  // leading and trailing edge (z) at spanwise position u = |x| / RAY_SPAN
  const le = lerp(0.7, -0.22, Math.pow(u, 1.2)) + 0.07 * Math.sin(Math.PI * u);
  const te = lerp(-0.64, -0.26, Math.pow(u, 0.75)) - 0.12 * Math.sin(Math.PI * Math.min(1, u * 1.1));
  return [le, Math.min(te, le - 0.01)];
}
function rayHalfT(u, v) {
  // half thickness: a thick body, thin wings, rounded at the leading edge, fine at the trailing edge
  const body = 0.15 * Math.pow(1 - u, 1.7) + 0.01;
  return body * Math.pow(Math.sin(Math.PI * clamp(v, 0, 1)), 0.55) * (1 - 0.35 * v);
}
export function buildMistRay(ctx, seed = 1) {
  const M = faunaMaterials(ctx.M);
  const rng = new RNG(seed);
  const root = new Node('mistray');
  const bones = {};
  const pal = rng.pick([
    { top: '#1a1a4a', mid: '#3a2f7a', rim: '#b9a8ff', belly: '#dfe4ff', glow: '#8ff0ff', star: '#fff2cc', eye: '#9fe8ff' },
    { top: '#14244a', mid: '#244a7a', rim: '#9fe0ff', belly: '#e6ecff', glow: '#b08cff', star: '#e8f4ff', eye: '#ffd98a' },
  ]);
  const scale = rng.range(0.9, 1.1);
  const inner = bone('scale', root);
  inner.setScale(scale);
  const body = bone('body', inner, 0, 0, 0);
  bones.body = body;
  // each ray has its own copy of the material: its wings keep their own rhythm
  const mat = new Material({
    defines: { FLAP: 1, SPOTS: 1 },
    uniforms: {
      uRough: 0.5, uDetail: [6, 0.05, 0.025, 4], uGlitter: [22, 0.05, 0.5], uRim: 0.85, uWrap: 0.6, uFill: 0.55,
      uSpots: [9.0, 0.16, 2.6, 0.0], uSpotColor: C(pal.star, 1.0), uSpotGlowPulse: 0.9,
      uFlap: [0, 0.3, 2.1, 1.5], uFlap2: [0.28, 0.2, 1.3, 0],
    },
  });
  // ---- the wing-body: one closed, smooth shell (top and bottom share the edges)
  const g = new Geometry();
  const NU = 34, NV = 24;
  const top = [], bot = [];
  for (let i = -NU; i <= NU; i++) {
    const u = Math.abs(i) / NU, x = (i / NU) * RAY_SPAN;
    const [le, te] = rayOutline(u);
    const rt = [], rb = [];
    for (let j = 0; j <= NV; j++) {
      const v = j / NV;
      // chordwise spacing denser at the leading edge
      const vv = 1 - Math.cos((v * Math.PI) / 2);
      const z = lerp(le, te, vv);
      const T = rayHalfT(u, vv);
      const hump = 0.05 * Math.pow(1 - u, 2) * Math.sin(Math.PI * vv);
      const yt = T + hump, yb = -T * 0.62 + hump * 0.3;
      if (j === 0 || j === NV) {
        const k = g.vert(x, (yt + yb) / 2, z);
        rt.push(k); rb.push(k);
      } else {
        rt.push(g.vert(x, yt, z));
        rb.push(g.vert(x, yb, z));
      }
    }
    top.push(rt); bot.push(rb);
  }
  for (let i = 0; i < 2 * NU; i++) for (let j = 0; j < NV; j++) {
    g.quad(top[i][j], top[i][j + 1], top[i + 1][j + 1], top[i + 1][j]);
    g.quad(bot[i][j], bot[i + 1][j], bot[i + 1][j + 1], bot[i][j + 1]);
  }
  // tips: the outermost columns collapse onto a point-ish edge, close them
  g.computeNormals();
  if (g.n[top[NU][NV >> 1] * 3 + 1] < 0) { for (let i = 0; i < g.idx.length; i += 3) { const t = g.idx[i + 1]; g.idx[i + 1] = g.idx[i + 2]; g.idx[i + 2] = t; } g.computeNormals(); }
  const cRim = C(pal.rim), cTop = C(pal.top), cMid = C(pal.mid), cBelly = C(pal.belly), cGlow = C(pal.glow);
  g.paint((p, n) => {
    const u = Math.abs(p[0]) / RAY_SPAN;
    const [le, te] = rayOutline(u);
    const v = clamp((le - p[2]) / Math.max(0.02, le - te), 0, 1);
    if (n[1] >= -0.15) {
      // the back: a deep night sky, lighter towards the leading edge, a pale rim along the edges
      let c = mix3(cTop, cMid, smoothstep(0.1, 0.9, u) * 0.6 + (noise.n3(p[0] * 3, p[2] * 3, seed) * 0.5 + 0.5) * 0.25);
      c = mix3(c, cRim, smoothstep(0.1, 0.0, v) * 0.55 + smoothstep(0.88, 1.0, u) * 0.4);
      // two pale shoulder marks, like a manta's
      const sh = Math.exp(-(((Math.abs(p[0]) - 0.34) / 0.16) ** 2) - (((p[2] - 0.22) / 0.2) ** 2));
      c = mix3(c, cBelly, sh * 0.45);
      return c.concat([0.85 + 0.15 * smoothstep(0, 0.3, u)]);
    }
    // the belly: pearl-pale with a few dark freckles and five gill slits on each side
    let c = mix3(cBelly, cRim, smoothstep(0.55, 1.0, u) * 0.5);
    const fr = smoothstep(0.62, 0.7, noise.n3(p[0] * 6 + seed, p[2] * 6, 3.3) * 0.5 + 0.5);
    c = mix3(c, cTop, fr * 0.6 * (1 - u));
    for (let k = 0; k < 5; k++) {
      const gz = 0.36 - k * 0.075;
      if (Math.abs(p[2] - gz) < 0.012 && Math.abs(Math.abs(p[0]) - 0.24) < 0.07) c = mix3(c, [0.05, 0.04, 0.12], 0.8);
    }
    return c.concat([0.95]);
  });
  // glow: the trailing edges and wingtips shimmer; star specks (SPOTS) only on the back
  g.paintExtra((p, n) => {
    const u = Math.abs(p[0]) / RAY_SPAN;
    const [le, te] = rayOutline(u);
    const v = clamp((le - p[2]) / Math.max(0.02, le - te), 0, 1);
    const edge = smoothstep(0.8, 1.0, v) * smoothstep(0.25, 0.8, u) + smoothstep(0.9, 1.0, u) * 0.8;
    return [edge * 0.9, 0, n[1] > 0 ? smoothstep(0.1, 0.3, u) : 0];
  });
  // glowing edge colour where it shimmers
  {
    const c = g.c, e = g.e;
    for (let i = 0; i < g.vertexCount; i++) if (e[i * 4] > 0.05) { const k = Math.min(1, e[i * 4]); c[i * 4] = lerp(c[i * 4], cGlow[0], k * 0.8); c[i * 4 + 1] = lerp(c[i * 4 + 1], cGlow[1], k * 0.8); c[i * 4 + 2] = lerp(c[i * 4 + 2], cGlow[2], k * 0.8); }
  }
  // ---- constellations on the back: small stars joined by faint lines (they ride the wing waves too)
  const stars = new Geometry();
  const surfY = (x, z) => {
    const u = Math.abs(x) / RAY_SPAN, [le, te] = rayOutline(u), vv = clamp((le - z) / Math.max(0.02, le - te), 0, 1);
    return rayHalfT(u, vv) + 0.05 * Math.pow(1 - u, 2) * Math.sin(Math.PI * vv);
  };
  for (let cst = 0; cst < 4; cst++) {
    const side = cst % 2 ? -1 : 1;
    const cx = side * rng.range(0.45, 1.0), cz = rng.range(-0.25, 0.25);
    const pts = [];
    for (let k = 0; k < rng.int(4, 6); k++) {
      const x = cx + rng.range(-0.22, 0.22), z = cz + rng.range(-0.18, 0.18);
      const u = Math.abs(x) / RAY_SPAN, [le, te] = rayOutline(Math.min(u, 0.95));
      if (z > le - 0.05 || z < te + 0.05) continue;
      pts.push([x, surfY(x, z) + 0.006, z]);
    }
    pts.forEach((p, k) => {
      const r = k === 0 ? 0.03 : rng.range(0.014, 0.022);
      const st = Geometry.disc(r, 10);
      st.translate(p[0], p[1] + 0.002, p[2]);
      st.setColor(C(pal.star), 1);
      st.setExtra([k === 0 ? 3.2 : 2.4]);
      stars.append(st);
      if (k > 0) {
        const a = pts[k - 1], dx = p[0] - a[0], dz = p[2] - a[2], L = Math.hypot(dx, dz);
        const ln = Geometry.plane(0.006, L, 1, 1);
        ln.rotateY(Math.atan2(dx, dz));
        ln.translate((a[0] + p[0]) / 2, Math.max(a[1], p[1]) + 0.001, (a[2] + p[2]) / 2);
        ln.setColor(C(pal.glow), 1);
        ln.setExtra([1.1]);
        stars.append(ln);
      }
    });
  }
  g.append(stars);
  // ---- cephalic fins: two curled horn-lobes by the mouth
  for (const s of [-1, 1]) {
    const pts = [];
    for (let k = 0; k <= 8; k++) {
      const t = k / 8;
      pts.push([s * (0.27 + 0.04 * Math.sin(t * 3)), -0.02 - 0.05 * t + Math.sin(t * Math.PI) * 0.02, 0.62 + t * 0.26 - t * t * 0.1]);
    }
    const cf = Geometry.tube(pts, (t) => 0.07 * (1 - t * 0.55), 10, { capStart: true, capEnd: true });
    cf.deform((p) => [p[0], (p[1] + 0.03) * 0.55 - 0.03, p[2]]);
    // curl the tip inwards
    cf.deform((p) => { const t = clamp((p[2] - 0.72) / 0.14, 0, 1); return [p[0] - s * t * t * 0.06, p[1] - t * t * 0.03, p[2]]; });
    cf.computeNormals();
    cf.paint((p, n) => mix3(cTop, cBelly, smoothstep(-0.2, -0.8, n[1]) * 0.8).concat([0.9]));
    g.append(cf);
  }
  // ---- the mouth: a wide dark slit on the front edge between the horn-fins
  const mouth = egg(0.2, 0.035, 0.05, 16, 6);
  mouth.translate(0, -0.012, 0.69);
  mouth.setColor([0.03, 0.02, 0.07], 0.5);
  g.append(mouth);
  // ---- the tail: a long whip with a small glowing spark at the tip, and two little pelvic fins
  {
    const pts = [];
    for (let k = 0; k <= 16; k++) { const t = k / 16; pts.push([0, 0.01 - t * 0.04, -0.6 - t * 1.6]); }
    const tl = Geometry.tube(pts, (t) => 0.045 * (1 - t) + 0.004, 8, { capStart: true, capEnd: true });
    tl.paint((p) => mix3(cTop, cGlow, smoothstep(-1.6, -2.2, p[2])).concat([0.9]));
    tl.paintExtra((p) => [smoothstep(-1.9, -2.2, p[2]) * 2.4]);
    g.append(tl);
    const tip = Geometry.icosphere(0.03, 1);
    tip.translate(0, -0.03, -2.21);
    tip.setColor(cGlow, 1);
    tip.setExtra([3]);
    g.append(tip);
    for (const s of [-1, 1]) {
      const pf = egg(0.1, 0.012, 0.13, 10, 4);
      pf.rotateY(s * 0.5);
      pf.translate(s * 0.13, -0.01, -0.62);
      pf.paint(() => cMid.concat([0.9]));
      g.append(pf);
    }
  }
  const bm = mesh(ctx, g, mat, 'rayBody');
  body.add(bm);
  // ---- eyes on the sides of the head (rigid: they sit on the thick body part, which does not flap)
  const eyesN = bone('eyes', body, 0, 0.055, 0.5);
  bones.eyes = eyesN;
  const eg = eyePair(0.3, 0, 0, 0.032, C(pal.eye), { glow: 1.4, pupil: 0.5, toe: 1.35, squash: 0.9 });
  for (const s of [-1, 1]) {
    const lid = egg(0.038, 0.02, 0.036, 10, 6);
    lid.translate(0, 0.016, 0);
    lid.rotateY(s * 1.35);
    lid.translate(s * 0.3, 0, 0);
    lid.setColor(cTop, 1);
    lid.setExtra([0]);
    eg.append(lid);
  }
  eyesN.add(mesh(ctx, eg, M.glowSoft, 'rayEyes'));
  // a morsel of bad dream it is about to swallow: a small dark orb with a violet rim
  const wisp = bone('wisp', root, 0, 1.2, 1.9);
  const wg = Geometry.icosphere(0.11, 2);
  wg.paint(() => mix3(C('#0a0612'), C('#8a4cff'), 0.25).concat([1]));
  wg.setExtra([0.9]);
  for (let k = 0; k < 4; k++) {
    const o = Geometry.icosphere(0.035, 1);
    const a = (k / 4) * TAU;
    o.translate(Math.cos(a) * 0.17, Math.sin(a * 2) * 0.05, Math.sin(a) * 0.17);
    o.setColor(C('#b88cff'), 1);
    o.setExtra([2.4]);
    wg.append(o);
  }
  wisp.add(mesh(ctx, wg, M.glowSoft, 'rayWisp'));
  wisp.visible = false;
  bones.wisp = wisp;
  return { root, bones, scale, pal, mat };
}

// ================================================================== Gyökérpók: the root spider
export const SPIDER_LEGS = 8;
export function buildRootSpider(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('rootspider');
  const bones = {};
  const scale = rng.range(0.9, 1.15);
  const inner = bone('scale', root);
  inner.setScale(scale);
  const body = bone('body', inner, 0, 0.55, 0);
  bones.body = body;
  const barkCol = (p, n, k = 0) => {
    const v = noise.n3(p[0] * 9 + seed, p[1] * 14, p[2] * 9) * 0.5 + 0.5;
    let c = mix3(C('#1c1714'), C('#4d4036'), v);
    if (n && n[1] > 0.55) c = mix3(c, C('#1e4a3c'), smoothstep(0.55, 0.9, n[1]) * smoothstep(0.35, 0.7, noise.n3(p[0] * 5, p[1] * 5, p[2] * 5 + seed) * 0.5 + 0.5) * 0.8);
    return c.concat([0.85 - k * 0.2]);
  };
  // head-body: a knotted core wrapped in twisted roots
  const core = egg(0.24, 0.17, 0.26, 16, 12);
  core.computeNormals();
  core.displace((p) => noise.fbm3(p[0] * 7 + seed, p[1] * 7, p[2] * 7, 3) * 0.05, true);
  for (let k = 0; k < 7; k++) {
    const a0 = (k / 7) * TAU + rng.range(-0.2, 0.2), twist = rng.range(1.2, 2.2) * (k % 2 ? 1 : -1);
    const pts = [];
    for (let i = 0; i <= 10; i++) {
      const t = i / 10, z = lerp(0.24, -0.26, t), a = a0 + twist * t;
      const s = Math.sqrt(Math.max(0.05, 1 - (z / 0.28) ** 2));
      pts.push([Math.cos(a) * 0.24 * s * 1.02, Math.sin(a) * 0.17 * s * 1.02 + 0.01, z]);
    }
    core.append(Geometry.tube(pts, (t) => 0.034 * (0.7 + 0.5 * Math.sin(t * Math.PI)), 6, { capStart: true, capEnd: true }));
  }
  core.computeNormals();
  core.paint((p, n) => barkCol(p, n));
  body.add(mesh(ctx, core, M.bark, 'spiderBody'));
  // abdomen: a big gnarled bulb with embers glowing in its cracks, moss and three tiny mushrooms on top
  const abd = bone('abdomen', body, 0, 0.08, -0.3);
  bones.abdomen = abd;
  const ag = egg(0.32, 0.27, 0.4, 20, 14);
  ag.translate(0, 0.05, -0.3);
  ag.computeNormals();
  ag.displace((p) => noise.fbm3(p[0] * 5 + seed, p[1] * 5, p[2] * 5, 4) * 0.07 - Math.pow(1 - Math.abs(noise.n3(p[0] * 6 + 3, p[1] * 6, p[2] * 6)), 14) * 0.03, true);
  ag.paint((p, n) => barkCol(p, n));
  ag.paintExtra((p) => {
    const crack = Math.pow(1 - Math.abs(noise.n3(p[0] * 6 + 3, p[1] * 6, p[2] * 6)), 14);
    return [smoothstep(0.35, 1, crack) * 1.3, 0, 0];
  });
  // (ember colour in the cracks: tint the glowing vertices orange)
  for (let i = 0; i < ag.vertexCount; i++) {
    const gl = ag.e[i * 4];
    if (gl > 0.05) {
      const t = clamp(gl / 1.6, 0, 1);
      const c = mix3([ag.c[i * 4], ag.c[i * 4 + 1], ag.c[i * 4 + 2]], C('#ff8a2a'), t);
      ag.c[i * 4] = c[0]; ag.c[i * 4 + 1] = c[1]; ag.c[i * 4 + 2] = c[2];
    }
  }
  for (let k = 0; k < 3; k++) {
    const x = rng.range(-0.12, 0.12), z = rng.range(-0.45, -0.15);
    const st = Geometry.cylinder(0.012, 0.016, 0.07, 6, 1);
    st.translate(x, 0.3, z);
    st.setColor(C('#cfc6e0'), 1);
    const cap = Geometry.sphere(0.035, 10, 6);
    cap.deform((p) => [p[0], Math.max(p[1], -0.005) * 0.7, p[2]]);
    cap.translate(x, 0.37, z);
    cap.setColor(C('#6fd8ff'), 1);
    cap.setExtra([1.4]);
    ag.append(st);
    ag.append(cap);
  }
  abd.add(mesh(ctx, ag, M.bark, 'spiderAbdomen'));
  // a cluster of amber eyes
  const eyesN = bone('eyes', body, 0, 0.05, 0.275);
  bones.eyes = eyesN;
  const eg = new Geometry();
  const spots = [[-0.055, 0.03, 0.03], [0.055, 0.03, 0.03], [-0.1, 0.07, 0.018], [0.1, 0.07, 0.018], [-0.03, 0.085, 0.016], [0.03, 0.085, 0.016], [-0.12, 0.0, 0.014], [0.12, 0.0, 0.014]];
  for (const [x, y, r] of spots) {
    const e = egg(r, r, r * 0.8, 10, 8);
    e.translate(x, y, 0.02 - Math.abs(x) * 0.25);
    e.setColor(C('#ffae40'), 1);
    e.setExtra([2.6]);
    eg.append(e);
    const hl = egg(r * 0.25, r * 0.25, r * 0.1, 5, 4);
    hl.translate(x + r * 0.3, y + r * 0.35, 0.02 - Math.abs(x) * 0.25 + r * 0.75);
    hl.setColor([1, 1, 0.9], 1);
    hl.setExtra([3]);
    eg.append(hl);
  }
  eyesN.add(mesh(ctx, eg, M.glowSoft, 'spiderEyes'));
  // thorn fangs
  for (const s of [-1, 1]) {
    const f = bone(s < 0 ? 'fangR' : 'fangL', body, s * 0.05, -0.06, 0.24);
    const fg = Geometry.tube([[0, 0, 0], [0, -0.07, 0.05], [0, -0.15, 0.04], [0, -0.2, -0.02]], [0.032, 0.022, 0.012, 0.003], 7, { capStart: true });
    fg.paint((p) => mix3(C('#3a2e26'), C('#0c0808'), smoothstep(-0.08, -0.18, p[1])).concat([1]));
    f.add(mesh(ctx, fg, M.bark));
    bones[s < 0 ? 'fangR' : 'fangL'] = f;
  }
  // eight legs, each a thigh and a shin of twisted root with knobbly joints and hairy rootlets
  bones.legs = [];
  const angs = [0.8, 0.28, -0.28, -0.8];
  for (let i = 0; i < SPIDER_LEGS; i++) {
    const s = i < 4 ? 1 : -1, k = i % 4;
    const ang = angs[k];
    const dx = s * Math.cos(ang), dz = Math.sin(ang);
    const hip = bone('hip' + i, body, s * 0.2 * Math.cos(ang * 0.6), -0.02, 0.2 * Math.sin(ang) + (k < 2 ? 0.04 : -0.04));
    const yaw = Math.atan2(dx, dz);
    hip.setEuler(0, yaw, 0);
    const len1 = rng.range(0.52, 0.6), len2 = rng.range(0.92, 1.02);
    const thigh = Geometry.tube([[0, 0, 0], [0, len1 * 0.45, len1 * 0.45], [0, len1 * 0.62, len1 * 0.8]], [0.05, 0.04, 0.034], 7, { capStart: true, capEnd: true });
    const knob = egg(0.052, 0.05, 0.052, 8, 6);
    knob.translate(0, len1 * 0.62, len1 * 0.8);
    thigh.append(knob);
    thigh.computeNormals();
    thigh.displace((p) => noise.n3(p[0] * 18 + i, p[1] * 18, p[2] * 18) * 0.012, true);
    thigh.paint((p, n) => barkCol(p, n, 0.3));
    hip.add(mesh(ctx, thigh, M.bark));
    const knee = bone('knee' + i, hip, 0, len1 * 0.62, len1 * 0.8);
    const shin = Geometry.tube([[0, 0, 0], [0, -len2 * 0.3, len2 * 0.25], [0, -len2 * 0.66, len2 * 0.33], [0, -len2 * 0.93, len2 * 0.3]], [0.034, 0.026, 0.016, 0.003], 7, { capStart: true });
    for (let h = 0; h < 3; h++) {
      const t = 0.25 + h * 0.22;
      const hx = rng.range(-1, 1);
      const hair = Geometry.tube([[0, -len2 * 0.8 * t, len2 * 0.3 * t], [hx * 0.05, -len2 * 0.8 * t - 0.04, len2 * 0.3 * t + 0.05], [hx * 0.09, -len2 * 0.8 * t - 0.03, len2 * 0.3 * t + 0.1]], [0.008, 0.005, 0.001], 4);
      shin.append(hair);
    }
    shin.computeNormals();
    shin.displace((p) => noise.n3(p[0] * 20 + i, p[1] * 20, p[2] * 20) * 0.008, true);
    shin.paint((p, n) => barkCol(p, n, 0.2));
    knee.add(mesh(ctx, shin, M.bark));
    bones.legs.push({ hip, knee, yaw, side: s, k, len1, len2 });
  }
  return { root, bones, scale };
}

// ================================================================== Csendes: the silent one
function antler(g, rng, p, dir, len, r, depth) {
  const pts = [p];
  let d = vnorm(dir), q = p;
  const n = 5;
  for (let i = 1; i <= n; i++) {
    d = vnorm([d[0] + rng.range(-0.25, 0.25), d[1] + rng.range(-0.1, 0.2), d[2] + rng.range(-0.25, 0.25)]);
    q = [q[0] + d[0] * len / n, q[1] + d[1] * len / n, q[2] + d[2] * len / n];
    pts.push(q);
  }
  g.append(Geometry.tube(pts, (t) => r * (1 - t * 0.75), 6, { capStart: true, capEnd: true }));
  if (depth <= 0) return;
  const forks = depth > 1 ? 3 : 2;
  for (let k = 0; k < forks; k++) {
    const t = rng.range(0.35, 0.85);
    const i = Math.min(n - 1, Math.max(1, Math.round(t * n)));
    const side = vnorm(vcross(dir, [0, 1, 0.01]));
    const sg = k % 2 ? 1 : -1;
    const nd = vnorm([dir[0] * 0.5 + side[0] * sg * 0.8 + rng.range(-0.2, 0.2), 0.9 + rng.range(-0.2, 0.3), dir[2] * 0.5 + side[2] * sg * 0.8 + rng.range(-0.2, 0.2)]);
    antler(g, rng, pts[i], nd, len * rng.range(0.4, 0.6), r * (1 - (i / n) * 0.7) * 0.8, depth - 1);
  }
}
export function buildSilentOne(ctx, seed = 1) {
  const M = faunaMaterials(ctx.M);
  const rng = new RNG(seed);
  const root = new Node('silent');
  const bones = {};
  const scale = rng.range(0.95, 1.1);
  const inner = bone('scale', root);
  inner.setScale(scale);
  const cloth = (p, k = 0) => mix3(C('#06050b'), C('#1a1928'), smoothstep(0.0, 2.0, p[1]) * 0.55 + noise.n3(p[0] * 4, p[1] * 2, p[2] * 4) * 0.2).concat([0.8 + k]);
  // long tattered robe from the waist to the ground
  const WAIST = 1.72;
  const skirt = bone('skirt', inner, 0, WAIST, 0);
  bones.skirt = skirt;
  const sg = Geometry.lathe(catmullRom([[0.17, 0.02], [0.2, -0.4], [0.28, -0.95], [0.38, -1.45], [0.47, -1.74]], 3), 28);
  sg.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const low = smoothstep(-1.0, -1.74, p[1]);
    const rag = (noise.n3(Math.cos(a) * 3 + seed, Math.sin(a) * 3, 0) * 0.5 + 0.5) * 0.3 + Math.max(0, Math.sin(a * 9 + seed)) * 0.14;
    const fold = 1 + Math.sin(a * 11 + seed) * 0.05 * low;
    return [p[0] * fold, p[1] + rag * low * (p[1] < -1.62 ? 1 : 0.35), p[2] * fold * 0.8];
  });
  sg.computeNormals();
  sg.paint((p) => cloth([p[0], p[1] + WAIST, p[2]]));
  skirt.add(mesh(ctx, sg, M.shade, 'silentRobe'));
  // narrow chest, sloping shoulders, a long neck in a ragged cowl
  const torso = bone('torso', inner, 0, WAIST, 0);
  bones.torso = torso;
  const tg = Geometry.lathe(catmullRom([[0.17, -0.05], [0.18, 0.3], [0.2, 0.6], [0.19, 0.8], [0.11, 0.93], [0.055, 1.02], [0.05, 1.12], [0.0, 1.15]], 2), 18);
  tg.scale(1, 1, 0.7);
  const cowl = Geometry.torus(0.12, 0.05, 8, 18);
  cowl.rotateX(Math.PI / 2);
  cowl.deform((p) => [p[0], p[1] + noise.n3(p[0] * 20, p[2] * 20, seed) * 0.03, p[2] * 0.85]);
  cowl.translate(0, 0.93, 0);
  tg.append(cowl);
  tg.computeNormals();
  tg.paint((p) => cloth([p[0], p[1] + WAIST, p[2]], 0.1));
  torso.add(mesh(ctx, tg, M.shade, 'silentTorso'));
  // head: a hood, a long porcelain mask with slanted empty eyes, antlers of bare branches
  const head = bone('head', torso, 0, 1.22, 0.02);
  bones.head = head;
  const hood = egg(0.17, 0.26, 0.19, 18, 12);
  hood.deform((p) => [p[0], p[1], p[2] < 0.03 ? p[2] : 0.03 + (p[2] - 0.03) * 0.2]);
  hood.translate(0, 0.03, -0.04);
  hood.computeNormals();
  hood.paint((p) => cloth([p[0], p[1] + 2.9, p[2]], 0.05));
  head.add(mesh(ctx, hood, M.shade, 'silentHood'));
  const mask = egg(0.1, 0.2, 0.09, 24, 20);
  mask.deform((p) => {
    const chin = smoothstep(0.0, -0.2, p[1]);
    return [p[0] * (1 - chin * 0.45), p[1], p[2] > 0 ? p[2] * (0.92 - Math.abs(p[1]) * 0.7) : p[2] * 0.6];
  });
  mask.translate(0, -0.02, 0.075);
  mask.computeNormals();
  mask.paint((p) => {
    const crack = Math.pow(1 - Math.abs(noise.n3(p[0] * 12 + seed, p[1] * 7, 1.3)), 24);
    // one long crack running down from the left eye, grey stains under both
    const split = smoothstep(0.006, 0.0, Math.abs(p[0] - 0.04 - Math.sin(p[1] * 60) * 0.006)) * smoothstep(0.0, -0.03, p[1]);
    const stain = Math.exp(-(((Math.abs(p[0]) - 0.04) / 0.022) ** 2) - (((p[1] + 0.025) / 0.05) ** 2));
    const shade = mix3(C('#d6d0e2'), C('#6a6478'), stain * 0.55);
    return mix3(shade, C('#1a1622'), Math.min(1, crack * 0.8 + split)).concat([1]);
  });
  head.add(mesh(ctx, mask, M.porcelain, 'silentMask'));
  const holes = new Geometry();
  for (const s of [-1, 1]) {
    const h = egg(0.019, 0.046, 0.012, 10, 10);
    h.rotateZ(s * 0.38);
    h.translate(s * 0.04, 0.035, 0.141);
    h.setColor([0.0, 0.0, 0.004], 1);
    holes.append(h);
    const pt = egg(0.0055, 0.0055, 0.004, 6, 4);
    pt.translate(s * 0.041, 0.03, 0.15);
    pt.setColor(C('#d8ecff'), 1);
    pt.setExtra([4]);
    holes.append(pt);
  }
  const eyesN = bone('eyes', head);
  bones.eyes = eyesN;
  eyesN.add(mesh(ctx, holes, M.glowSoft, 'silentEyes'));
  const ant = new Geometry();
  for (const s of [-1, 1]) antler(ant, rng, [s * 0.07, 0.19, -0.05], [s * 0.75, 1, -0.3], rng.range(0.78, 0.92), 0.034, 3);
  ant.computeNormals();
  ant.paint((p, n) => mix3(C('#120f17'), C('#342d3a'), noise.n3(p[0] * 20, p[1] * 20, p[2] * 20) * 0.5 + 0.5).concat([0.9]));
  // two faint lights caught in the branches
  for (const s of [-1, 1]) {
    const b = Geometry.icosphere(0.02, 1);
    b.translate(s * rng.range(0.3, 0.42), rng.range(0.6, 0.78), rng.range(-0.2, 0.0));
    b.setColor(C('#bfe0ff'), 1);
    b.setExtra([3.0]);
    ant.append(b);
  }
  head.add(mesh(ctx, ant, M.bark, 'silentAntlers'));
  // long thin arms in ragged sleeves, twig fingers reaching the knees
  for (const s of [-1, 1]) {
    const arm = bone(s < 0 ? 'armR' : 'armL', torso, s * 0.19, 0.84, 0);
    const sl = Geometry.tube([[0, 0.02, 0], [s * 0.03, -0.35, 0.01], [s * 0.05, -0.62, 0.03]], [0.075, 0.08, 0.095], 10, { capStart: true, capEnd: false });
    sl.deform((p) => [p[0], p[1] + (p[1] < -0.55 ? (noise.n3(p[0] * 30, p[2] * 30, seed) * 0.06) : 0), p[2]]);
    sl.computeNormals();
    sl.paint((p) => cloth([p[0], p[1] + 2.55, p[2]], 0.05));
    arm.add(mesh(ctx, sl, M.shade));
    const limb = Geometry.tube([[s * 0.04, -0.45, 0.02], [s * 0.06, -0.85, 0.06], [s * 0.06, -1.22, 0.05]], [0.03, 0.024, 0.02], 7, { capStart: true, capEnd: true });
    for (let f = 0; f < 4; f++) {
      const fa = (f - 1.5) * 0.35;
      const base = [s * 0.06, -1.22, 0.05];
      const pts = [base];
      let q = base;
      for (let j = 1; j <= 3; j++) {
        q = [q[0] + Math.sin(fa) * 0.04 + rng.range(-0.01, 0.01), q[1] - 0.075, q[2] + Math.cos(fa) * 0.012 + j * 0.012];
        pts.push(q);
      }
      limb.append(Geometry.tube(pts, [0.012, 0.009, 0.006, 0.002], 5, { capStart: true }));
    }
    limb.computeNormals();
    limb.paint(() => C('#5a5468').concat([0.9]));
    arm.add(mesh(ctx, limb, M.bark));
    bones[s < 0 ? 'armR' : 'armL'] = arm;
  }
  return { root, bones, scale };
}
