// Procedural plants and fungi. All builders return Geometry in local space (base at origin).
import { Geometry, catmullRom } from '../engine/geometry.js';
import { noise } from '../engine/noise.js';
import { RNG, vnorm, vadd, vscale, vcross, TAU, lerp, mat4, quat, smoothstep } from '../engine/math.js';
import { C, LEAF_CARD } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

// Foliage cards cut to the outline of the leaf texture's opaque part (LEAF_CARD.poly, in uv space) with the
// exact uv mapping of the full quad. `map(u, v)` gives the position, `nrm` the facing normal.
function trimmedCard(map, nrm, fallback) {
  const poly = LEAF_CARD.poly;
  if (!poly || poly.length < 3) return fallback();
  const g = new Geometry();
  const ids = poly.map(([u, v]) => { const p = map(u, v); return g.vert(p[0], p[1], p[2], nrm[0], nrm[1], nrm[2], u, v); });
  // wind the fan like the original quad (its front face towards nrm)
  const P = (i) => [g.p[i * 3], g.p[i * 3 + 1], g.p[i * 3 + 2]];
  const a = P(ids[0]), b = P(ids[1]), c = P(ids[2]);
  const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  const cr = vcross(ab, ac);
  const flip = cr[0] * nrm[0] + cr[1] * nrm[1] + cr[2] * nrm[2] < 0;
  for (let i = 1; i < ids.length - 1; i++) {
    if (flip) g.tri(ids[0], ids[i + 1], ids[i]);
    else g.tri(ids[0], ids[i], ids[i + 1]);
  }
  return g;
}
// same as Geometry.quadXY(w, h): facing +Z, bottom at y = 0
const leafQuadXY = (w, h) => trimmedCard((u, v) => [(u - 0.5) * w, v * h, 0], [0, 0, 1], () => Geometry.quadXY(w, h));
// same as Geometry.plane(w, d): facing +Y, centered
const leafPlane = (w, d) => trimmedCard((u, v) => [(u - 0.5) * w, 0, (v - 0.5) * d], [0, 1, 0], () => Geometry.plane(w, d));

// ------------------------------------------------------------------ giant glowing mushroom (unit height = 1)
export function giantMushroom(seed = 1, { capRatio = 0.55, bend = 0.12, stemR = 0.075, variant = 0, lod = 0 } = {}) {
  const rng = new RNG(seed);
  const H = 1;
  const R = capRatio * H;
  const capY = 0.9 * H;
  // stem
  const prof = [];
  const rings = 14;
  for (let j = 0; j <= rings; j++) {
    const t = j / rings;
    let r = stemR * (1.0 + 1.1 * Math.pow(1 - t, 6) + 0.15 * Math.sin(t * 7 + seed));
    if (t > 0.9) r *= 1 + (t - 0.9) * 4;
    prof.push([r, t * capY]);
  }
  const stem = Geometry.lathe(prof, lod ? 8 : 16);
  const stemCol = C('#7d8ab8');
  const stemDark = C('#1a2140');
  stem.paint((p) => mix3(stemDark, stemCol, smoothstep(0.0, 0.35, p[1])).concat([smoothstep(-0.05, 0.3, p[1]) * 0.6 + 0.4]));
  stem.displace((p) => noise.n3(p[0] * 30 + seed, p[1] * 8, p[2] * 30) * stemR * 0.12);
  // subtle glowing streaks on the stem
  stem.paintExtra((p) => [Math.max(0, noise.n3(p[0] * 20, p[1] * 3 + seed, p[2] * 20) - 0.35) * 0.4 * smoothstep(0.2, 0.9, p[1] / capY)]);

  const g = new Geometry();
  g.append(stem);

  // skirt ring (annulus)
  if (variant !== 2) {
    const sk = Geometry.lathe([[stemR * 1.02, capY * 0.66], [stemR * 1.5, capY * 0.62], [stemR * 1.65, capY * 0.6]], lod ? 8 : 16);
    sk.setColor(C('#5a6488'), 0.7);
    sk.setExtra([0.1]);
    g.append(sk);
  }

  // gills (underside), faint glow
  const gillProf = [];
  for (let j = 0; j <= 6; j++) {
    const t = j / 6;
    gillProf.push([lerp(R * 0.97, stemR * 1.2, t), capY + lerp(-0.02 * R, 0.08 * R, Math.pow(t, 0.7))]);
  }
  const gills = Geometry.lathe(gillProf, lod ? 16 : 48);
  gills.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const r = Math.hypot(p[0], p[2]);
    const k = Math.abs(Math.sin(a * 36)) * 0.03 * R * smoothstep(stemR, R, r);
    return [p[0], p[1] + k, p[2]];
  });
  gills.computeNormals();
  gills.paint((p) => {
    const r = Math.hypot(p[0], p[2]) / R;
    return mix3(C('#223a7a'), C('#5fa8ff'), r).concat([0.8]);
  });
  gills.paintExtra((p) => [0.35 + 0.4 * Math.hypot(p[0], p[2]) / R]);
  g.append(gills);

  // cap
  const capProf = [
    [R * 0.9, capY - 0.06 * R],
    [R * 1.0, capY - 0.01 * R],
    [R * 1.02, capY + 0.06 * R],
    [R * 0.96, capY + 0.18 * R],
    [R * 0.84, capY + 0.33 * R],
    [R * 0.66, capY + 0.47 * R],
    [R * 0.44, capY + 0.57 * R],
    [R * 0.2, capY + 0.62 * R],
    [0.0, capY + 0.635 * R],
  ];
  const capDense = catmullRom(capProf, lod ? 1 : 3);
  const cap = Geometry.lathe(capDense, lod ? 16 : 40);
  cap.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const wob = 1 + noise.n2(Math.cos(a) * 1.5 + seed, Math.sin(a) * 1.5) * 0.07;
    return [p[0] * wob, p[1] + noise.n2(p[0] * 3 + seed, p[2] * 3) * 0.015, p[2] * wob];
  });
  cap.computeNormals();
  const capTop = C(variant === 1 ? '#1c2766' : '#123251');
  const capRim = C(variant === 1 ? '#4452a8' : '#2d6f96');
  cap.paint((p) => {
    const r = Math.hypot(p[0], p[2]) / R;
    return mix3(capTop, capRim, smoothstep(0.5, 1.0, r)).concat([1]);
  });
  cap.paintExtra((p) => [smoothstep(0.9, 1.02, Math.hypot(p[0], p[2]) / R) * 0.25, 0, 1]);
  const capG = cap;

  // bend everything
  const bendAll = (geo) =>
    geo.deform((p) => {
      const t = p[1] / H;
      const b = bend * t * t;
      return [p[0] + b * Math.cos(seed), p[1], p[2] + b * Math.sin(seed)];
    });
  bendAll(g);
  bendAll(capG);
  return { stem: g, cap: capG, capY, R };
}

// ------------------------------------------------------------------ fly agaric (unit height)
export function amanita(seed = 1, { capRatio = 0.45, open = 0.6, lod = 0 } = {}) {
  const rng = new RNG(seed);
  const R = capRatio;
  const capY = 0.82;
  const sr = 0.07;
  const prof = [];
  for (let j = 0; j <= 10; j++) {
    const t = j / 10;
    let r = sr * (1.45 - t * 0.5 + 0.25 * Math.exp(-t * 12));
    prof.push([r, t * capY]);
  }
  const stem = Geometry.lathe(prof, lod ? 7 : 14);
  stem.displace((p) => noise.n3(p[0] * 40, p[1] * 10 + seed, p[2] * 40) * 0.006);
  stem.paint((p) => mix3(C('#6d6f7e'), C('#bdb9b0'), smoothstep(0, 0.5, p[1])).concat([smoothstep(-0.1, 0.4, p[1]) * 0.5 + 0.5]));
  const skirt = Geometry.lathe([[sr * 1.0, capY * 0.72], [sr * 1.7, capY * 0.64], [sr * 1.9, capY * 0.6]], lod ? 7 : 14);
  skirt.setColor(C('#efe9dc'), 0.8);
  stem.append(skirt);
  // cap: open dome
  const h = R * (0.7 - open * 0.35);
  const capProf = catmullRom([
    [R * 0.55, capY - 0.02],
    [R * 0.9, capY + 0.0],
    [R * 1.0, capY + h * 0.15],
    [R * 0.9, capY + h * 0.55],
    [R * 0.55, capY + h * 0.9],
    [0.0, capY + h],
  ], lod ? 1 : 3);
  const cap = Geometry.lathe(capProf, lod ? 12 : 32);
  cap.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const wob = 1 + noise.n2(Math.cos(a) * 1.2 + seed, Math.sin(a) * 1.2) * 0.06;
    return [p[0] * wob, p[1], p[2] * wob];
  });
  cap.computeNormals();
  cap.paint((p) => {
    const r = Math.hypot(p[0], p[2]) / R;
    const under = p[1] < capY + h * 0.08 && r < 0.93;
    if (under) return C('#d8cfbf').concat([0.6]);
    return mix3(C('#e0141a'), C('#9e0b16'), smoothstep(0.3, 1.0, r)).concat([1]);
  });
  cap.paintExtra((p) => {
    const r = Math.hypot(p[0], p[2]) / R;
    const under = p[1] < capY + h * 0.08 && r < 0.93;
    return [0, 0, under ? 0 : 1];
  });
  return { stem, cap };
}

// ------------------------------------------------------------------ small glowing mushroom cluster
export function glowShroomCluster(seed = 1, count = 5) {
  const rng = new RNG(seed);
  const g = new Geometry();
  for (let i = 0; i < count; i++) {
    const h = rng.range(0.12, 0.42);
    const a = rng.range(0, TAU), d = i === 0 ? 0 : rng.range(0.05, 0.25);
    const x = Math.cos(a) * d, z = Math.sin(a) * d;
    const sr = h * 0.08;
    const stem = Geometry.lathe([[sr * 1.3, 0], [sr, h * 0.5], [sr * 0.9, h]], 5);
    stem.setColor(C('#c9d2f0'), 0.9);
    stem.setExtra([0.25, 0, 0, 0]);
    const R = h * rng.range(0.28, 0.45);
    const cap = Geometry.lathe(catmullRom([[R * 0.5, h - 0.01], [R, h + R * 0.05], [R * 0.85, h + R * 0.4], [R * 0.4, h + R * 0.7], [0, h + R * 0.78]], 1), 9);
    cap.setColor([1, 1, 1], 1);
    cap.setExtra([0.9, 0, 0, 0]);
    const lean = rng.range(-0.25, 0.25), lean2 = rng.range(-0.25, 0.25);
    for (const part of [stem, cap]) {
      part.deform((p) => [p[0] + lean * p[1] * p[1] * 3, p[1], p[2] + lean2 * p[1] * p[1] * 3]);
      part.translate(x, 0, z);
      part.windByHeight(0, 0.5, 1);
      g.append(part);
    }
  }
  g.computeNormals();
  return g;
}

// ------------------------------------------------------------------ gnarled tree
function branchCurve(rng, start, dir, len, segs, twist) {
  const pts = [start];
  let d = vnorm(dir);
  let p = start;
  for (let i = 1; i <= segs; i++) {
    d = vnorm(vadd(d, [rng.range(-twist, twist), rng.range(-twist * 0.4, twist * 0.6), rng.range(-twist, twist)]));
    p = vadd(p, vscale(d, len / segs));
    pts.push(p);
  }
  return pts;
}

export function gnarledTree(seed = 1, { height = 9, dead = false, spread = 1, lod = 0, leafA = '#233c5c', leafB = '#2f5f73', glow = 0, cardScale = 1 } = {}) {
  const rng = new RNG(seed);
  const wood = new Geometry();
  const leafSpots = [];
  const baseR = height * 0.055;
  // trunk
  const trunk = branchCurve(rng, [0, -0.3, 0], [rng.range(-0.15, 0.15), 1, rng.range(-0.15, 0.15)], height * 0.62, 7, 0.22);
  const trunkG = Geometry.tube(trunk, (t) => baseR * (1 - t * 0.55) * (1 + 0.5 * Math.exp(-t * 10)), lod ? 5 : 10, { capEnd: true });
  trunkG.windByHeight(height * 0.3, height, 2);
  wood.append(trunkG);
  // roots
  const nRoots = rng.int(4, 6);
  for (let i = 0; i < nRoots; i++) {
    const a = (i / nRoots) * TAU + rng.range(-0.3, 0.3);
    const start = [Math.cos(a) * baseR * 0.4, height * 0.08, Math.sin(a) * baseR * 0.4];
    const pts = [start];
    let p = start;
    for (let k = 1; k <= 4; k++) {
      const out = baseR * (0.8 + k * 0.7);
      p = [Math.cos(a + k * 0.08) * out, height * 0.07 - k * k * 0.07 * height * 0.2 - 0.08, Math.sin(a + k * 0.08) * out]; // (v8: the tips dig into the ground)
      pts.push(p);
    }
    if (lod) continue; // roots vanish in the distance
    const rg = Geometry.tube(pts, (t) => baseR * 0.55 * (1 - t * 0.85), 7, { capEnd: true });
    rg.setExtra([null, 0]);
    wood.append(rg);
  }
  // branches (recursive)
  const grow = (pts, radius, depth) => {
    const n = depth === 0 ? rng.int(3, 5) : rng.int(2, 3);
    for (let i = 0; i < n; i++) {
      const t = rng.range(depth === 0 ? 0.55 : 0.4, 0.95);
      const idx = Math.min(pts.length - 2, Math.floor(t * (pts.length - 1)));
      const base = pts[idx];
      const pd = vnorm([pts[idx + 1][0] - base[0], pts[idx + 1][1] - base[1], pts[idx + 1][2] - base[2]]);
      const a = rng.range(0, TAU);
      const out = [Math.cos(a), 0, Math.sin(a)];
      const dir = vnorm(vadd(vscale(pd, 0.8), vscale(out, 0.9 * spread + 0.3)));
      const len = height * (depth === 0 ? rng.range(0.28, 0.45) : rng.range(0.16, 0.26));
      const bp = branchCurve(rng, base, dir, len, 4, 0.3);
      const r0 = radius * rng.range(0.45, 0.6);
      const bg = Geometry.tube(bp, (tt) => r0 * (1 - tt * 0.8), lod ? (depth === 0 ? 4 : 3) : depth === 0 ? 7 : 5, { capEnd: true });
      bg.windByHeight(height * 0.3, height * 1.1, 1.5);
      wood.append(bg);
      if (depth < 1) grow(bp, r0, depth + 1);
      else leafSpots.push(bp[bp.length - 1], bp[Math.floor(bp.length / 2)]);
      if (depth === 0) leafSpots.push(bp[bp.length - 1]);
    }
  };
  grow(trunk, baseR * (1 - 0.55 * 0.6), 0);
  leafSpots.push(trunk[trunk.length - 1]);
  wood.displace((p) => noise.n3(p[0] * 2.5 + seed, p[1] * 1.2, p[2] * 2.5) * baseR * 0.15, true);
  const barkA = C(dead ? '#2c2e3c' : '#2a2c3a'), barkB = C(dead ? '#6d7288' : '#565e78');
  wood.paint((p, n) => {
    const m = noise.n3(p[0] * 0.8, p[1] * 0.5 + seed, p[2] * 0.8) * 0.5 + 0.5;
    let c = mix3(barkA, barkB, m);
    // moss on upward faces
    if (!dead && n[1] > 0.3) c = mix3(c, C('#1f4a4a'), smoothstep(0.3, 0.8, n[1]) * 0.7);
    return c.concat([smoothstep(-0.3, 1.5, p[1]) * 0.6 + 0.4]);
  });
  // foliage cards
  const leaves = new Geometry();
  if (!dead) {
    for (const s of leafSpots) {
      const size = height * rng.range(0.22, 0.34) * cardScale;
      const nCards = 3;
      const tint = mix3(C(leafA), C(leafB), rng.next());
      for (let k = 0; k < nCards; k++) {
        const q = lod ? Geometry.quadXY(size, size) : leafQuadXY(size, size);
        q.translate(0, -size * 0.5, 0);
        q.rotateY((k / nCards) * Math.PI + rng.range(0, 0.5));
        q.rotateX(rng.range(-0.4, 0.4));
        q.translate(s[0] + rng.range(-0.3, 0.3), s[1] + size * 0.1, s[2] + rng.range(-0.3, 0.3));
        q.setColor(tint, 1);
        q.setExtra([0, 1, 0, rng.next()]);
        leaves.append(q);
      }
      // horizontal card for canopy from below
      const hq = lod ? Geometry.plane(size * 1.2, size * 1.2) : leafPlane(size * 1.2, size * 1.2);
      hq.translate(s[0], s[1] + 0.1, s[2]);
      hq.setColor(mix3(tint, [0, 0, 0], 0.2), 1);
      hq.setExtra([0, 1, 0, rng.next()]);
      leaves.append(hq);
    }
    // wind on leaves scaled by height
    leaves.paintExtra((p) => [glow || null, 0.6 + 0.4 * smoothstep(0, height, p[1])]);
    // leaf normals point outward from tree center for soft lighting
    const cy = height * 0.75;
    for (let i = 0; i < leaves.vertexCount; i++) {
      const nx = leaves.p[i * 3], ny = leaves.p[i * 3 + 1] - cy * 0.8, nz = leaves.p[i * 3 + 2];
      const l = Math.hypot(nx, ny, nz) || 1;
      leaves.n[i * 3] = nx / l; leaves.n[i * 3 + 1] = ny / l; leaves.n[i * 3 + 2] = nz / l;
    }
  }
  return { wood, leaves, radius: baseR };
}

// ------------------------------------------------------------------ swamp cypress with buttress roots
export function swampTree(seed = 1, { height = 16, lod = 0 } = {}) {
  const rng = new RNG(seed);
  const baseR = height * 0.07;
  const prof = [];
  const N = 16;
  for (let j = 0; j <= N; j++) {
    const t = j / N;
    const y = -0.6 + t * height * 0.8;
    const r = baseR * (0.55 + 2.4 * Math.pow(1 - Math.min(t * 3.5, 1), 2.5) - t * 0.2);
    prof.push([r, y]);
  }
  const trunk = Geometry.lathe(prof, lod ? 10 : 24);
  const flutes = rng.int(6, 8);
  trunk.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const t = (p[1] + 0.6) / (height * 0.8);
    const fl = Math.pow(Math.max(0, 1 - t * 3), 1.5);
    const k = 1 + (Math.pow(Math.abs(Math.sin(a * flutes * 0.5 + seed)), 3) * 0.9 - 0.3) * fl + noise.n3(p[0], p[1] * 0.4, p[2]) * 0.1;
    return [p[0] * k, p[1], p[2] * k];
  });
  trunk.computeNormals();
  trunk.displace((p) => noise.n3(p[0] * 1.8 + seed, p[1] * 0.6, p[2] * 1.8) * 0.12, true);
  trunk.windByHeight(height * 0.5, height, 2);
  const wood = new Geometry();
  wood.append(trunk);
  const leafSpots = [];
  const top = height * 0.8 - 0.6;
  for (let i = 0; i < 6; i++) {
    const a = rng.range(0, TAU);
    const y = top - rng.range(0, height * 0.25);
    const r0 = baseR * 0.35;
    const bp = branchCurve(rng, [0, y, 0], [Math.cos(a), rng.range(0.1, 0.5), Math.sin(a)], height * rng.range(0.2, 0.32), 4, 0.25);
    const bg = Geometry.tube(bp, (t) => r0 * (1 - t * 0.8), lod ? 4 : 6);
    bg.windByHeight(height * 0.5, height, 1.5);
    wood.append(bg);
    leafSpots.push(bp[bp.length - 1], bp[2]);
  }
  leafSpots.push([0, top + 0.5, 0]);
  wood.paint((p, n) => {
    const m = noise.n3(p[0] * 0.5, p[1] * 0.3 + seed, p[2] * 0.5) * 0.5 + 0.5;
    let c = mix3(C('#2b2a36'), C('#5a5a6e'), m);
    if (p[1] < 2.5) c = mix3(c, C('#1c3b3c'), smoothstep(2.5, 0, p[1]) * 0.6);
    return c.concat([smoothstep(-0.6, 3, p[1]) * 0.55 + 0.45]);
  });
  // canopy: flat wide clumps
  const leaves = new Geometry();
  for (const s of leafSpots) {
    const size = height * rng.range(0.25, 0.36);
    const tint = mix3(C('#20364a'), C('#2c5a58'), rng.next());
    for (let k = 0; k < 3; k++) {
      const q = lod ? Geometry.quadXY(size, size * 0.7) : leafQuadXY(size, size * 0.7);
      q.translate(0, -size * 0.35, 0);
      q.rotateY((k / 3) * Math.PI + rng.range(0, 0.4));
      q.translate(s[0], s[1], s[2]);
      q.setColor(tint, 1);
      q.setExtra([0, 1, 0, rng.next()]);
      leaves.append(q);
    }
    const hq = lod ? Geometry.plane(size * 1.3, size * 1.3) : leafPlane(size * 1.3, size * 1.3);
    hq.rotateY(rng.range(0, 3));
    hq.translate(s[0], s[1] + 0.2, s[2]);
    hq.setColor(tint, 1);
    hq.setExtra([0, 1, 0, rng.next()]);
    leaves.append(hq);
  }
  leaves.paintExtra((p) => [null, 0.7]);
  for (let i = 0; i < leaves.vertexCount; i++) {
    const nx = leaves.p[i * 3], ny = leaves.p[i * 3 + 1] - top * 0.7, nz = leaves.p[i * 3 + 2];
    const l = Math.hypot(nx, ny, nz) || 1;
    leaves.n[i * 3] = nx / l; leaves.n[i * 3 + 1] = ny / l; leaves.n[i * 3 + 2] = nz / l;
  }
  // hanging moss strands
  const moss = new Geometry();
  for (let i = 0; i < 26; i++) {
    const s = leafSpots[i % leafSpots.length];
    const len = rng.range(1.2, 3.5);
    const x = s[0] + rng.range(-1.5, 1.5), z = s[2] + rng.range(-1.5, 1.5), y = s[1] - rng.range(0, 0.6);
    const pts = [];
    for (let k = 0; k <= 5; k++) pts.push([x + Math.sin(k * 0.9 + i) * 0.08, y - (k / 5) * len, z + Math.cos(k * 0.7 + i) * 0.08]);
    const st = Geometry.tube(pts, (t) => 0.07 * (1 - t * 0.7), 4, { capEnd: false });
    st.setColor(C('#6f8f94'), 1);
    st.paintExtra((p) => [0.0, 0.3 + (y - p[1]) / len * 0.8, 0, rng.next()]);
    if (!lod) moss.append(st);
  }
  return { wood, leaves, moss, radius: baseR * 1.8 };
}

// ------------------------------------------------------------------ conifer (mountains)
export function pine(seed = 1, { height = 10 } = {}) {
  const rng = new RNG(seed);
  const g = new Geometry();
  const trunk = Geometry.cylinder(height * 0.02, height * 0.045, height * 0.35, 6, 1, { capTop: false, capBottom: false });
  trunk.translate(0, -0.3, 0);
  trunk.setColor(C('#2a2630'), 0.7);
  g.append(trunk);
  const layers = 5;
  for (let i = 0; i < layers; i++) {
    const t = i / layers;
    const y0 = height * (0.18 + t * 0.62);
    const r = height * 0.28 * (1 - t * 0.75);
    const cone = Geometry.lathe([[r, y0], [r * 0.92, y0 + height * 0.04], [r * 0.3, y0 + height * 0.2], [0, y0 + height * 0.26]], 9, { capBottom: true });
    cone.deform((p) => {
      const a = Math.atan2(p[2], p[0]);
      const k = 1 + Math.sin(a * 5 + i * 2 + seed) * 0.12;
      return [p[0] * k, p[1] - (Math.hypot(p[0], p[2]) / r) * height * 0.03, p[2] * k];
    });
    cone.computeNormals();
    const c = mix3(C('#15283a'), C('#24485a'), rng.next() * 0.6 + t * 0.4);
    cone.setColor(c, 0.6 + t * 0.4);
    g.append(cone);
  }
  g.windByHeight(height * 0.3, height, 2);
  g.paintExtra((p, n, i, e) => [null, e[1] * 0.3]);
  return g;
}

// ------------------------------------------------------------------ palm (silhouettes near the pyramid)
export function palm(seed = 1, { height = 9 } = {}) {
  const rng = new RNG(seed);
  const lean = rng.range(0.1, 0.35);
  const ang = rng.range(0, TAU);
  const pts = [];
  for (let i = 0; i <= 10; i++) {
    const t = i / 10;
    pts.push([Math.cos(ang) * lean * t * t * height, t * height, Math.sin(ang) * lean * t * t * height]);
  }
  const trunk = Geometry.tube(pts, (t) => 0.22 * (1 - t * 0.4) * (1 + 0.12 * Math.abs(Math.sin(t * 40))), 8);
  trunk.setColor(C('#3a3444'), 0.8);
  trunk.windByHeight(height * 0.4, height, 2);
  trunk.paintExtra((p, n, i, e) => [null, e[1] * 0.3]);
  const top = pts[pts.length - 1];
  const fronds = new Geometry();
  const nf = rng.int(7, 9);
  for (let i = 0; i < nf; i++) {
    const a = (i / nf) * TAU + rng.range(-0.2, 0.2);
    const len = rng.range(3.0, 4.4);
    const segs = 8;
    const w = 0.9;
    const dir = [Math.cos(a), 0, Math.sin(a)];
    const side = [-Math.sin(a), 0, Math.cos(a)];
    const base = fronds.vertexCount;
    for (let k = 0; k <= segs; k++) {
      const t = k / segs;
      const x = top[0] + dir[0] * t * len, z = top[2] + dir[2] * t * len;
      const y = top[1] + Math.sin(t * Math.PI * 0.6) * 0.9 - t * t * 2.2;
      for (const s of [-1, 1]) {
        fronds.color = C('#2b4a5a');
        fronds.extra = [0, 0.4 + t * 0.6, 0, rng.next()];
        fronds.vert(x + side[0] * s * w * 0.5, y, z + side[2] * s * w * 0.5, 0, 1, 0, t, s < 0 ? 0 : 1);
      }
    }
    for (let k = 0; k < segs; k++) {
      const a0 = base + k * 2;
      fronds.quad(a0, a0 + 1, a0 + 3, a0 + 2);
    }
  }
  fronds.computeNormals();
  return { trunk, fronds };
}

// ------------------------------------------------------------------ rocks
export function rock(seed = 1, { flat = 0.6, rough = 1, detail = 3 } = {}) {
  const g = Geometry.icosphere(1, detail);
  g.deform((p) => {
    const n = noise.fbm3(p[0] * 1.3 + seed, p[1] * 1.3, p[2] * 1.3, 4) * 0.35 * rough;
    const s = 1 + n;
    return [p[0] * s, p[1] * s * flat, p[2] * s];
  });
  // flatten the bottom
  g.deform((p) => [p[0], Math.max(p[1], -0.25 * flat), p[2]]);
  g.computeNormals();
  g.paint((p, n) => {
    const m = noise.n3(p[0] * 2 + seed, p[1] * 2, p[2] * 2) * 0.5 + 0.5;
    let c = mix3(C('#343a52'), C('#6c7596'), m);
    c = mix3(c, C('#1e4b48'), smoothstep(0.45, 0.85, n[1]) * 0.75);
    return c.concat([smoothstep(-0.3, 0.4, p[1]) * 0.5 + 0.5]);
  });
  return g;
}

// ------------------------------------------------------------------ ferns (undergrowth)
export function fern(seed = 1) {
  const rng = new RNG(seed);
  const g = new Geometry();
  const n = rng.int(6, 9);
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + rng.range(-0.3, 0.3);
    const len = rng.range(0.7, 1.2);
    const segs = 6;
    const dir = [Math.cos(a), 0, Math.sin(a)], side = [-Math.sin(a), 0, Math.cos(a)];
    const base = g.vertexCount;
    const rise = rng.range(0.4, 0.7);
    for (let k = 0; k <= segs; k++) {
      const t = k / segs;
      const d = t * len;
      const y = Math.sin(t * Math.PI * 0.7) * rise - t * t * 0.3;
      const w = 0.28 * Math.sin(t * Math.PI * 0.95 + 0.1) + 0.02;
      for (const s of [-1, 1]) {
        g.color = mix3(C('#1d4050'), C('#3a7078'), t);
        g.extra = [0, t, 0, rng.next()];
        g.vert(dir[0] * d + side[0] * s * w, y, dir[2] * d + side[2] * s * w, 0, 1, 0, t, s < 0 ? 0 : 1);
      }
    }
    for (let k = 0; k < segs; k++) {
      const a0 = base + k * 2;
      g.quad(a0, a0 + 1, a0 + 3, a0 + 2);
    }
  }
  g.computeNormals();
  return g;
}

// ------------------------------------------------------------------ flowers (moon garden)
export function flower(seed = 1, color = '#e0302a') {
  const rng = new RNG(seed);
  const g = new Geometry();
  const h = rng.range(0.25, 0.55);
  const stem = Geometry.cylinder(0.008, 0.012, h, 4, 3, { capTop: false, capBottom: false });
  stem.deform((p) => [p[0] + Math.sin(p[1] * 4 + seed) * 0.03, p[1], p[2]]);
  stem.setColor(C('#244a3c'), 0.8);
  stem.windByHeight(0, h, 1.5);
  g.append(stem);
  const petals = rng.int(5, 7);
  const pr = rng.range(0.05, 0.08);
  const top = [Math.sin(h * 4 + seed) * 0.03, h, 0];
  for (let i = 0; i < petals; i++) {
    const a = (i / petals) * TAU;
    const pg = new Geometry();
    pg.color = C(color);
    pg.extra = [0.15, 1, 0, 0];
    const c0 = pg.vert(0, 0, 0, 0, 1, 0);
    const c1 = pg.vert(Math.cos(a - 0.35) * pr * 0.7, 0.01, Math.sin(a - 0.35) * pr * 0.7, 0, 1, 0);
    const c2 = pg.vert(Math.cos(a) * pr, 0.03, Math.sin(a) * pr, 0, 1, 0);
    const c3 = pg.vert(Math.cos(a + 0.35) * pr * 0.7, 0.01, Math.sin(a + 0.35) * pr * 0.7, 0, 1, 0);
    pg.tri(c0, c2, c1);
    pg.tri(c0, c3, c2);
    pg.translate(top[0], top[1], top[2]);
    g.append(pg);
  }
  const center = Geometry.sphere(pr * 0.3, 6, 4);
  center.translate(top[0], top[1] + 0.01, top[2]);
  center.setColor(C('#ffd35a'), 1);
  center.setExtra([0.6, 1, 0, 0]);
  g.append(center);
  return g;
}

// ------------------------------------------------------------------ fallen log
export function log(seed = 1, { length = 7, radius = 0.55 } = {}) {
  const pts = [];
  for (let i = 0; i <= 8; i++) {
    const t = i / 8;
    pts.push([(t - 0.5) * length, radius * 0.8 + Math.sin(t * 3 + seed) * 0.08, Math.sin(t * 2.3 + seed) * 0.3]);
  }
  const g = Geometry.tube(pts, (t) => radius * (1 - t * 0.2) * (1 + 0.15 * Math.sin(t * 20)), 12, { capEnd: true, capStart: true });
  g.displace((p) => noise.n3(p[0] * 1.5 + seed, p[1] * 3, p[2] * 3) * 0.06, true);
  g.paint((p, n) => {
    let c = mix3(C('#2b2833'), C('#4f4c60'), noise.n3(p[0] * 0.8, p[1], p[2]) * 0.5 + 0.5);
    c = mix3(c, C('#1e4a44'), smoothstep(0.2, 0.9, n[1]) * 0.8);
    return c.concat([0.8]);
  });
  return g;
}
