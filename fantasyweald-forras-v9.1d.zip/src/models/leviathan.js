// (v9) A Mélység Lámpása — the Lantern of the Deep: one enormous deep-sea beast in the dream sea. An eel's
// body (v9.1: the game shows it at LEV_SCALE, some two hundred and fifty metres long), a blind anglerfish head with an underbite full of glassy needle teeth, rows
// of glowing photophores along its flanks, ragged veil fins, and the lantern: a glowing bulb on a long stalk
// that you see under the water long before you see the rest of it.
// The body is a chain of segments (each a tapered tube with a ball joint, so it can bend without gaps); the
// game places every segment along the path the head swam, so the whole length follows the head like a snake.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, lerp, smoothstep, clamp, vnorm, vcross, vlen, mat4, TAU } from '../engine/math.js';
import { ATTR } from '../engine/gl.js';
import { MAX_BONES } from '../engine/shaders/standard.js';
import { C } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const mesh = (ctx, g, mat, name = '') => new Mesh(new GpuGeometry(ctx.gl, g), mat, name);
function egg(rx, ry, rz, ws = 12, hs = 8) {
  const g = Geometry.sphere(1, ws, hs);
  g.scale(rx, ry, rz);
  return g;
}
function bone(name, parent, x = 0, y = 0, z = 0) {
  const n = new Node(name);
  n.setPos(x, y, z);
  parent.add(n);
  return n;
}
function alignMatrix(dir, pos = null) {
  const d = vnorm(dir);
  const m = mat4.create();
  let ax = vcross([0, 1, 0], d);
  const s = vlen(ax), c = d[1];
  if (s < 1e-6) {
    if (c < 0) { m[5] = -1; m[10] = -1; }
  } else {
    ax = [ax[0] / s, ax[1] / s, ax[2] / s];
    const t = 1 - c, [x, y, z] = ax;
    m[0] = t * x * x + c; m[1] = t * x * y + s * z; m[2] = t * x * z - s * y;
    m[4] = t * x * y - s * z; m[5] = t * y * y + c; m[6] = t * y * z + s * x;
    m[8] = t * x * z + s * y; m[9] = t * y * z - s * x; m[10] = t * z * z + c;
  }
  if (pos) { m[12] = pos[0]; m[13] = pos[1]; m[14] = pos[2]; }
  return m;
}

export const LEV_SEGS = 22;
export const LEV_SCALE = 4;              // (v9.1) the model is built at 1/4 size, the game scales every part up
export const LEV_SEG = 2.7;
// body radius along its length (0 = neck, 1 = tail tip)
export const levRadius = (s) => (s < 0.16 ? lerp(4.4, 5.1, smoothstep(0, 0.16, s)) : 5.1 * Math.pow(1 - smoothstep(0.16, 1.0, s), 0.9) + 0.45);

const SKIN_TOP = C('#04060d'), SKIN_SIDE = C('#0d1726'), SKIN_BELLY = C('#27303f');
const skinCol = (n, p, k = 0) => {
  const up = n[1];
  let c = up > 0 ? mix3(SKIN_SIDE, SKIN_TOP, smoothstep(0.0, 0.7, up)) : mix3(SKIN_SIDE, SKIN_BELLY, smoothstep(0.0, -0.8, up));
  // pale mottling, like old scars
  const m = noise.n3(p[0] * 0.5 + k, p[1] * 0.5, p[2] * 0.5);
  c = mix3(c, SKIN_BELLY, smoothstep(0.35, 0.75, m) * 0.35);
  return c.concat([0.85]);
};

export function leviathanMaterials(M) {
  if (!M.levSkin) {
    M.levSkin = new Material({ defines: { SCALES: 1 }, uniforms: { uScales: [4.2, 0.12, 0.028, 0.4], uEmberColor: C('#36d4ff', 0.9), uEmber: 0, uRough: 0.32, uDetail: [2.6, 0.14, 0.3, 5], uGlitter: [0, 0, 0], uRim: 0.55, uWrap: 0.3, uFill: 0.18, uFogScale: 0.75, uGlowStrength: 1.1 } });
    M.levFin = new Material({ cull: 'none', uniforms: { uRough: 0.5, uDetail: [5.0, 0.2, 0.25, 4], uGlitter: [0, 0, 0], uRim: 0.7, uWrap: 0.6, uFill: 0.2, uFogScale: 0.75, uGlowStrength: 1.2 } });
    M.levTeeth = new Material({ uniforms: { uRough: 0.18, uGlowStrength: 0.8, uRim: 0.9, uWrap: 0.3, uFill: 0.35, uGlitter: [12, 0.1, 0.6], uFogScale: 0.75 } });
  }
  return M;
}

// a ragged fin: a sheet between a base line and a crest, glowing dots along the crest; `rays` adds bony
// spines running through the membrane (every other step), so it reads as a real fin up close
function finSheet(base, crest, n, rng, glowCol, rays = 0) {
  const g = new Geometry();
  const ids = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const b = base(t), c = crest(t);
    const rag = 1 - Math.max(0, Math.sin(t * 37 + 1.3)) * 0.18 - noise.n3(t * 9, 3.1, 0.7) * 0.12;
    const cc = [lerp(b[0], c[0], rag), lerp(b[1], c[1], rag), lerp(b[2], c[2], rag)];
    const k0 = g.vert(b[0], b[1], b[2], 0, 0, 1);
    const km = g.vert(lerp(b[0], cc[0], 0.55), lerp(b[1], cc[1], 0.55), lerp(b[2], cc[2], 0.55), 0, 0, 1);
    const k1 = g.vert(cc[0], cc[1], cc[2], 0, 0, 1);
    for (const [k, v] of [[k0, 0], [km, 0.55], [k1, 1]]) {
      const col = mix3(C('#060a14'), C('#1c3350'), v);
      g.c[k * 4] = col[0]; g.c[k * 4 + 1] = col[1]; g.c[k * 4 + 2] = col[2]; g.c[k * 4 + 3] = 0.9;
    }
    if (i % 3 === 0) {
      const col = glowCol;
      g.c[k1 * 4] = col[0]; g.c[k1 * 4 + 1] = col[1]; g.c[k1 * 4 + 2] = col[2];
      g.e[k1 * 4] = 1.6;
    }
    ids.push([k0, km, k1]);
  }
  for (let i = 0; i < n; i++) {
    const a = ids[i], b = ids[i + 1];
    g.quad(a[0], b[0], b[1], a[1]);
    g.quad(a[1], b[1], b[2], a[2]);
  }
  g.computeNormals();
  if (rays > 0) {
    for (let i = 1; i < n; i += 2) {
      const k0 = ids[i][0], k1 = ids[i][2];
      const b0 = [g.p[k0 * 3], g.p[k0 * 3 + 1], g.p[k0 * 3 + 2]], c1 = [g.p[k1 * 3], g.p[k1 * 3 + 1], g.p[k1 * 3 + 2]];
      const ray = Geometry.tube([b0, [lerp(b0[0], c1[0], 0.5), lerp(b0[1], c1[1], 0.5), lerp(b0[2], c1[2], 0.5)], c1], [rays, rays * 0.7, rays * 0.3], 5, { capStart: false, capEnd: true });
      ray.paint((p) => mix3(C('#0b1322'), C('#3a5470'), smoothstep(0, 1, Math.hypot(p[0] - b0[0], p[1] - b0[1], p[2] - b0[2]) / (Math.hypot(c1[0] - b0[0], c1[1] - b0[1], c1[2] - b0[2]) || 1))).concat([0.9]));
      g.append(ray);
    }
  }
  return g;
}

// ------------------------------------------------------------------ (v9.1b) one continuous, smoothly bending skin
// Every vertex of the body is bound to the chain by how far along it lies: between two joints it blends the
// two neighbouring segments, so the whole length bends like one soft body instead of a string of sausages.
const LEN = LEV_SEGS * LEV_SEG;
function boneCoord(s) {
  if (s >= LEV_SEGS) return LEV_SEGS; // the tail fan follows the tail bone
  const b = Math.floor(s), w = s - b;
  if (w >= 0.5) return b + (w - 0.5);
  if (b === 0) return 0;
  return b - 1 + (0.5 + w);
}
function chainSkin(ctx, geo, material, name, bones) {
  const gl = ctx.gl;
  const nv = geo.vertexCount;
  const P = new Float32Array(geo.p), N = new Float32Array(geo.n), UV = new Float32Array(geo.uv);
  const COL = new Float32Array(geo.c), EX = new Float32Array(geo.e), BONE = new Float32Array(nv);
  for (let i = 0; i < nv; i++) BONE[i] = boneCoord(Math.max(0, -P[i * 3 + 2] / LEV_SEG));
  const big = nv > 65535;
  const IDX = big ? new Uint32Array(geo.idx) : new Uint16Array(geo.idx);
  const mk = (data, target = gl.ARRAY_BUFFER) => {
    const bf = gl.createBuffer();
    gl.bindBuffer(target, bf);
    gl.bufferData(target, data, gl.STATIC_DRAW);
    return bf;
  };
  const buffers = { p: mk(P), n: mk(N), uv: mk(UV), c: mk(COL), e: mk(EX), b: mk(BONE) };
  const vao = gl.createVertexArray();
  gl.bindVertexArray(vao);
  const bind = (buf, loc, size) => { gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0); };
  bind(buffers.p, ATTR.aPosition, 3); bind(buffers.n, ATTR.aNormal, 3); bind(buffers.uv, ATTR.aUv, 2);
  bind(buffers.c, ATTR.aColor, 4); bind(buffers.e, ATTR.aExtra, 4); bind(buffers.b, ATTR.aIData, 1);
  buffers.idx = mk(IDX, gl.ELEMENT_ARRAY_BUFFER);
  gl.bindVertexArray(null);
  const gpu = { gl, vertexCount: nv, count: IDX.length, bounds: { center: [0, 0, -LEN / 2], radius: LEN }, buffers, indexType: big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT, vao, cpu: null };
  const mesh = new Mesh(gpu, material, name);
  mesh.skinned = true;
  mesh.frustumCulled = false;
  mesh.castShadow = false;
  const inv = bones.map((_, i) => { const m = mat4.create(); m[14] = i * LEV_SEG; return m; });
  const mats = new Float32Array(MAX_BONES * 16), tmp = mat4.create();
  mesh.onBeforeDraw = (prog) => {
    for (let i = 0; i < bones.length; i++) { mat4.multiply(tmp, bones[i].world, inv[i]); mats.set(tmp, i * 16); }
    prog.set('uBones', mats);
  };
  return mesh;
}
// the body's cross-section at z (model space, the neck at 0, the tail at -LEN), angle th (0 = +x, PI/2 = top)
function bodyR(z) { return levRadius(clamp(-z / LEN, 0, 1)); }
function bodyAt(z, th, out = [0, 0, 0]) {
  const R = bodyR(z);
  const band = 1 + 0.016 * Math.pow(Math.sin((z * TAU) / 1.4), 2); // myomeres: faint muscle bands
  let dTop = th - Math.PI / 2; dTop = Math.atan2(Math.sin(dTop), Math.cos(dTop));
  let dBot = th + Math.PI / 2; dBot = Math.atan2(Math.sin(dBot), Math.cos(dBot));
  out[0] = R * 0.93 * Math.cos(th) * band;
  out[1] = R * 1.04 * Math.sin(th) * band + R * 0.1 * Math.exp(-((dTop / 0.2) ** 2)) - R * 0.04 * Math.exp(-((dBot / 0.3) ** 2));
  out[2] = z;
  return out;
}
function skinPaint(p, n, k) {
  const up = n[1];
  let c = up > 0 ? mix3(SKIN_SIDE, SKIN_TOP, smoothstep(0.0, 0.7, up)) : mix3(SKIN_SIDE, SKIN_BELLY, smoothstep(0.0, -0.8, up));
  const m = noise.n3(p[0] * 0.5 + k, p[1] * 0.5, p[2] * 0.5);
  c = mix3(c, SKIN_BELLY, smoothstep(0.35, 0.75, m) * 0.35);
  // long pale scars
  const sc = Math.pow(1 - Math.abs(noise.n3(p[0] * 0.25 + 7, p[1] * 0.9, p[2] * 0.12)), 18);
  c = mix3(c, C('#5a6878'), sc * 0.5 * smoothstep(-0.3, 0.3, up));
  return c;
}

export function buildLeviathan(ctx, seed = 11) {
  const M = leviathanMaterials(ctx.M);
  const rng = new RNG(seed);
  const root = new Node('leviathan');
  const segs = [];
  const PH_A = C('#7ff4ff'), PH_B = C('#b58cff');
  // ---------------------------------------------------------------- the chain (bones only; the game places them)
  for (let i = 0; i < LEV_SEGS; i++) segs.push(bone('seg' + i, root, 0, 0, -i * LEV_SEG));
  const tail = bone('tail', root, 0, 0, -LEN);
  const chain = segs.concat([tail]);
  // ---------------------------------------------------------------- the body: one smooth tube
  const body = new Geometry();
  {
    const RAD = 60, z0 = 1.2, z1 = -LEN - 0.25, rings = 150;
    const ids = [];
    const q = [0, 0, 0];
    for (let r = 0; r <= rings; r++) {
      const z = lerp(z0, z1, r / rings);
      const row = [];
      for (let k = 0; k < RAD; k++) {
        const th = (k / RAD) * TAU;
        bodyAt(z, th, q);
        const R = bodyR(z);
        const nz = noise.n3(q[0] * 0.55, q[1] * 0.55, z * 0.55) * 0.035 * R;
        const l = Math.hypot(q[0], q[1]) || 1;
        row.push(body.vert(q[0] + (q[0] / l) * nz, q[1] + (q[1] / l) * nz, z));
      }
      ids.push(row);
    }
    for (let r = 0; r < rings; r++) for (let k = 0; k < RAD; k++) {
      const a = ids[r][k], b = ids[r][(k + 1) % RAD], c = ids[r + 1][(k + 1) % RAD], d = ids[r + 1][k];
      body.tri(a, c, b); body.tri(a, d, c);
    }
    const tip = body.vert(0, 0, z1 - 0.35);
    for (let k = 0; k < RAD; k++) body.tri(ids[rings][k], tip, ids[rings][(k + 1) % RAD]);
    body.computeNormals();
    // make sure the faces point outwards
    const top = ids[70][RAD / 4];
    if (body.n[top * 3 + 1] < 0) { for (let i = 0; i < body.idx.length; i += 3) { const t = body.idx[i + 1]; body.idx[i + 1] = body.idx[i + 2]; body.idx[i + 2] = t; } body.computeNormals(); }
    body.paint((p, n) => {
      const c = skinPaint(p, n, 0);
      // the lateral line: a thin pale groove along each flank
      const ll = Math.exp(-(((n[1] + 0.02) / 0.035) ** 2));
      return mix3(c, C('#44607a'), ll * 0.6).concat([0.9 - ll * 0.25]);
    });
    // glow in the scale creases on the belly and low on the flanks (SCALES shader, ember channel)
    body.paintExtra((p, n) => [0, 0, smoothstep(-0.15, -0.75, n[1]) * 0.9]);
  }
  // barnacle crusts on the upper flanks
  for (let i = 0; i < 26; i++) {
    const z = -rng.range(3, LEN * 0.8), side = rng.sign(), th0 = rng.range(0.35, 1.05) * side + (side < 0 ? Math.PI : 0);
    const nb = rng.int(4, 10);
    for (let k = 0; k < nb; k++) {
      const th = th0 + rng.range(-0.12, 0.12), zz = z + rng.range(-0.9, 0.9);
      const p = bodyAt(zz, th), R = bodyR(zz);
      const nrm = vnorm([p[0], p[1] - R * 0.02, 0]);
      const br = rng.range(0.1, 0.26);
      const bn = Geometry.cylinder(br * 0.4, br, br * 0.85, 8, 1, { capBottom: false });
      bn.applyMatrix(alignMatrix(nrm, [p[0] - nrm[0] * 0.05, p[1] - nrm[1] * 0.05, zz]));
      const bc = rng.next() * 0.5;
      bn.paint(() => mix3(C('#4a5560'), C('#a4b0b4'), bc).concat([0.8]));
      body.append(bn);
    }
  }
  root.add(chainSkin(ctx, body, M.levSkin, 'levBody', chain));
  // ---------------------------------------------------------------- lights: two rows along each flank, a few on the belly
  const lights = new Geometry();
  const light = (z, th, size, col, glow) => {
    const p = bodyAt(z, th);
    const nrm = vnorm([p[0], p[1], 0]);
    const d = egg(size, size * 0.42, size, 10, 6);
    d.paint((q) => mix3(col, [1, 1, 1], (1 - smoothstep(0, size * 0.6, Math.hypot(q[0], q[2]))) * 0.6).concat([1]));
    d.applyMatrix(alignMatrix(nrm, [p[0] + nrm[0] * 0.02, p[1] + nrm[1] * 0.02, z]));
    d.setExtra([glow]);
    lights.append(d);
    const rim = Geometry.torus(size * 1.12, size * 0.2, 6, 14);
    rim.applyMatrix(alignMatrix(nrm, [p[0], p[1], z]));
    rim.setColor(C('#020409'), 0.8);
    rim.setExtra([0]);
    lights.append(rim);
  };
  for (let z = -1.2, i = 0; z > -LEN * 0.88; z -= 1.15, i++) {
    const sz = 0.2 * (bodyR(z) / 5 + 0.45);
    for (const side of [1, -1]) {
      const base = side > 0 ? 0 : Math.PI;
      light(z, base - side * 0.3, sz, PH_A, 3.0);
      light(z - 0.55, base - side * 0.92, sz * 0.85, i % 2 ? PH_B : PH_A, 2.6);
    }
    if (i % 3 === 0) light(z - 0.3, -Math.PI / 2 + rng.range(-0.35, 0.35), sz * 0.6, PH_B, 2.2);
  }
  root.add(chainSkin(ctx, lights, M.glowSoft, 'levLights', chain));
  // ---------------------------------------------------------------- fins: the dorsal veil, the belly fin, the tail fan
  const finG = new Geometry();
  const veil = (s0, s1, sign, hFn, lean, glowCol, cols) => {
    // a continuous ragged membrane along the ridge (sign 1) or the keel (sign -1), with bony rays
    const ids = [];
    const g = new Geometry();
    const tears = [];
    for (let k = 0; k < Math.round(cols / 40); k++) tears.push(rng.range(0.08, 0.92));
    for (let i = 0; i <= cols; i++) {
      const s = lerp(s0, s1, i / cols), z = -s * LEN;
      const p = bodyAt(z, sign * Math.PI / 2);
      const baseY = p[1] - sign * 0.12;
      // a soft, uneven crest with a few old tears in it (no saw teeth)
      const u = i / cols;
      let tear = 0;
      for (const tc of tears) tear = Math.max(tear, Math.exp(-(((u - tc) / 0.011) ** 2)));
      const rag = 1 - (noise.n3(u * 7 + sign * 3, s0 * 9, 1.3) * 0.5 + 0.5) * 0.22 - tear * 0.45;
      const h = hFn((s - s0) / (s1 - s0)) * rag;
      const row = [];
      for (let j = 0; j <= 3; j++) {
        const t = j / 3;
        const k = g.vert(0, baseY + sign * h * t, z - lean * h * t * t);
        const col = mix3(C('#060a16'), C('#2a4a70'), t * t);
        g.c[k * 4] = col[0]; g.c[k * 4 + 1] = col[1]; g.c[k * 4 + 2] = col[2]; g.c[k * 4 + 3] = 0.9;
        if (j === 3) { const gl = i % 6 === 0 ? 1.6 : 0.35; g.c[k * 4] = lerp(col[0], glowCol[0], gl / 1.6); g.c[k * 4 + 1] = lerp(col[1], glowCol[1], gl / 1.6); g.c[k * 4 + 2] = lerp(col[2], glowCol[2], gl / 1.6); g.e[k * 4] = gl; }
        row.push(k);
      }
      ids.push(row);
      if (i % 3 === 0 && h > 0.3) {
        const b0 = [0, baseY, z], b1 = [0, baseY + sign * h * 0.98, z - lean * h * 0.96];
        const ray = Geometry.tube([b0, [0, lerp(b0[1], b1[1], 0.5), lerp(b0[2], b1[2], 0.35)], b1], [0.05, 0.035, 0.01], 5, { capStart: false, capEnd: true });
        ray.paint((q) => mix3(C('#0b1322'), C('#4a6a8a'), clamp(Math.abs(q[1] - baseY) / (h || 1), 0, 1)).concat([0.9]));
        g.append(ray);
      }
    }
    for (let i = 0; i < cols; i++) for (let j = 0; j < 3; j++) g.quad(ids[i][j], ids[i + 1][j], ids[i + 1][j + 1], ids[i][j + 1]);
    g.computeNormals();
    finG.append(g);
  };
  veil(0.035, 0.82, 1, (t) => (1.0 + 2.1 * Math.sin(Math.PI * t)) * (0.6 + 0.4 * Math.min(1, t * 6)), 0.55, PH_A, 240);
  veil(0.5, 0.9, -1, (t) => 0.4 + 1.1 * Math.sin(Math.PI * t), 0.45, PH_B, 60);
  // the tail fan: long ragged lobes above and below, following the tail bone
  {
    const tr = levRadius(1);
    for (const sy of [-1, 1]) {
      const g = new Geometry();
      const ids = [];
      const cols = 26;
      for (let i = 0; i <= cols; i++) {
        const t = i / cols, z = -LEN + 0.6 - t * 8.2;
        const rag = 1 - Math.max(0, Math.sin(i * 2.3)) * 0.15 - Math.max(0, noise.n3(i * 0.4, sy * 2, 1)) * 0.25;
        const h = (tr * 0.4 + 3.4 * Math.sin(Math.PI * Math.min(1, t * 1.08)) + 0.3) * rag;
        const row = [];
        for (let j = 0; j <= 3; j++) {
          const u = j / 3;
          const k = g.vert(0, sy * (tr * 0.35 * (1 - t) + (h - tr * 0.35 * (1 - t)) * u), z - u * u * 1.2);
          const col = mix3(C('#050912'), C('#26405e'), u);
          g.c[k * 4] = col[0]; g.c[k * 4 + 1] = col[1]; g.c[k * 4 + 2] = col[2]; g.c[k * 4 + 3] = 0.9;
          if (j === 3 && i % 4 === 0) { g.c[k * 4] = PH_B[0]; g.c[k * 4 + 1] = PH_B[1]; g.c[k * 4 + 2] = PH_B[2]; g.e[k * 4] = 1.8; }
          row.push(k);
        }
        ids.push(row);
        if (i % 2 === 0) {
          const b0 = [0, sy * tr * 0.35 * (1 - t), z], b1 = [0, sy * h * 0.97, z - 1.1];
          const ray = Geometry.tube([b0, [0, lerp(b0[1], b1[1], 0.5), z - 0.3], b1], [0.06, 0.045, 0.012], 5, { capStart: false, capEnd: true });
          ray.paint((q) => mix3(C('#0b1322'), C('#4a6a8a'), clamp(Math.abs(q[1]) / (h || 1), 0, 1)).concat([0.9]));
          g.append(ray);
        }
      }
      for (let i = 0; i < cols; i++) for (let j = 0; j < 3; j++) g.quad(ids[i][j], ids[i + 1][j], ids[i + 1][j + 1], ids[i][j + 1]);
      g.computeNormals();
      finG.append(g);
    }
  }
  root.add(chainSkin(ctx, finG, M.levFin, 'levFins', chain));
  // ---------------------------------------------------------------- the head
  const head = bone('head', root, 0, 0, 0);
  const cr = egg(4.3, 3.7, 5.8, 56, 38);
  cr.deform((p) => {
    // a flat palate where the lower jaw closes, a heavy brow ridge
    const front = smoothstep(-1, 3, p[2]);
    let y = p[1];
    if (y < -0.6) y = lerp(y, -0.6 - (y + 0.6) * 0.25, front);
    const brow = Math.exp(-(((p[2] - 2.2) / 1.6) ** 2)) * smoothstep(1.5, 3.2, Math.abs(p[0])) * 0.5;
    return [p[0] * (1 + brow * 0.1), y + brow * 0.6, p[2]];
  });
  cr.translate(0, 0.6, 4.4);
  cr.computeNormals();
  cr.displace((p) => noise.fbm3(p[0] * 0.35 + 5, p[1] * 0.35, p[2] * 0.35, 3) * 0.3, true);
  cr.paint((p, n) => {
    const c = skinCol(n, p, 3);
    // the roof of the mouth
    if (n[1] < -0.6 && p[2] > 2.5 && p[1] < 0.2) return mix3(C('#2a0610'), C('#4a0c18'), noise.n3(p[0], p[2], 1) * 0.5 + 0.5).concat([0.7]);
    return c;
  });
  // gill slits on the neck
  for (const s of [-1, 1]) {
    for (let k = 0; k < 6; k++) {
      const gs = egg(0.2, 1.9 - k * 0.12, 0.42, 10, 8);
      gs.rotateZ(s * 0.25);
      gs.translate(s * 4.12, -0.25, 1.2 - k * 0.72);
      gs.setColor(C('#020306'), 1);
      cr.append(gs);
    }
  }
  // heavy brow ridges and a crown of backward spines
  for (const s of [-1, 1]) {
    const br = egg(1.3, 0.62, 2.6, 18, 12);
    br.rotateY(s * -0.18);
    br.translate(s * 2.55, 2.75, 5.9);
    br.paint((p, n) => skinCol(n, p, 5));
    cr.append(br);
  }
  for (let k = 0; k < 6; k++) {
    const len = lerp(2.4, 1.1, k / 5);
    const sp = Geometry.cylinder(0.02, 0.42 - k * 0.04, len, 8, 2, { capBottom: false });
    sp.deform((p) => [p[0], p[1], p[2] - (p[1] / len) ** 2 * len * 0.35]);
    sp.applyMatrix(alignMatrix([0, 1, -0.9], [0, 3.95 - k * 0.12, 3.4 - k * 0.95]));
    sp.paint((p, n) => mix3(C('#0a1220'), C('#58708a'), smoothstep(0.3, 1.0, n[1]) * 0.5).concat([0.9]));
    cr.append(sp);
  }
  // nostril pits on the snout
  for (const s of [-1, 1]) {
    const ns = egg(0.28, 0.12, 0.45, 10, 6);
    ns.rotateX(-0.35);
    ns.translate(s * 0.85, 2.72, 9.05);
    ns.setColor(C('#020306'), 0.6);
    cr.append(ns);
  }
  cr.paintExtra((p, n) => [0, 0.7, smoothstep(-0.2, -0.8, n[1]) * 0.7]);
  head.add(mesh(ctx, cr, M.levSkin, 'levHead'));
  // frilled gill-fins behind the jaw hinge, like a frilled shark's
  const frills = new Geometry();
  for (const s of [-1, 1]) {
    frills.append(finSheet(
      (t) => [s * 4.05, lerp(1.6, -2.2, t), lerp(0.9, 0.2, t)],
      (t) => [s * (4.05 + 2.4 * Math.sin(Math.PI * (0.15 + t * 0.8))), lerp(2.0, -2.8, t), lerp(-1.6, -2.0, t)],
      12, rng, PH_B, 0.06,
    ));
  }
  head.add(mesh(ctx, frills, M.levFin, 'levFrills'));
  // eyes: milky and blind-looking, two on each side
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    for (const [x, y, z, r] of [[3.3, 1.7, 7.0, 0.5], [2.9, 2.5, 5.6, 0.32], [3.35, 2.1, 4.6, 0.18], [3.55, 1.6, 3.9, 0.14], [3.6, 1.1, 3.3, 0.11]]) {
      const e = egg(r, r, r * 0.7, 12, 9);
      e.rotateY(s * 1.2);
      e.translate(s * x, y, z);
      e.setColor(C('#cfe8ff'), 1);
      e.setExtra([1.7]);
      eyes.append(e);
      const ring = Geometry.torus(r * 1.05, r * 0.18, 6, 14);
      ring.rotateY(s * 1.2 + Math.PI / 2);
      ring.translate(s * (x - 0.05), y, z);
      ring.setColor(C('#05070d'), 0.8);
      eyes.append(ring);
    }
  }
  // light organs: a long glowing lamp under each big eye, a row of small lights along the lip
  for (const s of [-1, 1]) {
    const so = egg(0.95, 0.3, 0.5, 14, 8);
    so.rotateZ(Math.PI / 2);
    so.rotateY(s * 1.25);
    so.translate(s * 3.55, 0.95, 5.95);
    so.setColor(PH_A, 1);
    so.setExtra([2.4]);
    eyes.append(so);
    for (let k = 0; k < 9; k++) {
      const th = lerp(0.35, 1.25, k / 8);
      const x = Math.cos(th) * 3.95, z = 4.4 + Math.sin(th) * 5.25;
      const d = egg(0.12, 0.12, 0.12, 6, 4);
      d.translate(s * x, -0.05, z);
      d.setColor(k % 2 ? PH_B : PH_A, 1);
      d.setExtra([2.8]);
      eyes.append(d);
    }
  }
  head.add(mesh(ctx, eyes, M.glowSoft, 'levEyes'));
  // upper teeth: long, glassy, crowded, pointing down and in
  const teeth = new Geometry();
  const tooth = (len, r, base, dir, glow = 0.4) => {
    const t = Geometry.cylinder(0, r, len, 6, 3, { capBottom: false });
    t.deform((p) => [p[0], p[1], p[2] + (p[1] / len) ** 2 * len * 0.12]);
    t.paint((p) => mix3(C('#9fb4c8'), C('#eef6ff'), smoothstep(0, len, p[1])).concat([1]));
    t.paintExtra((p) => [smoothstep(len * 0.6, len, p[1]) * glow]);
    t.applyMatrix(alignMatrix(dir, base));
    return t;
  };
  for (let k = 0; k < 26; k++) {
    const th = lerp(0.1, Math.PI - 0.1, k / 25);
    const x = Math.cos(th) * 3.55, z = 4.6 + Math.sin(th) * 5.0;
    const front = Math.sin(th);
    if (k % 2 && rng.chance(0.35)) continue; // gaps: broken and missing teeth
    const len = lerp(0.9, 2.3, front) * rng.range(0.55, 1.25);
    teeth.append(tooth(len, lerp(0.12, 0.24, front) * rng.range(0.8, 1.2), [x, 0.1, z], [-x * 0.08 + rng.range(-0.25, 0.25), -1, -(z - 4.6) * 0.05 + rng.range(-0.25, 0.25)]));
  }
  for (let k = 0; k < 30; k++) {
    const th = lerp(0.2, Math.PI - 0.2, k / 29);
    const x = Math.cos(th) * 2.9, z = 4.8 + Math.sin(th) * 4.1;
    const len = lerp(0.5, 1.2, Math.sin(th)) * rng.range(0.6, 1.2);
    teeth.append(tooth(len, 0.1 * rng.range(0.8, 1.2), [x, 0.05, z], [-x * 0.15 + rng.range(-0.2, 0.2), -1, -0.35 + rng.range(-0.2, 0.2)], 0.25));
  }
  head.add(mesh(ctx, teeth, M.levTeeth, 'levTeeth'));
  // a dull ember deep in the throat
  const throat = egg(1.6, 1.3, 1.6, 12, 8);
  throat.translate(0, -0.4, 1.8);
  throat.setColor(C('#ff4a20'), 1);
  throat.setExtra([1.2]);
  head.add(mesh(ctx, throat, M.glowSoft, 'levThroat'));
  // the lower jaw: a huge scoop, hinged under the skull, jutting out past it
  const jaw = bone('jaw', head, 0, -0.8, 0.9);
  const jg = egg(4.1, 2.3, 6.4, 48, 30);
  jg.deform((p) => [p[0] * (1 - smoothstep(2, 6.4, p[2]) * 0.25), p[1] > 0 ? p[1] * 0.12 : p[1], p[2]]);
  jg.translate(0, -0.9, 4.3);
  jg.computeNormals();
  jg.displace((p) => noise.fbm3(p[0] * 0.4 + 9, p[1] * 0.4, p[2] * 0.4, 3) * 0.2, true);
  jg.paint((p, n) => (n[1] > 0.5 ? mix3(C('#300812'), C('#5a1020'), noise.n3(p[0] * 0.8, p[2] * 0.8, 2) * 0.5 + 0.5).concat([0.7]) : skinCol(n, p, 7)));
  jg.paintExtra((p, n) => [0, 0.7, smoothstep(-0.2, -0.8, n[1]) * 0.8]);
  jaw.add(mesh(ctx, jg, M.levSkin, 'levJaw'));
  const jt = new Geometry();
  for (let k = 0; k < 22; k++) {
    const th = lerp(0.12, Math.PI - 0.12, k / 21);
    const x = Math.cos(th) * 3.4, z = 4.3 + Math.sin(th) * 5.7;
    const front = Math.sin(th);
    if (k % 2 && rng.chance(0.3)) continue;
    const len = lerp(1.0, 3.0, front * front) * rng.range(0.55, 1.2);
    jt.append(tooth(len, lerp(0.13, 0.28, front) * rng.range(0.8, 1.2), [x, -0.75, z], [-x * 0.1 + rng.range(-0.3, 0.3), 1, (z - 4.3) * 0.08 + rng.range(-0.3, 0.3)]));
  }
  jaw.add(mesh(ctx, jt, M.levTeeth, 'levJawTeeth'));
  // barbels: long feelers hanging from the chin, their tips glowing faintly
  const barb = new Geometry();
  for (let k = 0; k < 7; k++) {
    const x = (k - 3) * 0.75, z0 = 8.2 - Math.abs(k - 3) * 0.55, len = rng.range(3.2, 5.6);
    const pts = [];
    for (let j = 0; j <= 7; j++) {
      const t = j / 7;
      pts.push([x * (1 + t * 0.4) + Math.sin(t * 4 + k) * 0.3 * t, -2.9 - t * len, z0 - Math.sin(t * 2.2) * 1.2 * t + t * 0.6]);
    }
    const b = Geometry.tube(pts, (t) => 0.13 * (1 - t) + 0.035, 6, { capStart: true, capEnd: true });
    b.paint((p) => mix3(C('#0b1424'), C('#6fdcff'), smoothstep(-2.9 - len * 0.6, -2.9 - len, p[1])).concat([0.9]));
    b.paintExtra((p) => [smoothstep(-2.9 - len * 0.7, -2.9 - len, p[1]) * 2.2]);
    barb.append(b);
  }
  jaw.add(mesh(ctx, barb, M.levSkin, 'levBarbels'));
  // pectoral fins: big and ragged, like torn sails
  const fins = [];
  for (const s of [-1, 1]) {
    const f = bone(s < 0 ? 'finR' : 'finL', segs[0], s * 4.2, -1.2, -1.2);
    const fg = finSheet(
      (t) => [s * 0.2, 0, -t * 4.5],
      (t) => [s * (4.8 * Math.sin(Math.PI * Math.min(1, 0.15 + t * 0.95)) + 0.4), -0.8 - t * 1.2, -t * 5.5 - 1.5],
      14, rng, PH_A, 0.08,
    );
    f.add(mesh(ctx, fg, M.levFin, 'levFin'));
    fins.push(f);
  }
  // ---------------------------------------------------------------- the lantern
  const lure = bone('lure', head, 0, 4.0, 5.2);
  const stalk = Geometry.tube(catmullRom([[0, -0.6, -0.4], [0, 2.4, 1.6], [0, 3.6, 4.6], [0, 2.8, 7.3], [0, 1.3, 8.6]], 3), (t) => lerp(0.34, 0.1, t), 8, { capStart: true, capEnd: true });
  stalk.paint((p) => mix3(C('#0a1220'), C('#2a4a66'), smoothstep(0, 9, p[2])).concat([0.9]));
  // little lights along the stalk
  for (let k = 1; k < 6; k++) {
    const t = k / 6;
    const b = egg(0.1, 0.1, 0.1, 6, 4);
    b.translate(0, lerp(0.8, 3.2, Math.sin(t * Math.PI)) + 0.2, t * 8.2);
    b.setColor(PH_A, 1);
    b.setExtra([2.5]);
    stalk.append(b);
  }
  lure.add(mesh(ctx, stalk, M.levSkin, 'levStalk'));
  const tip = bone('lureTip', lure, 0, 1.3, 8.6);
  const bulb = egg(0.7, 0.8, 0.7, 16, 12);
  bulb.translate(0, -0.55, 0);
  bulb.setColor(C('#d8fcff'), 1);
  bulb.setExtra([3.4]);
  // hanging filaments with glowing ends
  for (let k = 0; k < 5; k++) {
    const a = (k / 5) * Math.PI * 2;
    const pts = [[Math.cos(a) * 0.3, -1.1, Math.sin(a) * 0.3], [Math.cos(a) * 0.45, -1.9, Math.sin(a) * 0.45], [Math.cos(a) * 0.4, -2.8 - (k % 2) * 0.6, Math.sin(a) * 0.4]];
    const fl = Geometry.tube(pts, [0.05, 0.035, 0.02], 4);
    fl.setColor(C('#6fdcff'), 1);
    fl.setExtra([1.4]);
    bulb.append(fl);
    const d = egg(0.09, 0.09, 0.09, 6, 4);
    d.translate(pts[2][0], pts[2][1], pts[2][2]);
    d.setColor(C('#e8feff'), 1);
    d.setExtra([4]);
    bulb.append(d);
  }
  tip.add(mesh(ctx, bulb, M.glowSoft, 'levLantern'));
  return { root, head, jaw, lure, tip, segs, tail, fins };
}
