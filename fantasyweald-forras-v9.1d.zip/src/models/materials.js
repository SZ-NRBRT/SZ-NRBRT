// Shared materials. Base colors live in vertex colors; materials carry the surface character.
import { Material } from '../engine/scene.js';
import { hexToLinear } from '../engine/math.js';
import { createTexture } from '../engine/gl.js';

export const C = (hex, mul = 1) => hexToLinear(hex, mul);

// detail types: 1 stone, 2 bark, 3 hair, 4 cloth, 5 moss
export function createMaterials(gl, tex) {
  const M = {};
  M.bark = new Material({ uniforms: { uRough: 0.92, uDetail: [1.3, 0.4, 0.8, 2], uGlitter: [11, 0.06, 0.45], uRim: 0.3 } });
  M.stone = new Material({ uniforms: { uRough: 0.78, uDetail: [0.7, 0.35, 1.0, 1], uGlitter: [9, 0.1, 0.8], uRim: 0.35 } });
  M.stoneFine = new Material({ uniforms: { uRough: 0.7, uDetail: [1.4, 0.25, 0.4, 1], uGlitter: [14, 0.08, 0.7], uRim: 0.4 } });
  M.bigStone = new Material({ uniforms: { uRough: 0.8, uDetail: [0.25, 0.45, 2.2, 1], uGlitter: [4, 0.14, 1.2], uRim: 0.45, uFogScale: 0.55 } });
  M.moss = new Material({ uniforms: { uRough: 0.95, uDetail: [1.6, 0.3, 0.35, 5], uGlitter: [10, 0.08, 0.35], uRim: 0.45, uWrap: 0.5 } });
  // (v9.1) moss for very big shapes (the sleeping giant, floating islands, the watcher): larger, calmer clumps
  M.mossBig = new Material({ uniforms: { uRough: 0.95, uDetail: [0.45, 0.26, 0.3, 5], uGlitter: [10, 0.06, 0.3], uRim: 0.45, uWrap: 0.5 } });
  M.wood = new Material({ uniforms: { uRough: 0.85, uDetail: [3.0, 0.35, 0.7, 2], uGlitter: [12, 0.04, 0.3] } });
  M.cloth = new Material({ uniforms: { uRough: 0.9, uDetail: [4.0, 0.14, 0.1, 4], uGlitter: [30, 0.04, 0.3], uRim: 0.4, uWrap: 0.4, uFill: 1.0 } });
  M.clothDS = new Material({ cull: 'none', uniforms: { uRough: 0.9, uDetail: [9.0, 0.18, 0.25, 4], uRim: 0.55, uWrap: 0.4 } });
  M.farStone = new Material({ uniforms: { uRough: 0.8, uDetail: [0.12, 0.5, 2.0, 1], uGlitter: [2.2, 0.12, 1.4], uRim: 0.6, uFogScale: 0.42, uWrap: 0.3 } });
  M.farGlow = new Material({ uniforms: { uRough: 0.6, uGlowStrength: 1.0, uRim: 0.3, uFogScale: 0.35 } });
  M.planks = new Material({ uniforms: { uRough: 0.85, uDetail: [1.6, 0.25, 0.3, 2], uGlitter: [14, 0.04, 0.3] } });
  M.robe = new Material({ uniforms: { uRough: 0.8, uDetail: [3.0, 0.2, 0.2, 4], uGlitter: [22, 0.28, 2.6], uRim: 0.6, uWrap: 0.4, uFill: 0.8 } });
  M.skin = new Material({ uniforms: { uRough: 0.6, uDetail: [6.0, 0.08, 0.15, 5], uRim: 0.5, uWrap: 0.55, uFill: 1.4 } });
  M.hair = new Material({ uniforms: { uRough: 0.75, uDetail: [3.0, 0.3, 0.6, 3], uGlitter: [30, 0.05, 0.6], uRim: 0.9, uWrap: 0.6, uFill: 1.3 } });
  M.metal = new Material({ uniforms: { uRough: 0.45, uDetail: [2.0, 0.3, 0.6, 1], uRim: 0.4 } });
  M.glow = new Material({ defines: { UNLIT: 1 }, uniforms: { uGlitter: [9, 0.0, 0.0] } });
  M.glowSoft = new Material({ uniforms: { uRough: 0.5, uGlowStrength: 1.0, uRim: 0.6 } });
  M.stem = new Material({ uniforms: { uRough: 0.7, uDetail: [3.0, 0.2, 0.5, 5], uGlitter: [12, 0.08, 0.9], uRim: 0.6, uWrap: 0.5 } });
  M.giantCap = new Material({
    defines: { SPOTS: 1 },
    cull: 'none', // never see-through, even from inside
    uniforms: {
      uRough: 0.5, uDetail: [3.0, 0.25, 0.4, 5], uGlitter: [9, 0.1, 1.0], uRim: 0.35, uWrap: 0.35,
      uSpots: [9.0, 0.95, 2.4, 0.5], uSpotColor: C('#8feaff', 1.0), uSpotGlowPulse: 0.3, uFogScale: 0.8,
    },
  });
  M.amanitaCap = new Material({
    defines: { SPOTS: 1 },
    cull: 'none', // never see-through, even from inside
    uniforms: {
      uRough: 0.45, uDetail: [2.0, 0.2, 0.3, 5], uGlitter: [9, 0.08, 0.8], uRim: 0.55, uWrap: 0.45, uFill: 0.9, uEmissive: [0.045, 0.003, 0.005],
      uSpots: [8.0, 0.85, 0.15, 0.8], uSpotColor: C('#f3efe6', 1.0), uSpotGlowPulse: 0.0,
    },
  });
  M.greatCap = new Material({
    defines: { SPOTS: 1 },
    cull: 'none', // never see-through, even from inside
    uniforms: {
      uRough: 0.5, uDetail: [2.0, 0.25, 0.4, 5], uGlitter: [4, 0.12, 1.2], uRim: 0.35, uWrap: 0.35,
      uSpots: [6.0, 0.95, 2.6, 0.6], uSpotColor: C('#b8bcff', 1.0), uSpotGlowPulse: 0.3, uFogScale: 0.6,
    },
  });
  M.leaves = new Material({
    defines: { MAP: 1, ALPHA_TEST: 1, WIND: 1 },
    textures: { uMap: tex.leaves },
    cull: 'none',
    uniforms: { uRough: 0.8, uGlitter: [14, 0.05, 0.5], uRim: 0.4, uWrap: 0.7, uWindParams: [0.35, 1, 0, 0], uAmbientBoost: 0.8 },
  });
  M.fronds = new Material({
    defines: { MAP: 1, ALPHA_TEST: 1, WIND: 1 },
    textures: { uMap: tex.frond },
    cull: 'none',
    uniforms: { uRough: 0.8, uGlitter: [16, 0.08, 0.9], uRim: 0.5, uWrap: 0.7, uWindParams: [0.25, 1.5, 0.5, 0], uAmbientBoost: 1.0 },
  });
  M.plants = new Material({
    defines: { WIND: 1 },
    cull: 'none',
    uniforms: { uRough: 0.7, uGlitter: [18, 0.1, 1.0], uRim: 0.55, uWrap: 0.7, uWindParams: [0.12, 2.0, 0.6, 0], uAmbientBoost: 1.2 },
  });
  M.mossStrands = new Material({
    defines: { WIND: 1 },
    cull: 'none',
    uniforms: { uRough: 0.9, uGlitter: [16, 0.08, 1.0], uRim: 0.7, uWrap: 0.8, uWindParams: [0.35, 0.7, 0, 0] },
  });
  M.glass = new Material({ uniforms: { uRough: 0.15, uGlowStrength: 1.4, uRim: 0.6, uGlitter: [20, 0.08, 0.6] } });
  M.crystal = new Material({ uniforms: { uRough: 0.1, uGlowStrength: 0.55, uRim: 0.9, uWrap: 0.3, uGlitter: [14, 0.16, 0.9], uFill: 0.3 } });
  M.bounceCap = new Material({
    defines: { SPOTS: 1 },
    cull: 'none', // never see-through, even from inside
    uniforms: {
      uRough: 0.4, uDetail: [2.0, 0.2, 0.3, 5], uGlitter: [9, 0.1, 1.0], uRim: 0.6, uWrap: 0.45, uFill: 0.8, uEmissive: [0.03, 0.006, 0.06],
      uSpots: [6.0, 0.9, 2.2, 0.6], uSpotColor: C('#7ff0ff', 1.0), uSpotGlowPulse: 0.5,
    },
  });
  M.houseCap = new Material({
    defines: { SPOTS: 1 },
    uniforms: {
      uRough: 0.5, uDetail: [0.8, 0.2, 0.3, 5], uGlitter: [8, 0.08, 0.8], uRim: 0.5, uWrap: 0.45, uFill: 0.7, uEmissive: [0.03, 0.004, 0.006],
      uSpots: [1.6, 0.85, 0.12, 0.6], uSpotColor: C('#f3efe6', 1.0), uSpotGlowPulse: 0.0,
    },
  });
  // sky creatures: less fog so they read as silhouettes against the sky from far away
  M.whale = new Material({ uniforms: { uRough: 0.55, uGlowStrength: 1.0, uRim: 0.9, uWrap: 0.5, uFogScale: 0.4, uFill: 0.25, uGlitter: [3, 0.08, 1.0] } });
  // clouds you can stand on: soft, bright on top, glowing a little from inside
  M.cloud = new Material({ uniforms: { uRough: 1.0, uDetail: [0.7, 0.08, 0.25, 5], uGlitter: [5, 0.1, 0.5], uRim: 0.7, uWrap: 0.85, uFill: 0.6, uGlowStrength: 1.0, uFogScale: 0.6 } });
  // shiny toy plastic (rubber duck, beach ball, the slide)
  M.glossy = new Material({ uniforms: { uRough: 0.22, uRim: 0.5, uWrap: 0.3, uFill: 0.45, uGlitter: [16, 0.05, 0.6] } });
  M.glossyDS = new Material({ cull: 'none', uniforms: { uRough: 0.22, uRim: 0.5, uWrap: 0.3, uFill: 0.45, uGlitter: [16, 0.05, 0.6] } });
  M.plaster = new Material({ uniforms: { uRough: 0.85, uDetail: [1.2, 0.18, 0.25, 5], uGlitter: [12, 0.05, 0.4], uRim: 0.35, uWrap: 0.4, uFill: 0.4 } });
  return M;
}

// ---------------------------------------------------------------- canvas textures
// The leaf clump only covers about a third of its square texture. Foliage cards are cut to a convex outline
// around the opaque pixels (in uv space), so the GPU never rasterizes the empty corners that the alpha test
// would throw away anyway: same picture, a third less foliage fill in both the main and the shadow pass.
export const LEAF_CARD = { poly: null };

function alphaOutline(c, k = 6, off = Math.PI / 6, margin = 6) {
  let data;
  try { data = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; } catch (e) { return null; }
  const w = c.width, h = c.height, cx = w / 2, cy = h / 2;
  const dirs = [];
  for (let i = 0; i < k; i++) dirs.push([Math.cos(off + (i / k) * Math.PI * 2), Math.sin(off + (i / k) * Math.PI * 2)]);
  const sup = new Array(k).fill(-Infinity);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (data[(y * w + x) * 4 + 3] < 100) continue;
      const px = x + 0.5 - cx, py = y + 0.5 - cy;
      for (let i = 0; i < k; i++) sup[i] = Math.max(sup[i], px * dirs[i][0] + py * dirs[i][1]);
    }
  }
  if (!Number.isFinite(sup[0])) return null;
  // corners where neighbouring support lines meet (the k-sided polygon enclosing the opaque pixels)
  let poly = [];
  for (let i = 0; i < k; i++) {
    const [ax, ay] = dirs[i], [bx, by] = dirs[(i + 1) % k];
    const h1 = sup[i] + margin, h2 = sup[(i + 1) % k] + margin;
    const det = ax * by - ay * bx;
    poly.push([cx + (h1 * by - ay * h2) / det, cy + (ax * h2 - h1 * bx) / det]);
  }
  // clip to the texture square
  const clip = (pts, inside, cut) => {
    const out = [];
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i], q = pts[(i + 1) % pts.length];
      const pin = inside(p), qin = inside(q);
      if (pin) out.push(p);
      if (pin !== qin) out.push(cut(p, q));
    }
    return out;
  };
  const lerpAt = (p, q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
  poly = clip(poly, (p) => p[0] >= 0, (p, q) => lerpAt(p, q, (0 - p[0]) / (q[0] - p[0])));
  poly = clip(poly, (p) => p[0] <= w, (p, q) => lerpAt(p, q, (w - p[0]) / (q[0] - p[0])));
  poly = clip(poly, (p) => p[1] >= 0, (p, q) => lerpAt(p, q, (0 - p[1]) / (q[1] - p[1])));
  poly = clip(poly, (p) => p[1] <= h, (p, q) => lerpAt(p, q, (h - p[1]) / (q[1] - p[1])));
  return poly.map(([x, y]) => [x / w, y / h]);
}

function canvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return c;
}

function shade(hex, k) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.round(((n >> 16) & 255) * k), gg = Math.round(((n >> 8) & 255) * k), b = Math.round((n & 255) * k);
  return `rgb(${r},${gg},${b})`;
}

export function createTextures(gl) {
  const T = {};
  // pool tiles for the floor of the dream sea: pale squares, soft grout, a few pastel ones
  {
    const c = canvas(512, 512);
    const g = c.getContext('2d');
    let seed = 11;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    g.fillStyle = '#7f8fa8';
    g.fillRect(0, 0, 512, 512);
    const N = 4, S = 512 / N, gap = 5;
    const pastel = ['#f4c8e0', '#c8e8f8', '#d8f4dc', '#e8dcf8', '#fff0c8'];
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const special = rnd() < 0.12;
        const base = special ? pastel[Math.floor(rnd() * pastel.length)] : ['#e8eef4', '#e2eaf2', '#edf1f6', '#dfe8f0'][Math.floor(rnd() * 4)];
        const x = i * S + gap / 2, y = j * S + gap / 2, w = S - gap;
        const gr = g.createLinearGradient(x, y, x + w, y + w);
        gr.addColorStop(0, base);
        gr.addColorStop(1, shade(base, 0.9));
        g.fillStyle = gr;
        g.fillRect(x, y, w, w);
        // a soft glossy highlight in one corner
        const hl = g.createRadialGradient(x + w * 0.25, y + w * 0.25, 2, x + w * 0.25, y + w * 0.25, w * 0.6);
        hl.addColorStop(0, 'rgba(255,255,255,0.35)');
        hl.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = hl;
        g.fillRect(x, y, w, w);
      }
    }
    T.tiles = createTexture(gl, { source: c, mipmaps: true, min: gl.LINEAR_MIPMAP_LINEAR, wrap: gl.REPEAT, anisotropy: 8 });
  }
  // leaf cluster: overlapping leaves forming a soft round clump
  {
    const c = canvas(256, 256);
    const g = c.getContext('2d', { willReadFrequently: true }); // read back once for the card outline
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    const leaf = (x, y, s, a, l) => {
      g.save();
      g.translate(x, y);
      g.rotate(a);
      g.fillStyle = `rgb(${l * 0.5 | 0},${l * 0.82 | 0},${l | 0})`;
      g.beginPath();
      g.moveTo(-s, 0);
      g.quadraticCurveTo(0, -s * 0.55, s, 0);
      g.quadraticCurveTo(0, s * 0.55, -s, 0);
      g.fill();
      g.strokeStyle = `rgba(0,0,0,0.25)`;
      g.lineWidth = 1.2;
      g.beginPath();
      g.moveTo(-s * 0.9, 0);
      g.lineTo(s * 0.9, 0);
      g.stroke();
      g.restore();
    };
    // back layer darker, front layer lighter
    for (let layer = 0; layer < 2; layer++) {
      const n = layer === 0 ? 70 : 60;
      for (let i = 0; i < n; i++) {
        const a = rnd() * Math.PI * 2;
        const r = Math.pow(rnd(), 0.7) * (layer === 0 ? 105 : 90);
        const x = 128 + Math.cos(a) * r, y = 128 + Math.sin(a) * r * 0.85;
        const s = 13 + rnd() * 12;
        const l = (layer === 0 ? 55 : 95) + rnd() * 70;
        leaf(x, y, s, a + (rnd() - 0.5) * 1.2, l);
      }
    }
    T.leaves = createTexture(gl, { source: c, mipmaps: true, wrap: gl.CLAMP_TO_EDGE });
    LEAF_CARD.poly = alphaOutline(c);
  }
  // fern / palm frond: a central rib with leaflets, uv.x along the frond
  {
    const c = canvas(256, 64);
    const g = c.getContext('2d');
    g.fillStyle = 'rgb(70,120,140)';
    g.fillRect(0, 30, 256, 4);
    for (let i = 0; i < 26; i++) {
      const x = 8 + i * 9.4;
      const len = 28 * Math.sin((i / 26) * Math.PI * 0.95 + 0.1);
      for (const side of [-1, 1]) {
        g.fillStyle = `rgb(${50 + (i % 3) * 8},${100 + (i % 4) * 10},${120 + (i % 2) * 20})`;
        g.beginPath();
        g.moveTo(x, 32);
        g.quadraticCurveTo(x + 8, 32 + side * len * 0.6, x + 14, 32 + side * len);
        g.quadraticCurveTo(x + 4, 32 + side * len * 0.5, x - 2, 32);
        g.fill();
      }
    }
    T.frond = createTexture(gl, { source: c, mipmaps: true });
  }
  return T;
}

// Rune circle floor texture (drawn on a canvas once)
export function runeTexture(gl) {
  const S = 1024;
  const c = canvas(S, S);
  const g = c.getContext('2d');
  g.clearRect(0, 0, S, S);
  g.translate(S / 2, S / 2);
  g.strokeStyle = 'rgba(160,200,255,1)';
  g.fillStyle = 'rgba(160,200,255,1)';
  g.shadowColor = 'rgba(120,170,255,1)';
  g.shadowBlur = 12;
  const ring = (r, w) => { g.lineWidth = w; g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.stroke(); };
  ring(490, 6); ring(465, 3); ring(330, 5); ring(310, 2); ring(150, 4);
  // runes between rings
  let seed = 3;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const glyph = (x, y, s, rot) => {
    g.save(); g.translate(x, y); g.rotate(rot); g.lineWidth = 4; g.beginPath();
    const n = 2 + Math.floor(rnd() * 3);
    g.moveTo(0, -s);
    g.lineTo(0, s);
    for (let i = 0; i < n; i++) {
      const y0 = -s + rnd() * s * 2;
      g.moveTo(0, y0);
      g.lineTo((rnd() < 0.5 ? -1 : 1) * s * 0.7, y0 + (rnd() - 0.5) * s);
    }
    g.stroke(); g.restore();
  };
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    glyph(Math.cos(a) * 398, Math.sin(a) * 398, 34, a + Math.PI / 2);
  }
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 + 0.13;
    glyph(Math.cos(a) * 230, Math.sin(a) * 230, 26, a + Math.PI / 2);
  }
  // star polygon
  g.lineWidth = 4;
  g.beginPath();
  const pts = 7;
  for (let i = 0; i <= pts; i++) {
    const a = (i * 3 / pts) * Math.PI * 2 - Math.PI / 2;
    const x = Math.cos(a) * 310, y = Math.sin(a) * 310;
    if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
  }
  g.stroke();
  return createTexture(gl, { source: c, mipmaps: true });
}
