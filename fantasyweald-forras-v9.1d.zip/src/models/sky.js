// Pieces of the sky layer: cloud puffs, the Cloud Harbour's pier, lighthouse, bell and sheep pen,
// and the Sky Garden's star lilies. Geometry only (local space); world/sky.js places them.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep } from '../engine/math.js';
import { C } from './materials.js';
import { lantern } from './structures.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

// a lumpy cloud made of overlapping blobs: flattened underside, bright top, a faint inner glow
export function cloudPuff(seed = 1, R = 2, { blobs = 7, flat = 0.5, tint = '#bcb8e0', shade = '#50569a', glow = 0.04, seg = 10 } = {}) {
  const rng = new RNG(seed);
  const g = new Geometry();
  for (let i = 0; i < blobs; i++) {
    const a = rng.range(0, TAU), d = i === 0 ? 0 : rng.range(0.4, 0.85) * R;
    const r = i === 0 ? R * 0.72 : R * rng.range(0.34, 0.58);
    const s = Geometry.sphere(r, seg, Math.max(6, seg - 3));
    s.translate(Math.cos(a) * d, i === 0 ? 0 : rng.range(-0.05, 0.3) * R, Math.sin(a) * d);
    g.append(s);
  }
  g.deform((p) => [p[0], p[1] < 0 ? p[1] * flat : p[1], p[2]]);
  g.computeNormals();
  g.displace((p) => noise.n3(p[0] * 1.3 / R + seed, p[1] * 1.3 / R, p[2] * 1.3 / R) * R * 0.07, true);
  const top = C(tint), low = C(shade);
  g.paint((p) => mix3(low, top, smoothstep(-R * 0.45, R * 0.55, p[1])).concat([smoothstep(-R * 0.6, R * 0.2, p[1]) * 0.45 + 0.55]));
  g.paintExtra((p) => [glow * smoothstep(-R * 0.1, R * 0.8, p[1])]);
  return g;
}

// wooden pier sticking out into the sky: deck along +z from z=0 to z=len
export function skyPier(len = 10, width = 2.6, seed = 3) {
  const rng = new RNG(seed);
  const wood = new Geometry();
  const n = Math.round(len / 0.42);
  for (let i = 0; i < n; i++) {
    const b = Geometry.box(width + rng.range(-0.1, 0.1), 0.12, 0.38, { y0: -0.12 });
    b.rotateY(rng.range(-0.02, 0.02));
    b.translate(rng.range(-0.04, 0.04), rng.range(-0.015, 0.015), (i + 0.5) * (len / n));
    b.setColor(mix3(C('#4a3a34'), C('#6e5648'), rng.next()), 0.9);
    wood.append(b);
  }
  // beams underneath and posts with a rope rail
  // (v9.1d) the posts stand on the deck and go down through it into the beams (they used to stand just
  // outside the planks, hanging in the air next to the pier)
  const PX = width / 2 - 0.13;
  for (const s of [-1, 1]) {
    const beam = Geometry.box(0.2, 0.24, len, { y0: -0.36 });
    beam.translate(s * PX, 0, len / 2);
    beam.setColor(C('#2c2420'), 0.8);
    wood.append(beam);
  }
  const posts = [];
  const np = Math.max(2, Math.round(len / 2.6));
  for (let i = 0; i <= np; i++) {
    for (const s of [-1, 1]) {
      const z = 0.3 + (i / np) * (len - 0.6);
      // (a cylinder is built upwards from y = 0: from inside the beam to just over the rope)
      const p = Geometry.cylinder(0.07, 0.09, 1.54, 7, 1);
      p.translate(s * PX, -0.36, z);
      p.setColor(C('#3a2e28'), 1);
      wood.append(p);
      const cap = Geometry.cylinder(0.1, 0.1, 0.05, 7, 1);
      cap.translate(s * PX, 0.02, z);
      cap.setColor(C('#2a211c'), 1);
      wood.append(cap);
      posts.push([s * PX, 1.12, z]);
    }
  }
  const rope = new Geometry();
  for (const s of [-1, 1]) {
    const pts = posts.filter((q) => Math.sign(q[0]) === s);
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1];
      const seg = [];
      for (let k = 0; k <= 6; k++) {
        const t = k / 6;
        seg.push([a[0], lerp(a[1], b[1], t) - Math.sin(t * Math.PI) * 0.16, lerp(a[2], b[2], t)]);
      }
      rope.append(Geometry.tube(seg, () => 0.025, 4, { capEnd: false }));
    }
  }
  rope.setColor(C('#c8b89a'), 1);
  wood.append(rope);
  // lanterns hanging on the last posts
  const frame = new Geometry(), glass = new Geometry();
  const spots = [];
  for (const s of [-1, 1]) {
    const q = [s * PX, 1.0, len - 0.3];
    const l = lantern();
    l.frame.translate(q[0], q[1], q[2]);
    l.glass.translate(q[0], q[1], q[2]);
    frame.append(l.frame);
    glass.append(l.glass);
    spots.push([q[0], q[1] - 0.2, q[2]]);
  }
  return { wood, frame, glass, lamps: spots };
}

// slim lighthouse of pale stone with a glowing moon lamp on top
export function skyLighthouse(h = 7.5) {
  const body = Geometry.lathe(catmullRom([[1.25, 0], [1.05, 0.4], [0.8, h * 0.45], [0.7, h * 0.9], [0.95, h * 0.93], [0.95, h * 0.97], [0.6, h]], 3), 16, { capTop: true });
  body.paint((p) => {
    const band = Math.sin(p[1] * 1.3) > 0.55 ? 1 : 0;
    return mix3(C('#bfc4e6'), C('#6e76b8'), band * 0.65).concat([smoothstep(0, 1.5, p[1]) * 0.4 + 0.6]);
  });
  const trim = new Geometry();
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU;
    const post = Geometry.box(0.07, 1.2, 0.07);
    post.translate(Math.cos(a) * 0.55, h + 0.6, Math.sin(a) * 0.55);
    trim.append(post);
  }
  const roof = Geometry.cylinder(0.02, 0.85, 0.9, 12, 1);
  roof.translate(0, h + 1.18, 0);
  trim.append(roof);
  const door = Geometry.box(0.6, 1.2, 0.1, { y0: 0 });
  door.translate(0, 0.05, 1.08);
  trim.append(door);
  trim.setColor(C('#3a3450'), 1);
  const lamp = Geometry.sphere(0.42, 14, 10);
  lamp.translate(0, h + 0.62, 0);
  lamp.setColor(C('#dff2ff'), 1);
  lamp.setExtra([3.2]);
  const win = new Geometry();
  for (const y of [h * 0.35, h * 0.62]) {
    const w = Geometry.box(0.28, 0.42, 0.08);
    w.translate(0, y, 0.84 - (y / h) * 0.12);
    win.append(w);
  }
  win.setColor(C('#ffd68a'), 1);
  win.setExtra([2.2]);
  lamp.append(win);
  return { body, trim, lamp, top: h + 0.62 };
}

// the cloud bell: a curved post with a bronze bell
export function skyBell() {
  const post = new Geometry();
  const pts = catmullRom([[0, 0, 0], [0.05, 1.4, 0], [0.2, 2.4, 0], [0.7, 2.75, 0], [1.05, 2.6, 0]], 4);
  post.append(Geometry.tube(pts, (t) => 0.1 * (1 - t * 0.45), 6, { capEnd: true }));
  post.setColor(C('#3c3044'), 1);
  const bell = Geometry.lathe(catmullRom([[0.36, -0.56], [0.4, -0.52], [0.3, -0.42], [0.24, -0.2], [0.16, 0.02], [0.02, 0.05]], 3), 16);
  bell.translate(1.05, 2.5, 0);
  bell.setColor(C('#c89a48'), 1);
  const clapper = Geometry.sphere(0.07, 6, 5);
  clapper.translate(1.05, 1.95, 0);
  clapper.setColor(C('#5a4a30'), 1);
  bell.append(clapper);
  return { post, bell, anchor: [1.05, 2.0, 0] };
}

// a round pen: cloud-white posts with a low rail
export function sheepPen(R = 2.8, gapA = 0, groundAt = null) {
  const g = new Geometry();
  const n = 14;
  const posts = [];
  for (let i = 0; i < n; i++) {
    const a = gapA + ((i + 0.5) / n) * TAU;
    if (i === 0) continue; // the gate
    // (v9.1d) each post stands in the cloud where it is (they used to start 35 cm above the ground)
    const px = Math.cos(a) * R, pz = Math.sin(a) * R;
    const gy = groundAt ? Math.min(0.3, groundAt(px, pz)) : 0;
    const p = Geometry.cylinder(0.06, 0.08, 0.8 - gy + 0.3, 6, 1);
    p.translate(px, gy - 0.3, pz);
    g.append(p);
    posts.push(a);
  }
  const a0 = posts[0], a1 = posts[posts.length - 1];
  for (const y of [0.35, 0.65]) {
    const t = Geometry.torus(R, 0.035, 4, 40, a1 - a0);
    t.rotateY(-a0);
    t.translate(0, y, 0);
    g.append(t);
  }
  g.setColor(C('#d8d0f0'), 1);
  return g;
}

// big glowing lily for the Sky Garden
export function starLily(seed = 1, color = '#bfe2ff') {
  const rng = new RNG(seed);
  const g = new Geometry();
  const col = C(color);
  const h = rng.range(1.8, 3.2);
  const stemPts = catmullRom([[0, 0, 0], [rng.range(-0.2, 0.2), h * 0.5, rng.range(-0.2, 0.2)], [rng.range(-0.3, 0.3), h, rng.range(-0.3, 0.3)]], 5);
  const stem = Geometry.tube(stemPts, (t) => 0.06 * (1 - t * 0.5), 5, { capEnd: false });
  stem.setColor(C('#2f6a66'), 1);
  g.append(stem);
  const top = stemPts[stemPts.length - 1];
  const np = 6;
  for (let i = 0; i < np; i++) {
    const a = (i / np) * TAU + rng.range(-0.1, 0.1);
    const petal = Geometry.lathe([[0.0, 0.0], [0.16, 0.25], [0.2, 0.6], [0.1, 0.95], [0.0, 1.0]], 6);
    petal.scale(1, 1, 0.25);
    petal.rotateX(0.9 + rng.range(-0.1, 0.15));
    petal.rotateY(a);
    petal.scale(0.9);
    petal.translate(top[0], top[1], top[2]);
    petal.paint((p) => mix3(col, C('#ffffff'), smoothstep(top[1] + 0.2, top[1] + 0.8, p[1]) * 0.6).concat([1]));
    petal.paintExtra((p) => [0.35 + smoothstep(top[1], top[1] + 0.9, p[1]) * 1.1]);
    g.append(petal);
  }
  const heart = Geometry.sphere(0.12, 8, 6);
  heart.translate(top[0], top[1] + 0.15, top[2]);
  heart.setColor(C('#fff2c0'), 1);
  heart.setExtra([3.0]);
  g.append(heart);
  return { geo: g, top: [top[0], top[1] + 0.3, top[2]] };
}

// a ring of flat stones around the Sky Mirror pond
export function mirrorRim(R = 2.4, seed = 5) {
  const rng = new RNG(seed);
  const g = new Geometry();
  const n = 16;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + rng.range(-0.08, 0.08);
    const s = Geometry.sphere(1, 7, 5);
    s.scale(rng.range(0.38, 0.55), rng.range(0.14, 0.22), rng.range(0.3, 0.42));
    s.rotateY(-a);
    s.translate(Math.cos(a) * R, 0.02, Math.sin(a) * R);
    g.append(s);
  }
  g.setColor(C('#8a8fb8'), 1);
  const water = Geometry.disc(R - 0.15, 32);
  water.translate(0, 0.06, 0);
  water.setColor(C('#9fd8ff'), 1);
  water.setExtra([0.9]);
  return { rim: g, water };
}
