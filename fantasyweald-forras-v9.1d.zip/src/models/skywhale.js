// (v9.1d) Égi bálnák — the sky whales, rebuilt as proper humpbacks of the dream sky: one smooth skinned body
// (the tail stock bends over three bones, so the fluke beat rolls down the body instead of snapping at a
// joint), a broad head with a mouth line, glowing pearl tubercles on the rostrum and along the lower jaw,
// throat pleats under the chin, side eyes with lids, a paired blowhole behind a splash guard, a small hump
// of a dorsal fin, long scalloped flippers and wide notched flukes with a serrated trailing edge. A row of
// soft lights runs along each flank and the dark back carries slowly breathing star specks.
// whaleSaddle() is the ferry whale's riding pavilion: a patterned rug with tassels held by leather girth
// straps, a planked deck with a balustrade, a leather seat with a bell on the pommel, cushions, a little
// chest, reins to a collar ring, and an onion-dome canopy on four posts with a scalloped valance, lanterns,
// fairy lights and a crescent moon on top.
import { Geometry } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { TAU, lerp, smoothstep, clamp, mat4 } from '../engine/math.js';
import { ATTR } from '../engine/gl.js';
import { MAX_BONES } from '../engine/shaders/standard.js';
import { C } from './materials.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const mesh = (ctx, g, mat, name = '') => new Mesh(new GpuGeometry(ctx.gl, g), mat, name);
function egg(rx, ry, rz, ws = 12, hs = 8) {
  const g = Geometry.sphere(1, ws, hs);
  g.scale(rx, ry, rz);
  return g;
}
function bone(name, parent, x = 0, y = 0, z = 0) {
  const n = new Node(name);
  n.setPos(x, y, z);
  parent.add(n);
  return n;
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

// ------------------------------------------------------------------ the body's shape
// [z, half width, height above the axis, depth below it]; the head is +z, the tail stock -z
const KN = [
  [-19.2, 0.48, 0.85, 0.7],
  [-17.6, 0.75, 1.35, 1.1],
  [-15, 1.3, 2.05, 1.75],
  [-11.5, 2.15, 2.8, 2.45],
  [-7, 3.25, 3.65, 3.25],
  [-2.5, 4.2, 4.35, 3.95],
  [2, 4.7, 4.62, 4.35],
  [5.5, 4.75, 4.45, 4.5],
  [8.5, 4.4, 3.85, 4.3],
  [11, 3.7, 2.95, 3.6],
  [12.8, 2.8, 2.05, 2.6],
  [13.9, 1.8, 1.25, 1.6],
];
const ZT = -19.2, ZH = 13.9, CT = 1.1, CH = 0.8;
const WZ0 = ZT - CT, WZ1 = ZH + CH;
function cr(z, col) {
  const K = KN, n = K.length;
  if (z <= K[0][0]) return K[0][col];
  if (z >= K[n - 1][0]) return K[n - 1][col];
  let i = 0;
  while (K[i + 1][0] < z) i++;
  const t = (z - K[i][0]) / (K[i + 1][0] - K[i][0]);
  const p0 = K[Math.max(0, i - 1)][col], p1 = K[i][col], p2 = K[i + 1][col], p3 = K[Math.min(n - 1, i + 2)][col];
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
}
const S3 = [0, 0, 0];
function shape(z) {
  let k = 1, zz = z;
  if (z < ZT) { const u = (ZT - z) / CT; k = Math.sqrt(Math.max(0, 1 - u * u)); zz = ZT; }
  else if (z > ZH) { const u = (z - ZH) / CH; k = Math.sqrt(Math.max(0, 1 - u * u)); zz = ZH; }
  S3[0] = cr(zz, 1) * k; S3[1] = cr(zz, 2) * k; S3[2] = cr(zz, 3) * k;
  return S3;
}
// the head slopes down a little towards the snout
const axisY = (z) => -0.85 * smoothstep(6.5, 14.7, z);
// a point on the skin at z, angle th around the axis (0 = the +x flank, PI/2 = the back, -PI/2 = the belly)
export function whaleSkin(z, th) {
  const [w, t, b] = shape(z);
  const c = Math.cos(th), s = Math.sin(th);
  const x = w * Math.sign(c) * Math.pow(Math.abs(c), 0.92);
  let y = s >= 0 ? t * s : -b * Math.pow(-s, 0.88);
  // keels along the top and bottom of the tail stock
  const kz = smoothstep(-6, -16.5, z) * (1 - smoothstep(-19.4, -20.2, z));
  if (kz > 0) {
    let dt = th - Math.PI / 2; dt = Math.atan2(Math.sin(dt), Math.cos(dt));
    let db = th + Math.PI / 2; db = Math.atan2(Math.sin(db), Math.cos(db));
    y += kz * (0.32 * Math.exp((-dt * dt) / 0.035) - 0.26 * Math.exp((-db * db) / 0.035));
  }
  return [x, y + axisY(z), z];
}
export function whaleNormal(z, th) {
  const a = whaleSkin(z, th - 0.01), b = whaleSkin(z, th + 0.01);
  const c = whaleSkin(z - 0.05, th), d = whaleSkin(z + 0.05, th);
  return norm(cross(sub(b, a), sub(d, c)));
}
// top of the back at z, for anything that sits on it
export const whaleTop = (z) => whaleSkin(z, Math.PI / 2)[1];
// the angle on the upper half whose skin point has lateral offset |x| at z (for skirts that meet the back)
function thAtX(z, x) {
  const w = shape(z)[0];
  const c = clamp(Math.abs(x) / Math.max(w, 1e-3), 0, 1);
  const th = Math.acos(Math.pow(c, 1 / 0.92));
  return x >= 0 ? th : Math.PI - th;
}

// ------------------------------------------------------------------ helpers
// a thin flat foil (fin, fluke): at(u, v, side) gives the surface point for span u, chord v, on the upper
// (+1) or lower (-1) face; each face is wound so that it faces away from the other one
function foil(nu, nv, at, axis) {
  const g = new Geometry();
  for (const side of [1, -1]) {
    const base = g.vertexCount, i0 = g.idx.length;
    for (let i = 0; i <= nu; i++) for (let j = 0; j <= nv; j++) {
      const p = at(i / nu, j / nv, side);
      g.vert(p[0], p[1], p[2]);
    }
    for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
      const a = base + i * (nv + 1) + j, b = a + nv + 1;
      g.quad(a, b, b + 1, a + 1);
    }
    // orient: the middle quad's normal must point along the face's side of the axis
    const mi = i0 + (Math.floor(nu / 2) * nv + Math.floor(nv / 2)) * 6;
    const P = (k) => [g.p[k * 3], g.p[k * 3 + 1], g.p[k * 3 + 2]];
    const A = P(g.idx[mi]), B = P(g.idx[mi + 1]), Cc = P(g.idx[mi + 2]);
    const n = cross(sub(B, A), sub(Cc, A));
    if ((n[0] * axis[0] + n[1] * axis[1] + n[2] * axis[2]) * side < 0) {
      for (let k = i0; k < g.idx.length; k += 3) { const t = g.idx[k + 1]; g.idx[k + 1] = g.idx[k + 2]; g.idx[k + 2] = t; }
    }
  }
  g.computeNormals();
  return g;
}
// a tube along a polyline, tapering towards both ends
function rope(pts, r0, r1 = r0, radial = 6, taper = 0) {
  const radii = pts.map((_, i) => {
    const t = i / (pts.length - 1);
    const e = taper > 0 ? Math.min(1, Math.min(t, 1 - t) / taper) : 1;
    return lerp(r0, r1, t) * (0.25 + 0.75 * e);
  });
  return Geometry.tube(pts, radii, radial, { capStart: true, capEnd: true });
}
// a skinned mesh: every vertex follows a fractional bone index (b + w blends bone b into b + 1); the bones'
// bind poses are plain translations in the model space the geometry was built in
function skinnedMesh(ctx, geo, material, name, bones, binds, boneOf, bounds) {
  const gl = ctx.gl;
  const nv = geo.vertexCount;
  const P = new Float32Array(geo.p), N = new Float32Array(geo.n), UV = new Float32Array(geo.uv);
  const COL = new Float32Array(geo.c), EX = new Float32Array(geo.e), BONE = new Float32Array(nv);
  for (let i = 0; i < nv; i++) BONE[i] = boneOf(P[i * 3], P[i * 3 + 1], P[i * 3 + 2]);
  const big = nv > 65535;
  const IDX = big ? new Uint32Array(geo.idx) : new Uint16Array(geo.idx);
  const mk = (data, target = gl.ARRAY_BUFFER) => {
    const bf = gl.createBuffer();
    gl.bindBuffer(target, bf);
    gl.bufferData(target, data, gl.STATIC_DRAW);
    return bf;
  };
  const buffers = { p: mk(P), n: mk(N), uv: mk(UV), c: mk(COL), e: mk(EX), b: mk(BONE) };
  const vao = gl.createVertexArray();
  gl.bindVertexArray(vao);
  const bind = (buf, loc, size) => { gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0); };
  bind(buffers.p, ATTR.aPosition, 3); bind(buffers.n, ATTR.aNormal, 3); bind(buffers.uv, ATTR.aUv, 2);
  bind(buffers.c, ATTR.aColor, 4); bind(buffers.e, ATTR.aExtra, 4); bind(buffers.b, ATTR.aIData, 1);
  buffers.idx = mk(IDX, gl.ELEMENT_ARRAY_BUFFER);
  gl.bindVertexArray(null);
  const gpu = { gl, vertexCount: nv, count: IDX.length, bounds, buffers, indexType: big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT, vao, cpu: null };
  const m = new Mesh(gpu, material, name);
  m.skinned = true;
  m.castShadow = false;
  const inv = binds.map((b) => { const q = mat4.create(); q[12] = -b[0]; q[13] = -b[1]; q[14] = -b[2]; return q; });
  const mats = new Float32Array(MAX_BONES * 16), tmp = mat4.create();
  m.onBeforeDraw = (prog) => {
    for (let i = 0; i < bones.length; i++) { mat4.multiply(tmp, bones[i].world, inv[i]); mats.set(tmp, i * 16); }
    prog.set('uBones', mats);
  };
  return m;
}

// the tail chain: pivots of body, tail1, tail2 and the fluke bone along z; each bone owns the stretch
// between the midpoints of its neighbours
const PIV = [0, -6, -11.5, -17.2];
const MID = [-3, -8.75, -14.35, -17.2];
function tailBone(z) {
  if (z >= MID[0]) return 0;
  if (z <= MID[3]) return 3;
  for (let i = 0; i < 3; i++) {
    if (z <= MID[i] && z > MID[i + 1]) {
      const t = (MID[i] - z) / (MID[i] - MID[i + 1]);
      return i + t * t * (3 - 2 * t);
    }
  }
  return 3;
}

const PALETTES = [
  { back: '#18214e', flank: '#2f3f7c', belly: '#a9b2e8', pleat: '#6c76b6', fin: '#c6cff4', pearl: '#b4ecff', light: '#8fd8ff', star: '#d4e8ff' },
  { back: '#133247', flank: '#25607a', belly: '#a6d6e2', pleat: '#5e98ad', fin: '#c4ecf2', pearl: '#bff6ff', light: '#7ff0e0', star: '#dcfff8' },
];

// ------------------------------------------------------------------ the whale
export function buildSkyWhale(ctx, seed = 1, saddle = false) {
  const M = ctx.M;
  const pal = PALETTES[(seed - 1) % PALETTES.length];
  const K = (h) => C(h);
  const col = { back: K(pal.back), flank: K(pal.flank), belly: K(pal.belly), pleat: K(pal.pleat), fin: K(pal.fin) };
  const matKey = 'skyWhale' + ((seed - 1) % PALETTES.length);
  if (!M[matKey]) {
    M[matKey] = new Material({
      defines: { SPOTS: 1 },
      uniforms: {
        uRough: 0.5, uGlowStrength: 1.0, uRim: 0.85, uWrap: 0.5, uFogScale: 0.4, uFill: 0.3, uGlitter: [3, 0.02, 0.3],
        uDetail: [0.5, 0.05, 0.12, 5], uSpots: [0.9, 0.3, 2.8, 0.0], uSpotColor: C(pal.star, 1.0), uSpotGlowPulse: 0.6,
      },
    });
  }
  const skinMat = M[matKey];
  const root = new Node('whale');
  const bones = {};
  const body = bone('body', root);
  bones.body = body;
  const tail1 = bone('tail1', body, 0, 0, PIV[1]);
  const tail2 = bone('tail2', tail1, 0, 0, PIV[2] - PIV[1]);
  const tail = bone('tail', tail2, 0, 0, PIV[3] - PIV[2]);
  Object.assign(bones, { tail1, tail2, tail });
  const L = 34;

  // ---- the body tube
  const g = new Geometry();
  const NZ = 150, NT = 76;
  const rings = [];
  for (let i = 0; i <= NZ; i++) {
    const u = i / NZ;
    const f = 0.7 * u + 0.3 * (1 - Math.cos(Math.PI * u)) / 2;
    const z = WZ0 + (WZ1 - WZ0) * f;
    const ring = [];
    for (let j = 0; j < NT; j++) {
      const th = -Math.PI + (j / NT) * TAU;
      const p = whaleSkin(z, th);
      ring.push(g.vert(p[0], p[1], p[2], 0, 1, 0, j / NT, u));
    }
    rings.push(ring);
  }
  for (let i = 0; i < NZ; i++) {
    for (let j = 0; j < NT; j++) {
      const j2 = (j + 1) % NT;
      g.quad(rings[i][j], rings[i][j2], rings[i + 1][j2], rings[i + 1][j]);
    }
  }
  g.computeNormals();
  // the paint: a night-blue back that breaks into the pale belly along a ragged, humpback-like line
  const ex = [];
  g.paint((p) => {
    const z = p[2];
    const [w, t, b] = shape(z);
    const yRel = p[1] - axisY(z);
    const s = yRel >= 0 ? yRel / Math.max(t, 0.01) : yRel / Math.max(b, 0.01);
    const n1 = noise.n3(p[0] * 0.28 + seed * 3, p[1] * 0.28, z * 0.22);
    const edge = -0.18 + (n1 - 0.5) * 0.35 + 0.08 * Math.sin(z * 0.9 + seed);
    const belly = smoothstep(edge + 0.14, edge - 0.14, s);
    let c = mix3(col.back, col.flank, smoothstep(0.85, 0.05, s));
    c = mix3(c, col.belly, belly);
    // soft pale mottling on the back and a lighter, freckled head
    const mot = noise.n3(p[0] * 0.3 + 7, p[1] * 0.3, z * 0.25);
    c = mix3(c, mix3(c, col.belly, 0.25), smoothstep(0.6, 0.8, mot) * (1 - belly) * 0.6);
    c = mix3(c, col.flank, smoothstep(9, 13.5, z) * (1 - belly) * 0.45);
    // the underside of the tail stock stays pale, the flanks behind the flippers darken
    const ao = 0.82 + 0.18 * smoothstep(-1, 0.6, s);
    return c.concat([ao]);
  });
  g.paintExtra((p) => {
    const z = p[2];
    const yRel = p[1] - axisY(z);
    const t = shape(z)[1];
    const up = yRel / Math.max(t, 0.01);
    // star specks only on the dark back, gathered into loose constellations
    const cl = noise.n3(p[0] * 0.16 + seed, p[1] * 0.16, z * 0.12);
    const mask = smoothstep(0.15, 0.45, up) * smoothstep(0.5, 0.6, cl) * (1 - smoothstep(10, 12.5, z)) * smoothstep(-19, -16, z);
    return [0, 0, mask, 0];
  });

  // ---- throat pleats: dark grooves from the chin to the navel
  const pl = new Geometry();
  const NPL = 15;
  for (let k = 0; k < NPL; k++) {
    const q = (k - (NPL - 1) / 2) / ((NPL - 1) / 2);
    const th = -Math.PI / 2 + q * 1.0;
    const z0 = 13.4 - Math.abs(q) * 1.4, z1 = -1.2 + Math.abs(q) * 2.2 + Math.sin(k * 2.1) * 0.5;
    const pts = [];
    for (let i = 0; i <= 40; i++) {
      const z = lerp(z0, z1, i / 40);
      const p = whaleSkin(z, th + Math.sin(z * 0.35 + k) * 0.015);
      const n = whaleNormal(z, th);
      pts.push([p[0] + n[0] * 0.012, p[1] + n[1] * 0.012, p[2] + n[2] * 0.012]);
    }
    const r = rope(pts, 0.042, 0.034, 5, 0.22);
    r.setColor(mix3(col.pleat, col.belly, 0.45), 0.9);
    r.setExtra([0, 0, 0, 0]);
    pl.append(r);
  }
  g.append(pl);

  // ---- the mouth line and the rim of the lower jaw
  const mouthY = (z) => -0.1 - 0.34 * smoothstep(9.6, 6.9, z);
  for (const sd of [1, -1]) {
    const pts = [], lip = [];
    for (let i = 0; i <= 44; i++) {
      const z = lerp(14.5, 6.9, i / 44);
      const [w, t, b] = shape(z);
      const s = clamp(mouthY(z), -0.95, 0.95);
      const th = Math.asin(-Math.pow(-s, 1 / 0.88));
      const thS = sd > 0 ? th : Math.PI - th;
      const p = whaleSkin(z, thS), n = whaleNormal(z, thS);
      pts.push([p[0] + n[0] * 0.01, p[1] + n[1] * 0.01, p[2] + n[2] * 0.01]);
      const th2 = thS + (sd > 0 ? -0.09 : 0.09);
      const p2 = whaleSkin(z, th2), n2 = whaleNormal(z, th2);
      lip.push([p2[0] + n2[0] * 0.02, p2[1] + n2[1] * 0.02, p2[2] + n2[2] * 0.02]);
    }
    const m = rope(pts, 0.07, 0.085, 6, 0.08);
    m.setColor(K('#0e1332'), 0.6);
    g.append(m);
    const lp = rope(lip, 0.1, 0.09, 6, 0.1);
    lp.setColor(mix3(col.belly, col.flank, 0.4), 0.9);
    g.append(lp);
  }

  // ---- blowholes behind a splash guard
  {
    const zb = 6.0, yt = whaleTop(zb);
    const guard = egg(0.75, 0.2, 0.55, 14, 8);
    guard.translate(0, yt + 0.02, zb + 0.65);
    guard.setColor(col.flank, 1);
    g.append(guard);
    for (const sd of [-1, 1]) {
      const slit = egg(0.08, 0.05, 0.42, 8, 6);
      slit.rotateY(sd * 0.28);
      slit.translate(sd * 0.2, yt + 0.035, zb);
      slit.setColor(K('#070a1c'), 0.4);
      g.append(slit);
      const rim = egg(0.14, 0.07, 0.5, 10, 6);
      rim.rotateY(sd * 0.28);
      rim.translate(sd * 0.22, yt - 0.01, zb);
      rim.setColor(mix3(col.back, col.flank, 0.6), 0.9);
      g.append(rim);
    }
  }

  // ---- a small hump of a dorsal fin
  {
    const df = foil(10, 12, (u, v, side) => {
      const h = u;
      const zl = lerp(-6.6, -9.5, Math.pow(h, 0.75)), zt = lerp(-10.2, -9.55, Math.pow(h, 1.4));
      const z = lerp(zl, zt, v);
      const th = 0.3 * Math.pow(1 - h, 0.7) * Math.pow(Math.sin(Math.PI * v), 0.6) + 0.004;
      const y = whaleTop(z) - 0.3 + h * 1.35 + 0.25 * Math.sin(Math.PI * v) * (1 - h);
      return [side * th, y, z];
    }, [1, 0, 0]);
    df.setColor(col.back, 1);
    df.paint((p) => mix3(col.back, col.flank, smoothstep(whaleTop(p[2]) + 0.9, whaleTop(p[2]) + 0.2, p[1]) * 0.5).concat([1]));
    g.append(df);
  }

  // ---- flukes: wide, swept, notched, with a serrated trailing edge and a pale starry underside
  {
    const SP = 6.4;
    const fl = foil(72, 12, (u, v, side) => {
      const q = u * 2 - 1, a = Math.abs(q);
      const zl = -18.7 - 2.3 * Math.pow(a, 1.5);
      let ch = 3.3 * Math.sqrt(Math.max(0, 1 - Math.pow(a, 2.4))) * (1 - 0.35 * a);
      ch -= 1.0 * Math.exp(-Math.pow(q / 0.075, 2)) * (1 - 0.2 * v);
      ch += 0.09 * Math.sin(a * 58) * smoothstep(0.08, 0.2, a) * (1 - smoothstep(0.85, 1, a));
      ch = Math.max(ch, 0);
      const z = zl - ch * v;
      const th = (0.42 * Math.pow(1 - a, 1.2) + 0.03) * Math.pow(Math.sin(Math.PI * Math.min(1, v * 1.02)), 0.65) * (1 - 0.35 * v);
      const y = 0.22 * q * q - 0.05 + side * th;
      return [q * SP, y, z];
    }, [0, 1, 0]);
    fl.paint((p, n) => {
      const a = Math.abs(p[0]) / SP;
      const under = n[1] < 0;
      let c = under ? col.fin : mix3(col.back, col.flank, smoothstep(0.2, 0.95, a) * 0.6);
      if (under) {
        // a dark ragged trailing edge and a few blotches: every whale's fluke is its own
        const zl = -18.7 - 2.3 * Math.pow(a, 1.5);
        const d = zl - p[2];
        const bl = noise.n3(p[0] * 0.7 + seed * 5, 0, p[2] * 0.7);
        c = mix3(c, col.flank, Math.max(smoothstep(1.6, 2.6, d + (bl - 0.5) * 1.2), smoothstep(0.66, 0.74, bl) * 0.8));
      }
      return c.concat([1]);
    });
    fl.paintExtra((p, n) => [0, 0, n[1] < 0 ? 0.8 : 0.3, 0]);
    g.append(fl);
  }

  const bodyMesh = skinnedMesh(ctx, g, skinMat, 'whaleBody', [body, tail1, tail2, tail],
    [[0, 0, 0], [0, 0, PIV[1]], [0, 0, PIV[2]], [0, 0, PIV[3]]], (x, y, z) => tailBone(z), { center: [0, 0, -3], radius: 24 });
  root.add(bodyMesh);

  // ---- soft lights along each flank (they reach down the tail, so they bend with it)
  const lights = new Geometry();
  for (const sd of [1, -1]) {
    for (let i = 0; i < 16; i++) {
      const z = 5.2 - i * 1.3;
      const th0 = 0.24 + Math.sin(i * 0.9) * 0.04;
      const th = sd > 0 ? th0 : Math.PI - th0;
      const p = whaleSkin(z, th), n = whaleNormal(z, th);
      const r = lerp(0.15, 0.07, i / 15);
      const d = egg(r, r, r * 1.2, 8, 6);
      d.translate(p[0] + n[0] * r * 0.3, p[1] + n[1] * r * 0.3, p[2] + n[2] * r * 0.3);
      d.setColor(C(pal.light), 1);
      d.setExtra([1.9]);
      lights.append(d);
    }
  }
  root.add(skinnedMesh(ctx, lights, M.glowSoft, 'whaleLights', [body, tail1, tail2, tail],
    [[0, 0, 0], [0, 0, PIV[1]], [0, 0, PIV[2]], [0, 0, PIV[3]]], (x, y, z) => tailBone(z), { center: [0, 0, -3], radius: 24 }));

  // ---- pearl tubercles on the rostrum and along the lower jaw (rigid: the head never bends)
  const pearls = new Geometry();
  const pearl = (z, th, r) => {
    const p = whaleSkin(z, th), n = whaleNormal(z, th);
    const e = egg(r, r * 0.85, r, 8, 6);
    e.translate(p[0] + n[0] * r * 0.35, p[1] + n[1] * r * 0.35, p[2] + n[2] * r * 0.35);
    e.setColor(C(pal.pearl), 1);
    e.setExtra([1.4]);
    pearls.append(e);
  };
  for (let z = 8.6; z < 14.3; z += 0.72) {
    const f = (z - 8.6) / 5.7;
    const r = lerp(0.17, 0.09, f);
    pearl(z, Math.PI / 2, r);
    for (const sd of [1, -1]) pearl(z + 0.36, Math.PI / 2 + sd * lerp(0.42, 0.62, f), r * 0.85);
  }
  for (const sd of [1, -1]) {
    for (let z = 13.9; z > 7.4; z -= 0.62) {
      const s = clamp(mouthY(z), -0.95, 0.95) - 0.16;
      const th = Math.asin(-Math.pow(Math.min(0.97, -s), 1 / 0.88));
      pearl(z, sd > 0 ? th : Math.PI - th, lerp(0.09, 0.14, (13.9 - z) / 6.5));
    }
  }
  body.add(mesh(ctx, pearls, M.glowSoft, 'whalePearls'));

  // ---- eyes: set in the side of the head just above the corner of the mouth, under a heavy lid
  const lids = new Geometry(), eyeG = new Geometry();
  for (const sd of [1, -1]) {
    const z = 7.25;
    const s = mouthY(z) + 0.2;
    const th0 = s >= 0 ? Math.asin(s) : -Math.asin(Math.pow(-s, 1 / 0.88));
    const th = sd > 0 ? th0 : Math.PI - th0;
    const p = whaleSkin(z, th);
    const rot = sd > 0 ? -0.22 : Math.PI + 0.22;
    const place = (gg) => { gg.rotateZ(-0.12); gg.rotateY(rot); gg.translate(p[0], p[1], p[2]); return gg; };
    const lid = egg(0.24, 0.52, 0.66, 14, 10);
    lid.translate(-0.02, 0.04, 0);
    lid.setColor(mix3(col.flank, col.back, 0.3), 0.9);
    lids.append(place(lid));
    const lower = egg(0.2, 0.3, 0.55, 12, 8);
    lower.translate(0.02, -0.26, 0.02);
    lower.setColor(mix3(col.flank, col.belly, 0.4), 0.9);
    lids.append(place(lower));
    const ball = egg(0.2, 0.3, 0.34, 12, 10);
    ball.translate(0.14, 0, 0.02);
    ball.setColor(K('#bfe8ff'), 1);
    ball.setExtra([2.0]);
    eyeG.append(place(ball));
    const pup = egg(0.07, 0.19, 0.17, 10, 8);
    pup.translate(0.31, 0, 0.04);
    pup.setColor([0.004, 0.004, 0.012], 1);
    pup.setExtra([0]);
    eyeG.append(place(pup));
    const hl = egg(0.035, 0.05, 0.05, 6, 4);
    hl.translate(0.33, 0.11, 0.1);
    hl.setColor([1, 1, 1], 1);
    hl.setExtra([3]);
    eyeG.append(place(hl));
  }
  body.add(mesh(ctx, lids, skinMat, 'whaleLids'));
  body.add(mesh(ctx, eyeG, M.glowSoft, 'whaleEyes'));

  // ---- long flippers with a scalloped leading edge (a glowing pearl on every scallop)
  for (const sd of [-1, 1]) {
    const z0 = 5.3, th0 = -0.42;
    const rp = whaleSkin(z0, sd > 0 ? th0 : Math.PI - th0);
    const fin = bone(sd < 0 ? 'finR' : 'finL', body, rp[0] - sd * 0.25, rp[1], rp[2]);
    const SPAN = 10.2;
    const lead = (t) => 0.9 * (1 - t) + 0.12 * Math.pow(Math.max(0, Math.sin(t * Math.PI * 9 - 0.6)), 0.7) * smoothstep(0.08, 0.3, t) * (1 - smoothstep(0.9, 1, t));
    const chord = (t) => 2.6 * Math.sqrt(Math.max(0, 1 - Math.pow(t, 2.4))) * (1 - 0.45 * t) + 0.02;
    const fg = foil(56, 12, (t, v, side) => {
      const zl = lead(t), ch = chord(t);
      const z = zl - ch * v;
      const th = (0.34 * (1 - t) + 0.05) * Math.pow(Math.sin(Math.PI * Math.min(1, v)), 0.6) * (1 - 0.35 * v) * (t > 0.985 ? 0.2 : 1);
      return [t * SPAN, side * th + 0.3 * t * t, z];
    }, [0, 1, 0]);
    fg.paint((p, n) => {
      const t = p[0] / SPAN;
      let c = n[1] > 0 ? mix3(col.flank, col.fin, smoothstep(0.3, 1.0, t) * 0.7) : col.fin;
      const zl = lead(t);
      c = mix3(c, col.fin, smoothstep(0.5, 0.05, zl - p[2]) * 0.8);
      return c.concat([1]);
    });
    fg.paintExtra(() => [0, 0, 0, 0]);
    const pg = new Geometry();
    for (let k = 0; k < 9; k++) {
      const t = (k + 0.5 + 0.6 / Math.PI) / 9;
      if (t < 0.12 || t > 0.93) continue;
      const r = lerp(0.12, 0.06, t);
      const e = egg(r, r * 0.8, r, 8, 6);
      e.translate(t * SPAN, 0.3 * t * t, lead(t) - 0.04);
      e.setColor(C(pal.pearl), 1);
      e.setExtra([1.5]);
      pg.append(e);
    }
    for (const gg of [fg, pg]) {
      gg.rotateZ(-0.5);
      gg.rotateY(0.55);
      if (sd < 0) gg.scale(-1, 1, 1);
    }
    fin.add(mesh(ctx, fg, skinMat, 'whaleFlipper'));
    fin.add(mesh(ctx, pg, M.glowSoft));
    bones[sd < 0 ? 'finR' : 'finL'] = fin;
  }

  const out = { root, bones, length: L, spout: [0, whaleTop(6.0) + 0.25, 6.0] };
  if (saddle) out.saddle = whaleSaddle(ctx, body);
  return out;
}

// ------------------------------------------------------------------ the riding pavilion on the ferry whale
export function whaleSaddle(ctx, parent) {
  const M = ctx.M;
  // soft silk and supple leather that stay clean up close (no coarse cloth grain)
  if (!M.silk) M.silk = new Material({ cull: 'none', uniforms: { uRough: 0.62, uDetail: [26, 0.04, 0.04, 4], uGlitter: [22, 0.03, 0.3], uRim: 0.55, uWrap: 0.45, uFill: 0.6 } });
  if (!M.fineWood) M.fineWood = new Material({ uniforms: { uRough: 0.55, uDetail: [16, 0.12, 0.06, 2], uGlitter: [0, 0, 0], uRim: 0.4, uWrap: 0.35, uFill: 0.5 } });
  if (!M.leather) M.leather = new Material({ cull: 'none', uniforms: { uRough: 0.55, uDetail: [5, 0.08, 0.1, 5], uGlitter: [0, 0, 0], uRim: 0.4, uWrap: 0.4, uFill: 0.5 } });
  const O = [0, 4.55, 2.4];
  const n = bone('saddle', parent, O[0], O[1], O[2]);
  const DECK = 4.66;                  // the deck's top in whale space (the rider's seat is at 4.67)
  const RX = 1.45, RZ = 1.72;         // the deck's oval
  const wood = new Geometry(), cloth = new Geometry(), leather = new Geometry(), gold = new Geometry(), glow = new Geometry();
  const add = (dst, gg, color, ao = 1) => { if (color) gg.setColor(color, ao); dst.append(gg); return gg; };
  const onSkin = (z, th, out) => { const p = whaleSkin(z, th), q = whaleNormal(z, th); return [p[0] + q[0] * out, p[1] + q[1] * out, p[2] + q[2] * out]; };

  // ---- the rug over the back: gold border, rose stripes, a plum field with teal diamonds
  {
    const NA = 52, NB = 30, A = 0.82, Z0 = 0.05, Z1 = 4.75;
    const rug = new Geometry();
    const grid = [];
    for (let i = 0; i <= NA; i++) {
      const a = (i / NA) * 2 - 1;
      const row = [];
      for (let j = 0; j <= NB; j++) {
        const b = j / NB;
        const z = lerp(Z0, Z1, b);
        const p = onSkin(z, Math.PI / 2 - a * A, 0.05 + 0.015 * (1 - Math.abs(a)));
        row.push(rug.vert(p[0], p[1], p[2], 0, 1, 0, a, b));
      }
      grid.push(row);
    }
    for (let i = 0; i < NA; i++) for (let j = 0; j < NB; j++) rug.quad(grid[i][j], grid[i][j + 1], grid[i + 1][j + 1], grid[i + 1][j]);
    rug.computeNormals();
    const plum = C('#4e2356'), rose = C('#b44a7c'), gld = C('#d8a848'), teal = C('#2a8c8e'), cream = C('#e8d8b0');
    rug.paint((p, nn, i) => {
      const a = rug.uv[i * 2], b = rug.uv[i * 2 + 1];
      const ea = Math.abs(a), eb = Math.min(b, 1 - b) * 2.4;
      const edge = Math.min(1 - ea, eb);
      let c = plum;
      if (edge < 0.08) c = gld;
      else if (edge < 0.12) c = plum;
      else if (edge < 0.17) c = rose;
      else {
        const da = Math.abs(((a * 3.2) % 1 + 1) % 1 - 0.5), db = Math.abs(((b * 4.2) % 1 + 1) % 1 - 0.5);
        const d = da + db;
        if (d < 0.16) c = teal;
        else if (d < 0.22) c = cream;
      }
      return c.concat([0.95]);
    });
    cloth.append(rug);
    // tassels along both lower edges
    for (const sd of [-1, 1]) {
      for (let k = 0; k <= 14; k++) {
        const z = lerp(Z0 + 0.1, Z1 - 0.1, k / 14);
        const p = onSkin(z, Math.PI / 2 - sd * A, 0.06);
        const knot = egg(0.05, 0.05, 0.05, 6, 5);
        knot.translate(p[0], p[1] - 0.02, p[2]);
        add(gold, knot, C('#e0b050'));
        const t = Geometry.lathe([[0.0, -0.36], [0.06, -0.33], [0.045, -0.12], [0.02, 0.0], [0.0, 0.02]], 7, {});
        t.translate(p[0] + sd * 0.02, p[1] - 0.04, p[2]);
        add(cloth, t, k % 2 ? C('#b44a7c') : C('#d8a848'));
      }
    }
  }

  // ---- leather girth straps round the whole body, a collar in front of the blowhole, buckles
  const strap = (zc, wdt, th0 = -Math.PI, th1 = Math.PI) => {
    const full = th1 - th0 > TAU - 1e-3;
    const NTH = full ? 72 : 40, g = new Geometry();
    const rows = [-wdt, -wdt * 0.7, wdt * 0.7, wdt];
    const grid = rows.map((dz) => {
      const r = [];
      for (let j = 0; j < (full ? NTH : NTH + 1); j++) {
        const th = th0 + (j / NTH) * (th1 - th0);
        const p = onSkin(zc + dz, th, 0.07);
        r.push(g.vert(p[0], p[1], p[2]));
      }
      return r;
    });
    for (let k = 0; k < rows.length - 1; k++) for (let j = 0; j < NTH; j++) {
      const j2 = full ? (j + 1) % NTH : j + 1;
      g.quad(grid[k][j], grid[k][j2], grid[k + 1][j2], grid[k + 1][j]);
    }
    g.computeNormals();
    g.paint((p) => (Math.abs(p[2] - zc) > wdt * 0.8 ? C('#b08858') : C('#6a3e2a')).concat([1]));
    leather.append(g);
    if (!full) {
      // open ends: a gold ring holds each end
      for (const th of [th0, th1]) {
        const p = onSkin(zc, th, 0.1);
        const rr = Geometry.torus(0.12, 0.03, 6, 14);
        rr.rotateZ(Math.PI / 2);
        rr.translate(p[0], p[1], p[2]);
        add(gold, rr, C('#e4b85a'));
      }
      return;
    }
    for (const sd of [-1, 1]) {
      const th = sd > 0 ? 0.25 : Math.PI - 0.25;
      const p = onSkin(zc, th, 0.1);
      const bk = Geometry.torus(0.2, 0.035, 6, 16);
      bk.rotateZ(Math.PI / 2);
      bk.scale(1, 1.25, 1);
      bk.translate(p[0], p[1], p[2]);
      add(gold, bk, C('#e4b85a'));
    }
    // a ring under the belly
    const pb = onSkin(zc, -Math.PI / 2, 0.12);
    const ring = Geometry.torus(0.16, 0.035, 6, 14);
    ring.rotateX(Math.PI / 2);
    ring.translate(pb[0], pb[1] - 0.12, pb[2]);
    add(gold, ring, C('#e4b85a'));
  };
  strap(0.55, 0.19);
  strap(3.5, 0.19);
  // a head band behind the pearls for the reins
  const HB = 8.2, HTH = 0.4;
  strap(HB, 0.13, HTH, Math.PI - HTH);

  // ---- the deck: planks inside a rim, and a drape that hangs from the deck down to the rug
  {
    const NPK = 12, pw = (RX * 2) / NPK;
    for (let k = 0; k < NPK; k++) {
      const x = -RX + (k + 0.5) * pw;
      const len = 2 * RZ * Math.sqrt(Math.max(0.04, 1 - Math.pow(Math.abs(x) + pw * 0.5, 2) / (RX * RX)));
      const pk = Geometry.box(pw - 0.025, 0.1, len, { y0: -0.1 });
      pk.translate(x, DECK, O[2]);
      add(wood, pk, mix3(C('#6b4a34'), C('#8a6444'), (k * 0.37) % 1));
    }
    const rimPts = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * TAU;
      rimPts.push([Math.cos(a) * RX, DECK - 0.04, O[2] + Math.sin(a) * RZ]);
    }
    const rim = Geometry.tube(rimPts, rimPts.map(() => 0.08), 8, { capStart: false, capEnd: false });
    add(wood, rim, C('#4a3024'));
    // drape
    const NP = 72, dr = new Geometry();
    const top = [], bot = [];
    for (let i = 0; i < NP; i++) {
      const a = (i / NP) * TAU;
      const x = Math.cos(a) * RX * 1.02, z = O[2] + Math.sin(a) * RZ * 1.02;
      const th = thAtX(z, x);
      const s = whaleSkin(z, th);
      const yb = Math.min(DECK - 0.1, s[1] + 0.02);
      top.push(dr.vert(x, DECK - 0.06, z));
      bot.push(dr.vert(x, yb - 0.04, z));
    }
    for (let i = 0; i < NP; i++) { const i2 = (i + 1) % NP; dr.quad(top[i], top[i2], bot[i2], bot[i]); }
    dr.computeNormals();
    dr.paint((p) => (p[1] > DECK - 0.14 ? C('#d8a848') : C('#2a347e')).concat([1]));
    cloth.append(dr);
  }

  // ---- balustrade: turned posts with gold knobs and a rail, open at the back
  const postAt = (a) => [Math.cos(a) * (RX - 0.1), O[2] + Math.sin(a) * (RZ - 0.1)];
  const GAP0 = -Math.PI / 2 - 0.42, GAP1 = -Math.PI / 2 + 0.42;
  const inGap = (a) => { let d = a - GAP0; d -= Math.floor(d / TAU) * TAU; return d < GAP1 - GAP0; };
  const canopyA = [Math.PI / 4, (3 * Math.PI) / 4, (5 * Math.PI) / 4, (7 * Math.PI) / 4];
  {
    const NPOST = 22;
    for (let k = 0; k < NPOST; k++) {
      const a = (k / NPOST) * TAU + 0.07;
      if (inGap(a) || canopyA.some((c) => Math.abs(Math.atan2(Math.sin(a - c), Math.cos(a - c))) < 0.12)) continue;
      const [x, z] = postAt(a);
      const p = Geometry.lathe([[0.045, 0], [0.04, 0.08], [0.028, 0.14], [0.042, 0.26], [0.026, 0.4], [0.034, 0.5], [0.03, 0.52]], 8, {});
      p.translate(x, DECK, z);
      add(wood, p, C('#5a3a28'));
    }
    for (const k of [0, 1]) {
      const y = DECK + (k ? 0.54 : 0.22), r = k ? 0.038 : 0.022;
      const pts = [];
      for (let i = 0; i <= 48; i++) {
        const a = GAP1 + (i / 48) * (TAU - (GAP1 - GAP0));
        const [x, z] = postAt(a);
        pts.push([x, y, z]);
      }
      add(wood, Geometry.tube(pts, pts.map(() => r), 7, { capStart: true, capEnd: true }), C('#6a4430'));
      for (const e of [pts[0], pts[pts.length - 1]]) {
        const kb = egg(0.06, 0.06, 0.06, 8, 6);
        kb.translate(e[0], e[1] + (k ? 0.03 : 0), e[2]);
        add(gold, kb, C('#e4b85a'));
      }
    }
  }

  // ---- the seat: a leather saddle with a high back, a pommel with a little bell, reins to the collar
  {
    const SZ = O[2];
    const pad = egg(0.36, 0.1, 0.44, 16, 8);
    pad.translate(0, DECK + 0.06, SZ - 0.02);
    add(leather, pad, C('#7a3a2c'));
    const quilt = egg(0.3, 0.06, 0.36, 14, 6);
    quilt.translate(0, DECK + 0.11, SZ - 0.02);
    add(cloth, quilt, C('#b44a7c'));
    const cantle = Geometry.torus(0.3, 0.075, 8, 18, Math.PI);
    cantle.rotateX(-Math.PI / 2);
    cantle.rotateX(-0.3);
    cantle.scale(1, 1.1, 1);
    cantle.translate(0, DECK + 0.1, SZ - 0.32);
    add(leather, cantle, C('#6a3024'));
    const back = egg(0.3, 0.26, 0.07, 14, 8);
    back.rotateX(-0.3);
    back.translate(0, DECK + 0.3, SZ - 0.44);
    add(leather, back, C('#7a3a2c'));
    const pom = Geometry.lathe([[0.08, 0], [0.07, 0.1], [0.045, 0.22], [0.07, 0.3], [0.0, 0.36]], 10, {});
    pom.translate(0, DECK + 0.02, SZ + 0.5);
    add(leather, pom, C('#6a3024'));
    const horn = egg(0.06, 0.05, 0.06, 8, 6);
    horn.translate(0, DECK + 0.38, SZ + 0.5);
    add(gold, horn, C('#e4b85a'));
    const bell = Geometry.lathe([[0.0, -0.13], [0.07, -0.12], [0.06, -0.06], [0.04, 0.0], [0.0, 0.02]], 10, {});
    bell.translate(0, DECK + 0.3, SZ + 0.6);
    add(gold, bell, C('#f0c860'));
    // reins: from the pommel over the back to rings on the collar
    for (const sd of [-1, 1]) {
      const a = [sd * 0.06, DECK + 0.3, SZ + 0.55], b = onSkin(HB, Math.PI / 2 - sd * (Math.PI / 2 - HTH - 0.12), 0.12);
      const pts = [];
      for (let i = 0; i <= 28; i++) {
        const t = i / 28;
        const x = lerp(a[0], b[0], t), z = lerp(a[2], b[2], t);
        let y = lerp(a[1], b[1], t) - Math.sin(Math.PI * t) * 0.16;
        y = Math.max(y, whaleSkin(z, thAtX(z, x))[1] + 0.07);
        pts.push([x, y, z]);
      }
      add(leather, rope(pts, 0.022, 0.022, 5), C('#4a2a1c'));
    }
    // cushions round the seat, each with a gold button
    const cush = [[0.84, -0.62, '#2f7f8a'], [-0.84, -0.62, '#b0507a'], [0.9, 0.5, '#c89a3a'], [-0.9, 0.5, '#7a5ab0']];
    for (const [x, dz, hex] of cush) {
      const c = egg(0.3, 0.14, 0.28, 14, 8);
      c.displace((p) => -0.03 * Math.exp(-(p[0] * p[0] + p[2] * p[2]) / 0.004) * (p[1] > 0 ? 1 : 0), true);
      c.rotateY(Math.atan2(x, dz) * 0.3);
      c.translate(x, DECK + 0.12, SZ + dz);
      add(cloth, c, C(hex));
      const btn = egg(0.035, 0.025, 0.035, 6, 4);
      btn.translate(x, DECK + 0.235, SZ + dz);
      add(gold, btn, C('#e4b85a'));
    }
    // a little chest behind the seat
    const ch = Geometry.box(0.5, 0.28, 0.32, { y0: 0 });
    ch.rotateY(0.35);
    ch.translate(-0.55, DECK, SZ - 1.05);
    add(wood, ch, C('#6a4028'));
    const lid = Geometry.cylinder(0.16, 0.16, 0.5, 10, 1);
    lid.rotateZ(Math.PI / 2);
    lid.translate(0.25, 0, 0);
    lid.scale(1, 0.6, 1);
    lid.rotateY(0.35);
    lid.translate(-0.55, DECK + 0.28, SZ - 1.05);
    add(wood, lid, C('#7a4c30'));
    for (const dx of [-0.17, 0.17]) {
      const band = Geometry.box(0.045, 0.3, 0.34, { y0: 0 });
      band.translate(dx, 0, 0);
      band.rotateY(0.35);
      band.translate(-0.55, DECK, SZ - 1.05);
      add(gold, band, C('#d8a848'));
    }
  }

  // ---- the canopy: four posts, an onion dome in gores, a scalloped valance, lanterns and fairy lights
  {
    const HEM = DECK + 2.35;
    const DX = 1.62, DZ = 1.88;
    const domeProf = [[1.0, 0.0], [0.97, 0.14], [0.9, 0.3], [0.74, 0.5], [0.5, 0.68], [0.28, 0.82], [0.12, 0.95], [0.0, 1.08]];
    const domeY = (r) => {
      for (let i = 0; i < domeProf.length - 1; i++) {
        const [r0, y0] = domeProf[i], [r1, y1] = domeProf[i + 1];
        if (r <= r0 && r >= r1) return lerp(y0, y1, (r0 - r) / (r0 - r1));
      }
      return 1.08;
    };
    const NPHI = 64, NR = domeProf.length;
    const dome = new Geometry();
    const rows = [];
    for (let i = 0; i < NR; i++) {
      const [r, y] = domeProf[i];
      const row = [];
      for (let j = 0; j < NPHI; j++) {
        const a = (j / NPHI) * TAU;
        const bulge = 1 + 0.03 * Math.cos(a * 8) * (i > 0 && i < NR - 1 ? 1 : 0);
        row.push(dome.vert(Math.cos(a) * r * DX * bulge, HEM + y * 0.8, O[2] + Math.sin(a) * r * DZ * bulge, 0, 1, 0, j / NPHI, i / (NR - 1)));
      }
      rows.push(row);
    }
    for (let i = 0; i < NR - 1; i++) for (let j = 0; j < NPHI; j++) {
      const j2 = (j + 1) % NPHI;
      dome.quad(rows[i][j], rows[i + 1][j], rows[i + 1][j2], rows[i][j2]);
    }
    dome.computeNormals();
    dome.paint((p, nn, i) => {
      const u = dome.uv[i * 2];
      const gore = Math.floor(u * 8);
      const f = u * 8 - gore;
      let c = gore % 2 ? C('#5a3a9a') : C('#2c2f7a');
      if (f < 0.07 || f > 0.93) c = C('#d8a848');
      return c.concat([1]);
    });
    cloth.append(dome);
    // gold trim round the rim and the valance below it
    const trim = [];
    for (let i = 0; i <= 96; i++) { const a = (i / 96) * TAU; trim.push([Math.cos(a) * DX, HEM, O[2] + Math.sin(a) * DZ]); }
    add(gold, Geometry.tube(trim, trim.map(() => 0.045), 6, { capStart: false, capEnd: false }), C('#e0b050'));
    const NV = 128, val = new Geometry(), vt = [], vb = [];
    const SC = 16;
    for (let i = 0; i < NV; i++) {
      const a = (i / NV) * TAU;
      const x = Math.cos(a) * DX * 1.005, z = O[2] + Math.sin(a) * DZ * 1.005;
      const drop = 0.14 + 0.16 * Math.pow(Math.abs(Math.sin((a * SC) / 2)), 0.7);
      vt.push(val.vert(x, HEM, z));
      vb.push(val.vert(x, HEM - drop, z));
    }
    for (let i = 0; i < NV; i++) { const i2 = (i + 1) % NV; val.quad(vt[i], vt[i2], vb[i2], vb[i]); }
    val.computeNormals();
    val.paint((p) => (p[1] > HEM - 0.06 ? C('#d8a848') : C('#8a3a7a')).concat([1]));
    cloth.append(val);
    for (let k = 0; k < SC; k++) {
      const a = ((k + 0.5) / SC) * TAU;
      const x = Math.cos(a) * DX * 1.005, z = O[2] + Math.sin(a) * DZ * 1.005;
      const y = HEM - 0.3;
      if (k % 2) {
        const t = Geometry.lathe([[0.0, -0.22], [0.045, -0.2], [0.035, -0.07], [0.015, 0.0], [0.0, 0.02]], 7, {});
        t.translate(x, y + 0.02, z);
        add(cloth, t, C('#d8a848'));
      } else {
        const b = egg(0.05, 0.06, 0.05, 8, 6);
        b.translate(x, y - 0.04, z);
        b.setExtra([3]);
        add(glow, b, C('#ffe2a0'));
      }
    }
    // posts: from the deck up into the dome's underside, turned, with gold bands
    for (const a of canopyA) {
      const [x, z] = postAt(a);
      const rN = Math.hypot(x / DX, (z - O[2]) / DZ);
      const topY = HEM + domeY(rN) * 0.8 + 0.02;
      const prof = [[0.06, 0], [0.05, 0.1], [0.04, 0.3]];
      const H = topY - DECK;
      for (let k = 1; k <= 6; k++) prof.push([k % 2 ? 0.05 : 0.036, 0.3 + (k / 6) * (H - 0.5)]);
      prof.push([0.045, H - 0.12], [0.04, H]);
      const post = Geometry.lathe(prof, 8, {});
      post.translate(x, DECK, z);
      add(wood, post, C('#5a3a28'));
      for (const hy of [0.32, H * 0.55, H - 0.14]) {
        const band = Geometry.torus(0.052, 0.018, 5, 12);
        band.translate(x, DECK + hy, z);
        add(gold, band, C('#e4b85a'));
      }
    }
    // hanging lanterns on the two front posts
    for (const a of [Math.PI / 4, (3 * Math.PI) / 4]) {
      const [x, z] = postAt(a);
      const d = [Math.cos(a), Math.sin(a) * 0.6];
      const dl = Math.hypot(d[0], d[1]);
      const ex = x + (d[0] / dl) * 0.36, ez = z + (d[1] / dl) * 0.36;
      const hy = DECK + 1.95;
      const arm = [[x, hy - 0.12, z], [lerp(x, ex, 0.5), hy + 0.02, lerp(z, ez, 0.5)], [ex, hy, ez], [ex, hy - 0.08, ez]];
      add(gold, rope(arm, 0.02, 0.018, 5), C('#c89a3a'));
      add(gold, rope([[ex, hy - 0.08, ez], [ex, hy - 0.26, ez]], 0.008, 0.008, 4), C('#c89a3a'));
      const cap = Geometry.lathe([[0.1, 0], [0.07, 0.06], [0.02, 0.1], [0.0, 0.12]], 8, { capBottom: true });
      cap.translate(ex, hy - 0.26, ez);
      add(gold, cap, C('#e4b85a'));
      const lamp = egg(0.085, 0.14, 0.085, 10, 8);
      lamp.translate(ex, hy - 0.4, ez);
      lamp.setExtra([3]);
      add(glow, lamp, C('#ffd08a'));
      const base = Geometry.lathe([[0.0, -0.08], [0.06, -0.05], [0.09, 0.0]], 8, {});
      base.translate(ex, hy - 0.52, ez);
      add(gold, base, C('#e4b85a'));
    }
    // finial: a gold stem, a ball and a glowing crescent moon
    const TOP = HEM + domeProf[NR - 1][1] * 0.8;
    const stem = Geometry.lathe([[0.07, 0], [0.04, 0.12], [0.03, 0.3], [0.0, 0.32]], 8, {});
    stem.translate(0, TOP - 0.04, O[2]);
    add(gold, stem, C('#e4b85a'));
    const ball = egg(0.09, 0.09, 0.09, 10, 8);
    ball.translate(0, TOP + 0.14, O[2]);
    add(gold, ball, C('#f0c860'));
    const moon = Geometry.torus(0.2, 0.05, 6, 18, Math.PI * 1.25);
    moon.rotateZ(-Math.PI * 0.12);
    moon.rotateX(Math.PI / 2);
    moon.translate(0, TOP + 0.52, O[2]);
    moon.setExtra([2.4]);
    add(glow, moon, C('#ffe6a0'));
  }

  const toLocal = (gg) => { gg.translate(-O[0], -O[1], -O[2]); return gg; };
  n.add(mesh(ctx, toLocal(wood), M.fineWood, 'saddleWood'));
  n.add(mesh(ctx, toLocal(cloth), M.silk, 'saddleCloth'));
  n.add(mesh(ctx, toLocal(leather), M.leather, 'saddleLeather'));
  n.add(mesh(ctx, toLocal(gold), M.glossy, 'saddleGold'));
  n.add(mesh(ctx, toLocal(glow), M.glow, 'saddleGlow'));
  return { node: n, seat: [0, 4.67, 2.4] };
}
