// Set pieces: the wizard's hut, cauldron, castle in the stone hand, gate, watcher stone,
// pyramid, rune circle, moon statue, pier, lanterns. Builders work in local space and return
// { root, colliders, platforms, lights, anchors } in LOCAL coordinates (placed by world.js).
import { Geometry, catmullRom } from '../engine/geometry.js';
import { Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep, vnorm } from '../engine/math.js';
import { C } from './materials.js';
import { makeMesh } from './characters.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

function result() {
  return { root: new Node(), colliders: [], platforms: [], surfaces: [], lights: [], anchors: {} };
}

function stoneRing(radius, height, seg, seed, color = '#3a3f58') {
  const g = Geometry.cylinder(radius, radius * 1.05, height, seg, 2, { capTop: true, capBottom: false });
  g.displace((p) => noise.n3(p[0] * 1.3 + seed, p[1] * 2.1, p[2] * 1.3) * 0.12, true);
  g.paint((p, n) => {
    const v = noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.5 + 0.5;
    return mix3(C(color, 0.6), C(color, 1.3), v).concat([1]);
  });
  return g;
}

// ------------------------------------------------------------------ wizard's hut
export function buildHut(ctx) {
  const { M } = ctx;
  const R = result();
  const rng = new RNG(42);
  const wallR = 3.0, wallH = 2.9;
  // foundation
  const found = stoneRing(wallR + 0.35, 0.55, 22, 1);
  found.translate(0, -0.3, 0);
  R.root.add(makeMesh(ctx, found, M.stone));
  // walls: slightly crooked cylinder
  const wall = Geometry.lathe([[wallR, 0.2], [wallR * 0.99, 1.2], [wallR * 0.96, 2.2], [wallR * 0.95, wallH]], 28, {});
  wall.deform((p) => [p[0] + p[1] * 0.04, p[1], p[2]]);
  wall.computeNormals();
  wall.paint((p) => {
    const v = noise.n3(p[0] * 1.5, p[1] * 1.5, p[2] * 1.5) * 0.5 + 0.5;
    return mix3(C('#3e3d57'), C('#6a6886'), v).concat([smoothstep(0.1, 1.2, p[1]) * 0.35 + 0.65]);
  });
  R.root.add(makeMesh(ctx, wall, M.stoneFine));
  // timber beams
  const beams = new Geometry();
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * TAU + 0.15;
    const b = Geometry.box(0.22, wallH + 0.1, 0.16, { y0: 0.15 });
    b.rotateY(-a + Math.PI / 2);
    b.deform((p) => [p[0] + p[1] * 0.04, p[1], p[2]]);
    b.translate(Math.cos(a) * (wallR + 0.02), 0, Math.sin(a) * (wallR + 0.02));
    beams.append(b);
  }
  const ringBeam = Geometry.torus(wallR + 0.04, 0.12, 5, 30);
  ringBeam.translate(0.1, wallH - 0.05, 0);
  beams.append(ringBeam);
  const ring2 = Geometry.torus(wallR + 0.05, 0.1, 5, 30);
  ring2.translate(0.05, 1.3, 0);
  beams.append(ring2);
  beams.setColor(C('#3a2c26'), 0.9);
  R.root.add(makeMesh(ctx, beams, M.wood));
  // roof: crooked wizard-hat cone with shingle rows
  const roofH = 6.6;
  const roofProf = [];
  for (let j = 0; j <= 30; j++) {
    const t = j / 30;
    const r = (wallR + 0.9) * Math.pow(1 - t, 1.15) + 0.03;
    roofProf.push([r, wallH - 0.35 + t * roofH]);
  }
  const roof = Geometry.lathe(roofProf, 30);
  roof.deform((p) => {
    const t = (p[1] - wallH) / roofH;
    const rr = Math.hypot(p[0], p[2]);
    // shingle rows: sawtooth in radius
    const row = (t * 16) % 1;
    const k = 1 + row * 0.05 * (1 - t);
    const bend = Math.pow(Math.max(t, 0), 2.2);
    return [p[0] * k + bend * 1.6 + 0.1, p[1] - bend * 0.6, p[2] * k + bend * 0.5];
  });
  roof.computeNormals();
  roof.paint((p, n) => {
    const v = noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.5 + 0.5;
    let c = mix3(C('#1f2350'), C('#3b418a'), v);
    c = mix3(c, C('#1e4a4a'), smoothstep(0.3, 0.9, noise.n3(p[0] * 0.8, p[1] * 0.8, p[2] * 0.8)) * 0.5);
    return c.concat([1]);
  });
  R.root.add(makeMesh(ctx, roof, M.moss));
  // eave lip
  const eave = Geometry.torus(wallR + 0.85, 0.12, 5, 30);
  eave.translate(0.12, wallH - 0.37, 0);
  eave.setColor(C('#2b2c52'), 1);
  R.root.add(makeMesh(ctx, eave, M.wood));
  // door (faces +Z)
  const door = new Geometry();
  const dz = wallR - 0.02;
  const slab = Geometry.box(1.2, 1.7, 0.14, { y0: 0.2 });
  const arch = Geometry.cylinder(0.6, 0.6, 0.14, 14, 1);
  arch.rotateX(Math.PI / 2);
  arch.translate(0, 1.9, -0.07);
  slab.append(arch);
  slab.deform((p) => [p[0], Math.min(p[1], 1.9 + Math.sqrt(Math.max(0, 0.36 - p[0] * p[0]))), p[2]]);
  slab.computeNormals();
  slab.paint((p) => mix3(C('#3a2a22'), C('#5e4434'), Math.abs(Math.sin(p[0] * 9)) ).concat([0.9]));
  slab.translate(0, 0, dz + 0.1);
  door.append(slab);
  const frame = Geometry.torus(0.68, 0.09, 6, 16, Math.PI);
  frame.rotateX(Math.PI / 2);
  frame.rotateZ(0);
  frame.translate(0, 1.9, dz + 0.18);
  frame.setColor(C('#2a211c'), 1);
  door.append(frame);
  for (const s of [-1, 1]) {
    const post = Geometry.box(0.16, 1.75, 0.18, { y0: 0.15 });
    post.translate(s * 0.68, 0, dz + 0.18);
    post.setColor(C('#2a211c'), 1);
    door.append(post);
  }
  // round window in the door
  const dw = Geometry.disc(0.16, 12);
  dw.rotateX(Math.PI / 2);
  dw.translate(0, 1.55, dz + 0.19);
  dw.setColor(C('#ffb760'), 1);
  dw.setExtra([2.2]);
  door.append(dw);
  // handle
  const handle = Geometry.torus(0.06, 0.015, 4, 10);
  handle.rotateX(Math.PI / 2);
  handle.translate(0.4, 1.1, dz + 0.2);
  handle.setColor(C('#b89a5a'), 1);
  door.append(handle);
  R.root.add(makeMesh(ctx, door, M.wood));
  // windows with warm glow
  const win = new Geometry();
  const winAngles = [2.2, 0.55, -0.4, 3.6];
  for (const a of winAngles) {
    const cx = Math.cos(a) * (wallR + 0.05), cz = Math.sin(a) * (wallR + 0.05);
    const w = Geometry.disc(0.36, 16);
    w.rotateX(Math.PI / 2);
    w.translate(0, 1.75, 0.05);
    w.setColor(C('#ffae57'), 1);
    w.setExtra([2.4]);
    const fr = Geometry.torus(0.38, 0.07, 5, 16);
    fr.rotateX(Math.PI / 2);
    fr.translate(0, 1.75, 0.08);
    fr.setColor(C('#2a211c'), 1);
    const cross1 = Geometry.box(0.72, 0.05, 0.05);
    cross1.translate(0, 1.75, 0.1);
    const cross2 = Geometry.box(0.05, 0.72, 0.05);
    cross2.translate(0, 1.75, 0.1);
    cross1.setColor(C('#2a211c'), 1); cross2.setColor(C('#2a211c'), 1);
    w.append(fr); w.append(cross1); w.append(cross2);
    w.rotateY(Math.PI / 2 - a);
    w.translate(cx + 0.06, 0, cz);
    win.append(w);
    R.lights.push({ pos: [Math.cos(a) * (wallR + 0.9), 1.8, Math.sin(a) * (wallR + 0.9)], color: C('#ff9a45'), intensity: 2.2, radius: 5.5, flicker: 0.08 });
  }
  R.root.add(makeMesh(ctx, win, M.glowSoft));
  // chimney
  const ch = Geometry.box(0.8, 3.2, 0.8, { y0: 0 });
  ch.deform((p) => [p[0] * (1 - p[1] * 0.04), p[1], p[2] * (1 - p[1] * 0.04)]);
  ch.displace((p) => noise.n3(p[0] * 4, p[1] * 4, p[2] * 4) * 0.05, false);
  ch.paint((p) => mix3(C('#34384e'), C('#5b6180'), noise.n3(p[0] * 5, p[1] * 5, p[2] * 5) * 0.5 + 0.5).concat([1]));
  ch.translate(-1.6, wallH + 1.0, -0.9);
  R.root.add(makeMesh(ctx, ch, M.stone));
  R.anchors.chimney = [-1.6, wallH + 4.3, -0.9];
  // porch lantern
  const lan = lantern();
  lan.translate(1.05, 2.25, dz + 0.45);
  R.root.add(makeMesh(ctx, lan.frame, M.metal));
  const lg = lan.glass;
  lg.translate(1.05, 2.25, dz + 0.45);
  R.root.add(makeMesh(ctx, lg, M.glowSoft));
  R.lights.push({ pos: [1.05, 2.0, dz + 0.6], color: C('#ffb060'), intensity: 3.0, radius: 9, flicker: 0.15 });
  // bench, barrels, potion shelf
  const props = new Geometry();
  const bench = Geometry.box(1.6, 0.1, 0.45, { y0: 0.45 });
  for (const s of [-1, 1]) {
    const leg = Geometry.box(0.1, 0.45, 0.4, { y0: 0 });
    leg.translate(s * 0.65, 0, 0);
    bench.append(leg);
  }
  bench.rotateY(0.5);
  bench.translate(-2.2, 0.2, 3.0);
  bench.setColor(C('#4a3a30'), 0.9);
  props.append(bench);
  for (let i = 0; i < 2; i++) {
    const barrel = Geometry.lathe([[0.32, 0], [0.38, 0.35], [0.32, 0.72]], 12, { capTop: true });
    barrel.translate(2.6 + i * 0.7, 0.2, 1.8 - i * 0.5);
    barrel.paint((p) => mix3(C('#3f3028'), C('#5a4636'), Math.abs(Math.sin(Math.atan2(p[2], p[0]) * 10))).concat([0.9]));
    props.append(barrel);
  }
  R.root.add(makeMesh(ctx, props, M.planks));
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: wallR + 0.45 });
  R.colliders.push({ type: 'circle', x: 2.6, z: 1.8, r: 0.45 }, { type: 'circle', x: 3.3, z: 1.3, r: 0.45 });
  R.anchors.door = [0, 0, dz + 0.6];
  return R;
}

export function lantern() {
  const frame = new Geometry();
  const top = Geometry.cylinder(0.0, 0.16, 0.14, 6, 1);
  top.translate(0, 0.2, 0);
  const bottom = Geometry.cylinder(0.12, 0.1, 0.05, 6, 1);
  bottom.translate(0, -0.2, 0);
  frame.append(top);
  frame.append(bottom);
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * TAU + 0.4;
    const bar = Geometry.box(0.018, 0.42, 0.018);
    bar.translate(Math.cos(a) * 0.11, 0, Math.sin(a) * 0.11);
    frame.append(bar);
  }
  const ringT = Geometry.torus(0.04, 0.012, 4, 8);
  ringT.rotateX(Math.PI / 2);
  ringT.translate(0, 0.36, 0);
  frame.append(ringT);
  frame.setColor(C('#26242c'), 1);
  const glass = Geometry.cylinder(0.09, 0.09, 0.34, 8, 1);
  glass.translate(0, -0.17, 0);
  glass.setColor(C('#ffc070'), 1);
  glass.setExtra([3.0]);
  const flame = { frame, glass, translate(x, y, z) { frame.translate(x, y, z); } };
  return flame;
}

export function buildLampPost(ctx) {
  const { M } = ctx;
  const R = result();
  const g = new Geometry();
  const pts = [];
  for (let i = 0; i <= 6; i++) {
    const t = i / 6;
    pts.push([Math.sin(t * 2.4) * 0.12, t * 2.6, 0]);
  }
  const post = Geometry.tube(pts, (t) => 0.09 * (1 - t * 0.35), 6, { capEnd: true });
  const arm = Geometry.tube(catmullRom([[0.05, 2.45, 0], [0.4, 2.7, 0], [0.8, 2.6, 0], [0.9, 2.45, 0]], 3), (t) => 0.04, 5);
  g.append(post);
  g.append(arm);
  g.setColor(C('#2e2620'), 1);
  R.root.add(makeMesh(ctx, g, M.wood));
  const lan = lantern();
  lan.translate(0.9, 2.1, 0);
  R.root.add(makeMesh(ctx, lan.frame, M.metal));
  R.root.add(makeMesh(ctx, lan.glass, M.glowSoft));
  R.lights.push({ pos: [0.9, 1.95, 0], color: C('#ffae5c'), intensity: 2.6, radius: 8, flicker: 0.12 });
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: 0.2 });
  return R;
}

// ------------------------------------------------------------------ cauldron
export function buildCauldron(ctx) {
  const { M } = ctx;
  const R = result();
  const pot = Geometry.lathe(catmullRom([[0.25, 0.15], [0.52, 0.28], [0.66, 0.6], [0.62, 0.92], [0.55, 1.05], [0.6, 1.1], [0.64, 1.13]], 3), 24);
  // inner wall
  const inner = Geometry.lathe([[0.5, 1.12], [0.54, 1.0], [0.56, 0.8]], 24);
  // flip inner normals by reversing via scale
  inner.scale(1, 1, 1);
  pot.append(inner);
  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * TAU;
    const leg = Geometry.cylinder(0.05, 0.08, 0.35, 6, 1);
    leg.rotateZ(0.3);
    leg.rotateY(-a);
    leg.translate(Math.cos(a) * 0.4, -0.02, Math.sin(a) * 0.4);
    pot.append(leg);
  }
  const rim = Geometry.torus(0.61, 0.05, 6, 24);
  rim.translate(0, 1.12, 0);
  pot.append(rim);
  pot.displace((p) => noise.n3(p[0] * 8, p[1] * 8, p[2] * 8) * 0.008, true);
  pot.paint((p) => mix3(C('#1d1e26'), C('#3a3c4c'), noise.n3(p[0] * 4, p[1] * 4, p[2] * 4) * 0.5 + 0.5).concat([1]));
  R.root.add(makeMesh(ctx, pot, M.metal));
  // brew surface
  const brew = Geometry.disc(0.56, 24);
  brew.translate(0, 1.02, 0);
  brew.setColor(C('#63ff9c'), 1);
  brew.setExtra([1.6]);
  const brewMesh = makeMesh(ctx, brew, M.glowSoft);
  R.root.add(brewMesh);
  R.anchors.brew = brewMesh;
  // firewood + stones
  const wood = new Geometry();
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * TAU + 0.3;
    const l = Geometry.cylinder(0.07, 0.08, 0.9, 6, 1);
    l.rotateZ(Math.PI / 2 - 0.35);
    l.rotateY(-a);
    l.translate(Math.cos(a) * 0.3, 0.05, Math.sin(a) * 0.3);
    wood.append(l);
  }
  wood.paint((p) => mix3(C('#2a1f1a'), C('#ff6a2a'), smoothstep(0.35, 0.05, Math.hypot(p[0], p[2]))).concat([1]));
  wood.paintExtra((p) => [smoothstep(0.35, 0.0, Math.hypot(p[0], p[2])) * 1.5]);
  R.root.add(makeMesh(ctx, wood, M.wood));
  const stones = new Geometry();
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * TAU;
    const s = Geometry.icosphere(0.18, 1);
    s.scale(1, 0.7, 1);
    s.displace((p) => noise.n3(p[0] * 9 + i, p[1] * 9, p[2] * 9) * 0.04, true);
    s.translate(Math.cos(a) * 0.85, 0.05, Math.sin(a) * 0.85);
    stones.append(s);
  }
  stones.setColor(C('#4a4f66'), 0.9);
  R.root.add(makeMesh(ctx, stones, M.stone));
  R.lights.push({ pos: [0, 0.5, 0], color: C('#ff7a30'), intensity: 3.2, radius: 7, flicker: 0.35, priority: 10 });
  R.lights.push({ pos: [0, 1.6, 0], color: C('#4dff90'), intensity: 1.6, radius: 5, flicker: 0.1 });
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: 0.95 });
  R.anchors.fire = [0, 0.2, 0];
  R.anchors.top = [0, 1.05, 0];
  return R;
}

// ------------------------------------------------------------------ castle + stone hand
function finger(base, dir, len, radius, curl, seed, nails = null) {
  const pts = [];
  const n = 18;
  let p = base.slice();
  let d = vnorm(dir);
  for (let i = 0; i <= n; i++) {
    pts.push(p.slice());
    const t = i / n;
    // curl towards +z (the palm side) progressively, mostly at the two joints
    const joint = 0.5 + 1.1 * Math.exp(-(((t - 0.36) / 0.1) ** 2)) + 1.1 * Math.exp(-(((t - 0.68) / 0.1) ** 2));
    d = vnorm([d[0], d[1], d[2] + curl * 0.09 * joint * (12 / n)]);
    p = [p[0] + d[0] * len / n, p[1] + d[1] * len / n, p[2] + d[2] * len / n];
  }
  // (v9) the finger starts deep inside the palm and its root is closed: before, the open end of the tube
  // stuck out of the back of the hand and you could see into (and through) the finger
  const d0 = vnorm(dir);
  const root = [];
  for (let k = 3; k >= 1; k--) root.push([base[0] - d0[0] * k * 3.2, base[1] - d0[1] * k * 3.2, base[2] - d0[2] * k * 3.2]);
  const all = root.concat(pts);
  const tipR = radius * 0.66;
  const radii = all.map((q, i) => {
    if (i < root.length) return radius * 1.04;
    const t = (i - root.length) / n;
    // knuckles swell, the finger narrows between them and towards the soft round tip
    const knuckle = 1 + 0.1 * Math.exp(-(((t - 0.36) / 0.07) ** 2)) + 0.08 * Math.exp(-(((t - 0.68) / 0.07) ** 2)) - 0.04 * Math.exp(-(((t - 0.52) / 0.08) ** 2));
    return Math.max(tipR, radius * (1 - t * 0.34) * knuckle);
  });
  const g = Geometry.tube(all, radii, 24, { capStart: true, capEnd: false });
  // (v9.1) a round fingertip instead of a flat cap and a claw
  const last = pts[pts.length - 1];
  const prev = pts[pts.length - 2];
  const td = vnorm([last[0] - prev[0], last[1] - prev[1], last[2] - prev[2]]);
  const tip = Geometry.sphere(tipR, 24, 14);
  tip.translate(last[0], last[1], last[2]);
  g.append(tip);
  // the nail, on the back of the tip (away from the palm)
  if (nails) {
    let back = [0, 0, -1];
    const k = back[0] * td[0] + back[1] * td[1] + back[2] * td[2];
    back = vnorm([back[0] - td[0] * k, back[1] - td[1] * k, back[2] - td[2] * k]);
    const side = vnorm([td[1] * back[2] - td[2] * back[1], td[2] * back[0] - td[0] * back[2], td[0] * back[1] - td[1] * back[0]]);
    const nl = Geometry.sphere(1, 18, 10);
    nl.scale(tipR * 0.62, tipR * 0.13, tipR * 0.95);
    // local frame: x = side, y = back (out of the nail), z = along the finger
    const c0 = [last[0] - td[0] * tipR * 0.55 + back[0] * tipR * 0.9, last[1] - td[1] * tipR * 0.55 + back[1] * tipR * 0.9, last[2] - td[2] * tipR * 0.55 + back[2] * tipR * 0.9];
    const m = new Float32Array([side[0], side[1], side[2], 0, back[0], back[1], back[2], 0, td[0], td[1], td[2], 0, c0[0], c0[1], c0[2], 1]);
    nl.applyMatrix(m);
    nails.append(nl);
  }
  return g;
}

export function buildStoneHand(ctx) {
  const { M } = ctx;
  const R = result();
  const hand = new Geometry();
  // (v9.1) the forearm: flattened like a real wrist and running up into the palm, so no round cuff pokes out of
  // the (much thinner) palm any more
  const arm = [];
  arm.push([0, -44, -8]);
  for (let i = 0; i <= 12; i++) {
    const t = i / 12;
    arm.push([Math.sin(t * 2) * 2, -28 + t * 70, -8 + t * 7.5]);
  }
  const armG = Geometry.tube(arm, (t, i) => (i === 0 ? 19.5 : 19 - ((i - 1) / 12) * 5.5 + Math.sin(((i - 1) / 12) * 9) * 0.6), 40, { capStart: true, capEnd: true });
  armG.deform((p) => {
    const t = Math.max(0, Math.min(1, (p[1] + 28) / 70));
    const xc = Math.sin(t * 2) * 2, zc = -8 + t * 7.5;
    const flat = lerp(1, 0.46, smoothstep(0.35, 0.95, t));
    // forearm muscles: a soft bulge on the back, tendons towards the wrist
    const tend = smoothstep(0.55, 0.9, t) * 0.35 * Math.max(0, Math.cos((p[0] - xc) * 0.9)) * (p[2] > zc ? 1 : 0);
    return [xc + (p[0] - xc) * lerp(1, 1.12, t), p[1], zc + (p[2] - zc) * flat + tend];
  });
  hand.append(armG);
  // palm: flattened ellipsoid, facing +z, a little cupped
  const palm = Geometry.sphere(1, 48, 34);
  palm.scale(22, 25, 9.5);
  palm.deform((p) => {
    const cup = p[2] > 0 ? -Math.exp(-((p[0] / 13) ** 2 + ((p[1] - 3) / 14) ** 2)) * 1.6 : 0;
    return [p[0] * (1 + (p[1] / 25) * 0.12), p[1], p[2] - Math.max(0, p[1]) * 0.05 + cup];
  });
  palm.translate(0, 52, 0);
  hand.append(palm);
  // thenar pad (thumb base) and heel of the hand
  const pad = Geometry.sphere(1, 28, 20);
  pad.scale(10, 13, 8);
  pad.translate(12, 40, 4);
  hand.append(pad);
  const pad2 = Geometry.sphere(1, 28, 20);
  pad2.scale(9, 10, 7);
  pad2.translate(-11, 38, 3);
  hand.append(pad2);
  // knuckle ridge on the back of the hand
  for (const [x, y] of [[-15.5, 66], [-5.5, 71], [5, 70.5], [14.5, 65]]) {
    const kn = Geometry.sphere(1, 18, 12);
    kn.scale(4.6, 3.6, 2.6);
    kn.translate(x, y - 1, -5.4);
    hand.append(kn);
  }
  // fingers: slightly spread, curling towards the viewer
  const fingers = [
    { x: -15.5, y: 68, len: 38, r: 5.6, spread: -0.28, curl: 1.5 },
    { x: -5.5, y: 74, len: 46, r: 6.2, spread: -0.08, curl: 1.1 },
    { x: 5.0, y: 73, len: 44, r: 6.1, spread: 0.08, curl: 1.25 },
    { x: 14.5, y: 67, len: 34, r: 5.3, spread: 0.3, curl: 1.7 },
  ];
  const nails = new Geometry();
  for (const f of fingers) {
    hand.append(finger([f.x, f.y, -1.5], [f.spread, 1, -0.05], f.len, f.r, f.curl, f.x, nails));
  }
  // thumb reaching out and up
  hand.append(finger([19, 40, 5], [0.9, 0.75, 0.55], 32, 6.6, 1.0, 9, nails));
  hand.weld(0.01);
  hand.computeNormals();
  // palm lines: three soft creases on the inside of the hand
  const lines = [
    [[-19, 62], [-8, 60.5], [3, 61.5], [12, 64]],            // heart line
    [[-18, 54], [-7, 52.5], [4, 51], [11, 48.5]],            // head line
    [[8, 58], [4, 50], [3, 42], [5, 33]],                    // life line, around the thumb pad
  ];
  const segD = (x, y, a, b) => {
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const u = Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / (dx * dx + dy * dy)));
    return Math.hypot(x - a[0] - dx * u, y - a[1] - dy * u);
  };
  const crease = (p) => {
    if (p[2] < 2 || p[1] < 28 || p[1] > 70) return 0;
    let d = Infinity;
    for (const L of lines) for (let i = 0; i < L.length - 1; i++) d = Math.min(d, segD(p[0], p[1], L[i], L[i + 1]));
    return Math.exp(-((d / 0.9) ** 2));
  };
  hand.displace((p) => {
    const n1 = noise.fbm3(p[0] * 0.08, p[1] * 0.08, p[2] * 0.08, 3);
    const crack = Math.pow(1 - Math.abs(noise.n3(p[0] * 0.05 + 3, p[1] * 0.03, p[2] * 0.05)), 12);
    return n1 * 1.3 - crack * 1.1 - crease(p) * 1.1;
  }, true);
  hand.paint((p, n) => {
    const v = noise.fbm3(p[0] * 0.05, p[1] * 0.05, p[2] * 0.05, 3) * 0.5 + 0.5;
    let c = mix3(C('#262a3e'), C('#6d7494'), v);
    // lichen and moss where rain collects (upward faces), darker in the creases
    c = mix3(c, C('#1d4442'), smoothstep(0.35, 0.8, n[1]) * 0.7);
    const lich = smoothstep(0.55, 0.8, noise.n3(p[0] * 0.09 + 7, p[1] * 0.09, p[2] * 0.09) * 0.5 + 0.5);
    c = mix3(c, C('#8a93a8'), lich * 0.35);
    c = mix3(c, C('#11131f'), crease(p) * 0.7);
    return c.concat([(smoothstep(-20, 60, p[1]) * 0.5 + 0.5) * (1 - crease(p) * 0.4)]);
  });
  nails.computeNormals();
  nails.paint((p, n) => mix3(C('#5e6784'), C('#a4acc4'), smoothstep(-0.2, 0.9, n[1]) * 0.5 + noise.n3(p[0] * 0.3, p[1] * 0.3, p[2] * 0.3) * 0.2).concat([0.95]));
  R.root.add(makeMesh(ctx, nails, M.stoneFine, 'handNails'));
  // a band of old runes around the wrist, glowing faintly like the moon gates
  const band = new Geometry();
  const bandG = new Geometry();
  for (let k = 0; k < 2; k++) {
    const y = 22 + k * 3.2, t = (y + 28) / 70;
    const xc = Math.sin(t * 2) * 2, zc = -8 + t * 7.5, rr = 19 - t * 5.5 + Math.sin(t * 9) * 0.6;
    const flat = lerp(1, 0.46, smoothstep(0.35, 0.95, t));
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * TAU;
      const bx = Math.cos(a) * rr * lerp(1, 1.12, t) * 1.03, bz = Math.sin(a) * rr * flat * 1.03;
      const st = Geometry.box(2.0, 1.1, 0.7);
      st.rotateY(-Math.atan2(bz, bx) + Math.PI / 2);
      st.translate(xc + bx, y, zc + bz);
      band.append(st);
      if ((i + k * 3) % 4 === 0) {
        const r = Geometry.box(0.25, 0.7, 0.2);
        r.rotateZ(((i * 37) % 5 - 2) * 0.35);
        r.rotateY(-Math.atan2(bz, bx) + Math.PI / 2);
        r.translate(xc + bx * 1.045, y, zc + bz * 1.045);
        bandG.append(r);
      }
    }
  }
  band.paint((p) => mix3(C('#2a2f46'), C('#4a5272'), noise.n3(p[0] * 0.4, p[1] * 0.4, p[2] * 0.4) * 0.5 + 0.5).concat([0.9]));
  R.root.add(makeMesh(ctx, band, M.farStone, 'handBand'));
  bandG.setColor(C('#b8a6ff'), 1);
  bandG.setExtra([2.2]);
  R.root.add(makeMesh(ctx, bandG, M.farGlow, 'handRunes'));
  // moss hanging from the fingers and the thumb
  const moss = new Geometry();
  const mrng = new RNG(77);
  for (let i = 0; i < 60; i++) {
    const f = fingers[i % 4];
    const t = mrng.range(0.15, 0.7);
    const x = f.x + f.spread * f.len * t + mrng.range(-3, 3), y = f.y + f.len * t * 0.85, z = -1.5 + t * 10 + f.r * 0.6;
    const len = mrng.range(2.5, 6.5);
    const pts = [];
    for (let k = 0; k <= 4; k++) pts.push([x + Math.sin(k + i) * 0.2, y - (k / 4) * len, z + k * 0.15]);
    const st = Geometry.tube(pts, (q) => 0.28 * (1 - q * 0.7), 4, { capEnd: false });
    st.setColor(mix3(C('#2c4a48'), C('#5f8a84'), mrng.next()), 0.9);
    st.paintExtra((q) => [0, (y - q[1]) / len * 0.5, 0, mrng.next()]);
    moss.append(st);
  }
  R.root.add(makeMesh(ctx, moss, M.mossStrands, 'handMoss'));
  R.root.add(makeMesh(ctx, hand, M.farStone, 'hand'));

  // ledge and castle in front of the palm
  const castle = new Node('castle');
  castle.setPos(0, 33, 14);
  R.root.add(castle);
  const ledge = Geometry.icosphere(1, 3);
  ledge.deform((p) => {
    const n = noise.fbm3(p[0] * 1.5, p[1] * 1.5, p[2] * 1.5, 3) * 0.3;
    return [p[0] * 14 * (1 + n), Math.min(p[1], 0.15) * 9 * (1 + n), p[2] * 11 * (1 + n)];
  });
  ledge.computeNormals();
  ledge.paint((p, n) => mix3(C('#2a2e44'), C('#1e4442'), smoothstep(0.4, 0.9, n[1])).concat([0.8]));
  castle.add(makeMesh(ctx, ledge, M.farStone));
  const cg = new Geometry();
  const glow = new Geometry();
  const stoneCol = C('#2b2d40');
  const roofCol = C('#191a2c');
  const winCol = C('#ff5530');
  const addWindows = (x, y0, z, w, h, count, face, cols = 1) => {
    for (let r = 0; r < count; r++) {
      for (let c = 0; c < cols; c++) {
        if (((r * 7 + c * 3 + Math.floor(x)) % 5) === 0) continue;
        const win = Geometry.box(0.35, 0.8, 0.1);
        win.translate(x + (c - (cols - 1) / 2) * (w / cols), y0 + r * h, z);
        if (face === 'x') { win.rotateY(Math.PI / 2); }
        win.setColor(winCol, 1);
        win.setExtra([2.8]);
        glow.append(win);
      }
    }
  };
  const tower = (x, z, r, h, roofH) => {
    const t = Geometry.cylinder(r, r * 1.08, h, 12, 2, { capTop: true, capBottom: false });
    t.translate(x, 0, z);
    t.setColor(stoneCol, 0.9);
    cg.append(t);
    const roof = Geometry.lathe([[r * 1.25, h], [r * 1.1, h + roofH * 0.1], [r * 0.5, h + roofH * 0.55], [0.05, h + roofH]], 12, { capBottom: true }); // (v9) closed eaves: no see-through roof from below
    roof.translate(x, 0, z);
    roof.setColor(roofCol, 1);
    cg.append(roof);
    // crenel ring
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * TAU;
      const b = Geometry.box(0.5, 0.6, 0.5, { y0: h - 0.1 });
      b.translate(x + Math.cos(a) * r * 1.1, 0, z + Math.sin(a) * r * 1.1);
      b.setColor(stoneCol, 0.9);
      cg.append(b);
    }
    for (let k = 0; k < Math.floor(h / 3.5); k++) {
      const a = (k * 1.7) % TAU;
      const win = Geometry.box(0.35, 0.85, 0.1);
      win.rotateY(-a + Math.PI / 2);
      win.translate(x + Math.cos(a) * r * 1.02, 2 + k * 3.4, z + Math.sin(a) * r * 1.02);
      win.setColor(winCol, 1);
      win.setExtra([3.0]);
      glow.append(win);
    }
  };
  // keep
  const keep = Geometry.box(9, 17, 7, { y0: 0 });
  keep.setColor(stoneCol, 0.9);
  cg.append(keep);
  const keepRoof = Geometry.lathe([[6.2, 17], [4.0, 20], [0.1, 31]], 4, { phase: Math.PI / 4, capBottom: true });
  keepRoof.scale(1, 1, 0.8);
  keepRoof.setColor(roofCol, 1);
  cg.append(keepRoof);
  addWindows(0, 4, 3.55, 7, 3.2, 4, 'z', 3);
  tower(-6, 2, 1.8, 20, 9);
  tower(6, 2, 1.8, 22, 10);
  tower(-3.5, 5, 1.2, 14, 6);
  tower(3.5, 5, 1.2, 15, 6.5);
  tower(-8.5, -2, 1.4, 15, 7);
  tower(8.5, -2, 1.4, 14, 7);
  tower(0, -3.5, 2.0, 25, 12);
  // front wall with crenellations
  const wall = Geometry.box(15, 7, 1.4, { y0: 0 });
  wall.translate(0, 0, 6.5);
  wall.setColor(stoneCol, 0.8);
  cg.append(wall);
  for (let i = 0; i < 12; i++) {
    const b = Geometry.box(0.7, 0.8, 1.4, { y0: 7 });
    b.translate(-7 + i * 1.27, 0, 6.5);
    b.setColor(stoneCol, 0.8);
    cg.append(b);
  }
  const gateGlow = Geometry.box(2.0, 3.2, 0.2, { y0: 0 });
  gateGlow.translate(0, 0, 7.25);
  gateGlow.setColor(C('#ff4a2a'), 1);
  gateGlow.setExtra([1.6]);
  glow.append(gateGlow);
  cg.displace((p) => noise.n3(p[0] * 0.8, p[1] * 0.8, p[2] * 0.8) * 0.08, false);
  castle.add(makeMesh(ctx, cg, M.farStone, 'castle'));
  castle.add(makeMesh(ctx, glow, M.farGlow, 'castleGlow'));
  R.lights.push({ pos: [0, 38, 24], color: C('#ff5a30'), intensity: 6, radius: 26, flicker: 0.1, priority: 5 });
  R.anchors.castle = castle;
  return R;
}

// ------------------------------------------------------------------ castle gate (at the end of the north path)
export function buildGate(ctx) {
  const { M } = ctx;
  const R = result();
  const g = new Geometry();
  const col = '#353a52';
  const wallSeg = (x0, x1, h, th) => {
    const w = Math.abs(x1 - x0);
    const b = Geometry.box(w, h, th, { y0: -2 });
    b.translate((x0 + x1) / 2, 0, 0);
    g.append(b);
    const n = Math.floor(w / 1.4);
    for (let i = 0; i < n; i++) {
      const c = Geometry.box(0.8, 0.9, th, { y0: h - 2 });
      c.translate(Math.min(x0, x1) + 0.7 + i * (w / n), 0, 0);
      g.append(c);
    }
  };
  wallSeg(-26, -4.6, 8, 2.6);
  wallSeg(4.6, 26, 8, 2.6);
  // towers
  for (const s of [-1, 1]) {
    const t = Geometry.cylinder(2.6, 2.9, 12, 16, 3, { capTop: true, capBottom: false });
    t.translate(s * 4.6, -2, 0);
    g.append(t);
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * TAU;
      const c = Geometry.box(0.7, 0.9, 0.7, { y0: 10 });
      c.translate(s * 4.6 + Math.cos(a) * 2.75, 0, Math.sin(a) * 2.75);
      g.append(c);
    }
    const roof = Geometry.lathe([[3.3, 10.9], [2.8, 11.6], [1.2, 15], [0.05, 18.5]], 16, { capBottom: true });
    roof.translate(s * 4.6, 0, 0);
    roof.setColor(C('#1d1f33'), 1);
    g.append(roof);
  }
  // arch lintel above the gate
  const lintel = Geometry.box(6.6, 2.8, 2.8, { y0: 5.2 });
  g.append(lintel);
  g.displace((p) => noise.n3(p[0] * 0.9, p[1] * 0.9, p[2] * 0.9) * 0.1, false);
  g.paint((p, n) => {
    const v = noise.n3(p[0] * 0.7, p[1] * 0.7, p[2] * 0.7) * 0.5 + 0.5;
    let c = mix3(C(col, 0.6), C(col, 1.4), v);
    if (n[1] > 0.6) c = mix3(c, C('#1e4a46'), 0.6);
    return c.concat([smoothstep(-2, 3, p[1]) * 0.4 + 0.6]);
  });
  R.root.add(makeMesh(ctx, g, M.stone, 'gate'));
  // arch opening (dark) + portcullis
  const dark = Geometry.box(4.2, 5.5, 0.4, { y0: -0.3 });
  dark.translate(0, 0, -0.6);
  dark.setColor([0.0, 0.0, 0.0], 1);
  const darkMesh = makeMesh(ctx, dark, M.glow);
  R.root.add(darkMesh);
  R.anchors.dark = darkMesh;
  const bars = new Geometry();
  for (let i = 0; i < 7; i++) {
    const b = Geometry.cylinder(0.07, 0.07, 5.4, 5, 1);
    b.translate(-1.8 + i * 0.6, -0.3, 0.2);
    bars.append(b);
    const tip = Geometry.cylinder(0.0, 0.1, 0.3, 5, 1);
    tip.rotateX(Math.PI);
    tip.translate(-1.8 + i * 0.6, -0.3, 0.2);
    bars.append(tip);
  }
  for (let j = 0; j < 5; j++) {
    const b = Geometry.box(4.2, 0.1, 0.1);
    b.translate(0, 0.6 + j * 1.1, 0.2);
    bars.append(b);
  }
  bars.setColor(C('#1b1c24'), 1);
  const barsMesh = makeMesh(ctx, bars, M.metal);
  R.root.add(barsMesh);
  R.anchors.bars = barsMesh;
  // skull ornament
  const skull = Geometry.sphere(0.75, 14, 10);
  skull.scale(1, 0.95, 0.9);
  const jaw = Geometry.box(0.8, 0.35, 0.6);
  jaw.translate(0, -0.65, 0.15);
  skull.append(jaw);
  skull.setColor(C('#9c9eb0'), 1);
  skull.translate(0, 7.3, 1.45);
  R.root.add(makeMesh(ctx, skull, M.stoneFine));
  const sockets = new Geometry();
  for (const s of [-1, 1]) {
    const e = Geometry.sphere(0.17, 8, 6);
    e.translate(s * 0.27, 7.35, 2.1);
    e.setColor(C('#ff4020'), 1);
    e.setExtra([2.5]);
    sockets.append(e);
  }
  R.root.add(makeMesh(ctx, sockets, M.glow));
  // torches on the tower fronts
  for (const s of [-1, 1]) {
    const tx = s * 3.7, tz = 2.75;
    const t = Geometry.cylinder(0.08, 0.06, 1.0, 6, 1);
    t.rotateX(0.35);
    t.translate(tx, 3.0, tz);
    t.setColor(C('#3a2c22'), 1);
    const bowl = Geometry.lathe([[0.08, 0], [0.22, 0.16], [0.25, 0.28]], 8);
    bowl.translate(tx, 3.9, tz + 0.35);
    bowl.setColor(C('#2a2a30'), 1);
    t.append(bowl);
    const bracket = Geometry.box(0.1, 0.1, 0.5);
    bracket.translate(tx, 3.1, tz - 0.2);
    bracket.setColor(C('#222228'), 1);
    t.append(bracket);
    R.root.add(makeMesh(ctx, t, M.metal));
    R.lights.push({ pos: [tx, 4.6, tz + 0.9], color: C('#ff8a3a'), intensity: 4.5, radius: 12, flicker: 0.4, priority: 6 });
    R.anchors[s < 0 ? 'torchR' : 'torchL'] = [tx, 4.15, tz + 0.35];
  }
  R.lights.push({ pos: [0, 2.5, 5], color: C('#7f9cff'), intensity: 1.5, radius: 10, flicker: 0.0 });
  R.colliders.push({ type: 'seg', ax: -27, az: 0, bx: -2.2, bz: 0, r: 1.5 });
  R.colliders.push({ type: 'seg', ax: 2.2, az: 0, bx: 27, bz: 0, r: 1.5 });
  R.colliders.push({ type: 'seg', ax: -2.2, az: -0.2, bx: 2.2, bz: -0.2, r: 0.5, tag: 'gateDoor' });
  R.colliders.push({ type: 'circle', x: -4.6, z: 0, r: 3.1 }, { type: 'circle', x: 4.6, z: 0, r: 3.1 });
  return R;
}

// ------------------------------------------------------------------ the watcher: mossy mound with one eye
export function buildWatcher(ctx) {
  const { M } = ctx;
  const R = result();
  // (v9.1) finer mesh, calmer lumps: the old 4-octave noise on a coarse mesh looked like crumpled foil
  const mound = Geometry.icosphere(1, 5);
  mound.deform((p) => {
    const n = noise.fbm3(p[0] * 1.2, p[1] * 1.2, p[2] * 1.2, 2) * 0.2 + noise.n3(p[0] * 4, p[1] * 4, p[2] * 4) * 0.018;
    let y = p[1];
    if (y < -0.2) y = -0.2 + (y + 0.2) * 0.2;
    return [p[0] * 6.5 * (1 + n), y * 7.5 * (1 + n) + 1.0, p[2] * 6.0 * (1 + n)];
  });
  mound.computeNormals();
  // carve socket at front (+z)
  mound.deform((p) => {
    const d = Math.hypot(p[0], (p[1] - 4.2) * 1.1, Math.max(0, 6.2 - p[2]) * 0.4);
    const k = p[2] > 3 ? Math.exp(-((Math.hypot(p[0], p[1] - 4.2) / 2.2) ** 2)) * 1.6 : 0;
    return [p[0], p[1], p[2] - k];
  });
  mound.computeNormals();
  mound.paint((p, n) => {
    const v = noise.fbm3(p[0] * 0.5, p[1] * 0.5, p[2] * 0.5, 3) * 0.5 + 0.5;
    let c = mix3(C('#2a3040'), C('#5d6680'), v);
    c = mix3(c, C('#23504a'), smoothstep(0.1, 0.7, n[1] + noise.n3(p[0], p[1], p[2]) * 0.3) * 0.8);
    return c.concat([smoothstep(-0.5, 4, p[1]) * 0.5 + 0.5]);
  });
  // (v9.1) a softer, larger moss pattern: the shared moss detail was far too fine (it shimmered) on something this big
  R.root.add(makeMesh(ctx, mound, M.mossBig, 'watcherBody'));
  // the mound's surface height over (x, z): so the horns grow out of it instead of hovering above
  const topAt = (x, z) => {
    let best = -Infinity;
    const P = mound.p;
    for (let i = 0; i < P.length; i += 3) if (Math.hypot(P[i] - x, P[i + 2] - z) < 0.9) best = Math.max(best, P[i + 1]);
    return best === -Infinity ? 1 : best;
  };
  // horns / spikes
  const horns = new Geometry();
  const rng = new RNG(5);
  const hornSpots = [[-2.5, -0.5, -0.4], [2.2, -0.3, 0.35], [0, -1.2, 0], [-4.3, 0.5, -0.8], [4.5, 0.3, 0.8], [1.0, 1.6, 0.15], [-1.4, 1.7, -0.2]];
  for (const [x, z, lean] of hornSpots) {
    const h = rng.range(2.4, 4.2);
    const y0 = topAt(x, z) - 0.7;
    const pts = [];
    for (let i = 0; i <= 6; i++) {
      const t = i / 6;
      pts.push([x + lean * t * t * 2.5, y0 + t * (h + 0.7), z - t * t * 0.8]);
    }
    const hg = Geometry.tube(pts, (t) => 0.8 * (1 - t) + 0.02, 10, { capStart: true, capEnd: true });
    horns.append(hg);
  }
  horns.displace((p) => noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.06, true);
  horns.paint((p) => mix3(C('#31364a'), C('#8a90a8'), smoothstep(9, 14, p[1])).concat([1]));
  R.root.add(makeMesh(ctx, horns, M.stone));
  // hanging moss strands under the eye (a beard)
  const strands = new Geometry();
  for (let i = 0; i < 70; i++) {
    const a = rng.range(-1.2, 1.2);
    const x = Math.sin(a) * 4.2, z = Math.cos(a) * 4.8 + 0.6;
    const y = 2.4 + rng.range(-0.3, 0.6);
    const len = rng.range(1.2, 2.6);
    const pts = [];
    for (let k = 0; k <= 4; k++) pts.push([x + Math.sin(k + i) * 0.05, y - (k / 4) * len, z + k * 0.06]);
    const st = Geometry.tube(pts, (t) => 0.1 * (1 - t * 0.6), 4, { capEnd: false });
    st.setColor(mix3(C('#3b5c5a'), C('#7a9a9a'), rng.next()), 0.9);
    st.paintExtra((p) => [0, (y - p[1]) / len * 0.6, 0, rng.next()]);
    strands.append(st);
  }
  R.root.add(makeMesh(ctx, strands, M.mossStrands));
  // the eye
  const eyeNode = new Node('eye');
  eyeNode.setPos(0, 4.2, 4.3);
  R.root.add(eyeNode);
  const eye = Geometry.sphere(1.55, 40, 56);
  eye.rotateX(Math.PI / 2); // pole faces forward so iris & pupil are true circles
  eye.paint((p) => {
    const n = [p[0] / 1.55, p[1] / 1.55, p[2] / 1.55];
    const d = Math.acos(Math.max(-1, Math.min(1, n[2]))); // angle from +z
    const ang = Math.atan2(n[1], n[0]);
    if (d < 0.24) return [0.0, 0.0, 0.0, 1];
    if (d < 0.64) {
      const fib = 0.75 + 0.25 * Math.sin(ang * 18 + Math.sin(ang * 5) * 2) * Math.sin(d * 40);
      const c = mix3(C('#0a3a26'), C('#4fe08c'), smoothstep(0.64, 0.3, d) * fib);
      return c.concat([1]);
    }
    if (d < 0.7) return C('#08140f').concat([1]);
    const vein = Math.pow(Math.abs(Math.sin(ang * 9 + d * 7)), 30) * smoothstep(0.9, 1.6, d);
    return mix3(C('#8a879c'), C('#7a1c2c'), vein * 0.6).concat([1]);
  });
  eye.paintExtra((p) => {
    const n = [p[0] / 1.55, p[1] / 1.55, p[2] / 1.55];
    const d = Math.acos(Math.max(-1, Math.min(1, n[2])));
    if (d < 0.24 || d > 0.64) return [0];
    return [0.9 * smoothstep(0.64, 0.3, d) + 0.15];
  });
  const eyeMat = new Material({ uniforms: { uRough: 0.2, uGlowStrength: 1.0, uRim: 0.15, uWrap: 0.3, uFill: 0.5 } });
  eyeNode.add(makeMesh(ctx, eye, eyeMat, 'eyeball'));
  // eyelids (upper & lower), rotate around X to blink
  const lids = {};
  for (const s of [1, -1]) {
    const lid = new Node(s > 0 ? 'lidUp' : 'lidDown');
    lid.setPos(0, 4.2, 4.3);
    R.root.add(lid);
    const lg = Geometry.sphere(1.72, 30, 16);
    // keep a hemispherical shell
    lg.deform((p) => {
      const yy = s > 0 ? Math.max(p[1], 0.05) : Math.min(p[1], -0.05);
      return [p[0], yy, p[2]];
    });
    lg.computeNormals();
    lg.paint((p) => mix3(C('#2d3448'), C('#4a5270'), noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.5 + 0.5).concat([1]));
    lid.add(makeMesh(ctx, lg, M.mossBig));
    lid.setEuler(s > 0 ? -0.95 : 0.8, 0, 0);
    lids[s > 0 ? 'up' : 'down'] = lid;
  }
  R.anchors.eye = eyeNode;
  R.anchors.lids = lids;
  R.lights.push({ pos: [0, 2.0, 8.5], color: C('#5dff9e'), intensity: 2.0, radius: 12, flicker: 0.05, priority: 4 });
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: 6.6 });
  return R;
}

// ------------------------------------------------------------------ dream pyramid
export function buildPyramid(ctx) {
  const { M } = ctx;
  const R = result();
  const g = new Geometry();
  const glow = new Geometry();
  const steps = 8;
  const base = 22, height = 17;
  for (let i = 0; i < steps; i++) {
    const t0 = i / steps;
    const w = base * (1 - t0);
    const h = height / steps;
    const b = Geometry.box(w, h, w, { y0: i * h - 0.4 });
    g.append(b);
    // glowing edges along each step top
    const e = w / 2 + 0.02;
    for (const [dx, dz, len, rot] of [[0, e, w, 0], [0, -e, w, 0], [e, 0, w, 1], [-e, 0, w, 1]]) {
      const l = Geometry.box(len, 0.07, 0.07);
      if (rot) l.rotateY(Math.PI / 2);
      l.translate(dx, (i + 1) * h - 0.4, dz);
      glow.append(l);
    }
  }
  // stairway up the front: each step matches the walkable surface exactly
  const half = base / 2, lh = height / steps;
  const slope = height / half;
  const NS = 30, dy = (height - 0.4) / NS, depth = dy / slope;
  const zStart = half + (lh - 0.4) / slope + 0.05;
  for (let i = 0; i < NS; i++) {
    const top = (i + 1) * dy;
    const s = Geometry.box(2.6, top + 0.4, depth, { y0: -0.4 });
    s.translate(0, 0, zStart - (i + 0.5) * depth);
    g.append(s);
  }
  g.displace((p) => noise.n3(p[0] * 1.3, p[1] * 1.3, p[2] * 1.3) * 0.04, false);
  g.paint((p) => mix3(C('#22233a'), C('#4a4a6a'), noise.n3(p[0] * 0.8, p[1] * 0.8, p[2] * 0.8) * 0.5 + 0.5).concat([smoothstep(-0.5, 6, p[1]) * 0.4 + 0.6]));
  R.root.add(makeMesh(ctx, g, M.stone, 'pyramid'));
  glow.setColor(C('#ffb54a'), 1);
  glow.setExtra([1.3]);
  // eye emblem on the front
  const emblem = new Geometry();
  const ring = Geometry.torus(1.5, 0.09, 6, 30);
  ring.scale(1, 0.55, 1);
  ring.rotateX(Math.PI / 2);
  emblem.append(ring);
  const iris = Geometry.disc(0.5, 20);
  iris.rotateX(Math.PI / 2);
  emblem.append(iris);
  emblem.setColor(C('#ffcf6a'), 1);
  emblem.setExtra([1.4]);
  emblem.translate(0, height * 0.55, (base / 2) * (1 - 0.55) + 0.9);
  glow.append(emblem);
  R.root.add(makeMesh(ctx, glow, M.glow));
  // floating capstone
  const cap = Geometry.cylinder(0.0, 1.6, 2.1, 4, 1, { capBottom: true });
  const capInv = Geometry.cylinder(1.6, 0.0, 1.0, 4, 1, { capTop: false });
  capInv.translate(0, -1.0, 0);
  cap.append(capInv);
  cap.rotateY(Math.PI / 4);
  cap.setColor(C('#9fd8ff'), 1);
  cap.setExtra([1.2]);
  const capNode = new Node('capstone');
  capNode.setPos(0, height + 2.6, 0);
  R.root.add(capNode);
  capNode.add(makeMesh(ctx, cap, M.glass));
  R.anchors.capstone = capNode;
  R.lights.push({ pos: [0, height + 2.6, 0], color: C('#9fd8ff'), intensity: 5, radius: 22, flicker: 0.05, priority: 4 });
  R.lights.push({ pos: [0, 4, base / 2 + 3], color: C('#ffae4a'), intensity: 2.0, radius: 10, flicker: 0.05 });
  // one solid, walkable shape: stepped terraces everywhere, real stairs in the front corridor
  R.surfaces = [{
    type: 'fn', x: 0, z: 0, r: half * 1.5 + 2, bottom: -3,
    topFn: (lx, lz) => {
      if (Math.abs(lx) < 1.3 && lz > 1.0 && lz < zStart) {
        const i = Math.floor((zStart - lz) / depth);
        return Math.min(NS, i + 1) * dy;
      }
      const m = Math.max(Math.abs(lx), Math.abs(lz));
      if (m >= half) return null;
      return Math.ceil(steps * (1 - m / half)) * lh - 0.4;
    },
  }];
  R.anchors.stairsFoot = [0, 0, zStart + 1.2];
  R.anchors.top = [0, height - 0.4, 0];
  return R;
}

// ------------------------------------------------------------------ rune circle
export function buildRuneCircle(ctx, runeTex) {
  const { M } = ctx;
  const R = result();
  const rng = new RNG(77);
  // flagstone floor
  const floor = Geometry.cylinder(9.5, 9.8, 0.5, 40, 1, { capTop: true, capBottom: false });
  floor.translate(0, -0.35, 0);
  floor.paint((p) => {
    const v = noise.n3(p[0] * 0.9, 0, p[2] * 0.9) * 0.5 + 0.5;
    return mix3(C('#252a3e'), C('#44496a'), v).concat([1]);
  });
  R.root.add(makeMesh(ctx, floor, M.stoneFine));
  R.platforms.push({ x: 0, z: 0, hx: 9.3, hz: 9.3, top: 0.15, yaw: 0, round: true });
  // rune overlay (additive)
  const runes = Geometry.plane(19, 19, 1, 1);
  runes.translate(0, 0.18, 0);
  const runeMat = new Material({ kind: 'standard', defines: { UNLIT: 1, MAP: 1, ADDITIVE: 1 }, textures: { uMap: runeTex }, transparent: true, blend: 'additive', depthWrite: false, castShadow: false, uniforms: { uColor: [0.25, 0.55, 1.6], uGlitter: [9, 0.0, 0.0] } });
  runes.setColor([1, 1, 1], 1);
  const runeMesh = makeMesh(ctx, runes, runeMat, 'runes');
  runeMesh.castShadow = false;
  R.root.add(runeMesh);
  R.anchors.runeMat = runeMat;
  // standing stones
  const stones = new Geometry();
  const glyphs = new Geometry();
  const n = 9;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + 0.2;
    const h = rng.range(3.2, 4.8);
    const s = Geometry.roundedBox(1.3, h, 0.8, 3, 0.5);
    s.translate(0, h / 2 - 0.3, 0);
    s.deform((p) => [p[0] * (1 - (p[1] / h) * 0.25), p[1], p[2]]);
    s.displace((p) => noise.n3(p[0] * 2 + i, p[1] * 1.5, p[2] * 2) * 0.12, true);
    s.rotateY(-a + Math.PI / 2);
    s.rotateZ(rng.range(-0.06, 0.06));
    s.translate(Math.cos(a) * 11, 0, Math.sin(a) * 11);
    stones.append(s);
    // glowing glyph strokes on inner face
    for (let k = 0; k < 3; k++) {
      const gl = Geometry.box(0.08, rng.range(0.3, 0.7), 0.05);
      gl.rotateZ(rng.range(-0.8, 0.8));
      gl.translate(rng.range(-0.25, 0.25), 1.2 + k * 0.75, -0.42);
      gl.rotateY(-a + Math.PI / 2);
      gl.translate(Math.cos(a) * 11, 0, Math.sin(a) * 11);
      glyphs.append(gl);
    }
    R.colliders.push({ type: 'circle', x: Math.cos(a) * 11, z: Math.sin(a) * 11, r: 0.85 });
    R.anchors['stone' + i] = [Math.cos(a) * 11, h - 0.3, Math.sin(a) * 11];
  }
  stones.paint((p, nn) => mix3(C('#2c3148'), C('#5c6384'), noise.n3(p[0] * 1.5, p[1] * 1.5, p[2] * 1.5) * 0.5 + 0.5).concat([smoothstep(-0.3, 2, p[1]) * 0.4 + 0.6]));
  R.root.add(makeMesh(ctx, stones, M.stone));
  glyphs.setColor(C('#6ab8ff'), 1);
  glyphs.setExtra([2.2]);
  R.root.add(makeMesh(ctx, glyphs, M.glow));
  // brazier
  const br = Geometry.lathe(catmullRom([[0.9, 0], [0.55, 0.3], [0.4, 0.9], [0.45, 1.1], [1.1, 1.35], [1.3, 1.6], [1.2, 1.7]], 3), 18);
  br.displace((p) => noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.04, true);
  br.paint((p) => mix3(C('#2a2d40'), C('#555b7a'), noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.5 + 0.5).concat([1]));
  R.root.add(makeMesh(ctx, br, M.stone));
  const coals = Geometry.disc(1.15, 18);
  coals.translate(0, 1.55, 0);
  coals.setColor(C('#4aa0ff'), 1);
  coals.setExtra([2.5]);
  R.root.add(makeMesh(ctx, coals, M.glow));
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: 1.5 });
  R.lights.push({ pos: [0, 3.2, 0], color: C('#3f8cff'), intensity: 7, radius: 18, flicker: 0.3, priority: 8 });
  R.anchors.flame = [0, 1.6, 0];
  return R;
}

// ------------------------------------------------------------------ the fallen moon (crescent face)
export function buildMoonStatue(ctx) {
  const { M } = ctx;
  const R = result();
  const Rr = 5.2;
  const pts = [];
  const n = 48;
  const a0 = -2.35, a1 = 2.35;
  for (let i = 0; i <= n; i++) {
    const a = lerp(a0, a1, i / n);
    pts.push([-Math.cos(a) * Rr, Math.sin(a) * Rr + Rr + 1.2, 0]);
  }
  const moon = Geometry.tube(pts, (t) => {
    const s = Math.sin(t * Math.PI);
    return 0.08 + 1.9 * Math.pow(s, 1.3);
  }, 20, { capEnd: true, capStart: true });
  // flatten the tube to make a crescent disc (thin in z)
  moon.deform((p) => [p[0], p[1], p[2] * 0.72]);
  // face on the inner (concave, +x) side near the middle
  const face = (p) => {
    const cx = -Rr + 1.3, cy = Rr + 1.2;
    return [p[0] - cx, p[1] - cy];
  };
  moon.deform((p) => {
    const [fx, fy] = face(p);
    let dx = 0;
    // nose
    dx += 1.1 * Math.exp(-((fx * fx) / 0.35 + ((fy - 0.6) ** 2) / 0.25)) * smoothstep(-0.5, 0.6, fx);
    // brow ridge
    dx += 0.35 * Math.exp(-((fy - 1.9) ** 2) / 0.2 - (fx * fx) / 0.8);
    // eye socket
    dx -= 0.45 * Math.exp(-(((fy - 1.55) ** 2) / 0.12 + ((fx + 0.4) ** 2) / 0.3));
    // cheek & chin
    dx += 0.4 * Math.exp(-(((fy + 1.3) ** 2) / 0.4 + (fx * fx) / 0.6));
    // mouth groove
    dx -= 0.3 * Math.exp(-(((fy + 0.45) ** 2) / 0.02 + (fx * fx) / 0.9));
    return [p[0] + dx, p[1], p[2]];
  });
  moon.computeNormals();
  moon.displace((p) => noise.fbm3(p[0] * 0.8, p[1] * 0.8, p[2] * 0.8, 3) * 0.12, true);
  moon.paint((p, nn) => {
    const v = noise.fbm3(p[0] * 0.6, p[1] * 0.6, p[2] * 0.6, 3) * 0.5 + 0.5;
    const crater = smoothstep(0.55, 0.75, noise.n3(p[0] * 0.9 + 4, p[1] * 0.9, p[2] * 0.9));
    return mix3(C('#5a6694'), C('#aab6e8'), v - crater * 0.3).concat([1]);
  });
  R.root.add(makeMesh(ctx, moon, M.robe, 'moon'));
  // glowing eye + teeth
  const feat = new Geometry();
  const cx = -Rr + 1.3, cy = Rr + 1.2;
  const eyeG = Geometry.sphere(0.34, 12, 10);
  eyeG.scale(0.7, 1, 1);
  eyeG.translate(cx - 0.05, cy + 1.55, 0.35);
  eyeG.setColor(C('#ff9a30'), 1);
  eyeG.setExtra([3.2]);
  feat.append(eyeG);
  const eyeG2 = Geometry.sphere(0.3, 12, 10);
  eyeG2.scale(0.7, 1, 1);
  eyeG2.translate(cx - 0.1, cy + 1.55, -0.45);
  eyeG2.setColor(C('#ff9a30'), 1);
  eyeG2.setExtra([3.2]);
  feat.append(eyeG2);
  R.root.add(makeMesh(ctx, feat, M.glow));
  const teeth = new Geometry();
  for (let i = 0; i < 9; i++) {
    const tz = (i - 4) * 0.19;
    const t = Geometry.box(0.16, 0.26, 0.15);
    t.translate(cx + 0.55 - Math.abs(tz) * 0.25, cy - 0.45 + (i % 2) * 0.03, tz);
    teeth.append(t);
  }
  teeth.setColor(C('#e8e4d8'), 1);
  teeth.setExtra([0.2]);
  R.root.add(makeMesh(ctx, teeth, M.stoneFine));
  // rocky pedestal
  const ped = Geometry.icosphere(1, 3);
  ped.deform((p) => {
    const n = noise.fbm3(p[0] * 1.6, p[1] * 1.6, p[2] * 1.6, 3) * 0.3;
    return [p[0] * 4.5 * (1 + n), Math.min(p[1], 0.3) * 2.6 * (1 + n), p[2] * 3.5 * (1 + n)];
  });
  ped.computeNormals();
  ped.paint((p, nn) => mix3(C('#2a3048'), C('#1f4b48'), smoothstep(0.3, 0.9, nn[1])).concat([0.8]));
  ped.translate(-0.8, 0.4, 0);
  R.root.add(makeMesh(ctx, ped, M.moss));
  R.lights.push({ pos: [cx + 1.5, cy + 1.5, 0], color: C('#ff9a40'), intensity: 3.5, radius: 9, flicker: 0.08 });
  R.lights.push({ pos: [0, 4, 0], color: C('#6a8cff'), intensity: 2.5, radius: 14, flicker: 0.05 });
  R.colliders.push({ type: 'circle', x: -1, z: 0, r: 4.2 });
  R.anchors.center = [0, 6, 0];
  return R;
}

// ------------------------------------------------------------------ pier
export function buildPier(ctx) {
  const { M } = ctx;
  const R = result();
  const g = new Geometry();
  const L = 14, W = 2.4;
  const rng = new RNG(8);
  for (let i = 0; i < Math.floor(L / 0.32); i++) {
    const p = Geometry.box(W + rng.range(-0.15, 0.15), 0.1, 0.28);
    p.rotateY(rng.range(-0.03, 0.03));
    p.translate(0, 0.45 + rng.range(-0.02, 0.02), -i * 0.32);
    g.append(p);
  }
  for (let i = 0; i <= 5; i++) {
    for (const s of [-1, 1]) {
      const post = Geometry.cylinder(0.12, 0.14, 3.2, 6, 1);
      post.translate(s * (W / 2 - 0.05), -2.4, -i * (L / 5));
      g.append(post);
    }
  }
  g.paint((p) => mix3(C('#2e2620'), C('#5a4a3c'), noise.n3(p[0] * 2, p[1] * 5, p[2] * 2) * 0.5 + 0.5).concat([0.9]));
  R.root.add(makeMesh(ctx, g, M.planks, 'pier'));
  R.platforms.push({ x: 0, z: -L / 2 + 0.2, hx: W / 2, hz: L / 2 + 0.2, top: 0.5, yaw: 0 });
  // lantern post at the end
  const lp = buildLampPost(ctx);
  lp.root.setPos(W / 2 - 0.1, 0.5, -L + 0.4);
  lp.root.setRotY(Math.PI);
  R.root.add(lp.root);
  for (const l of lp.lights) R.lights.push({ ...l, pos: [W / 2 - 0.1 - l.pos[0], l.pos[1] + 0.5, -L + 0.4 - l.pos[2]] });
  R.colliders.push({ type: 'circle', x: W / 2 - 0.1, z: -L + 0.4, r: 0.2 });
  R.anchors.end = [0, 0.5, -L + 1];
  return R;
}
