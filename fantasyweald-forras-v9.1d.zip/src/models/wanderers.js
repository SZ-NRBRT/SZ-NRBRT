// More strange things that walk the ground: colossal long-legged walkers crossing the land and the sea,
// a turtle with a garden on its back, giant plush bunnies, walking eye-flowers, little walking paper
// lanterns, and the Mumus. Rigs like the other creatures: { root, bones }.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep } from '../engine/math.js';
import { C } from './materials.js';
import { cloudPuff } from './sky.js';
import * as flora from './flora.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const mesh = (ctx, g, mat, name = '') => new Mesh(new GpuGeometry(ctx.gl, g), mat, name);
function egg(rx, ry, rz, ws = 12, hs = 8) {
  const g = Geometry.sphere(1, ws, hs);
  g.scale(rx, ry, rz);
  return g;
}
function bone(name, parent, x = 0, y = 0, z = 0) {
  const n = new Node(name);
  n.setPos(x, y, z);
  parent.add(n);
  return n;
}

// ------------------------------------------------------------------ the colossus (Lépegető)
// Taller than the tallest tree: a small round body on two impossibly long legs, a veil hanging from it,
// a lantern swinging underneath and two calm lights for eyes.
export function buildColossus(ctx, seed = 1, H = 48) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('colossus');
  const bones = {};
  const hips = bone('hips', root, 0, H, 0);
  bones.hips = hips;
  const tint = C(rng.pick(['#3a3a6a', '#2e3c5c', '#46365e']));
  // body: a soft rounded bell, a veil below it
  const body = Geometry.lathe(catmullRom([[0.3, -3.5], [3.2, -2.8], [4.2, -0.5], [3.8, 1.8], [2.4, 3.4], [0.2, 3.9]], 3), 20, { capTop: true });
  body.paint((p) => mix3(tint, C('#8a8ac8'), smoothstep(-3, 4, p[1])).concat([1]));
  hips.add(mesh(ctx, body, M.whale, 'colossusBody'));
  const veil = new Geometry();
  const N = 24;
  for (let i = 0; i < N; i++) {
    const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU;
    const len = 9 + Math.sin(i * 1.7 + seed) * 2.5;
    const r0 = 3.3, r1 = 3.9;
    const v = [
      veil.vert(Math.cos(a0) * r0, -2.6, Math.sin(a0) * r0), veil.vert(Math.cos(a1) * r0, -2.6, Math.sin(a1) * r0),
      veil.vert(Math.cos(a1) * r1, -2.6 - len, Math.sin(a1) * r1), veil.vert(Math.cos(a0) * r1, -2.6 - len, Math.sin(a0) * r1),
    ];
    veil.quad(v[0], v[1], v[2], v[3]);
  }
  veil.computeNormals();
  veil.paint((p) => mix3(C('#6a6ab0'), C('#20203a'), smoothstep(-3, -12, p[1])).concat([1]));
  hips.add(mesh(ctx, veil, M.clothDS, 'colossusVeil'));
  // eyes on the front
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(0.55, 0.75, 0.3, 10, 8);
    e.translate(s * 1.3, 1.2, 3.85);
    eyes.append(e);
  }
  eyes.setColor(C('#fff2c0'), 1);
  eyes.setExtra([2.0]);
  hips.add(mesh(ctx, eyes, M.glow, 'colossusEyes'));
  // a lantern swinging under the veil
  const lantern = bone('lantern', hips, 0, -3.2, 0);
  bones.lantern = lantern;
  const cord = Geometry.cylinder(0.05, 0.05, 6, 4, 1);
  cord.translate(0, -3, 0);
  cord.setColor(C('#1a1a24'), 1);
  lantern.add(mesh(ctx, cord, M.metal));
  const lg = egg(0.9, 1.2, 0.9, 12, 8);
  lg.translate(0, -6.8, 0);
  lg.setColor(C('#ffd08a'), 1);
  lg.setExtra([3]);
  lantern.add(mesh(ctx, lg, M.glow, 'colossusLamp'));
  bones.lamp = bone('lamp', lantern, 0, -6.8, 0);
  // legs: thin, jointed high up, ending in small pointed feet
  for (const s of [-1, 1]) {
    const leg = bone(s < 0 ? 'legR' : 'legL', hips, s * 2.2, -1.5, 0);
    // (v7.2: sturdier legs with round knee and ankle joints and a splayed three-toed foot)
    const knee = [s * 0.7, -H * 0.42, 1.2], ankle = [s * 0.2, -H + 2.2, -0.3];
    const lgm = Geometry.tube([[0, 0.6, 0], [s * 0.5, -H * 0.2, 0.8], knee], (t) => 1.25 - t * 0.55, 10, { capStart: true, capEnd: true });
    lgm.append(Geometry.tube([knee, [s * 0.45, -H * 0.7, 0.4], ankle], (t) => 0.62 - t * 0.28, 10, { capStart: true, capEnd: true }));
    for (const [q, r] of [[knee, 0.95], [ankle, 0.55]]) { const j = egg(r, r, r, 12, 8); j.translate(q[0], q[1], q[2]); lgm.append(j); }
    for (const a of [-0.7, 0, 0.7, Math.PI]) {
      const len = a === Math.PI ? 1.4 : 2.6;
      const tip = [ankle[0] + Math.sin(a) * len, -H + 0.25, ankle[2] + Math.cos(a) * len];
      lgm.append(Geometry.tube([ankle, [(ankle[0] + tip[0]) / 2, -H + 1.0, (ankle[2] + tip[2]) / 2], tip], (t) => 0.42 - t * 0.3, 8, { capEnd: true }));
    }
    lgm.paint((p) => mix3(tint, C('#12121e'), smoothstep(-H * 0.2, -H, p[1])).concat([1]));
    leg.add(mesh(ctx, lgm, M.whale, 'colossusLeg'));
    bones[s < 0 ? 'legR' : 'legL'] = leg;
  }
  return { root, bones, H };
}

// ------------------------------------------------------------------ the hill turtle (Dombteknős)
// So slow and so big that a little garden grows on its shell: moss, mushrooms, a lamp, a tiny house.
export function buildHillTurtle(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('turtle');
  const bones = {};
  const R = 12, SH = 8.5, Y0 = 3.2;
  const body = bone('body', root, 0, 0, 0);
  bones.body = body;
  // shell: a dome with plates, mossy on top
  const shell = Geometry.lathe(catmullRom([[R * 1.05, Y0], [R, Y0 + 1.2], [R * 0.86, Y0 + SH * 0.55], [R * 0.55, Y0 + SH * 0.9], [0.01, Y0 + SH]], 4), 32);
  shell.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const plate = Math.abs(Math.sin(a * 4)) * Math.abs(Math.sin((p[1] - Y0) * 0.9));
    return [p[0] * (1 + plate * 0.02), p[1] + plate * 0.25, p[2] * (1 + plate * 0.02)];
  });
  shell.computeNormals();
  shell.paint((p, n) => {
    const moss = smoothstep(0.55, 0.85, n[1]);
    const a = Math.atan2(p[2], p[0]);
    const seam = Math.abs(Math.sin(a * 4)) < 0.08 || Math.abs(Math.sin((p[1] - Y0) * 0.9)) < 0.1 ? 0.6 : 1;
    return mix3(mix3(C('#5a4a3a'), C('#8a6a48'), noise.n3(p[0] * 0.3, p[1] * 0.3, p[2] * 0.3) * 0.5 + 0.5), C('#2f6a5a'), moss).map((v) => v * seam).concat([1]);
  });
  body.add(mesh(ctx, shell, M.bigStone, 'turtleShell'));
  const under = Geometry.cylinder(R * 1.02, R * 0.95, 1.4, 32, 1);
  under.translate(0, Y0 - 0.3, 0);
  under.setColor(C('#c8b890'), 0.8);
  body.add(mesh(ctx, under, M.stone));
  // the garden on top
  const garden = new Geometry();
  for (let i = 0; i < 14; i++) {
    const a = rng.range(0, TAU), d = rng.range(1.5, R * 0.5);
    const x = Math.cos(a) * d, z = Math.sin(a) * d;
    const y = Y0 + SH * Math.sqrt(Math.max(0, 1 - (d / (R * 0.93)) ** 2)) - 0.1;
    const f = rng.chance(0.5) ? flora.glowShroomCluster(1900 + i, 4) : flora.flower(1950 + i, rng.pick(['#ffd6a0', '#e6b8ff', '#9fb4ff']));
    f.scale(rng.range(2, 3.5));
    f.translate(x, y, z);
    garden.append(f);
  }
  body.add(mesh(ctx, garden, M.plants, 'turtleGarden'));
  // a tiny house with a lit window, and a lamp
  const house = new Geometry();
  const hx = 2.2, hz = -1.5, hy = Y0 + SH - 0.5;
  const walls = Geometry.box(2.2, 1.8, 2.0, { y0: 0 });
  walls.translate(hx, hy, hz);
  walls.setColor(C('#e8d8c0'), 0.9);
  house.append(walls);
  const roof = Geometry.lathe([[1.9, 0], [0.05, 1.4]], 4, { phase: Math.PI / 4, capBottom: true });
  roof.translate(hx, hy + 1.8, hz);
  roof.setColor(C('#b84a5a'), 1);
  house.append(roof);
  body.add(mesh(ctx, house, M.plaster, 'turtleHouse'));
  const win = Geometry.box(0.5, 0.5, 0.05, { y0: 0 });
  win.translate(hx, hy + 0.7, hz + 1.02);
  win.setColor(C('#ffc070'), 1);
  win.setExtra([2.6]);
  body.add(mesh(ctx, win, M.glow));
  bones.lamp = bone('lamp', body, hx, hy + 2.8, hz + 1.3);
  // head and legs
  const neck = bone('neck', body, 0, Y0 + 1.2, R * 0.95);
  bones.neck = neck;
  const ng = Geometry.tube([[0, 0, -1], [0, 0.6, 1.5], [0, 1.6, 3.2]], (t) => 1.7 - t * 0.5, 12, { capEnd: false });
  ng.setColor(C('#6a8a78'), 1);
  neck.add(mesh(ctx, ng, M.skin, 'turtleNeck'));
  const head = bone('head', neck, 0, 1.8, 3.6);
  bones.head = head;
  const hg = egg(1.5, 1.3, 2.0, 16, 12);
  hg.setColor(C('#7a9a88'), 1);
  head.add(mesh(ctx, hg, M.skin, 'turtleHead'));
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(0.32, 0.18, 0.2, 10, 8);
    e.translate(s * 1.05, 0.45, 1.2);
    e.setColor(C('#1a1a28'), 1);
    eyes.append(e);
  }
  head.add(mesh(ctx, eyes, M.cloth));
  for (const [name, x, z] of [['legFL', 8, 7], ['legFR', -8, 7], ['legBL', 8, -7], ['legBR', -8, -7]]) {
    const leg = bone(name, body, x, Y0, z);
    const lgm = Geometry.tube([[0, 0.5, 0], [x * 0.08, -1.2, z * 0.05], [x * 0.1, -Y0 + 0.4, z * 0.06]], (t) => 1.6 - t * 0.4, 10, { capEnd: true });
    lgm.setColor(C('#6a8a78'), 1);
    leg.add(mesh(ctx, lgm, M.skin));
    bones[name] = leg;
  }
  return { root, bones, R, SH, Y0 };
}

// ------------------------------------------------------------------ plush bunnies (Plüssnyuszik)
// Giant, well-loved plush toys walking the roads on their own: button eyes (one hangs a little loose on
// its thread), a stitched smile, a sewn-on patch, one ear flopped over. Taller than a gnome.
export function buildPlushBunny(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('plush');
  const bones = {};
  // (mid-tone pastels: in the moonlight anything paler glows like a lamp)
  const fur = C(rng.pick(['#946a80', '#6a7aa0', '#958660', '#7c6c9a', '#6a8a78']));
  const pale = mix3(fur, C('#c8bcb8'), 0.35);
  const pink = C('#c87890');
  const hips = bone('hips', root, 0, 0.46, 0);
  bones.hips = hips;
  // body: a soft pear with a paler tummy and a sewn-on heart patch
  const body = Geometry.lathe(catmullRom([[0.06, -0.34], [0.36, -0.26], [0.44, 0.02], [0.4, 0.32], [0.28, 0.52], [0.1, 0.6]], 3), 18);
  body.deform((p) => [p[0], p[1], p[2] * 0.9]);
  body.computeNormals();
  body.paint((p) => {
    const tummy = smoothstep(0.16, 0.34, p[2]) * smoothstep(0.42, 0.1, Math.abs(p[1] - 0.05));
    return mix3(fur, pale, tummy * 0.9).concat([0.8 + 0.2 * smoothstep(-0.3, 0.3, p[1])]);
  });
  const patch = egg(0.08, 0.07, 0.02, 10, 6);
  patch.translate(-0.13, 0.16, 0.36);
  patch.setColor(C(rng.pick(['#f08ab0', '#8ab8f0', '#f0c86a'])), 1);
  body.append(patch);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU, st = Geometry.box(0.006, 0.022, 0.006, { y0: -0.011 });
    st.rotateZ(a);
    st.translate(-0.13 + Math.cos(a) * 0.095, 0.16 + Math.sin(a) * 0.085, 0.365);
    st.setColor(C('#3a2a3a'), 1);
    body.append(st);
  }
  hips.add(mesh(ctx, body, M.cloth, 'plushBody'));
  // head
  const head = bone('head', hips, 0, 0.58, 0);
  bones.head = head;
  const hg = egg(0.34, 0.3, 0.31, 18, 12);
  hg.translate(0, 0.28, 0);
  hg.paint((p) => mix3(fur, pale, smoothstep(0.1, 0.3, p[2]) * smoothstep(0.34, 0.12, p[1]) * 0.8).concat([1]));
  const mz = egg(0.15, 0.1, 0.09, 12, 8);
  mz.translate(0, 0.2, 0.25);
  mz.setColor(pale, 1);
  hg.append(mz);
  const nose = egg(0.045, 0.03, 0.03, 8, 6);
  nose.translate(0, 0.27, 0.33);
  nose.setColor(pink, 1);
  hg.append(nose);
  head.add(mesh(ctx, hg, M.cloth, 'plushHead'));
  // button eyes, a thread, a stitched smile
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const ey = s > 0 ? 0.262 : 0.3; // this one hangs loose
    const e = Geometry.cylinder(0.062, 0.062, 0.035, 14, 1);
    e.rotateX(Math.PI / 2);
    e.translate(s * 0.14, ey, 0.285);
    e.setColor(C('#141018'), 1);
    eyes.append(e);
    for (const [hx, hy] of [[-0.017, 0.017], [0.017, 0.017], [-0.017, -0.017], [0.017, -0.017]]) {
      const h = egg(0.008, 0.008, 0.004, 4, 3);
      h.translate(s * 0.14 + hx, ey + hy, 0.304);
      h.setColor(C('#4a4454'), 1);
      eyes.append(h);
    }
  }
  const th = Geometry.tube([[0.14, 0.31, 0.27], [0.155, 0.29, 0.285], [0.14, 0.275, 0.29]], () => 0.004, 3, { capEnd: false });
  th.setColor(C('#2a2430'), 1);
  eyes.append(th);
  for (let i = -3; i <= 3; i++) {
    const x = i * 0.024, y = 0.135 + x * x * 3.2;
    const st = Geometry.box(0.007, 0.03, 0.007, { y0: -0.015 });
    st.rotateZ(x * 6);
    st.translate(x, y, 0.3 - Math.abs(x) * 0.25);
    st.setColor(C('#3a2a3a'), 1);
    eyes.append(st);
  }
  head.add(mesh(ctx, eyes, M.glossy, 'plushEyes'));
  // long ears, one flopped over
  for (const s of [-1, 1]) {
    const ear = bone(s < 0 ? 'earR' : 'earL', head, s * 0.14, 0.5, -0.03);
    const eg = egg(0.09, 0.36, 0.045, 12, 8);
    eg.translate(0, 0.32, 0);
    eg.paint((p) => mix3(fur, pink, smoothstep(0.0, 0.03, p[2]) * smoothstep(0.08, 0.02, Math.abs(p[0])) * smoothstep(0.04, 0.16, p[1]) * smoothstep(0.62, 0.42, p[1])).concat([1]));
    ear.add(mesh(ctx, eg, M.cloth));
    ear.setEuler(s < 0 ? 0.1 : 1.05, 0, s * -0.12);
    bones[s < 0 ? 'earR' : 'earL'] = ear;
  }
  // stubby arms with round paws, short legs with big soft feet
  for (const s of [-1, 1]) {
    const arm = bone(s < 0 ? 'armR' : 'armL', hips, s * 0.36, 0.34, 0.02);
    const ag = egg(0.1, 0.25, 0.1, 10, 8);
    ag.translate(s * 0.03, -0.2, 0.03);
    ag.setColor(fur, 1);
    const paw = egg(0.1, 0.085, 0.1, 10, 8);
    paw.translate(s * 0.04, -0.42, 0.05);
    paw.setColor(pale, 1);
    ag.append(paw);
    arm.add(mesh(ctx, ag, M.cloth));
    arm.setEuler(0, 0, s * 0.25);
    bones[s < 0 ? 'armR' : 'armL'] = arm;
    const leg = bone(s < 0 ? 'legR' : 'legL', hips, s * 0.19, -0.2, 0);
    const lg = egg(0.13, 0.16, 0.14, 10, 8);
    lg.translate(0, -0.06, 0.02);
    lg.setColor(fur, 1);
    const foot = egg(0.14, 0.075, 0.22, 10, 8);
    foot.translate(0, -0.18, 0.08);
    foot.paint((p) => mix3(fur, pale, smoothstep(0.1, 0.25, p[2])).concat([1]));
    lg.append(foot);
    leg.add(mesh(ctx, lg, M.cloth));
    bones[s < 0 ? 'legR' : 'legL'] = leg;
  }
  return { root, bones };
}

// ------------------------------------------------------------------ helpers
// a flat polygon in the xz plane, extruded from y0 to y1 (faces wound outwards whatever the point order)
export function flatPoly(pts, y0, y1) {
  const g = new Geometry();
  let area = 0;
  for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; area += a[0] * b[1] - b[0] * a[1]; }
  const P = area > 0 ? pts.slice().reverse() : pts; // clockwise in (x, z) seen from above = counter-clockwise from +y
  const top = P.map((q) => g.vert(q[0], y1, q[1], 0, 1, 0));
  const bot = P.map((q) => g.vert(q[0], y0, q[1], 0, -1, 0));
  for (let i = 1; i < P.length - 1; i++) { g.tri(top[0], top[i], top[i + 1]); g.tri(bot[0], bot[i + 1], bot[i]); }
  for (let i = 0; i < P.length; i++) {
    const j = (i + 1) % P.length;
    const a = g.vert(P[i][0], y1, P[i][1]), b = g.vert(P[j][0], y1, P[j][1]), c = g.vert(P[j][0], y0, P[j][1]), d = g.vert(P[i][0], y0, P[i][1]);
    g.quad(a, d, c, b);
  }
  g.computeNormals();
  return g;
}
// ------------------------------------------------------------------ eye-flowers (Szemvirágok)
// A tall pastel flower on a crooked stem, walking about on its roots. In the middle of the petals there
// is no pollen but a big, wet, blinking eye, and it follows you wherever you go.
function hemisphere(r, seg = 14) {
  // a dome over +y (profile from the rim up to the pole), then turned so its pole points along +z
  const prof = [];
  for (let i = 0; i <= 6; i++) { const a = (i / 6) * Math.PI / 2; prof.push([Math.cos(a) * r, Math.sin(a) * r]); }
  prof[6][0] = 0.001;
  const g = Geometry.lathe(prof, seg);
  g.rotateX(Math.PI / 2);
  return g;
}
export function buildEyeFlower(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('eyeflower');
  const bones = {};
  const petalC = C(rng.pick(['#c8b0c8', '#d0a8b8', '#b0a8d0', '#d0c0a0', '#a8c0d0']));
  const heartC = C(rng.pick(['#c06088', '#8a60c0', '#c08040', '#5898b8']));
  const irisC = C(rng.pick(['#5a8cff', '#9a5aff', '#2ab090', '#ff9a3a', '#ff5a8a']));
  const green = C('#3f7a4a'), dark = C('#23452e');
  const body = bone('body', root, 0, 0.32, 0);
  bones.body = body;
  // the root bulb, and a crooked stem with two leaves
  const bulb = egg(0.22, 0.17, 0.22, 12, 8);
  bulb.paint((p) => mix3(C('#3a3a2a'), C('#5f7a44'), smoothstep(-0.15, 0.15, p[1])).concat([1]));
  const stem = Geometry.tube([[0, 0.1, 0], [0.04, 0.5, 0.02], [-0.03, 0.9, 0.05], [0, 1.2, 0.08]], (t) => 0.05 - t * 0.015, 8, { capEnd: false });
  stem.setColor(green, 1);
  bulb.append(stem);
  for (const [y, s] of [[0.45, 1], [0.72, -1]]) {
    const lf = egg(0.24, 0.018, 0.09, 10, 4);
    lf.translate(0.22, 0, 0);
    lf.rotateZ(0.35);
    if (s < 0) lf.rotateY(Math.PI);
    lf.translate(0.01 * s, y, 0.03);
    lf.paint((p) => mix3(dark, green, smoothstep(0.02, 0.3, Math.abs(p[0]))).concat([1]));
    bulb.append(lf);
  }
  body.add(mesh(ctx, bulb, M.moss, 'eyeStem'));
  // root legs with little root toes
  for (const s of [-1, 1]) {
    const leg = bone(s < 0 ? 'legR' : 'legL', body, s * 0.1, -0.08, 0);
    const lg = Geometry.tube([[0, 0, 0], [s * 0.06, -0.12, 0.03], [s * 0.03, -0.24, 0.07]], (t) => 0.045 - t * 0.025, 6, { capEnd: true });
    for (const a of [-0.6, 0, 0.6]) lg.append(Geometry.tube([[s * 0.03, -0.24, 0.07], [s * 0.03 + Math.sin(a) * 0.1, -0.25, 0.07 + Math.cos(a) * 0.1]], () => 0.014, 4, { capEnd: true }));
    lg.setColor(C('#4a4230'), 1);
    leg.add(mesh(ctx, lg, M.bark));
    bones[s < 0 ? 'legR' : 'legL'] = leg;
  }
  // the flower head faces +z: a ring of petals around a green cup
  const head = bone('head', body, 0, 1.22, 0.08);
  bones.head = head;
  const petals = new Geometry();
  const n = rng.int(8, 10);
  for (let i = 0; i < n; i++) {
    const pg = egg(0.1, 0.27, 0.024, 10, 6);
    pg.translate(0, 0.33, -0.02);
    pg.rotateX(-0.25);
    pg.rotateZ((i / n) * TAU + rng.range(-0.08, 0.08));
    petals.append(pg);
  }
  petals.paint((p) => mix3(heartC, petalC, smoothstep(0.1, 0.35, Math.hypot(p[0], p[1]))).concat([1]));
  const cup = egg(0.2, 0.2, 0.09, 12, 8);
  cup.translate(0, 0, -0.08);
  cup.setColor(green, 1);
  petals.append(cup);
  head.add(mesh(ctx, petals, M.cloth, 'eyePetals'));
  // the eye: wet white ball, a softly glowing iris, a black pupil and a highlight
  const eye = bone('eye', head, 0, 0, 0.03);
  bones.eye = eye;
  const ball = Geometry.sphere(0.17, 16, 12);
  ball.paint((p) => mix3(C('#d8d0d0'), C('#c08890'), smoothstep(0.08, -0.1, p[2]) * 0.6).concat([1]));
  eye.add(mesh(ctx, ball, M.glossy, 'eyeBall'));
  const iris = Geometry.cylinder(0.085, 0.085, 0.02, 18, 1);
  iris.rotateX(Math.PI / 2);
  iris.translate(0, 0, 0.162);
  iris.paint((p) => mix3(irisC, mix3(irisC, [1, 1, 1], 0.4), smoothstep(0.05, 0.085, Math.hypot(p[0], p[1]))).concat([1]));
  iris.setExtra([0.45]);
  eye.add(mesh(ctx, iris, M.glowSoft, 'eyeIris'));
  const pupil = new Geometry();
  const pu = Geometry.cylinder(0.042, 0.042, 0.02, 14, 1);
  pu.rotateX(Math.PI / 2);
  pu.translate(0, 0, 0.17);
  pu.setColor(C('#06060a'), 1);
  pupil.append(pu);
  const hl = egg(0.018, 0.018, 0.008, 6, 4);
  hl.translate(0.03, 0.035, 0.182);
  hl.setColor([1, 1, 1], 1);
  pupil.append(hl);
  eye.add(mesh(ctx, pupil, M.glossy, 'eyePupil'));
  // the eyelid: a dome that sweeps down over the eye when it blinks
  const lid = bone('lid', head, 0, 0, 0.03);
  bones.lid = lid;
  const lg = hemisphere(0.182, 16);
  lg.paint((p) => mix3(mix3(petalC, heartC, 0.35), C('#b8889a'), smoothstep(0.1, 0.18, Math.hypot(p[0], p[1])) * 0.3).concat([1]));
  lid.add(mesh(ctx, lg, M.cloth, 'eyeLid'));
  lid.setEuler(-2.0, 0, 0);
  return { root, bones };
}

// ------------------------------------------------------------------ the Mumus (the sack man)
// The bogeyman of the old stories: a tall, hunched figure in a tattered black cloak, a pale mask of a
// face with a crooked smile, horns, arms far too long with fingers like twigs, and a sack on its back.
// Its eyes are two red embers; they flare up when it has seen you.
export function buildMumus(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('mumus');
  const bones = {};
  const cloakC = C('#15111c'), cloakHi = C('#2a2236'), claw = C('#1a1420');
  // a plain, matte, double-sided cloth (the usual cloth weave shimmers like static on something this dark)
  const cloakM = M.mumusCloak || (M.mumusCloak = new Material({ cull: 'none', uniforms: { uRough: 0.95, uRim: 0.45, uWrap: 0.3, uFill: 0.3, uGlitter: [0, 0, 0] } }));
  const hips = bone('hips', root, 0, 1.7, 0);
  bones.hips = hips;
  // long thin legs under the cloak
  for (const s of [-1, 1]) {
    const leg = bone(s < 0 ? 'legR' : 'legL', hips, s * 0.14, 0, 0);
    const lg = Geometry.tube([[0, 0, 0], [0, -0.8, 0.06], [0, -1.62, -0.02]], (t) => 0.055 - t * 0.02, 6, { capEnd: true });
    const foot = egg(0.07, 0.04, 0.17, 8, 5);
    foot.translate(0, -1.66, 0.08);
    lg.append(foot);
    lg.setColor(claw, 1);
    leg.add(mesh(ctx, lg, M.cloth));
    bones[s < 0 ? 'legR' : 'legL'] = leg;
  }
  // the torso leans forward: a ragged cloak
  const torso = bone('torso', hips, 0, 0, 0);
  bones.torso = torso;
  const cloak = Geometry.lathe(catmullRom([[0.56, -1.3], [0.48, -0.8], [0.37, -0.2], [0.32, 0.4], [0.38, 0.74], [0.22, 0.95], [0.06, 1.02]], 3), 22);
  cloak.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const rag = smoothstep(-0.85, -1.3, p[1]);
    const tear = (0.5 + 0.5 * Math.sin(a * 9 + seed)) * (0.6 + 0.4 * Math.sin(a * 23)) * 0.28 * rag;
    const wob = 1 + noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.08;
    return [p[0] * wob, p[1] + tear, p[2] * wob * 0.85];
  });
  cloak.computeNormals();
  cloak.paint((p) => mix3(cloakC, cloakHi, smoothstep(-0.2, 0.9, p[1]) * 0.6).concat([0.8]));
  torso.add(mesh(ctx, cloak, cloakM, 'mumusCloak'));
  // the sack on its back
  const sack = bone('sack', torso, 0.05, 0.55, -0.42);
  bones.sack = sack;
  const sg = egg(0.34, 0.4, 0.3, 12, 10);
  sg.deform((p) => [p[0] * (1 + noise.n3(p[0] * 5, p[1] * 5, p[2] * 5) * 0.12), p[1], p[2]]);
  sg.computeNormals();
  sg.paint((p) => mix3(C('#3a3024'), C('#6a5a44'), smoothstep(-0.3, 0.35, p[1])).concat([0.9]));
  const tie = Geometry.torus(0.09, 0.03, 6, 12);
  tie.translate(0, 0.4, 0);
  tie.setColor(C('#2a2018'), 1);
  sg.append(tie);
  const strap = Geometry.tube([[0, 0.4, 0.05], [0.1, 0.55, 0.3], [0.22, 0.35, 0.5]], () => 0.025, 5, { capEnd: true });
  strap.setColor(C('#2a2018'), 1);
  sg.append(strap);
  sack.add(mesh(ctx, sg, M.cloth, 'mumusSack'));
  // head: hood, pale mask, crooked smile, horns, ember eyes
  const head = bone('head', torso, 0, 1.0, 0.1);
  bones.head = head;
  const hood = Geometry.lathe(catmullRom([[0.24, -0.08], [0.25, 0.12], [0.2, 0.3], [0.08, 0.4], [0.01, 0.42]], 3), 16);
  hood.deform((p) => [p[0], p[1], p[2] < 0 ? p[2] * 1.15 : p[2] * 0.7]);
  hood.computeNormals();
  hood.setColor(cloakC, 0.8);
  head.add(mesh(ctx, hood, cloakM, 'mumusHood'));
  const face = egg(0.15, 0.22, 0.1, 14, 10);
  face.deform((p) => [p[0] * (1 - Math.max(0, -p[1]) * 1.2), p[1], p[2]]);
  face.computeNormals();
  face.translate(0, 0.13, 0.14);
  face.paint((p) => mix3(C('#bfb6aa'), C('#e2dcd2'), smoothstep(-0.05, 0.25, p[1])).concat([1]));
  const holes = new Geometry();
  for (const s of [-1, 1]) {
    const h = egg(0.038, 0.052, 0.02, 8, 6);
    h.rotateZ(s * 0.35);
    h.translate(s * 0.058, 0.19, 0.225);
    holes.append(h);
  }
  const mouth = Geometry.tube([[-0.08, 0.06, 0.215], [-0.03, 0.035, 0.228], [0.03, 0.04, 0.228], [0.085, 0.075, 0.21]], () => 0.009, 4, { capEnd: true });
  holes.append(mouth);
  holes.setColor(C('#050406'), 1);
  face.append(holes);
  head.add(mesh(ctx, face, M.plaster, 'mumusFace'));
  const horns = new Geometry();
  for (const s of [-1, 1]) horns.append(Geometry.tube([[s * 0.1, 0.3, -0.02], [s * 0.17, 0.46, -0.1], [s * 0.15, 0.62, -0.26], [s * 0.09, 0.7, -0.36]], (t) => 0.035 * (1 - t) + 0.004, 6, { capEnd: true }));
  horns.paint((p) => mix3(C('#2a2230'), C('#5a5060'), smoothstep(0.3, 0.7, p[1])).concat([1]));
  head.add(mesh(ctx, horns, M.bark, 'mumusHorns'));
  const eyes = bone('eyes', head, 0, 0.19, 0.228);
  bones.eyes = eyes;
  const eg = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(0.016, 0.016, 0.01, 6, 4);
    e.translate(s * 0.058, 0, 0);
    eg.append(e);
  }
  eg.setColor(C('#ff3a24'), 1);
  const em = mesh(ctx, eg, M.glow, 'mumusEyes');
  em.castShadow = false;
  eyes.add(em);
  // arms far too long, fingers like twigs
  for (const s of [-1, 1]) {
    const arm = bone(s < 0 ? 'armR' : 'armL', torso, s * 0.34, 0.78, 0.05);
    const ag = Geometry.tube([[0, 0, 0], [s * 0.06, -0.5, 0.08], [s * 0.02, -1.05, 0.12]], (t) => 0.06 - t * 0.025, 6, { capEnd: true });
    ag.setColor(cloakC, 0.85);
    arm.add(mesh(ctx, ag, M.cloth));
    const hand = new Geometry();
    for (let k = 0; k < 4; k++) {
      const dx = (k - 1.5) * 0.035, dz = rng.range(-0.03, 0.03);
      hand.append(Geometry.tube([[s * 0.02 + dx * 0.4, -1.04, 0.12], [s * 0.02 + dx, -1.2, 0.14 + dz], [s * 0.02 + dx * 1.2, -1.36, 0.1 + dz]], (t) => 0.013 * (1 - t) + 0.003, 4, { capEnd: true }));
    }
    hand.setColor(claw, 1);
    arm.add(mesh(ctx, hand, M.bark));
    bones[s < 0 ? 'armR' : 'armL'] = arm;
  }
  torso.setEuler(0.3, 0, 0);
  return { root, bones };
}

// ------------------------------------------------------------------ walking paper lanterns (Lámpások)
export function buildLampling(ctx, seed = 1) {
  const M = ctx.M;
  const rng = new RNG(seed);
  const root = new Node('lampling');
  const bones = {};
  const body = bone('body', root, 0, 0.28, 0);
  bones.body = body;
  const col = C(rng.pick(['#ffb46a', '#ff8a8a', '#ffd88a', '#f0a0ff']));
  const lan = Geometry.lathe(catmullRom([[0.04, -0.16], [0.14, -0.12], [0.17, 0.0], [0.14, 0.12], [0.04, 0.16]], 3), 12);
  lan.deform((p) => { const a = Math.atan2(p[2], p[0]); const r = 1 + Math.abs(Math.sin(a * 5)) * 0.04; return [p[0] * r, p[1], p[2] * r]; });
  lan.computeNormals();
  lan.paint((p) => mix3(col, C('#fff0c8'), smoothstep(0.12, -0.05, Math.abs(p[1]))).concat([1]));
  lan.setExtra([0.7]);
  body.add(mesh(ctx, lan, M.glowSoft, 'lampBody'));
  const caps = new Geometry();
  for (const y of [-0.17, 0.17]) {
    const c = Geometry.cylinder(0.05, 0.05, 0.03, 8, 1);
    c.translate(0, y, 0);
    caps.append(c);
  }
  caps.setColor(C('#2a2028'), 1);
  body.add(mesh(ctx, caps, M.wood));
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = egg(0.018, 0.026, 0.01, 6, 4);
    e.translate(s * 0.05, 0.02, 0.16);
    e.setColor(C('#3a2010'), 1);
    eyes.append(e);
  }
  body.add(mesh(ctx, eyes, M.cloth));
  for (const s of [-1, 1]) {
    const leg = bone(s < 0 ? 'legR' : 'legL', body, s * 0.06, -0.16, 0);
    const lg = Geometry.cylinder(0.008, 0.01, 0.12, 4, 1);
    lg.translate(0, -0.06, 0);
    lg.setColor(C('#2a2028'), 1);
    leg.add(mesh(ctx, lg, M.wood));
    bones[s < 0 ? 'legR' : 'legL'] = leg;
  }
  return { root, bones, color: col };
}
