// Second wave of set pieces: mushroom houses, lantern strings, the moon well, crystals, floating
// islands, the fallen star, the astronomer's tower, moon gates, the sleeping giant, ruins,
// lore stones, star shards, bounce mushrooms and obelisks.
// Builders return { root, colliders, surfaces, lights, anchors } in LOCAL space (see world.place).
import { Geometry, catmullRom } from '../engine/geometry.js';
import { Node, Material } from '../engine/scene.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp, smoothstep, vnorm, vcross, vsub, mat4, quat } from '../engine/math.js';
import { C } from './materials.js';
import { makeMesh } from './characters.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
function result() {
  return { root: new Node(), colliders: [], surfaces: [], lights: [], anchors: {} };
}
// orient a geometry so +Y points along dir, then move to pos
function alongDir(g, dir, pos) {
  const d = vnorm(dir);
  const q = quat.fromUpTo([0, 0, 0, 1], d);
  const m = mat4.compose(mat4.create(), pos, q, [1, 1, 1]);
  return g.applyMatrix(m);
}

// ------------------------------------------------------------------ mushroom house
const HOUSE_CAPS = ['#c81f28', '#7d3fd6', '#1f8f9a', '#d45a1e'];
export function buildMushroomHouse(ctx, variant = 0, seed = 1) {
  const { M } = ctx;
  const R = result();
  const rng = new RNG(seed);
  const sr = 2.1 + rng.range(-0.2, 0.3), H = 3.3 + rng.range(-0.3, 0.6);
  const body = Geometry.lathe(catmullRom([[sr * 1.08, -0.3], [sr * 1.05, 0.4], [sr, H * 0.5], [sr * 0.93, H * 0.9], [sr * 0.9, H]], 3), 26);
  body.displace((p) => noise.n3(p[0] * 0.9 + seed, p[1] * 0.9, p[2] * 0.9) * 0.06, true);
  body.paint((p) => mix3(C('#8a8070'), C('#e2d6bd'), smoothstep(-0.3, 1.5, p[1])).concat([smoothstep(-0.3, 1, p[1]) * 0.4 + 0.6]));
  R.root.add(makeMesh(ctx, body, M.plaster, 'houseBody'));
  // cap
  const CR = sr * 1.85 + rng.range(-0.2, 0.3), ch = CR * rng.range(0.55, 0.75);
  const capProf = catmullRom([[sr * 0.85, H - 0.1], [CR * 0.95, H - 0.35], [CR * 1.02, H - 0.1], [CR * 0.92, H + ch * 0.35], [CR * 0.6, H + ch * 0.8], [CR * 0.25, H + ch * 0.98], [0, H + ch]], 4);
  const cap = Geometry.lathe(capProf, 36);
  cap.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const w = 1 + noise.n2(Math.cos(a) * 1.3 + seed, Math.sin(a) * 1.3) * 0.06;
    return [p[0] * w, p[1] + Math.sin(a * 2 + seed) * 0.08, p[2] * w];
  });
  cap.computeNormals();
  const cc = C(HOUSE_CAPS[variant % HOUSE_CAPS.length]);
  cap.paint((p) => {
    const r = Math.hypot(p[0], p[2]) / CR;
    const under = p[1] < H - 0.05 && r < 0.97;
    if (under) return C('#cbbfa8').concat([0.6]);
    return mix3(cc, mix3(cc, [0, 0, 0], 0.4), smoothstep(0.4, 1.0, r)).concat([1]);
  });
  cap.paintExtra((p) => [0, 0, p[1] > H - 0.05 ? 1 : 0]);
  R.root.add(makeMesh(ctx, cap, M.houseCap, 'houseCap'));
  // door + windows
  const wood = new Geometry();
  const glow = new Geometry();
  const door = Geometry.box(1.0, 1.7, 0.12, { y0: 0 });
  const arch = Geometry.cylinder(0.5, 0.5, 0.12, 12, 1);
  arch.rotateX(Math.PI / 2); arch.translate(0, 1.7, -0.06);
  door.append(arch);
  door.deform((p) => [p[0], Math.min(p[1], 1.7 + Math.sqrt(Math.max(0, 0.25 - p[0] * p[0]))), p[2]]);
  door.computeNormals();
  door.paint((p) => mix3(C('#3a2a22'), C('#6b4c36'), Math.abs(Math.sin(p[0] * 10))).concat([0.9]));
  door.translate(0, 0, sr * 1.04 + 0.02);
  wood.append(door);
  const knob = Geometry.sphere(0.06, 6, 4);
  knob.translate(0.3, 0.95, sr * 1.04 + 0.1);
  knob.setColor(C('#d8b050'), 1);
  wood.append(knob);
  const nWin = 2 + (seed % 2);
  for (let i = 0; i < nWin; i++) {
    const a = Math.PI / 2 + (i - (nWin - 1) / 2) * 1.2 + (i >= nWin / 2 ? 0.6 : -0.6);
    const wy = 1.3 + (i % 2) * 0.9;
    const rw = sr * 0.98 + 0.03;
    const wg = Geometry.disc(0.33, 14);
    wg.rotateX(Math.PI / 2);
    wg.translate(0, wy, 0.02);
    wg.setColor(C('#ffb35c'), 1);
    wg.setExtra([2.2]);
    wg.rotateY(Math.PI / 2 - a);
    wg.translate(Math.cos(a) * rw, 0, Math.sin(a) * rw);
    glow.append(wg);
    const fr = Geometry.torus(0.35, 0.06, 5, 14);
    fr.rotateX(Math.PI / 2);
    fr.translate(0, wy, 0.05);
    fr.setColor(C('#3a2a22'), 1);
    fr.rotateY(Math.PI / 2 - a);
    fr.translate(Math.cos(a) * rw, 0, Math.sin(a) * rw);
    wood.append(fr);
  }
  // little chimney pipe poking out of the cap
  const pipe = Geometry.cylinder(0.18, 0.2, 1.3, 8, 1, { capTop: false });
  pipe.translate(CR * 0.45, H + ch * 0.55, -CR * 0.1);
  pipe.setColor(C('#3b3b46'), 1);
  wood.append(pipe);
  R.anchors.chimney = [CR * 0.45, H + ch * 0.55 + 1.3, -CR * 0.1];
  // step stones in front of the door
  for (let i = 0; i < 3; i++) {
    const st = Geometry.icosphere(0.35, 1);
    st.scale(1.2, 0.35, 0.9);
    st.translate((i - 1) * 0.2, 0.0, sr + 0.7 + i * 0.75);
    st.setColor(C('#50566e'), 0.9);
    wood.append(st);
  }
  R.root.add(makeMesh(ctx, wood, M.wood));
  R.root.add(makeMesh(ctx, glow, M.glowSoft));
  R.lights.push({ pos: [0, 2.0, sr + 1.6], color: C('#ffa24f'), intensity: 2.4, radius: 7, flicker: 0.1 });
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: sr * 1.08 + 0.1 });
  // the cap can be stood on (you get there with a bounce mushroom or a good jump)
  R.surfaces.push({ type: 'disc', x: 0, z: 0, r: CR * 0.85, top: H + ch - 0.05, dome: ch * 0.75, bottom: H - 0.4 });
  R.anchors.door = [0, 0, sr + 1.6];
  R.anchors.capTop = [0, H + ch, 0];
  return R;
}

// ------------------------------------------------------------------ lantern string between two world points
export function lanternString(a, b, sag = 1.2, seed = 1) {
  const rng = new RNG(seed);
  const rope = new Geometry();
  const bulbs = new Geometry();
  const pts = [];
  const N = 16;
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    pts.push([lerp(a[0], b[0], t), lerp(a[1], b[1], t) - Math.sin(t * Math.PI) * sag, lerp(a[2], b[2], t)]);
  }
  rope.append(Geometry.tube(pts, () => 0.025, 4, { capEnd: false }));
  rope.setColor(C('#2a2420'), 1);
  const cols = ['#ffcf6a', '#8fe6ff', '#ff8ad0', '#b59bff', '#9dffb0'];
  const nb = Math.max(3, Math.round(Math.hypot(b[0] - a[0], b[2] - a[2]) / 1.3));
  for (let i = 1; i < nb; i++) {
    const t = i / nb;
    const p = [lerp(a[0], b[0], t), lerp(a[1], b[1], t) - Math.sin(t * Math.PI) * sag - 0.12, lerp(a[2], b[2], t)];
    const s = Geometry.sphere(0.09, 8, 6);
    s.scale(1, 1.25, 1);
    s.translate(p[0], p[1], p[2]);
    s.setColor(C(rng.pick(cols)), 1);
    s.setExtra([2.6]);
    bulbs.append(s);
  }
  return { rope, bulbs };
}

// ------------------------------------------------------------------ the moon well (village center)
export function buildWell(ctx) {
  const { M } = ctx;
  const R = result();
  const ring = Geometry.cylinder(1.5, 1.6, 0.95, 20, 2, { capTop: false });
  const inner = Geometry.cylinder(1.25, 1.25, 0.95, 20, 1, { capTop: false, capBottom: false });
  inner.scale(1, 1, 1);
  ring.append(inner);
  const lip = Geometry.torus(1.38, 0.17, 6, 24);
  lip.translate(0, 0.95, 0);
  ring.append(lip);
  ring.displace((p) => noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.05, true);
  ring.paint((p) => mix3(C('#3c4260'), C('#6f7898'), noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.5 + 0.5).concat([1]));
  R.root.add(makeMesh(ctx, ring, M.stone));
  const water = Geometry.disc(1.26, 20);
  water.translate(0, 0.62, 0);
  water.setColor(C('#6ff2ff'), 1);
  water.setExtra([1.8]);
  R.root.add(makeMesh(ctx, water, M.glowSoft));
  const frame = new Geometry();
  for (const s of [-1, 1]) {
    const post = Geometry.box(0.16, 2.4, 0.16, { y0: 0.8 });
    post.translate(s * 1.3, 0, 0);
    frame.append(post);
  }
  const beam = Geometry.box(2.9, 0.14, 0.14, { y0: 3.1 });
  frame.append(beam);
  const roof = Geometry.lathe([[2.1, 3.1], [1.3, 3.6], [0.05, 4.4]], 4, { phase: Math.PI / 4, capBottom: true });
  roof.scale(1, 1, 0.7);
  frame.append(roof);
  frame.setColor(C('#3a2c24'), 1);
  const bucket = Geometry.lathe([[0.18, 0], [0.22, 0.3]], 8, { capBottom: true });
  bucket.translate(0.2, 2.2, 0);
  bucket.setColor(C('#5a4636'), 1);
  frame.append(bucket);
  R.root.add(makeMesh(ctx, frame, M.wood));
  R.lights.push({ pos: [0, 1.4, 0], color: C('#6fe6ff'), intensity: 2.5, radius: 9, flicker: 0.05 });
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: 1.75 });
  return R;
}

// ------------------------------------------------------------------ crystal cluster (instanced)
export function crystalCluster(seed = 1, count = 6) {
  const rng = new RNG(seed);
  const g = new Geometry();
  for (let i = 0; i < count; i++) {
    const h = i === 0 ? rng.range(1.6, 2.4) : rng.range(0.5, 1.5);
    const r = h * rng.range(0.12, 0.18);
    const c = Geometry.lathe([[r * 0.8, -0.2], [r, h * 0.1], [r, h * 0.78], [0.0, h]], 6, { capBottom: true });
    c.paintExtra((p) => [0.25 + 1.4 * smoothstep(0, h, p[1]), 0, 0, rng.next()]);
    c.setColor([1, 1, 1], 1);
    const tilt = i === 0 ? rng.range(0, 0.15) : rng.range(0.25, 0.8);
    const a = rng.range(0, TAU);
    const dir = [Math.cos(a) * Math.sin(tilt), Math.cos(tilt), Math.sin(a) * Math.sin(tilt)];
    alongDir(c, dir, [Math.cos(a) * rng.range(0, 0.35), 0, Math.sin(a) * rng.range(0, 0.35)]);
    g.append(c);
  }
  return g;
}

// ------------------------------------------------------------------ floating island
export function floatingIsland(ctx, seed = 1, R0 = 5, { top: topCols = ['#16384a', '#2b6a70'] } = {}) {
  const { M } = ctx;
  const rng = new RNG(seed);
  const g = new Geometry();
  // grassy top
  // rim -> centre, so the faces look up (the other way round they were invisible from above)
  const top = Geometry.lathe([[R0 * 1.02, -0.4], [R0, -0.1], [R0 * 0.9, 0.12], [R0 * 0.5, 0.3], [0.0, 0.35]], 28);
  top.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const w = 1 + noise.n2(Math.cos(a) * 1.4 + seed, Math.sin(a) * 1.4) * 0.16;
    return [p[0] * w, p[1], p[2] * w];
  });
  top.computeNormals();
  top.paint((p, n) => mix3(C(topCols[0]), C(topCols[1]), noise.n3(p[0] * 0.5, 0, p[2] * 0.5) * 0.5 + 0.5).concat([1]));
  g.append(top);
  // rocky underside tapering to a point
  const depth = R0 * rng.range(1.2, 1.7);
  const under = Geometry.lathe([[0.0, -depth], [R0 * 0.15, -depth * 0.8], [R0 * 0.5, -depth * 0.45], [R0 * 0.85, -depth * 0.15], [R0 * 1.02, -0.4]], 22);
  under.deform((p) => {
    const a = Math.atan2(p[2], p[0]);
    const w = 1 + noise.n2(Math.cos(a) * 1.4 + seed, Math.sin(a) * 1.4) * 0.16;
    return [p[0] * w + Math.sin(p[1] * 0.7 + seed) * 0.3, p[1], p[2] * w];
  });
  under.computeNormals();
  under.displace((p) => noise.fbm3(p[0] * 0.4 + seed, p[1] * 0.4, p[2] * 0.4, 3) * R0 * 0.14, true);
  under.paint((p) => mix3(C('#20243a'), C('#565e80'), noise.n3(p[0] * 0.6, p[1] * 0.6, p[2] * 0.6) * 0.5 + 0.5).concat([smoothstep(-depth, 0, p[1]) * 0.5 + 0.5]));
  g.append(under);
  const island = new Node('island');
  island.add(makeMesh(ctx, g, M.mossBig, 'island'));
  // hanging roots
  const roots = new Geometry();
  for (let i = 0; i < 16; i++) {
    const a = rng.range(0, TAU), rr = R0 * rng.range(0.5, 0.95);
    const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
    const y0 = -depth * (1 - rr / R0) * 0.6 - 0.3;
    const len = rng.range(1.5, 4.5);
    const pts = [];
    for (let k = 0; k <= 5; k++) pts.push([x + Math.sin(k + i) * 0.15, y0 - (k / 5) * len, z + Math.cos(k * 0.7 + i) * 0.15]);
    const st = Geometry.tube(pts, (t) => 0.08 * (1 - t * 0.7), 4, { capEnd: false });
    st.setColor(mix3(C('#35505a'), C('#6a8f96'), rng.next()), 1);
    st.paintExtra((p) => [0, (y0 - p[1]) / len * 0.8 + 0.1, 0, rng.next()]);
    roots.append(st);
  }
  island.add(makeMesh(ctx, roots, M.mossStrands));
  // glowing crystals under the island
  const cr = new Geometry();
  for (let i = 0; i < 5; i++) {
    const c = crystalCluster(seed * 13 + i, 3);
    c.rotateX(Math.PI);
    c.scale(0.9);
    const a = rng.range(0, TAU), rr = R0 * rng.range(0.1, 0.45);
    c.translate(Math.cos(a) * rr, -depth * (1 - rr / R0) * 0.75, Math.sin(a) * rr);
    cr.append(c);
  }
  cr.setColor(C(rng.pick(['#9d7bff', '#6fe6ff', '#ff8ad8'])), 1);
  island.add(makeMesh(ctx, cr, M.crystal));
  return { node: island, depth, R: R0 };
}

// ------------------------------------------------------------------ fallen star heart + cracks
export function buildStarHeart(ctx) {
  const { M } = ctx;
  const R = result();
  // stellated core: icosphere with a spike on every face
  const core = Geometry.icosphere(1, 1);
  const spikes = new Geometry();
  for (let i = 0; i < core.idx.length; i += 3) {
    const ia = core.idx[i], ib = core.idx[i + 1], ic = core.idx[i + 2];
    const A = [core.p[ia * 3], core.p[ia * 3 + 1], core.p[ia * 3 + 2]];
    const B = [core.p[ib * 3], core.p[ib * 3 + 1], core.p[ib * 3 + 2]];
    const Cc = [core.p[ic * 3], core.p[ic * 3 + 1], core.p[ic * 3 + 2]];
    const cen = vnorm([(A[0] + B[0] + Cc[0]) / 3, (A[1] + B[1] + Cc[1]) / 3, (A[2] + B[2] + Cc[2]) / 3]);
    const tip = cen.map((v) => v * (1.9 + ((i * 7) % 5) * 0.12));
    const a = spikes.vert(...A, ...cen), b = spikes.vert(...B, ...cen), c = spikes.vert(...Cc, ...cen), t = spikes.vert(...tip, ...cen);
    spikes.tri(a, b, t); spikes.tri(b, c, t); spikes.tri(c, a, t);
  }
  spikes.computeNormals();
  spikes.setColor(C('#fff1c8'), 1);
  spikes.paintExtra((p) => [1.2 + Math.hypot(p[0], p[1], p[2]) * 0.6]);
  const node = new Node('starHeart');
  node.setPos(0, 3.2, 0);
  node.add(makeMesh(ctx, spikes, M.glass, 'star'));
  R.root.add(node);
  R.anchors.star = node;
  // cracks radiating over the crater floor
  const cracks = new Geometry();
  const rng = new RNG(4);
  for (let i = 0; i < 14; i++) {
    let a = (i / 14) * TAU + rng.range(-0.2, 0.2);
    let x = 0, z = 0;
    for (let k = 0; k < 7; k++) {
      const len = rng.range(1.2, 2.6);
      a += rng.range(-0.5, 0.5);
      const nx = x + Math.cos(a) * len, nz = z + Math.sin(a) * len;
      const seg = Geometry.box(0.14 * (1 - k / 8), 0.05, len);
      seg.rotateY(-a + Math.PI / 2);
      seg.translate((x + nx) / 2, 0.02, (z + nz) / 2);
      cracks.append(seg);
      x = nx; z = nz;
    }
  }
  cracks.setColor(C('#ffcf6e'), 1);
  cracks.setExtra([1.6]);
  const crackMesh = makeMesh(ctx, cracks, M.glow, 'cracks');
  crackMesh.castShadow = false;
  R.root.add(crackMesh);
  R.anchors.cracks = crackMesh;
  R.lights.push({ pos: [0, 3.5, 0], color: C('#ffd98a'), intensity: 6, radius: 22, flicker: 0.12, priority: 6 });
  R.colliders.push({ type: 'circle', x: 0, z: 0, r: 1.6, yMax: 5.5 });
  return R;
}

// ------------------------------------------------------------------ astronomer's tower with an outside spiral stair
export function buildTower(ctx) {
  const { M } = ctx;
  const R = result();
  const rT = 3.2, H = 16;
  // (no flared crown at the top: the platform covers it, and the stairs come up right beside it)
  const body = Geometry.lathe([[rT * 1.12, -0.5], [rT * 1.05, 0.5], [rT, H * 0.5], [rT * 0.94, H - 0.3], [rT * 0.97, H - 0.1], [rT * 0.99, H]], 28, { capTop: true });
  body.deform((p) => [p[0] + (p[1] / H) ** 2 * 0.7, p[1], p[2]]);
  body.computeNormals();
  body.displace((p) => noise.n3(p[0] * 1.2, p[1] * 0.8, p[2] * 1.2) * 0.07, true);
  body.paint((p) => mix3(C('#353b56'), C('#6a7194'), noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.5 + 0.5).concat([smoothstep(-0.5, 3, p[1]) * 0.4 + 0.6]));
  R.root.add(makeMesh(ctx, body, M.stoneFine, 'tower'));
  // windows
  const glow = new Geometry();
  for (let i = 0; i < 6; i++) {
    const a = i * 2.1 + 0.4, y = 3 + i * 2.1;
    const lean = (y / H) ** 2 * 0.7;
    const w = Geometry.box(0.45, 0.9, 0.1);
    w.translate(0, y, 0);
    w.rotateY(Math.PI / 2 - a);
    w.translate(Math.cos(a) * (rT - 0.02) + lean, 0, Math.sin(a) * (rT - 0.02));
    glow.append(w);
  }
  glow.setColor(C('#ffc070'), 1);
  glow.setExtra([2.4]);
  R.root.add(makeMesh(ctx, glow, M.glowSoft));
  // spiral steps
  const steps = new Geometry();
  const N = 40, turns = 1.4;
  const a0 = Math.PI / 2 + 0.3; // start in front
  for (let i = 0; i < N; i++) {
    const t = i / (N - 1);
    const a = a0 - t * turns * TAU;
    const top = 0.42 + t * (H - 0.62);
    // treads reach in to the tower wall, so there is no gap to slip through (you are small!)
    const rr = rT + 0.72;
    const lean = (top / H) ** 2 * 0.7;
    const cx = Math.cos(a) * rr + lean, cz = Math.sin(a) * rr;
    const st = Geometry.box(1.5, 0.28, 1.2, { y0: top - 0.28 });
    const yaw = Math.PI / 2 - a;
    st.rotateY(yaw);
    st.translate(cx, 0, cz);
    steps.append(st);
    R.surfaces.push({ type: 'box', x: cx, z: cz, hx: 0.75, hz: 0.64, yaw, top, bottom: top - 0.5 });
    // outer railing post every few steps
    if (i % 3 === 0) {
      const post = Geometry.box(0.08, 0.9, 0.08, { y0: top });
      post.translate(Math.cos(a) * (rr + 0.68) + lean, 0, Math.sin(a) * (rr + 0.68));
      steps.append(post);
    }
  }
  steps.paint((p) => mix3(C('#3a2e26'), C('#6a5240'), noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.5 + 0.5).concat([1]));
  R.root.add(makeMesh(ctx, steps, M.planks, 'stairs'));
  // top platform with railing, telescope and a little dome
  const lean = 0.7;
  // the platform has a real opening above the last steps (the stairs come up through it)
  const notchA = a0 - 0.955 * turns * TAU, notchW = 0.75, rIn = rT * 0.97; // (the walkable edge stays at rT * 1.03)
  const angD = (a) => { let d = Math.abs(((a - notchA) % TAU + TAU) % TAU); return Math.min(d, TAU - d); };
  const plat = new Geometry();
  {
    const NS = 64, yT = H + 0.25, yB = H - 0.1;
    const ct = plat.vert(0, yT, 0, 0, 1, 0), cb = plat.vert(0, yB, 0, 0, -1, 0);
    for (let i = 0; i < NS; i++) {
      const a1 = (i / NS) * TAU, a2 = ((i + 1) / NS) * TAU;
      const open = angD((a1 + a2) / 2) < notchW;
      const rt = open ? rIn : rT * 1.35, rb = open ? rIn : rT * 1.2;
      const P = (a, r, y) => [Math.cos(a) * r, y, Math.sin(a) * r];
      const t1 = P(a1, rt, yT), t2 = P(a2, rt, yT), b1 = P(a1, rb, yB), b2 = P(a2, rb, yB);
      const vt1 = plat.vert(...t1, 0, 1, 0), vt2 = plat.vert(...t2, 0, 1, 0);
      plat.tri(ct, vt2, vt1);
      const vb1 = plat.vert(...b1, 0, -1, 0), vb2 = plat.vert(...b2, 0, -1, 0);
      plat.tri(cb, vb1, vb2);
      const am = (a1 + a2) / 2, nx = Math.cos(am), nz = Math.sin(am);
      const s1 = plat.vert(...t1, nx, 0, nz), s2 = plat.vert(...t2, nx, 0, nz), s3 = plat.vert(...b2, nx, 0, nz), s4 = plat.vert(...b1, nx, 0, nz);
      plat.quad(s1, s2, s3, s4);
      // walls where the opening starts and ends
      const nextOpen = angD(((i + 1.5) / NS) * TAU) < notchW;
      if (open !== nextOpen) {
        const a = a2, ro = rT * 1.35, rbo = rT * 1.2, tn = [-Math.sin(a), 0, Math.cos(a)];
        const w1 = plat.vert(...P(a, rIn, yT), ...tn), w2 = plat.vert(...P(a, ro, yT), ...tn), w3 = plat.vert(...P(a, rbo, yB), ...tn), w4 = plat.vert(...P(a, rIn, yB), ...tn);
        plat.quad(w1, w2, w3, w4);
        plat.quad(w4, w3, w2, w1); // both sides (one wall faces each way)
      }
    }
  }
  plat.translate(lean, 0, 0);
  plat.setColor(C('#4a4f6c'), 1);
  const rail = new Geometry();
  for (let i = 0; i < 26; i++) {
    const a = (i / 26) * TAU;
    if (angD(a) < notchW + 0.08) continue; // opening at the stair top
    const post = Geometry.box(0.09, 1.0, 0.09, { y0: H + 0.25 });
    post.translate(Math.cos(a) * rT * 1.28 + lean, 0, Math.sin(a) * rT * 1.28);
    rail.append(post);
  }
  // the ring rail is an arc that leaves the opening free
  const railArc = TAU - 2 * (notchW + 0.08);
  const ringRail = Geometry.torus(rT * 1.28, 0.05, 4, 36, railArc);
  ringRail.rotateY(-(notchA + notchW + 0.08));
  ringRail.translate(lean, H + 1.2, 0);
  rail.append(ringRail);
  rail.setColor(C('#2c2c36'), 1);
  plat.append(rail);
  R.root.add(makeMesh(ctx, plat, M.metal));
  // the physics platform has the same opening
  R.surfaces.push({
    type: 'fn', x: lean, z: 0, r: rT * 1.3, bottom: H - 0.3,
    topFn: (lx, lz) => {
      if (Math.hypot(lx, lz) > rT * 1.3) return null;
      let d = Math.abs(((Math.atan2(lz, lx) - notchA) % TAU + TAU) % TAU);
      d = Math.min(d, TAU - d);
      if (d < notchW && Math.hypot(lx, lz) > rT * 1.03) return null;
      return H + 0.25;
    },
  });
  // telescope
  const tel = new Node('telescope');
  tel.setPos(lean - 0.8, H + 0.25, -0.6);
  tel.setEuler(-0.7, 0.8, 0);
  const tg = Geometry.cylinder(0.22, 0.32, 2.6, 14, 1);
  tg.translate(0, 0, 0);
  const tripod = new Geometry();
  for (let i = 0; i < 3; i++) {
    const l = Geometry.cylinder(0.04, 0.04, 1.3, 5, 1);
    l.rotateZ(0.4);
    l.rotateY((i / 3) * TAU);
    tripod.append(l);
  }
  tg.setColor(C('#b98a3a'), 1);
  const telMesh = makeMesh(ctx, tg, M.metal);
  telMesh.setPos(0, 1.1, 0);
  tel.add(telMesh);
  tripod.setColor(C('#2c2c36'), 1);
  const tri = makeMesh(ctx, tripod, M.metal);
  tel.add(tri);
  R.root.add(tel);
  R.anchors.telescope = tel;
  R.anchors.top = [lean, H + 0.25, 0];
  R.anchors.stairBottom = [Math.cos(a0) * (rT + 0.85), 0, Math.sin(a0) * (rT + 0.85)];
  R.lights.push({ pos: [lean, H + 2.5, 0], color: C('#ffd08a'), intensity: 2.2, radius: 9, flicker: 0.1 });
  R.lights.push({ pos: [0, 1.8, rT + 1.5], color: C('#ffb060'), intensity: 1.8, radius: 7, flicker: 0.1 });
  // door
  const door = Geometry.box(1.1, 2.0, 0.15, { y0: 0 });
  door.translate(0, 0, rT + 0.08);
  door.setColor(C('#3e2c22'), 1);
  R.root.add(makeMesh(ctx, door, M.wood));
  R.colliders.push({ type: 'circle', x: 0.2, z: 0, r: rT * 1.08, yMax: H - 0.35 });
  // railing keeps you on the platform (except at the stair opening)
  const ringR = rT * 1.3;
  const stairTopA = a0 - turns * TAU;
  for (let i = 0; i < 16; i++) {
    const a1 = (i / 16) * TAU, a2 = ((i + 1) / 16) * TAU;
    const mid = (a1 + a2) / 2;
    let dd = Math.abs(((mid - stairTopA) % TAU + TAU) % TAU);
    dd = Math.min(dd, TAU - dd);
    if (dd < 0.45) continue;
    R.colliders.push({ type: 'seg', ax: Math.cos(a1) * ringR + lean, az: Math.sin(a1) * ringR, bx: Math.cos(a2) * ringR + lean, bz: Math.sin(a2) * ringR, r: 0.15, yMin: H - 0.2 });
  }
  return R;
}

// ------------------------------------------------------------------ moon gate (fast travel portal)
export function buildMoonGate(ctx, { plinth: withPlinth = true } = {}) {
  const { M } = ctx;
  const R = result();
  const g = new Geometry();
  const ring = Geometry.torus(2.5, 0.38, 10, 40);
  ring.rotateX(Math.PI / 2);
  ring.translate(0, 3.0, 0);
  g.append(ring);
  for (const s of [-1, 1]) {
    const p = Geometry.roundedBox(0.9, 3.4, 0.9, 3, 0.4);
    p.translate(s * 2.6, 1.3, 0);
    g.append(p);
  }
  const base = Geometry.roundedBox(7.2, 0.7, 2.2, 3, 0.4);
  base.translate(0, 0.0, 0);
  g.append(base);
  // (v9.1) a stepped masonry plinth under the slab, wider towards the bottom and reaching well into the ground:
  // on a slope the gate stands on a built podium (a low stair, then fitted blocks) instead of a slab in the air
  g.displace((p) => noise.n3(p[0] * 1.3, p[1] * 1.3, p[2] * 1.3) * 0.06, true);
  if (withPlinth) {
    const stair = Geometry.roundedBox(8.0, 0.5, 3.0, 2, 0.12);
    stair.translate(0, -0.55, 0);
    g.append(stair);
    const plinth = Geometry.roundedBox(7.8, 2.4, 2.8, 2, 0.1);
    plinth.translate(0, -2.0, 0);
    g.append(plinth);
  }
  g.paint((p, n) => {
    let c = mix3(C('#3a4062'), C('#77809e'), noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.5 + 0.5);
    if (n[1] > 0.6) c = mix3(c, C('#1f4a48'), 0.6);
    if (p[1] < -0.84 && Math.abs(n[1]) < 0.7) {
      // fitted blocks: running bond courses with dark joints
      const row = Math.floor((p[1] + 0.84) / 0.52), u = (Math.abs(n[0]) > 0.5 ? p[2] : p[0]) / 1.15 + (row & 1) * 0.5;
      const jv = Math.abs(((p[1] + 0.84) / 0.52) - Math.round((p[1] + 0.84) / 0.52)), ju = Math.abs(u - Math.round(u));
      const joint = 1 - smoothstep(0.05, 0.1, Math.min(jv, ju * 0.45));
      c = mix3(mix3(c, C('#4a5070'), 0.35), C('#141626'), joint * 0.85);
    }
    return c.concat([1]);
  });
  R.root.add(makeMesh(ctx, g, M.stone, 'moongate'));
  // runes around the ring
  const runes = new Geometry();
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    const r = Geometry.box(0.1, 0.32, 0.06);
    r.rotateZ(a);
    r.translate(Math.cos(a) * 2.5, 3.0 + Math.sin(a) * 2.5, 0.4);
    runes.append(r);
    const r2 = r.clone();
    r2.translate(0, 0, -0.8);
    runes.append(r2);
  }
  runes.setColor(C('#b8a6ff'), 1);
  runes.setExtra([2.4]);
  R.root.add(makeMesh(ctx, runes, M.glow));
  // portal surface
  const disc = Geometry.disc(2.2, 40);
  disc.rotateX(Math.PI / 2);
  disc.translate(0, 3.0, 0);
  const mat = new Material({ kind: 'portal', transparent: true, blend: 'additive', depthWrite: false, castShadow: false, cull: 'none', renderOrder: 7 });
  const portal = makeMesh(ctx, disc, mat, 'portal');
  portal.castShadow = false;
  R.root.add(portal);
  R.anchors.portal = portal;
  R.lights.push({ pos: [0, 3, 0.8], color: C('#9a88ff'), intensity: 3, radius: 11, flicker: 0.06 });
  R.colliders.push({ type: 'circle', x: -2.6, z: 0, r: 0.6 }, { type: 'circle', x: 2.6, z: 0, r: 0.6 });
  R.surfaces.push({ type: 'box', x: 0, z: 0, hx: 3.6, hz: 1.1, top: 0.33, bottom: -1 });
  if (withPlinth) R.surfaces.push({ type: 'box', x: 0, z: 0, hx: 4.0, hz: 1.5, top: -0.3, bottom: -3.2 });
  return R;
}

// ------------------------------------------------------------------ the sleeping giant (lies along local z, head at -z)
export function buildGiant(ctx) {
  const { M } = ctx;
  const R = result();
  const g = new Geometry();
  const part = (geo) => { g.append(geo); return geo; };
  // torso: big half-buried ellipsoid
  const torso = Geometry.sphere(1, 28, 18);
  torso.scale(8.5, 6.5, 12);
  torso.translate(0, -1.5, 2);
  part(torso);
  // head
  const head = Geometry.sphere(1, 26, 18);
  head.scale(5.2, 4.8, 5.6);
  head.translate(0, 0.2, -13.5);
  part(head);
  const nose = Geometry.sphere(1, 14, 10);
  nose.scale(1.4, 2.4, 1.6);
  nose.translate(0, 4.3, -15.2);
  part(nose);
  // brow ridges over closed eyes
  for (const s of [-1, 1]) {
    const brow = Geometry.sphere(1, 12, 8);
    brow.scale(1.8, 0.8, 1.0);
    brow.translate(s * 2.1, 4.2, -13.3 - 2.2);
    part(brow);
    const lid = Geometry.sphere(1, 12, 8);
    lid.scale(1.4, 0.55, 0.9);
    lid.translate(s * 2.1, 3.75, -15.1);
    part(lid);
    // arms along the body
    const arm = [];
    for (let i = 0; i <= 8; i++) {
      const t = i / 8;
      arm.push([s * (8.6 + Math.sin(t * 3) * 0.8), -0.6 + Math.sin(t * Math.PI) * 1.2, -6 + t * 16]);
    }
    part(Geometry.tube(arm, (t) => 2.6 - t * 0.6, 12));
    const hand = Geometry.sphere(1, 16, 12);
    hand.scale(2.4, 1.6, 2.8);
    hand.translate(s * 9.4, 0.3, 11.5);
    part(hand);
    for (let f = 0; f < 4; f++) {
      const fp = [[s * (9.4 + (f - 1.5) * 0.9), 0.4, 13.2], [s * (9.4 + (f - 1.5) * 1.0), 0.9, 15.0], [s * (9.4 + (f - 1.5) * 1.05), 0.3, 16.2]];
      part(Geometry.tube(catmullRom(fp, 2), (t) => 0.55 - t * 0.2, 7));
    }
    // knees and feet further down
    const leg = [];
    for (let i = 0; i <= 8; i++) {
      const t = i / 8;
      leg.push([s * 3.8, -1 + Math.sin(t * Math.PI) * 4.5, 12 + t * 16]);
    }
    part(Geometry.tube(leg, (t) => 3.0 - t * 0.6, 12));
    const foot = Geometry.sphere(1, 14, 10);
    foot.scale(2.0, 3.2, 1.8);
    foot.translate(s * 3.8, 1.8, 29);
    part(foot);
  }
  g.displace((p) => noise.fbm3(p[0] * 0.18, p[1] * 0.18, p[2] * 0.18, 3) * 0.9, true);
  g.paint((p, n) => {
    const v = noise.fbm3(p[0] * 0.1, p[1] * 0.1, p[2] * 0.1, 3) * 0.5 + 0.5;
    let c = mix3(C('#2a2f44'), C('#6a7090'), v);
    c = mix3(c, C('#1d4a44'), smoothstep(0.35, 0.8, n[1]) * 0.85);
    return c.concat([smoothstep(-2, 4, p[1]) * 0.5 + 0.5]);
  });
  const body = makeMesh(ctx, g, M.mossBig, 'giant');
  const bodyNode = new Node('giantBody');
  bodyNode.add(body);
  R.root.add(bodyNode);
  R.anchors.body = bodyNode;
  // a beard of moss strands
  const beard = new Geometry();
  const rng = new RNG(9);
  for (let i = 0; i < 60; i++) {
    const a = rng.range(-1.3, 1.3);
    const x = Math.sin(a) * 4.2, z = -13.5 + Math.cos(a) * 1.5 + 3.8, y = 1.6 + rng.range(-0.5, 1.5);
    const len = rng.range(2, 4);
    const pts = [];
    for (let k = 0; k <= 4; k++) pts.push([x + Math.sin(k + i) * 0.2, y - k * 0.2, z + (k / 4) * len]);
    const st = Geometry.tube(pts, (t) => 0.22 * (1 - t * 0.6), 4, { capEnd: false });
    st.setColor(mix3(C('#3b5c5a'), C('#8aa8a0'), rng.next()), 0.9);
    st.paintExtra((p) => [0, 0.2, 0, rng.next()]);
    beard.append(st);
  }
  bodyNode.add(makeMesh(ctx, beard, M.mossStrands));
  R.anchors.mouth = [0, 2.2, -16.5];
  // you can climb him: soft domed surfaces over belly, head, hands, knees
  R.surfaces.push({ type: 'disc', x: 0, z: 2, r: 8.0, top: 4.9, dome: 3.4, bottom: -2 });
  R.surfaces.push({ type: 'disc', x: 0, z: -13.5, r: 4.6, top: 5.0, dome: 2.8, bottom: -2 });
  for (const s of [-1, 1]) {
    R.surfaces.push({ type: 'disc', x: s * 9.4, z: 11.5, r: 2.4, top: 1.9, dome: 1.2, bottom: -2 });
    R.surfaces.push({ type: 'disc', x: s * 3.8, z: 20, r: 3.0, top: 6.4, dome: 3.5, bottom: -2 });
    R.surfaces.push({ type: 'ramp', x: s * 8.7, z: 2, hx: 2.2, hz: 8, y0: 1.2, y1: 1.8, bottom: -2 });
  }
  return R;
}

// ------------------------------------------------------------------ ruins of a forgotten town
export function buildRuins(ctx, seed = 5) {
  const { M } = ctx;
  const R = result();
  const rng = new RNG(seed);
  const g = new Geometry();
  const col = (x, z, h, broken) => {
    const shaft = Geometry.cylinder(0.55, 0.62, h, 12, 4);
    shaft.deform((p) => {
      const a = Math.atan2(p[2], p[0]);
      const fl = 1 + Math.abs(Math.sin(a * 6)) * 0.05;
      return [p[0] * fl, p[1], p[2] * fl];
    });
    shaft.computeNormals();
    if (broken) {
      shaft.deform((p) => [p[0], p[1] > h - 0.4 ? h - 0.4 + noise.n2(p[0] * 3 + x, p[2] * 3) * 0.35 : p[1], p[2]]);
      shaft.computeNormals();
    }
    shaft.translate(x, 0, z);
    g.append(shaft);
    const base = Geometry.box(1.6, 0.4, 1.6, { y0: -0.1 });
    base.translate(x, 0, z);
    g.append(base);
    if (!broken) {
      const cap = Geometry.box(1.5, 0.35, 1.5, { y0: h });
      cap.translate(x, 0, z);
      g.append(cap);
    }
    R.colliders.push({ type: 'circle', x, z, r: 0.7, yMax: h - 0.3 });
    R.surfaces.push({ type: 'disc', x, z, r: broken ? 0.62 : 0.78, top: broken ? h - 0.35 : h + 0.35, bottom: 0 });
    return h;
  };
  const tops = [];
  // two rows of columns (a forgotten avenue)
  for (let i = 0; i < 6; i++) {
    for (const s of [-1, 1]) {
      if (rng.chance(0.2)) continue;
      const broken = rng.chance(0.55);
      const h = broken ? rng.range(1.2, 4.2) : rng.range(4.6, 5.4);
      const x = s * 4.2, z = -9 + i * 3.6;
      col(x, z, h, broken);
      tops.push([x, (broken ? h - 0.35 : h + 0.35), z]);
    }
  }
  // an arch at the end
  for (const s of [-1, 1]) col(s * 2.2, 13.5, 5.2, false);
  const arch = Geometry.torus(2.2, 0.45, 8, 20, Math.PI);
  arch.rotateX(0);
  arch.rotateX(-Math.PI / 2);
  arch.rotateX(Math.PI);
  arch.translate(0, 5.5, 13.5);
  g.append(arch);
  // fallen column pieces
  for (let i = 0; i < 4; i++) {
    const p = Geometry.cylinder(0.55, 0.58, rng.range(1.5, 3), 12, 1);
    p.rotateZ(Math.PI / 2);
    p.rotateY(rng.range(0, TAU));
    const x = rng.range(-7, 7), z = rng.range(-11, 10);
    p.translate(x, 0.5, z);
    g.append(p);
    R.colliders.push({ type: 'circle', x, z, r: 0.9, yMax: 1.0 });
  }
  // broken wall fragments
  for (let i = 0; i < 3; i++) {
    const w = Geometry.box(rng.range(3, 6), rng.range(1.2, 3.2), 0.7, { y0: -0.2 });
    w.deform((p) => [p[0], p[1] > 0.5 ? p[1] * (0.6 + 0.4 * (noise.n2(p[0] * 0.8 + i, 3) * 0.5 + 0.5)) : p[1], p[2]]);
    w.computeNormals();
    const yaw = rng.range(0, TAU);
    w.rotateY(yaw);
    const x = rng.range(-10, 10) * 1.1, z = rng.range(-12, 12);
    w.translate(x, 0, z);
    g.append(w);
  }
  g.displace((p) => noise.n3(p[0] * 1.5, p[1] * 1.5, p[2] * 1.5) * 0.05, false);
  g.paint((p, n) => {
    let c = mix3(C('#434866'), C('#8a90ac'), noise.n3(p[0] * 0.8, p[1] * 0.8, p[2] * 0.8) * 0.5 + 0.5);
    if (n[1] > 0.55) c = mix3(c, C('#1f4b46'), 0.7);
    c = mix3(c, C('#1f3b3a'), smoothstep(1.2, 0, p[1]) * 0.4);
    return c.concat([smoothstep(-0.5, 2, p[1]) * 0.4 + 0.6]);
  });
  R.root.add(makeMesh(ctx, g, M.stone, 'ruins'));
  // a giant fallen stone head, half buried
  const head = Geometry.sphere(1, 22, 16);
  head.scale(2.6, 3.0, 2.6);
  const nose = Geometry.sphere(1, 10, 8);
  nose.scale(0.6, 1.1, 0.8);
  nose.translate(0, -0.2, 2.5);
  head.append(nose);
  for (const s of [-1, 1]) {
    const eye = Geometry.sphere(0.45, 10, 8);
    eye.translate(s * 0.9, 0.6, 2.2);
    head.append(eye);
  }
  head.displace((p) => noise.fbm3(p[0] * 0.5, p[1] * 0.5, p[2] * 0.5, 3) * 0.2, true);
  head.paint((p, n) => mix3(C('#565c7a'), C('#1f4b46'), smoothstep(0.3, 0.9, n[1]) * 0.7).concat([1]));
  head.rotateZ(1.2);
  head.rotateY(0.6);
  head.translate(8, 0.8, -4);
  R.root.add(makeMesh(ctx, head, M.stone));
  R.colliders.push({ type: 'circle', x: 8, z: -4, r: 2.7 });
  R.surfaces.push({ type: 'disc', x: 8, z: -4, r: 2.2, top: 3.2, dome: 1.6, bottom: -1 });
  R.anchors.tops = tops;
  return R;
}

// ------------------------------------------------------------------ lore stone (readable)
export function loreStoneGeometry() {
  const g = Geometry.roundedBox(0.9, 1.6, 0.5, 3, 0.5);
  g.translate(0, 0.7, 0);
  g.deform((p) => [p[0] * (1 - p[1] * 0.12), p[1], p[2]]);
  g.displace((p) => noise.n3(p[0] * 3, p[1] * 3, p[2] * 3) * 0.04, true);
  g.paint((p, n) => mix3(C('#3e4462'), C('#1f4b46'), smoothstep(0.4, 0.9, n[1]) * 0.7).concat([1]));
  const rune = new Geometry();
  const strokes = [[0, 1.05, 0, 0.5], [-0.12, 0.85, 0.7, 0.25], [0.12, 0.8, -0.7, 0.25], [0, 0.55, 1.57, 0.28]];
  for (const [x, y, a, l] of strokes) {
    const b = Geometry.box(0.06, l, 0.04);
    b.rotateZ(a);
    b.translate(x, y, 0.27);
    rune.append(b);
  }
  rune.setColor(C('#8fd6ff'), 1);
  rune.setExtra([2.4]);
  return { stone: g, rune };
}

// ------------------------------------------------------------------ star shard (collectible)
export function starShardGeometry() {
  const g = new Geometry();
  const pts = [];
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + Math.PI / 2;
    const r = i % 2 === 0 ? 0.42 : 0.14;
    pts.push([Math.cos(a) * r, Math.sin(a) * r]);
  }
  for (const zs of [1, -1]) {
    const c = g.vert(0, 0, 0.12 * zs, 0, 0, zs);
    const ids = pts.map((p) => g.vert(p[0], p[1], 0, 0, 0, zs));
    for (let i = 0; i < 8; i++) {
      if (zs > 0) g.tri(c, ids[i], ids[(i + 1) % 8]);
      else g.tri(c, ids[(i + 1) % 8], ids[i]);
    }
  }
  g.computeNormals();
  g.setColor(C('#ffe7a0'), 1);
  g.setExtra([3.2]);
  return g;
}

// ------------------------------------------------------------------ bounce mushroom (instanced, unit size)
export function bounceShroom(seed = 1) {
  const rng = new RNG(seed);
  const g = new Geometry();
  const stem = Geometry.lathe(catmullRom([[0.22, 0], [0.16, 0.5], [0.14, 1.1], [0.18, 1.35]], 3), 12);
  stem.paint((p) => mix3(C('#6f6aa0'), C('#d8d2f0'), smoothstep(0, 1.2, p[1])).concat([1]));
  g.append(stem);
  const R0 = 0.95;
  const cap = Geometry.lathe(catmullRom([[0.2, 1.3], [R0, 1.28], [R0 * 1.05, 1.4], [R0 * 0.85, 1.72], [R0 * 0.4, 1.9], [0, 1.94]], 3), 24);
  cap.deform((p) => [p[0], p[1] + Math.sin(Math.atan2(p[2], p[0]) * 5) * 0.02, p[2]]);
  cap.computeNormals();
  cap.paint((p) => {
    const r = Math.hypot(p[0], p[2]) / R0;
    if (p[1] < 1.33 && r < 0.95) return C('#b89cff').concat([0.8]);
    return mix3(C('#7a2fe0'), C('#c24ad8'), smoothstep(0.3, 1.0, r)).concat([1]);
  });
  cap.paintExtra((p) => {
    const r = Math.hypot(p[0], p[2]) / R0;
    return [p[1] < 1.33 && r < 0.95 ? 0.8 : smoothstep(0.9, 1.05, r) * 0.8, 0, p[1] > 1.33 ? 1 : 0];
  });
  return { stem, cap, top: 1.94, R: R0 };
}

// ------------------------------------------------------------------ obelisk (desert)
export function obelisk(seed = 1) {
  const g = Geometry.box(1.2, 7, 1.2, { y0: 0 });
  g.deform((p) => [p[0] * (1 - p[1] / 7 * 0.35), p[1], p[2] * (1 - p[1] / 7 * 0.35)]);
  const tip = Geometry.cylinder(0.0, 0.55, 1.1, 4, 1);
  tip.rotateY(Math.PI / 4);
  tip.translate(0, 7, 0);
  g.append(tip);
  g.computeNormals();
  g.paint((p) => mix3(C('#2a2b44'), C('#565a80'), noise.n3(p[0] * 2 + seed, p[1] * 0.8, p[2] * 2) * 0.5 + 0.5).concat([1]));
  const runes = new Geometry();
  for (let i = 0; i < 5; i++) {
    for (const [dx, dz, ry] of [[0, 0.56, 0], [0, -0.56, Math.PI], [0.56, 0, Math.PI / 2], [-0.56, 0, -Math.PI / 2]]) {
      const b = Geometry.box(0.3, 0.06, 0.03);
      b.translate(0, 1 + i * 1.1, 0);
      b.rotateY(ry);
      b.translate(dx * (1 - (1 + i * 1.1) / 7 * 0.35), 0, dz * (1 - (1 + i * 1.1) / 7 * 0.35));
      runes.append(b);
    }
  }
  runes.setColor(C('#ffb54a'), 1);
  runes.setExtra([1.8]);
  return { stone: g, runes };
}

// ------------------------------------------------------------------ bridges over the rivers
// Lies along local z (the road), centred on the river. `stone`: arched stone bridge with low
// parapets and lanterns; otherwise a plank bridge with rope railings.
// endA / endB: deck height at the -z / +z ends (the banks may not be level: the deck ramps between them)
// (v9) ground(lx, lz): terrain height under a local point (relative to the bridge's origin). With it the
// bridge gets masonry abutments down into the banks and a short paved apron onto the road, so the deck
// never hangs over a gap where the ground falls away into the gorge.
export function buildBridge(ctx, { span = 14, width = 3.4, rise = 1.3, stone = true, seed = 1, endA = 0, endB = 0, ground = null } = {}) {
  const { M } = ctx;
  const R = result();
  const rng = new RNG(seed);
  const half = span / 2, hw = width / 2;
  const deck = (z) => endA + (endB - endA) * (z + half) / span + rise * (1 - (z / half) ** 2);
  const N = 16;
  const g = new Geometry();
  const rail = new Geometry();
  const glow = new Geometry();
  const thick = stone ? 0.55 : 0.18;
  // deck slab: top, underside (arched deeper for stone), sides
  const under = (z) => (stone ? deck(z) - thick - 1.4 * (1 - (z / half) ** 2) ** 0.6 : deck(z) - thick);
  const ring = [];
  for (let i = 0; i <= N; i++) {
    const z = -half + (i / N) * span;
    const yt = deck(z), yb = under(z) - (stone ? 0 : 0);
    ring.push([
      g.vert(-hw, yt, z, 0, 1, 0), g.vert(hw, yt, z, 0, 1, 0),
      g.vert(hw, yb, z, 1, 0, 0), g.vert(-hw, yb, z, -1, 0, 0),
    ]);
  }
  for (let i = 0; i < N; i++) {
    const a = ring[i], b = ring[i + 1];
    // (wound so that every face looks outwards: the deck's top used to face down and vanish from above)
    g.quad(b[0], b[1], a[1], a[0]); // top
    g.quad(b[1], b[2], a[2], a[1]); // right side
    g.quad(b[3], b[0], a[0], a[3]); // left side
    g.quad(b[2], b[3], a[3], a[2]); // underside
  }
  g.computeNormals();
  if (stone) {
    // parapets + end piers
    for (const sx of [-1, 1]) {
      for (let i = 0; i < N; i++) {
        const z0 = -half + (i / N) * span, z1 = -half + ((i + 1) / N) * span;
        const zc = (z0 + z1) / 2;
        const b = Geometry.box(0.32, 0.62, span / N + 0.02, { y0: 0 });
        b.rotateX(-Math.atan2(deck(z1) - deck(z0), z1 - z0));
        b.translate(sx * (hw - 0.16), deck(zc), zc);
        rail.append(b);
      }
      for (const sz of [-1, 1]) {
        const ey = sz < 0 ? endA : endB;
        const p = Geometry.roundedBox(0.7, 1.3, 0.7, 2, 0.12);
        p.translate(sx * (hw - 0.1), ey + 0.45, sz * (half + 0.2));
        rail.append(p);
        const cap = Geometry.sphere(0.16, 8, 6);
        cap.translate(sx * (hw - 0.1), ey + 1.25, sz * (half + 0.2));
        glow.append(cap);
        R.lights.push({ pos: [sx * (hw - 0.1), ey + 1.6, sz * (half + 0.2)], color: C('#9fd8ff'), intensity: 1.2, radius: 6, flicker: 0.05 });
      }
    }
    g.paint((p, n) => (n[1] > 0.5 ? C('#1e2132').concat([0.8]) : mix3(C('#3a3f58'), C('#6d7494'), noise.n3(p[0] * 1.3, p[1] * 1.3, p[2] * 1.3) * 0.5 + 0.5).concat([0.7])));
    rail.paint((p, n) => {
      let c = mix3(C('#353a52'), C('#636a8a'), noise.n3(p[0] * 2, p[1] * 2, p[2] * 2) * 0.5 + 0.5);
      if (n[1] > 0.6) c = mix3(c, C('#1f4a46'), 0.6);
      return c.concat([0.9]);
    });
    glow.setColor(C('#a8e4ff'), 1);
    glow.setExtra([3]);
  } else {
    // planks: darker gaps drawn as colour bands, posts and sagging rope rails
    g.paint((p, n) => (n[1] > 0.5 ? C('#140f0c').concat([0.7]) : mix3(C('#2e2620'), C('#5a4a3c'), noise.n3(p[0] * 2, p[1] * 5, p[2] * 2) * 0.5 + 0.5).concat([0.9])));
    for (const sx of [-1, 1]) {
      const posts = [];
      for (let i = 0; i <= 4; i++) {
        const z = -half + (i / 4) * span;
        const post = Geometry.cylinder(0.07, 0.08, 1.15, 6, 1);
        post.translate(sx * (hw - 0.05), deck(z) - 0.1, z);
        rail.append(post);
        posts.push([sx * (hw - 0.05), deck(z) + 1.0, z]);
      }
      for (let i = 0; i < posts.length - 1; i++) {
        const a = posts[i], b = posts[i + 1];
        const pts = [];
        for (let k = 0; k <= 6; k++) {
          const t = k / 6;
          pts.push([a[0], lerp(a[1], b[1], t) - Math.sin(t * Math.PI) * 0.18, lerp(a[2], b[2], t)]);
        }
        rail.append(Geometry.tube(pts, () => 0.025, 4));
      }
      // little lanterns hanging on the middle posts
      const lp = posts[2];
      const bulb = Geometry.sphere(0.12, 8, 6);
      bulb.scale(1, 1.3, 1);
      bulb.translate(lp[0] + sx * 0.12, lp[1] - 0.2, lp[2]);
      glow.append(bulb);
      R.lights.push({ pos: [lp[0] + sx * 0.3, lp[1], lp[2]], color: C('#ffb45a'), intensity: 1.4, radius: 5, flicker: 0.12 });
    }
    rail.setColor(C('#3a2e26'), 0.9);
    glow.setColor(C('#ffc070'), 1);
    glow.setExtra([3]);
  }
  // the walking surface: real paving stones (stone bridge) or loose planks with gaps (wooden bridge),
  // laid on the slab and following its curve
  const pave = new Geometry();
  const TH = stone ? 0.035 : 0.03;
  const slopeAt = (z) => Math.atan2(deck(z + 0.05) - deck(z - 0.05), 0.1);
  if (stone) {
    const xa = -(hw - 0.33), xb = hw - 0.33, rowL = 0.42;
    const rows = Math.floor(span / rowL);
    for (let r = 0; r < rows; r++) {
      const z0 = -half + (span - rows * rowL) / 2 + r * rowL, zc = z0 + rowL / 2;
      let x = xa - (r % 2) * 0.3;
      while (x < xb - 0.05) {
        const w = rng.range(0.45, 0.7);
        const x0 = Math.max(xa, x), x1 = Math.min(xb, x + w);
        if (x1 - x0 > 0.12) {
          const b = Geometry.box(x1 - x0 - 0.045, TH, rowL - 0.045, { y0: -0.01 });
          b.rotateX(-slopeAt(zc));
          b.translate((x0 + x1) / 2, deck(zc), zc);
          const k = rng.range(0, 1);
          b.setColor(mix3(C('#4a5070'), C('#7a82a4'), k), 0.9);
          pave.append(b);
        }
        x += w;
      }
    }
  } else {
    const pl = 0.26, rows = Math.floor(span / pl);
    for (let r = 0; r < rows; r++) {
      const zc = -half + (span - rows * pl) / 2 + r * pl + pl / 2;
      const b = Geometry.box(width - 0.12 + rng.range(-0.06, 0.06), TH, pl - 0.035, { y0: -0.01 });
      b.rotateY(rng.range(-0.02, 0.02));
      b.rotateX(-slopeAt(zc));
      b.translate(rng.range(-0.03, 0.03), deck(zc), zc);
      b.setColor(mix3(C('#3e3026'), C('#6a5646'), rng.range(0, 1)), 0.9);
      pave.append(b);
    }
  }
  // (v9) abutments and aprons
  const AP = 1.7, IN = Math.min(2.8, half * 0.42), aw = hw + 0.2;
  let apron = null;
  if (ground) {
    const gMax = (lz) => Math.max(ground(-aw, lz), ground(0, lz), ground(aw, lz));
    const gMin = (lz) => Math.min(ground(-aw, lz), ground(0, lz), ground(aw, lz), ground(-hw * 0.5, lz), ground(hw * 0.5, lz));
    const outer = [-1, 1].map((sg) => gMax(sg * (half + AP)) - 0.03);
    apron = (lz) => {
      const sg = lz < 0 ? -1 : 1;
      const t = Math.min(1, Math.max(0, (Math.abs(lz) - half) / AP));
      const e = deck(sg * half), o = outer[(sg + 1) / 2];
      return e + (o - e) * t * t * (3 - 2 * t);
    };
    const core = new Geometry();
    const masonry = new Geometry();
    const face = (g, a, b, c, d, out) => {
      let n = vcross(vsub(b, a), vsub(c, a));
      const flip = n[0] * out[0] + n[1] * out[1] + n[2] * out[2] < 0;
      const q = flip ? [d, c, b, a] : [a, b, c, d];
      n = vnorm(flip ? [-n[0], -n[1], -n[2]] : n);
      const ids = q.map((v) => g.vert(v[0], v[1], v[2], n[0], n[1], n[2]));
      g.quad(ids[0], ids[1], ids[2], ids[3]);
    };
    const pal = stone ? [C('#383d55'), C('#6a7192')] : [C('#373b4c'), C('#5e6478')];
    // ashlar blocks laid in courses on a wall; u runs along the wall, bot(u)/top(u) bound it
    const wall = (origin, uDir, out, u0, u1, bot, top) => {
      const len = u1 - u0;
      let lo = Infinity, hi = -Infinity;
      for (let k = 0; k <= 12; k++) { const u = u0 + (len * k) / 12; lo = Math.min(lo, bot(u)); hi = Math.max(hi, top(u)); }
      let y = lo, row = 0;
      while (y < hi - 0.12) {
        const ch = rng.range(0.5, 0.64);
        let u = u0 - (row % 2) * rng.range(0.3, 0.55);
        while (u < u1 - 0.05) {
          const bl = rng.range(0.75, 1.25);
          const a = Math.max(u0, u), b = Math.min(u1, u + bl);
          u += bl;
          if (b - a < 0.18) continue;
          const tmin = Math.min(top(a), top(b), top((a + b) / 2)) - 0.03;
          const bmax = Math.max(bot(a), bot(b), bot((a + b) / 2));
          const y0 = y + 0.02, y1 = Math.min(y + ch - 0.02, tmin);
          if (y1 - y0 < 0.14 || y1 < bmax) continue; // buried or squeezed out under the deck
          const blk = Geometry.box(b - a - 0.045, y1 - y0, 0.26, { y0: 0 });
          blk.rotateY(Math.atan2(uDir[0], uDir[2]) - Math.PI / 2);
          const mu = (a + b) / 2;
          blk.translate(origin[0] + uDir[0] * mu + out[0] * 0.1, y0, origin[2] + uDir[2] * mu + out[2] * 0.1);
          const k = rng.range(0, 1);
          const c = mix3(pal[0], pal[1], k);
          blk.paint((pp) => { const f = 0.72 + 0.28 * smoothstep(bmax, bmax + 1.4, pp[1]); return [c[0] * f, c[1] * f, c[2] * f, 0.85]; });
          masonry.append(blk);
        }
        y += ch;
        row++;
      }
    };
    for (const sg of [-1, 1]) {
      const zi = sg * (half - IN), zo = sg * (half + AP);
      const top = (lz) => (Math.abs(lz) <= half ? deck(lz) - 0.03 : apron(lz));
      const bot = (lz) => Math.max(gMin(lz) - 0.9, top(lz) - 15);
      // the solid core, one slice every ~25 cm
      const n = Math.ceil((IN + AP) / 0.25);
      const sl = [];
      for (let i = 0; i <= n; i++) {
        const lz = zi + ((zo - zi) * i) / n;
        const t = top(lz), b = bot(lz);
        sl.push([[-aw, t, lz], [aw, t, lz], [aw, b, lz], [-aw, b, lz]]);
      }
      for (let i = 0; i < n; i++) {
        const A = sl[i], B = sl[i + 1];
        face(core, A[0], A[1], B[1], B[0], [0, 1, 0]);
        face(core, A[1], A[2], B[2], B[1], [1, 0, 0]);
        face(core, A[3], A[0], B[0], B[3], [-1, 0, 0]);
        face(core, A[2], A[3], B[3], B[2], [0, -1, 0]);
      }
      face(core, sl[0][0], sl[0][1], sl[0][2], sl[0][3], [0, 0, -sg]);
      face(core, sl[n][0], sl[n][1], sl[n][2], sl[n][3], [0, 0, sg]);
      // masonry on the face towards the river and on both sides
      wall([0, 0, zi], [1, 0, 0], [0, 0, -sg], -aw, aw, (u) => ground(u, zi) - 0.35, () => under(zi) - 0.02);
      for (const sx of [-1, 1]) {
        const lo = Math.min(zi, zo), hi = Math.max(zi, zo);
        wall([sx * aw, 0, 0], [0, 0, 1], [sx, 0, 0], lo, hi, (u) => ground(sx * aw, u) - 0.35, top);
      }
    }
    core.paint((pp, nn) => (nn[1] > 0.5 ? C('#23263a').concat([0.8]) : C('#1b1d2c').concat([0.7])));
    R.root.add(makeMesh(ctx, core, M.stone, 'bridgeAbutment'));
    R.root.add(makeMesh(ctx, masonry, M.stone, 'bridgeMasonry'));
    // the apron's paving, in line with the deck's
    const ap = new Geometry();
    const slopeA = (z) => Math.atan2(apron(z + 0.05) - apron(z - 0.05), 0.1);
    for (const sg of [-1, 1]) {
      const rowL = 0.42, rows = Math.floor(AP / rowL);
      for (let r = 0; r < rows; r++) {
        const zc = sg * (half + r * rowL + rowL / 2);
        let x = -(aw - 0.08) - (r % 2) * 0.3;
        while (x < aw - 0.12) {
          const w = rng.range(0.45, 0.7);
          const x0 = Math.max(-(aw - 0.08), x), x1 = Math.min(aw - 0.08, x + w);
          if (x1 - x0 > 0.12) {
            const b = Geometry.box(x1 - x0 - 0.045, TH, rowL - 0.045, { y0: -0.01 });
            b.rotateX(-slopeA(zc));
            b.translate((x0 + x1) / 2, apron(zc), zc);
            b.setColor(mix3(C('#474d6c'), C('#767ea0'), rng.range(0, 1)), 0.9);
            ap.append(b);
          }
          x += w;
        }
      }
    }
    R.root.add(makeMesh(ctx, ap, M.stone, 'bridgeApron'));
  }
  const pm = makeMesh(ctx, pave, stone ? M.stone : M.planks, 'bridgeDeck');
  R.root.add(pm);
  R.root.add(makeMesh(ctx, g, stone ? M.stone : M.planks, 'bridge'));
  R.root.add(makeMesh(ctx, rail, stone ? M.stone : M.wood, 'bridgeRail'));
  const gm = makeMesh(ctx, glow, M.glow, 'bridgeGlow');
  gm.castShadow = false;
  R.root.add(gm);
  R.surfaces.push({
    type: 'fn', x: 0, z: 0, r: Math.hypot(aw, half + (apron ? AP : 0) + 0.3), bottom: -1.5,
    topFn: (lx, lz) => {
      const az = Math.abs(lz);
      if (Math.abs(lx) <= hw - (stone ? 0.3 : 0.05) && az <= half + 0.2) return deck(Math.max(-half, Math.min(half, lz))) + TH;
      if (apron && az > half && az <= half + AP && Math.abs(lx) <= aw) return apron(lz) + TH;
      return null;
    },
  });
  for (const sx of [-1, 1]) R.colliders.push({ type: 'seg', ax: sx * (hw + 0.05), az: -half - 0.3, bx: sx * (hw + 0.05), bz: half + 0.3, r: 0.2 });
  R.anchors.deck = deck;
  return R;
}
