// DOM user interface: screens, HUD, quest tracker, toasts, dialogue, compass, map, journal, settings.
import { T } from '../i18n.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

const IDS = [
  'loading', 'loadText', 'loadBar', 'title', 'btnPlay', 'btnNew', 'btnTitleSettings', 'titleHint',
  'hud', 'hudRegion', 'hudFound', 'hudShards', 'hudShardN', 'hudShardT', 'tracker', 'toasts', 'prompt', 'promptKey', 'promptVerb', 'promptName',
  'banner', 'bannerEyebrow', 'bannerName', 'bannerBlurb', 'dialogue', 'dialogueName', 'dialogueText', 'dialogueHint', 'keys', 'fps',
  'touch', 'lookPad', 'stick', 'knob', 'tJump', 'tAct', 'tMap', 'tMenu', 'tSneak', 'map', 'mapCanvas', 'mapFound',
  'pause', 'btnResume', 'btnMap', 'btnSettings', 'btnHome', 'journalList', 'journalQuests', 'journalPlaces', 'journalCollection',
  'travel', 'travelList', 'btnTravelBack', 'ending', 'endingStats', 'btnEndingContinue',
  'settings', 'setDyn', 'setSens', 'setMusic', 'setAmb', 'setSfx', 'setInvert', 'setLock', 'setFps', 'btnSettingsBack', 'fade', 'flash', 'compassStrip',
  'btnMulti', 'mpJoin', 'mpJoinForm', 'mpName', 'mpColors', 'mpStatus', 'btnMpGo', 'btnMpBack', 'btnMainMenu', 'mpPlayers', 'mpPlayersTitle', 'tChat', 'mpCount', 'chat',
  'minimap', 'miniCanvas', 'mmIn', 'mmOut', 'mmClose', 'mmOpen',
];

export class UI {
  constructor() {
    this.el = {};
    for (const id of IDS) this.el[id] = $(id);
    this.dialogue = null;
    this.bannerTimer = 0;
    this.currentRegion = null;
    this.mapBase = null;
    this.trackerKey = '';
    this.initMinimap();
    // journal tabs
    this.tab = 'quests';
    for (const b of document.querySelectorAll('.tabs button')) {
      b.addEventListener('click', () => this.selectTab(b.dataset.tab));
    }
  }

  // ------------------------------------------------------------ screens
  show(id, on = true) {
    const e = this.el[id];
    if (e) e.hidden = !on;
  }
  setLoading(p, text) {
    this.el.loadBar.style.width = Math.round(p * 100) + '%';
    if (text) this.el.loadText.textContent = T(text);
  }
  fade(on) {
    this.el.fade.classList.toggle('on', on);
  }
  // (v9) a cold, dark pulse (the silent ones)
  dark() {
    const f = this.el.flash;
    f.classList.remove('on');
    f.classList.add('dark');
    void f.offsetWidth;
    f.classList.add('on');
    clearTimeout(this._darkT);
    this._darkT = setTimeout(() => f.classList.remove('dark'), 1700);
  }
  flash() {
    const f = this.el.flash;
    f.classList.remove('on', 'dark');
    void f.offsetWidth;
    f.classList.add('on');
  }

  // ------------------------------------------------------------ multiplayer
  setMpMode(on) {
    document.getElementById('ui').classList.toggle('mpmode', on);
  }
  mpStatus(text, kind = '') {
    const e = this.el.mpStatus;
    e.textContent = T(text);
    e.className = 'mp-status' + (kind ? ' ' + kind : '');
  }
  mpColors(colors, current, onPick) {
    const box = this.el.mpColors;
    box.textContent = '';
    const btns = colors.map((c, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'radio');
      b.setAttribute('aria-label', T(c.name));
      b.title = T(c.name);
      b.style.background = c.coat;
      b.style.setProperty('--hat', c.hat);
      b.addEventListener('click', () => { pick(i); onPick(i); });
      box.appendChild(b);
      return b;
    });
    const pick = (i) => btns.forEach((b, j) => b.setAttribute('aria-checked', String(i === j)));
    pick(current);
  }
  // pause menu in multiplayer: who is in the forest, and which way
  mpPlayers(list, total) {
    this.el.mpPlayersTitle.textContent = T('Vándorok az erdőben: {0}', total);
    const ul = this.el.mpPlayers;
    ul.textContent = '';
    for (const p of list) {
      const li = document.createElement('li');
      const st = document.createElement('span');
      st.className = 'st';
      st.textContent = p.self ? '✦' : '●';
      st.style.color = p.css;
      const nm = document.createElement('span');
      const b = document.createElement('b');
      b.textContent = p.name;
      b.style.color = p.css;
      nm.appendChild(b);
      if (p.self) nm.appendChild(document.createTextNode(' ' + T('(te)')));
      const where = document.createElement('small');
      where.textContent = p.where || '';
      li.append(st, nm, where);
      ul.appendChild(li);
    }
    if (total > list.length) {
      const li = document.createElement('li');
      li.className = 'unknown';
      li.textContent = T('…és még {0} vándor, messze.', total - list.length);
      ul.appendChild(li);
    }
  }

  // (v8) the language changed: refresh what is already on screen
  relang() {
    if (this._cards) for (const c of this._cards) c.s.textContent = T(c.t);
    const r = this.currentRegion;
    this.currentRegion = undefined;
    this.el.hudRegion.textContent = T(r || 'FantasyWeald');
    this.currentRegion = r;
    if (this._found) this.setFound(this._found[0], this._found[1]);
    this.trackerKey = '';
    if (this.dialogue) this.closeDialogue();
  }

  // ------------------------------------------------------------ HUD
  setRegion(name) {
    if (this.currentRegion === name) return;
    this.currentRegion = name;
    const e = this.el.hudRegion;
    e.style.transition = 'opacity 0.4s';
    e.style.opacity = '0';
    setTimeout(() => {
      e.textContent = T(name || 'FantasyWeald');
      e.style.opacity = '1';
    }, 400);
  }
  setFound(n, total) {
    this._found = [n, total];
    const t = T('Felfedezve: {0} / {1}', n, total);
    this.el.hudFound.textContent = t;
    this.el.mapFound.textContent = t;
  }
  setShards(n, total, pop = false) {
    this.el.hudShardN.textContent = n;
    this.el.hudShardT.textContent = total;
    if (pop) {
      const e = this.el.hudShards;
      e.classList.remove('pop');
      void e.offsetWidth;
      e.classList.add('pop');
    }
  }
  banner({ eyebrow = 'Felfedezted', name, blurb = '' }) {
    const b = this.el.banner;
    this.el.bannerEyebrow.textContent = T(eyebrow);
    this.el.bannerName.textContent = T(name);
    this.el.bannerBlurb.textContent = T(blurb);
    b.hidden = false;
    b.classList.remove('show');
    void b.offsetWidth;
    b.classList.add('show');
    clearTimeout(this.bannerTimer);
    this.bannerTimer = setTimeout(() => (b.hidden = true), 8100);
  }
  // (v9) toasts stay long enough to be read: at least 6.5 s, plus time for longer text
  toast(title, { sub = '', gold = false, time = 0 } = {}) {
    const box = this.el.toasts;
    const d = document.createElement('div');
    d.className = 'toast' + (gold ? ' gold' : '');
    const tt = T(title), ts = sub ? T(sub) : '';
    d.innerHTML = `<b>${esc(tt)}</b>${ts ? `<small>${esc(ts)}</small>` : ''}`;
    time = Math.max(time, Math.min(14000, 5200 + (tt.length + ts.length) * 60));
    d.style.animationDuration = time + 'ms';
    box.appendChild(d);
    while (box.children.length > 4) box.firstChild.remove();
    setTimeout(() => d.remove(), time + 50);
  }
  tracker(list) {
    const key = JSON.stringify(list);
    if (key === this.trackerKey) return;
    this.trackerKey = key;
    this.el.tracker.innerHTML = list.map((o) => `<li><span class="tq${o.main ? ' main' : ''}">${esc(T(o.quest))}</span><span class="to">${esc(T(o.text))}</span>${o.detail ? `<span class="td">${esc(T(o.detail))}</span>` : ''}</li>`).join('');
  }
  prompt(target, touch) {
    const p = this.el.prompt;
    if (!target) {
      p.hidden = true;
      return;
    }
    p.hidden = false;
    this.el.promptKey.textContent = touch ? '◉' : 'E';
    const verb = target.verbFn ? target.verbFn() : target.verb || (target.kind === 'talk' ? 'Beszélgetés' : target.kind === 'read' ? 'Elolvasom' : target.kind === 'take' ? 'Felveszem' : 'Megnézem');
    this.el.promptVerb.textContent = T(verb);
    this.el.promptName.textContent = T(target.name);
  }
  openDialogue(name, text, hasMore) {
    text = T(text);
    this.dialogue = { name, text, shown: 0, done: false };
    this.el.dialogue.hidden = false;
    this.el.dialogueName.textContent = T(name);
    this.el.dialogueText.textContent = '';
    this.el.dialogueHint.textContent = T(hasMore ? 'E · tovább' : 'E · bezárás');
    const d = this.el.dialogue;
    d.style.animation = 'none';
    void d.offsetWidth;
    d.style.animation = '';
  }
  closeDialogue() {
    this.dialogue = null;
    this.el.dialogue.hidden = true;
  }
  dialogueTyping() {
    return this.dialogue && !this.dialogue.done;
  }
  finishTyping() {
    if (!this.dialogue) return;
    this.dialogue.shown = this.dialogue.text.length;
  }
  updateDialogue(dt) {
    const d = this.dialogue;
    if (!d || d.done) return;
    d.shown = Math.min(d.text.length, d.shown + dt * 55);
    this.el.dialogueText.textContent = d.text.slice(0, Math.floor(d.shown));
    if (d.shown >= d.text.length) d.done = true;
  }
  fps(v, visible, extra = '') {
    this.el.fps.hidden = !visible;
    if (visible) this.el.fps.textContent = `${v.toFixed(0)} FPS${extra}`;
  }
  fadeKeys() {
    this.el.keys.classList.add('faded');
  }

  // compass strip: heading 0 = north (-z). marks: { deg, kind: 'known'|'unknown'|'quest'|'shard'|'gate', name }
  compass(camYaw, marks) {
    const strip = this.el.compassStrip;
    if (!this._compassInit) {
      this._compassInit = true;
      this._cards = [['É', 0], ['ÉK', 45], ['K', 90], ['DK', 135], ['D', 180], ['DNY', 225], ['NY', 270], ['ÉNY', 315]].map(([t, deg]) => {
        const s = document.createElement('span');
        s.textContent = T(t);
        s.className = t.length === 1 ? 'card' : '';
        strip.appendChild(s);
        return { s, deg, t };
      });
      this._marks = [];
    }
    const heading = ((Math.atan2(Math.sin(camYaw), -Math.cos(camYaw)) * 180) / Math.PI + 360) % 360;
    const W = strip.clientWidth || 400;
    const place = (s, deg) => {
      let d = deg - heading;
      while (d > 180) d -= 360;
      while (d < -180) d += 360;
      const vis = Math.abs(d) < 75;
      s.style.display = vis ? '' : 'none';
      if (vis) s.style.left = `${W / 2 + (d / 75) * (W / 2)}px`;
    };
    for (const c of this._cards) place(c.s, c.deg);
    while (this._marks.length < marks.length) {
      const s = document.createElement('span');
      strip.appendChild(s);
      this._marks.push(s);
    }
    const glyph = { known: '◆', unknown: '◇', quest: '◎', shard: '✦', gate: '◈', friend: '●' };
    const color = { quest: '#ffd98a', shard: '#ffe7a0', gate: '#b8a6ff' };
    this._marks.forEach((s, i) => {
      const m = marks[i];
      if (!m) { s.style.display = 'none'; return; }
      s.className = 'mark' + (m.kind === 'unknown' ? ' unknown' : '');
      s.textContent = glyph[m.kind] || '◆';
      s.style.color = m.color || color[m.kind] || '';
      s.title = T(m.name || '');
      place(s, m.deg);
    });
  }

  // ------------------------------------------------------------ journal
  selectTab(tab) {
    this.tab = tab;
    for (const b of document.querySelectorAll('.tabs button')) b.setAttribute('aria-selected', String(b.dataset.tab === tab));
    this.el.journalQuests.hidden = tab !== 'quests';
    this.el.journalPlaces.hidden = tab !== 'places';
    this.el.journalCollection.hidden = tab !== 'collection';
  }
  journal(j) {
    // quests
    this.el.journalQuests.innerHTML = j.quests.length
      ? j.quests.map((q) => `<div class="quest${q.done ? ' done' : ''}"><h4>${esc(T(q.title))}${q.main ? `<span class="tag">${esc(T('fő'))}</span>` : ''}${q.done ? `<span class="tag">${esc(T('teljesítve'))}</span>` : ''}</h4>${q.desc ? `<p>${esc(T(q.desc))}</p>` : ''}${q.steps && q.steps.length ? `<ul>${q.steps.map((s) => `<li class="${s.ok ? 'ok' : ''}">${esc(T(s.text))}</li>`).join('')}</ul>` : ''}</div>`).join('')
      : `<p class="coll">${esc(T('Még nincs küldetésed. Beszélgess az erdő lakóival!'))}</p>`;
    // places
    const ul = this.el.journalList;
    ul.innerHTML = '';
    for (const r of j.places) {
      const li = document.createElement('li');
      li.className = r.known ? '' : 'unknown';
      li.innerHTML = r.known ? `<span class="st">✦</span><span>${esc(T(r.name))}<small>${esc(T(r.blurb))}</small></span>` : `<span class="st">✧</span><span>${esc(T(r.hidden ? 'Rejtett hely' : 'Ismeretlen hely'))}</span>`;
      ul.appendChild(li);
    }
    // collection
    const c = j.collection;
    let h = `<div class="coll"><div class="coll-grid">`;
    const lab = (k) => esc(T(k));
    h += `<div><b>${c.shards} / ${c.shardTotal}</b><span>${lab('csillagszilánk')}</span></div>`;
    h += `<div><b>${c.lore} / ${c.loreTotal}</b><span>${lab('rúnakő')}</span></div>`;
    h += `<div><b>${c.curios} / ${c.curioTotal}</b><span>${lab('csoda')}</span></div>`;
    h += `<div><b>${c.gates} / ${c.gateTotal}</b><span>${lab('holdkapu')}</span></div>`;
    if (c.creatureTotal) h += `<div><b>${c.creatures.length} / ${c.creatureTotal}</b><span>${lab('álomlény')}</span></div>`;
    h += `</div><h5>${lab('Képességek')}</h5>`;
    for (const a of c.abilities) h += `<p class="${a.has ? '' : 'locked'}">${a.has ? '✦' : '✧'} <b>${lab(a.name)}</b> — ${lab(a.has ? a.text : a.lockText)}</p>`;
    if (c.items.length) { h += `<h5>${lab('Tarsoly')}</h5><p>${c.items.map(lab).join(' · ')}</p>`; }
    if (c.curioNames.length) { h += `<h5>${lab('Csodák')}</h5>`; for (const n of c.curioNames) h += `<p>✧ <b>${lab(n.name)}</b> — ${lab(n.blurb)}</p>`; }
    if (c.creatureTotal) {
      h += `<h5>${lab('Álomlények')}</h5>`;
      if (c.creatures.length) for (const n of c.creatures) h += `<p>❦ <b>${lab(n.name)}</b> — ${lab(n.blurb)}</p>`;
      else h += `<p class="locked">${lab('Még egy álomlénnyel sem találkoztál. Nézz körül: a fűben, a tetőkön, az égen…')}</p>`;
    }
    h += `<h5>${lab('Rúnakövek')}</h5>`;
    if (c.loreTexts.length) for (const t of c.loreTexts) h += `<p class="lore">${lab(t)}</p>`;
    else h += `<p class="locked">${lab('Még egy rúnakövet sem olvastál el.')}</p>`;
    h += `</div>`;
    this.el.journalCollection.innerHTML = h;
    this.selectTab(this.tab);
  }

  // ------------------------------------------------------------ travel & ending
  travel(list, onPick, onBack) {
    const box = this.el.travelList;
    box.innerHTML = '';
    if (!list.length) {
      const p = document.createElement('p');
      p.className = 'panel-sub';
      p.textContent = T('Még nem ébresztettél fel másik Holdkaput. Keresd őket a helyszínek közelében!');
      box.appendChild(p);
    }
    for (const g of list) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn';
      b.innerHTML = `${esc(T(g.name))}<small>${esc(g.dist)}</small>`;
      b.addEventListener('click', () => onPick(g));
      box.appendChild(b);
    }
    this.el.btnTravelBack.onclick = onBack;
    this.show('travel', true);
    const first = box.querySelector('button');
    (first || this.el.btnTravelBack).focus();
  }
  ending(stats, onContinue) {
    this.el.endingStats.textContent = stats;
    this.el.btnEndingContinue.onclick = onContinue;
    this.show('ending', true);
    setTimeout(() => this.el.btnEndingContinue.focus(), 50);
  }

  // ------------------------------------------------------------ settings binding
  bindSettings(settings, onChange) {
    const e = this.el;
    const segBtns = [...document.querySelectorAll('.seg button')];
    const refresh = () => {
      segBtns.forEach((b) => b.setAttribute('aria-checked', String(Number(b.dataset.q) === settings.quality)));
      e.setDyn.checked = settings.dynRes;
      e.setSens.value = settings.sensitivity;
      e.setMusic.value = settings.music;
      e.setAmb.value = settings.ambience;
      e.setSfx.value = settings.sfx;
      e.setInvert.checked = settings.invertY;
      e.setLock.checked = settings.pointerLock;
      e.setFps.checked = settings.showFps;
    };
    refresh();
    segBtns.forEach((b) => b.addEventListener('click', () => { settings.quality = Number(b.dataset.q); refresh(); onChange('quality'); }));
    const num = (el, key) => el.addEventListener('input', () => { settings[key] = Number(el.value); onChange(key); });
    num(e.setSens, 'sensitivity');
    num(e.setMusic, 'music');
    num(e.setAmb, 'ambience');
    num(e.setSfx, 'sfx');
    const chk = (el, key) => el.addEventListener('change', () => { settings[key] = el.checked; onChange(key); });
    chk(e.setDyn, 'dynRes');
    chk(e.setInvert, 'invertY');
    chk(e.setLock, 'pointerLock');
    chk(e.setFps, 'showFps');
    this.refreshSettings = refresh;
  }

  // ------------------------------------------------------------ map
  buildMapBase(terrain, waterLevel) {
    const n = terrain.n;
    const c = document.createElement('canvas');
    c.width = n;
    c.height = n;
    const g = c.getContext('2d');
    const img = g.createImageData(n, n);
    const H = terrain.h;
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const k = j * n + i;
        const h = H[k];
        const hl = H[j * n + Math.max(0, i - 1)], hu = H[Math.max(0, j - 1) * n + i];
        const shade = Math.max(0, Math.min(1, 0.55 + (hl - h) * 0.35 + (hu - h) * 0.35));
        let r = 12 + shade * 40, gg = 14 + shade * 44, b = 38 + shade * 80;
        const hn = Math.min(1, Math.max(0, h / 40));
        r += hn * 30; gg += hn * 30; b += hn * 40;
        if (terrain.wRock[k] > 0.5) { r += 10; gg += 10; b += 14; }
        if (terrain.wSand && terrain.wSand[k] > 0.4) { r += 34 * terrain.wSand[k]; gg += 24 * terrain.wSand[k]; b += 6 * terrain.wSand[k]; }
        if (terrain.tintA && terrain.tintA[k] > 0.3) { r += 24 * terrain.tintA[k]; b += 30 * terrain.tintA[k]; }
        if (h < waterLevel) {
          const d = Math.min(1, (waterLevel - h) / 3);
          r = 10 + (1 - d) * 30; gg = 90 + (1 - d) * 70; b = 110 + (1 - d) * 60;
        }
        const p = terrain.wPath[k];
        if (p > 0.3) { r = r + (170 - r) * p * 0.8; gg = gg + (200 - gg) * p * 0.8; b = b + (255 - b) * p * 0.8; }
        if (h > 1 && Math.abs(((h / 6) % 1) - 0.5) < 0.05) { r *= 0.8; gg *= 0.8; b *= 0.9; }
        const o = k * 4;
        img.data[o] = r; img.data[o + 1] = gg; img.data[o + 2] = b; img.data[o + 3] = 255;
      }
    }
    g.putImageData(img, 0, 0);
    this.mapBase = c;
  }
  // m: { terrain, waterLevel, regions, player, discovered, revealed, targets, gates, curios, time }
  // ---------------------------------------------------------------- (v9.1c) minimap, top right
  initMinimap() {
    const ZOOMS = (this.mmZooms = [45, 90, 180, 360]);
    let st = { open: true, zoom: 1 };
    try { const v = JSON.parse(localStorage.getItem('fw.minimap') || 'null'); if (v && typeof v === 'object') st = { open: v.open !== false, zoom: Math.max(0, Math.min(ZOOMS.length - 1, v.zoom | 0)) }; } catch (e) { /* private mode */ }
    this.mm = st;
    const save = () => { try { localStorage.setItem('fw.minimap', JSON.stringify(this.mm)); } catch (e) { /* ignore */ } };
    const apply = () => {
      this.el.minimap.hidden = !this.mm.open;
      this.el.mmOpen.hidden = this.mm.open;
      this.el.hud.classList.toggle('mm-on', this.mm.open);
      this.el.hud.classList.toggle('mm-off', !this.mm.open);
      this.el.mmIn.disabled = this.mm.zoom <= 0;
      this.el.mmOut.disabled = this.mm.zoom >= ZOOMS.length - 1;
      this.mmDirty = true;
    };
    const stop = (e) => { e.stopPropagation(); };
    for (const b of [this.el.mmIn, this.el.mmOut, this.el.mmClose, this.el.mmOpen, this.el.minimap]) {
      b.addEventListener('pointerdown', stop);
      b.addEventListener('mousedown', stop);
      b.addEventListener('touchstart', stop, { passive: true });
    }
    const zoom = (d) => { this.mm.zoom = Math.max(0, Math.min(ZOOMS.length - 1, this.mm.zoom + d)); apply(); save(); };
    this.el.mmIn.addEventListener('click', () => zoom(-1));
    this.el.mmOut.addEventListener('click', () => zoom(1));
    this.el.mmClose.addEventListener('click', () => { this.mm.open = false; apply(); save(); });
    this.el.mmOpen.addEventListener('click', () => { this.mm.open = true; apply(); save(); });
    this.el.minimap.addEventListener('wheel', (e) => { e.preventDefault(); e.stopPropagation(); zoom(e.deltaY > 0 ? 1 : -1); }, { passive: false });
    this.toggleMinimap = () => { this.mm.open = !this.mm.open; apply(); save(); };
    apply();
  }
  drawMinimap(m) {
    if (!this.mm || !this.mm.open) return;
    if (!this.mapBase) this.buildMapBase(m.terrain, m.waterLevel);
    const cv = this.el.miniCanvas;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const css = cv.clientWidth || 184;
    const S = Math.max(64, Math.round(css * dpr));
    if (cv.width !== S) { cv.width = S; cv.height = S; }
    const g = cv.getContext('2d');
    const R = this.mmZooms[this.mm.zoom], k = S / (2 * R);
    const p = m.player, px = p.pos[0], pz = p.pos[2];
    const toMini = (x, z) => [S / 2 + (x - px) * k, S / 2 + (z - pz) * k];
    const size = m.terrain.size, mb = this.mapBase, bw = mb.width;
    g.save();
    g.clearRect(0, 0, S, S);
    g.beginPath();
    g.arc(S / 2, S / 2, S / 2, 0, Math.PI * 2);
    g.clip();
    g.fillStyle = 'rgb(26,104,124)';
    g.fillRect(0, 0, S, S);
    // the island map under us (the same picture as the big map)
    const u0 = ((px - R + size / 2) / size) * bw, v0 = ((pz - R + size / 2) / size) * bw, uw = ((2 * R) / size) * bw;
    const cu0 = Math.max(0, u0), cv0 = Math.max(0, v0), cu1 = Math.min(bw, u0 + uw), cv1 = Math.min(bw, v0 + uw);
    if (cu1 > cu0 && cv1 > cv0) {
      g.imageSmoothingEnabled = true;
      g.drawImage(mb, cu0, cv0, cu1 - cu0, cv1 - cv0, ((cu0 - u0) / uw) * S, ((cv0 - v0) / uw) * S, ((cu1 - cu0) / uw) * S, ((cv1 - cv0) / uw) * S);
    }
    const clampRim = (x, y, pad) => {
      const dx = x - S / 2, dy = y - S / 2, d = Math.hypot(dx, dy), lim = S / 2 - pad;
      return d > lim ? [S / 2 + (dx / d) * lim, S / 2 + (dy / d) * lim, true] : [x, y, false];
    };
    // moon gates
    g.textAlign = 'center';
    g.font = `${Math.round(13 * dpr)}px "Cormorant Garamond", Georgia, serif`;
    for (const gt of m.gates || []) {
      const [x, y] = toMini(gt.x, gt.z);
      if (Math.hypot(x - S / 2, y - S / 2) > S / 2 - 6 * dpr) continue;
      g.fillStyle = gt.active ? '#c8b8ff' : 'rgba(150,140,210,0.45)';
      g.fillText('\u25C8', x, y + 5 * dpr);
    }
    // the Lantern of the Deep: a faint light (and its body, when it is close)
    if (m.leviathan) {
      const lv = m.leviathan;
      g.save();
      g.lineCap = 'round';
      g.strokeStyle = `rgba(3,10,24,${lv.up ? 0.5 : 0.3})`;
      g.lineWidth = Math.max(2, 26 * k);
      g.beginPath();
      lv.body.forEach((q, i) => { const [x, y] = toMini(q[0], q[1]); if (i) g.lineTo(x, y); else g.moveTo(x, y); });
      g.stroke();
      const [lx, ly, out] = clampRim(...toMini(lv.lure[0], lv.lure[1]), 7 * dpr);
      const lp = 0.55 + 0.45 * Math.sin(m.time * (lv.hunting ? 5 : 1.6));
      g.beginPath();
      g.arc(lx, ly, (out ? 2.2 : 3) * dpr, 0, Math.PI * 2);
      g.fillStyle = `rgba(170,245,255,${(out ? 0.35 : 0.5) + lp * 0.3})`;
      g.shadowColor = lv.hunting ? '#ff9a8a' : '#8ff4ff';
      g.shadowBlur = 8 * dpr;
      g.fill();
      g.restore();
    }
    // other dreamers
    for (const o of m.others || []) {
      const [x, y] = clampRim(...toMini(o.x, o.z), 5 * dpr);
      g.beginPath();
      g.arc(x, y, 3.2 * dpr, 0, Math.PI * 2);
      g.fillStyle = o.css;
      g.fill();
    }
    // quest targets (on the rim when they are further away)
    const pulse = 1 + Math.sin(m.time * 3) * 0.15;
    for (const t of m.targets || []) {
      const tp = t.pos || t;
      if (!tp || !Number.isFinite(tp[0])) continue;
      const [x, y, out] = clampRim(...toMini(tp[0], tp[2]), 8 * dpr);
      g.beginPath();
      g.arc(x, y, (out ? 3.2 : 5.5 * pulse) * dpr, 0, Math.PI * 2);
      g.strokeStyle = '#ffd98a';
      g.lineWidth = 1.6 * dpr;
      g.shadowColor = '#ffb45a';
      g.shadowBlur = 8 * dpr;
      g.stroke();
      if (!out) { g.beginPath(); g.arc(x, y, 1.8 * dpr, 0, Math.PI * 2); g.fillStyle = '#ffe7a0'; g.fill(); }
      g.shadowBlur = 0;
    }
    // soft dark rim
    const grd = g.createRadialGradient(S / 2, S / 2, S * 0.34, S / 2, S / 2, S * 0.5);
    grd.addColorStop(0, 'rgba(5,6,20,0)');
    grd.addColorStop(1, 'rgba(5,6,20,0.7)');
    g.fillStyle = grd;
    g.fillRect(0, 0, S, S);
    // north
    g.font = `600 ${Math.round(12 * dpr)}px "Cormorant Garamond", Georgia, serif`;
    g.fillStyle = 'rgba(255,231,160,0.9)';
    g.fillText('N', S / 2, 14 * dpr);
    // you
    g.translate(S / 2, S / 2);
    g.rotate(-p.yaw + Math.PI);
    g.beginPath();
    g.moveTo(0, -8 * dpr); g.lineTo(5.5 * dpr, 6 * dpr); g.lineTo(0, 3 * dpr); g.lineTo(-5.5 * dpr, 6 * dpr);
    g.closePath();
    g.fillStyle = '#bff0ff';
    g.shadowColor = '#8fe6ff';
    g.shadowBlur = 10 * dpr;
    g.fill();
    g.restore();
  }

  drawMap(m) {
    if (!this.mapBase) this.buildMapBase(m.terrain, m.waterLevel);
    const cv = this.el.mapCanvas;
    const g = cv.getContext('2d');
    const S = cv.width;
    const size = m.terrain.size;
    // the map shows the island, and as much of the dream sea around it as you have wandered into
    const ext = m.extent || size;
    const toMap = (x, z) => [((x + ext / 2) / ext) * S, ((z + ext / 2) / ext) * S];
    g.clearRect(0, 0, S, S);
    g.imageSmoothingEnabled = true;
    g.fillStyle = 'rgb(38,132,150)';
    g.fillRect(0, 0, S, S);
    if (ext > size) {
      // faint tiles under the sea
      g.strokeStyle = 'rgba(200,240,255,0.08)';
      g.lineWidth = 1;
      const stp = (40 / ext) * S;
      for (let v = (S / 2) % stp; v < S; v += stp) { g.beginPath(); g.moveTo(v, 0); g.lineTo(v, S); g.stroke(); g.beginPath(); g.moveTo(0, v); g.lineTo(S, v); g.stroke(); }
    }
    const [ix, iz] = toMap(-size / 2, -size / 2);
    g.drawImage(this.mapBase, ix, iz, (size / ext) * S, (size / ext) * S);
    const grd = g.createRadialGradient(S / 2, S / 2, S * 0.36, S / 2, S / 2, S * 0.56);
    grd.addColorStop(0, 'rgba(5,6,20,0)');
    grd.addColorStop(1, 'rgba(5,6,20,0.92)');
    g.fillStyle = grd;
    g.fillRect(0, 0, S, S);
    g.textAlign = 'center';
    // curiosities
    for (const c of m.curios) {
      const [mx, my] = toMap(c.x, c.z);
      g.font = '18px "Cormorant Garamond", Georgia, serif';
      g.fillStyle = '#9fe7ff';
      g.fillText('✧', mx, my + 6);
    }
    // moon gates
    for (const gt of m.gates) {
      const [mx, my] = toMap(gt.x, gt.z);
      g.font = '20px "Cormorant Garamond", Georgia, serif';
      g.fillStyle = gt.active ? '#c8b8ff' : 'rgba(150,140,210,0.35)';
      g.fillText('◈', mx, my + 7);
    }
    // regions
    for (const r of m.regions) {
      const known = m.discovered.has(r.id);
      if (r.hidden && !known && !m.revealed) continue;
      const [mx, my] = toMap(r.center[0], r.center[1]);
      g.beginPath();
      g.arc(mx, my, (r.radius / size) * S, 0, Math.PI * 2);
      g.strokeStyle = r.sky ? (known ? 'rgba(230,200,255,0.5)' : 'rgba(200,180,240,0.25)') : known ? 'rgba(160,220,255,0.35)' : 'rgba(140,150,210,0.2)';
      g.setLineDash(r.sky ? [2, 4] : known ? [] : [4, 6]);
      g.lineWidth = 1.2;
      g.stroke();
      g.setLineDash([]);
      g.font = known ? '600 20px "Cormorant Garamond", Georgia, serif' : 'italic 18px "Cormorant Garamond", Georgia, serif';
      g.shadowColor = 'rgba(0,0,0,0.9)';
      g.shadowBlur = 6;
      g.fillStyle = known ? '#eaf0ff' : 'rgba(170,178,230,0.6)';
      const rn = T(r.name);
      g.fillText(known || m.revealed ? (r.sky ? '☁ ' + rn : r.sea ? '≈ ' + rn : rn) : '?', mx, my + 8);
      g.shadowBlur = 0;
    }
    // (v9.1) the Lantern of the Deep, live: a faint dark shape in the sea and its slowly pulsing light
    if (m.leviathan) {
      const lv = m.leviathan, k = S / ext;
      const inView = (x, z) => { const [a, b] = toMap(x, z); return a > -40 && a < S + 40 && b > -40 && b < S + 40; };
      if (inView(lv.x, lv.z) || lv.body.some((q) => inView(q[0], q[1]))) {
        // (v9.1b) a smooth, tapering silhouette that bends with the body: head, neck, the long curving tail
        const hx = lv.x + Math.sin(lv.yaw) * 30, hz = lv.z + Math.cos(lv.yaw) * 30;
        const pts = [[hx, hz, 9], [lv.x + Math.sin(lv.yaw) * 15, lv.z + Math.cos(lv.yaw) * 15, 15]].concat(lv.body);
        const P = pts.map((q) => { const [x, y] = toMap(q[0], q[1]); return [x, y, Math.max(0.8, q[2] * k * 0.62)]; });
        const Lh = [], Rh = [];
        for (let i = 0; i < P.length; i++) {
          const a0 = P[Math.max(0, i - 1)], a1 = P[Math.min(P.length - 1, i + 1)];
          let tx = a1[0] - a0[0], ty = a1[1] - a0[1];
          const tl = Math.hypot(tx, ty) || 1;
          tx /= tl; ty /= tl;
          Lh.push([P[i][0] - ty * P[i][2], P[i][1] + tx * P[i][2]]);
          Rh.push([P[i][0] + ty * P[i][2], P[i][1] - tx * P[i][2]]);
        }
        const smooth = (arr, first) => {
          if (first) g.moveTo(arr[0][0], arr[0][1]); else g.lineTo(arr[0][0], arr[0][1]);
          for (let i = 1; i < arr.length - 1; i++) g.quadraticCurveTo(arr[i][0], arr[i][1], (arr[i][0] + arr[i + 1][0]) / 2, (arr[i][1] + arr[i + 1][1]) / 2);
          g.lineTo(arr[arr.length - 1][0], arr[arr.length - 1][1]);
        };
        g.save();
        g.beginPath();
        smooth(Lh, true);
        const tail = P[P.length - 1];
        g.lineTo(tail[0], tail[1]);
        smooth(Rh.slice().reverse(), false);
        g.closePath();
        g.fillStyle = `rgba(3,10,24,${lv.up ? 0.5 : 0.3})`;
        g.fill();
        g.lineWidth = 1;
        g.strokeStyle = `rgba(120,220,245,${lv.up ? 0.22 : 0.12})`;
        g.stroke();
        // a faint row of lights along its flank
        g.fillStyle = `rgba(140,240,255,${lv.up ? 0.35 : 0.18})`;
        for (let i = 3; i < P.length - 2; i += 2) { g.beginPath(); g.arc(P[i][0], P[i][1], 1.1, 0, Math.PI * 2); g.fill(); }
        g.restore();
        g.save();
        const [lx, ly] = toMap(lv.lure[0], lv.lure[1]);
        const lp = 0.55 + 0.45 * Math.sin(m.time * (lv.hunting ? 5 : 1.6));
        g.beginPath();
        g.arc(lx, ly, 3 + lp * 2, 0, Math.PI * 2);
        g.fillStyle = `rgba(170,245,255,${0.45 + lp * 0.35})`;
        g.shadowColor = lv.hunting ? '#ff9a8a' : '#8ff4ff';
        g.shadowBlur = 10 + lp * 8;
        g.fill();
        g.restore();
      } else {
        // off the edge of the map: a faint light on the rim, towards where it swims
        let [lx, ly] = toMap(lv.lure[0], lv.lure[1]);
        const cx = S / 2, cyy = S / 2, dx = lx - cx, dy = ly - cyy, sc = (S / 2 - 16) / Math.max(Math.abs(dx), Math.abs(dy));
        lx = cx + dx * sc; ly = cyy + dy * sc;
        const lp = 0.55 + 0.45 * Math.sin(m.time * (lv.hunting ? 5 : 1.6));
        g.save();
        g.translate(lx, ly);
        g.rotate(Math.atan2(dy, dx));
        g.beginPath();
        g.moveTo(12, 0); g.lineTo(2, -7); g.lineTo(2, 7); g.closePath();
        g.fillStyle = `rgba(160,240,255,${0.4 + lp * 0.35})`;
        g.shadowColor = lv.hunting ? '#ff9a8a' : '#8ff4ff';
        g.shadowBlur = 12 + lp * 6;
        g.fill();
        g.beginPath();
        g.arc(-4, 0, 3.5, 0, Math.PI * 2);
        g.fill();
        g.restore();
      }
    }
    // quest targets
    const pulse = 1 + Math.sin(m.time * 3) * 0.12;
    for (const t of m.targets) {
      const tp = t.pos || t;
      if (!tp || !Number.isFinite(tp[0])) continue;
      const [mx, my] = toMap(tp[0], tp[2]);
      g.beginPath();
      g.arc(mx, my, 13 * pulse, 0, Math.PI * 2);
      g.strokeStyle = '#ffd98a';
      g.lineWidth = 2;
      g.shadowColor = '#ffb45a';
      g.shadowBlur = 12;
      g.stroke();
      g.beginPath();
      g.arc(mx, my, 3.5, 0, Math.PI * 2);
      g.fillStyle = '#ffe7a0';
      g.fill();
      g.shadowBlur = 0;
    }
    // other dreamers (multiplayer)
    if (m.others) {
      g.font = '600 15px "Cormorant Garamond", Georgia, serif';
      const labels = [];
      for (const o of m.others) {
        let [mx, my] = toMap(o.x, o.z);
        mx = Math.max(10, Math.min(S - 10, mx)); my = Math.max(10, Math.min(S - 10, my));
        g.beginPath();
        g.arc(mx, my, 5, 0, Math.PI * 2);
        g.fillStyle = o.css;
        g.shadowColor = o.css;
        g.shadowBlur = 10;
        g.fill();
        g.shadowColor = 'rgba(0,0,0,0.9)';
        g.shadowBlur = 5;
        // names only where they don't pile up on each other
        if (labels.every((q) => Math.abs(q[0] - mx) > 60 || Math.abs(q[1] - my) > 14)) { g.fillText(o.name, mx, my - 9); labels.push([mx, my]); }
        g.shadowBlur = 0;
      }
    }
    // player arrow
    const p = m.player;
    let [px, pz] = toMap(p.pos[0], p.pos[2]);
    px = Math.max(18, Math.min(S - 18, px)); pz = Math.max(18, Math.min(S - 18, pz));
    g.save();
    g.translate(px, pz);
    g.rotate(-p.yaw + Math.PI);
    g.beginPath();
    g.arc(0, 0, 16 * pulse, 0, Math.PI * 2);
    g.fillStyle = 'rgba(143,230,255,0.18)';
    g.fill();
    g.beginPath();
    g.moveTo(0, -13);
    g.lineTo(8, 9);
    g.lineTo(0, 4);
    g.lineTo(-8, 9);
    g.closePath();
    g.fillStyle = '#bff0ff';
    g.shadowColor = '#8fe6ff';
    g.shadowBlur = 14;
    g.fill();
    g.restore();
    // compass rose
    g.save();
    g.translate(S - 70, 70);
    g.strokeStyle = 'rgba(200,210,255,0.6)';
    g.fillStyle = 'rgba(220,228,255,0.9)';
    g.lineWidth = 1;
    g.beginPath();
    g.arc(0, 0, 34, 0, Math.PI * 2);
    g.stroke();
    for (let k = 0; k < 4; k++) {
      g.rotate(Math.PI / 2);
      g.beginPath();
      g.moveTo(0, -30); g.lineTo(5, 0); g.lineTo(-5, 0); g.closePath();
      g.fill();
    }
    g.restore();
    g.font = '700 22px "Grenze Gotisch", Georgia, serif';
    g.fillStyle = '#eef0ff';
    g.fillText(T('É'), S - 70, 26);
  }

  // ------------------------------------------------------------ touch
  enableTouch(input) {
    this.el.touch.hidden = false;
    this.el.keys.hidden = true;
    if (this._touchOn) return;
    this._touchOn = true;
    input.attachTouch({
      stick: this.el.stick,
      knob: this.el.knob,
      lookPad: this.el.lookPad,
      buttons: { Space: this.el.tJump, KeyE: this.el.tAct, KeyM: this.el.tMap, Escape: this.el.tMenu },
    });
    const sn = this.el.tSneak;
    sn.addEventListener('touchstart', (e) => {
      input.sneakToggle = !input.sneakToggle;
      sn.setAttribute('aria-pressed', String(input.sneakToggle));
      e.preventDefault();
    }, { passive: false });
  }
}
