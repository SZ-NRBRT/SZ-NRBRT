// Ash Isle (Hamusziget): the realm of the Seven-Headed Dragon, out on the dream sea. A dark volcanic island
// ringed by obsidian spikes, grey ash and glowing lava cracks, the bones of whatever came too close, the
// broken pillars of an old throne, and in the middle, in a shallow bowl, the dragon asleep around its
// hoard. A red pillar of light marks it from far away. The creatures themselves live in game/realm.js;
// this file builds the place and hands the game its shape (W.ashIsle).
import { Geometry, catmullRom } from '../engine/geometry.js';
import { Node, Material } from '../engine/scene.js';
import { RNG, TAU, lerp, smoothstep } from '../engine/math.js';
import { noise } from '../engine/noise.js';
import { C } from '../models/materials.js';
import { SEA_FLOOR } from './terrain.js';
import { particleSystem } from './fx.js';

const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

export function buildAshIsle(sea, x, z) {
  const W = sea.W, P = W.physics, WL = W.L.waterLevel;
  const R = 72;
  const rng = new RNG(6660);
  const face = Math.atan2(-x, -z); // the dragon looks back towards the forest island
  const VOLC = [-6, -52], VOLC_R = 21, VOLC_H = 26;
  // ------------------------------------------------------------ the island's shape (local coordinates)
  const coast = (a) => R + noise.n2(Math.cos(a) * 2.1 + 5, Math.sin(a) * 2.1) * 6 + Math.sin(a * 3 + 1) * 3;
  const height = (lx, lz) => {
    const r = Math.hypot(lx, lz), a = Math.atan2(lz, lx);
    const c = coast(a);
    let h = lerp(WL - 3.2, WL + 2.2, smoothstep(c + 5, c - 12, r));
    const inner = smoothstep(c - 4, c - 20, r);
    h += noise.fbm2(lx * 0.045 + 3, lz * 0.045 - 7, 3) * 1.4 * inner;
    // a ring of low ridges around the lair, and the lair itself: a shallow bowl
    h += Math.exp(-(((r - 27) / 6) ** 2)) * 1.6 * inner;
    h -= smoothstep(21, 7, r) * 1.1;
    // the smoking mountain behind the throne, with a glowing crater on top
    const vr = Math.hypot(lx - VOLC[0], lz - VOLC[1]);
    if (vr < VOLC_R) {
      const u = 1 - vr / VOLC_R;
      h += Math.pow(u, 1.35) * VOLC_H * (1 + noise.n2(lx * 0.2, lz * 0.2) * 0.08) - smoothstep(0.8, 0.97, u) * 9;
    }
    // and under water the rock falls away steeply, so the sea around it stays deep
    h -= smoothstep(c + 2, c + 12, r) * 5;
    return h;
  };
  const ext = R + 12;
  // ------------------------------------------------------------ lava cracks (their paths; the ground glows around them)
  const cracks = [];
  for (let k = 0; k < 22; k++) {
    let a = (k / 22) * TAU + rng.range(-0.2, 0.2), r = rng.range(8, 14);
    const pts = [];
    for (let s = 0; s < 34; s++) {
      const lx = Math.cos(a) * r, lz = Math.sin(a) * r;
      if (r > coast(a) - 6) break;
      if (Math.hypot(lx - VOLC[0], lz - VOLC[1]) < VOLC_R * 0.75) break; // not up the mountain
      pts.push([lx, height(lx, lz) + 0.04, lz]);
      a += rng.range(-0.07, 0.07);
      r += rng.range(0.9, 1.7);
    }
    if (pts.length >= 3) cracks.push(pts);
  }
  const CELL = 4, grid = new Map();
  for (const pts of cracks) {
    for (let i = 0; i < pts.length - 1; i++) {
      const key = Math.floor(pts[i][0] / CELL) + ',' + Math.floor(pts[i][2] / CELL);
      if (!grid.has(key)) grid.set(key, []);
      grid.get(key).push([pts[i], pts[i + 1]]);
    }
  }
  const crackDist = (x, z) => {
    let best = 99;
    const cx = Math.floor(x / CELL), cz = Math.floor(z / CELL);
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
      const list = grid.get(cx + i + ',' + (cz + j));
      if (!list) continue;
      for (const [a, b] of list) {
        const vx = b[0] - a[0], vz = b[2] - a[2];
        const t = Math.max(0, Math.min(1, ((x - a[0]) * vx + (z - a[2]) * vz) / (vx * vx + vz * vz || 1)));
        best = Math.min(best, Math.hypot(x - a[0] - vx * t, z - a[2] - vz * t));
      }
    }
    return best;
  };
  // ------------------------------------------------------------ ground mesh (polar grid, denser in the middle)
  const g = new Geometry();
  const RINGS = 64, SEG = 160;
  const rows = [];
  for (let i = 0; i <= RINGS; i++) {
    const u = i / RINGS;
    const r = ext * Math.pow(u, 0.85);
    const row = [];
    for (let j = 0; j < (i === 0 ? 1 : SEG); j++) {
      const a = (j / SEG) * TAU;
      const lx = Math.cos(a) * r, lz = Math.sin(a) * r;
      row.push(g.vert(lx, height(lx, lz), lz));
    }
    rows.push(row);
  }
  for (let j = 0; j < SEG; j++) g.tri(rows[0][0], rows[1][(j + 1) % SEG], rows[1][j]);
  for (let i = 1; i < RINGS; i++) {
    for (let j = 0; j < SEG; j++) {
      const a = rows[i][j], b = rows[i][(j + 1) % SEG], c = rows[i + 1][(j + 1) % SEG], d = rows[i + 1][j];
      g.quad(a, b, c, d);
    }
  }
  g.computeNormals();
  g.paint((p, n) => {
    const ash = noise.fbm2(p[0] * 0.09, p[2] * 0.09, 3) * 0.5 + 0.5;
    const wet = smoothstep(WL + 0.4, WL - 0.3, p[1]);
    let c = mix3(C('#151216'), C('#2e282e'), ash);
    c = mix3(c, C('#0a0809'), smoothstep(0.75, 0.4, n[1]) * 0.7);
    // near the crater the rock is scorched red
    const vr = Math.hypot(p[0] - VOLC[0], p[2] - VOLC[1]);
    c = mix3(c, C('#3a1210'), smoothstep(10, 3, vr) * 0.8);
    c = mix3(c, C('#0c0c12'), wet);
    // the ash is warm around the fissures: a dull red glow under it
    const heat = Math.exp(-((crackDist(p[0], p[2]) / 1.6) ** 2));
    c = mix3(c, C('#3a0c06'), heat * 0.85);
    return c.concat([0.85]);
  });
  g.paintExtra((p) => [Math.exp(-((crackDist(p[0], p[2]) / 1.6) ** 2)) * 0.55, 0, 0, 0]);
  const groundM = new Material({ uniforms: { uRough: 0.95, uDetail: [1.4, 0.35, 0.6, 1], uGlitter: [0, 0, 0], uRim: 0.1, uFill: 0.05, uWrap: 0.2 } });
  const node = new Node('ashIsle');
  node.setPos(x, 0, z);
  node.setRotY(face);
  const ground = W.mesh(g, groundM, 'ashGround');
  ground.maxDistance = 900;
  node.add(ground);
  // local <-> world (the node is turned so that local +z faces the forest island)
  const cf = Math.cos(face), sf = Math.sin(face);
  const toWorld = (lx, lz) => [x + lx * cf + lz * sf, z - lx * sf + lz * cf];
  const toLocal = (wx, wz) => { const dx = wx - x, dz = wz - z; return [dx * cf - dz * sf, dx * sf + dz * cf]; };
  // walkable ground (it goes all the way down: you can't swim under the island)
  P.addSurface({
    type: 'fn', x, z, r: ext, top: WL + 6, bottom: SEA_FLOOR - 1, noCamera: false, tag: 'ash',
    topFn: (wx, wz) => {
      // (fn surfaces get coordinates relative to their centre, unrotated)
      const lx = wx * cf - wz * sf, lz = wx * sf + wz * cf;
      if (lx * lx + lz * lz > ext * ext) return null;
      const h = height(lx, lz);
      return h > WL - 3 ? h : null;
    },
  });
  // ------------------------------------------------------------ lava cracks: glowing seams in the ash
  const lava = new Geometry();
  for (const pts of cracks) {
    // a thin fissure, wider in the middle, flattened onto the ash
    const t = Geometry.tube(pts, (u) => 0.055 * Math.sin(Math.PI * Math.min(1, u * 1.15 + 0.05)) + 0.012, 4, { capEnd: true });
    t.deform((p) => { const gh = height(p[0], p[2]); return [p[0], gh + 0.05 + (p[1] - (gh + 0.04)) * 0.25, p[2]]; });
    lava.append(t);
  }
  // the crater: a disc of lava in the mountain's mouth
  {
    const top = height(VOLC[0], VOLC[1]);
    const d = Geometry.disc(VOLC_R * 0.2, 24);
    d.translate(VOLC[0], top + 1.2, VOLC[1]);
    lava.append(d);
  }
  lava.paint((p) => (p[1] > WL + 12 ? C('#ff6a24') : C('#b02a0c')).concat([1]));
  lava.setExtra([0.4]);
  const lavaM = W.mesh(lava, W.M.glow, 'lavaCracks');
  lavaM.castShadow = false;
  lavaM.maxDistance = 420;
  node.add(lavaM);
  // ------------------------------------------------------------ obsidian spikes: a crown around the shore, a few inside for cover
  const obs = new Geometry();
  const spike = (lx, lz, h, r, lean = 0.12) => {
    const s = Geometry.cylinder(0.02, r, h, 5, 3); // (base at y=0)
    s.deform((p) => { const k = p[1] / h; return [p[0] + noise.n2(p[1] * 0.4, lx) * 0.25 * k, p[1], p[2]]; });
    const a = Math.atan2(lz, lx);
    s.rotateZ(-lean);
    s.rotateY(-a);
    s.translate(lx, height(lx, lz) - 0.6, lz);
    obs.append(s);
    const [wx, wz] = toWorld(lx, lz);
    P.addCircle(wx, wz, r * 0.8, { yMax: height(lx, lz) + h * 0.8 });
  };
  const gates = [1.9, 3.9, 5.9]; // three ways in (one of them faces the forest island)
  for (let i = 0; i < 44; i++) {
    const a = (i / 44) * TAU;
    if (gates.some((ga) => Math.abs(((a - ga + Math.PI * 3) % TAU) - Math.PI) < 0.22)) continue;
    const r = coast(a) - rng.range(6, 10);
    spike(Math.cos(a) * r, Math.sin(a) * r, rng.range(5, 13), rng.range(0.9, 1.8), rng.range(0.1, 0.35));
  }
  const cover = [];
  for (let i = 0; i < 12; i++) {
    const a = rng.range(0, TAU), r = rng.range(32, 52);
    const lx = Math.cos(a) * r, lz = Math.sin(a) * r;
    spike(lx, lz, rng.range(3.5, 6), rng.range(1.2, 1.9), rng.range(-0.1, 0.1));
    cover.push([lx, lz]);
  }
  obs.computeNormals();
  obs.paint((p, n) => mix3(C('#0a0910'), C('#3a2a52'), Math.max(0, n[1]) * 0.6 + Math.max(0, n[0]) * 0.2).concat([1]));
  const obsM = W.mesh(obs, W.M.glossy, 'obsidian');
  obsM.maxDistance = 700;
  node.add(obsM);
  // ------------------------------------------------------------ bones: a great ribcage, a skull, scattered bones
  const bones = new Geometry();
  const rib = (cx, cz, yaw, span, n) => {
    for (let i = 0; i < n; i++) {
      const off = (i - (n - 1) / 2) * 1.6;
      const pts = [];
      for (let k = 0; k <= 8; k++) {
        const u = k / 8, ang = u * Math.PI;
        pts.push([Math.cos(ang) * span * (1 - i * 0.04), Math.sin(ang) * span * 0.9 * (1 - Math.abs(off) * 0.05), off]);
      }
      const t = Geometry.tube(pts, () => 0.22, 6, { capStart: true, capEnd: true });
      t.rotateY(yaw);
      t.translate(cx, height(cx, cz) - 0.3, cz);
      bones.append(t);
    }
    const spine = Geometry.tube([[0, 0.1, -(n / 2) * 1.8], [0, 0.4, (n / 2) * 1.8]], () => 0.35, 6, { capStart: true, capEnd: true });
    spine.rotateY(yaw);
    spine.translate(cx, height(cx, cz) - 0.1, cz);
    bones.append(spine);
  };
  rib(-38, 14, 0.7, 4.2, 7);
  rib(30, -30, -0.4, 3.2, 5);
  const skull = Geometry.sphere(2.2, 14, 10);
  skull.scale(1, 0.8, 1.4);
  skull.deform((p) => [p[0], p[1], p[2] + (p[1] < 0 ? p[1] * 0.3 : 0)]);
  const sk = [-18, -34];
  skull.translate(sk[0], height(sk[0], sk[1]) + 0.9, sk[1]);
  bones.append(skull);
  for (let i = 0; i < 30; i++) {
    const a = rng.range(0, TAU), r = rng.range(14, 58);
    const lx = Math.cos(a) * r, lz = Math.sin(a) * r;
    const b = Geometry.cylinder(0.08, 0.1, rng.range(0.8, 2.2), 5, 1);
    b.rotateZ(Math.PI / 2);
    b.rotateY(rng.range(0, TAU));
    b.translate(lx, height(lx, lz) + 0.08, lz);
    bones.append(b);
  }
  bones.computeNormals();
  bones.paint((p) => mix3(C('#6a6258'), C('#a09682'), smoothstep(0, 4, p[1] - WL)).concat([0.9]));
  const bonesM = W.mesh(bones, W.M.plaster, 'ashBones');
  bonesM.maxDistance = 260;
  node.add(bonesM);
  P.addCircle(...toWorld(sk[0], sk[1]), 2.4, { yMax: height(sk[0], sk[1]) + 3 });
  // ------------------------------------------------------------ the broken throne: black pillars behind the lair
  const ruin = new Geometry();
  for (let i = 0; i < 7; i++) {
    const a = Math.PI + (i - 3) * 0.28, r = 34;
    const lx = Math.cos(a + Math.PI / 2) * r * 0.0 + Math.sin(a) * r, lz = Math.cos(a) * r;
    const h = [9, 5, 12, 14, 11, 4, 8][i];
    const col = Geometry.box(2.2, h, 2.2, { y0: 0 });
    col.deform((p) => [p[0] * (1 - p[1] / h * 0.15), p[1], p[2] * (1 - p[1] / h * 0.15)]);
    col.rotateY(rng.range(-0.3, 0.3));
    col.translate(lx, height(lx, lz) - 0.3, lz);
    ruin.append(col);
    const [wx, wz] = toWorld(lx, lz);
    P.addCircle(wx, wz, 1.5, { yMax: height(lx, lz) + h });
  }
  // a toppled arch lintel
  const lint = Geometry.box(9, 1.6, 2, { y0: 0 });
  lint.rotateZ(0.35);
  lint.translate(-3, height(-3, -33) + 12.5, -33.5);
  ruin.append(lint);
  ruin.computeNormals();
  ruin.paint((p) => mix3(C('#16121c'), C('#3a2e44'), noise.n3(p[0] * 0.5, p[1] * 0.5, p[2] * 0.5) * 0.5 + 0.5).concat([0.9]));
  const ruinM = W.mesh(ruin, W.M.stone, 'throneRuins');
  ruinM.maxDistance = 520;
  node.add(ruinM);
  // ------------------------------------------------------------ the hoard, cradled between the dragon's flank and its curled tail
  const hoardL = [8.5, -11];
  const HR = 3.0, HH = 1.15;
  const hy0 = height(hoardL[0], hoardL[1]) - 0.1;
  const moundY = (dx, dz) => { const q = 1 - (dx * dx + dz * dz) / (HR * HR); return q > 0 ? hy0 + Math.sqrt(q) * HH : null; };
  const hoardAt = (dx, dz) => moundY(dx, dz) ?? height(hoardL[0] + dx, hoardL[1] + dz);
  const gold = new Geometry(), wood = new Geometry(), steel = new Geometry(), gems = new Geometry(), boneG = new Geometry();
  // the heap itself: lumpy with thousands of coins, darker in the hollows
  const mound = Geometry.sphere(HR, 40, 18);
  mound.scale(1, HH / HR, 1);
  mound.displace((p) => noise.n3(p[0] * 3.1, p[1] * 3.1, p[2] * 3.1) * 0.08 + noise.n3(p[0] * 16, p[1] * 16, p[2] * 16) * 0.035, true);
  mound.translate(hoardL[0], hy0, hoardL[1]);
  mound.paint((p) => mix3(C('#2a1604'), C('#9a6a1c'), smoothstep(-0.5, 0.7, noise.n3(p[0] * 16, p[1] * 16, p[2] * 16))).concat([0.8]));
  gold.append(mound);
  // coins: a thick layer over the heap (tilted with its slope), and a spill around it
  for (let i = 0; i < 720; i++) {
    const a = rng.range(0, TAU), r = i < 560 ? Math.sqrt(rng.next()) * HR * 0.97 : HR * 0.95 + Math.pow(rng.next(), 1.6) * 2.6;
    const dx = Math.cos(a) * r, dz = Math.sin(a) * r;
    const y = hoardAt(dx, dz);
    const rad = rng.range(0.09, 0.15);
    const coin = Geometry.cylinder(rad, rad, 0.025, 9, 1);
    const slope = r < HR ? Math.atan((HH / HR) * (r / HR) / Math.sqrt(Math.max(0.05, 1 - (r / HR) ** 2))) : 0;
    coin.rotateX(rng.next() < 0.08 ? Math.PI / 2 : rng.range(-0.35, 0.35) - Math.min(1.1, slope));
    coin.rotateY(-a + Math.PI / 2 + rng.range(-0.3, 0.3));
    coin.translate(hoardL[0] + dx, y + 0.005, hoardL[1] + dz);
    const tone = rng.range(0, 1);
    coin.setColor(mix3(C('#8a5a14'), C('#f0c060'), tone), 1);
    gold.append(coin);
  }
  // goblets, a candlestick, a few ingots
  for (let i = 0; i < 8; i++) {
    const a = rng.range(0, TAU), r = rng.range(0.6, HR * 0.85);
    const dx = Math.cos(a) * r, dz = Math.sin(a) * r;
    const cup = Geometry.lathe([[0.12, 0], [0.13, 0.03], [0.05, 0.08], [0.035, 0.22], [0.06, 0.28], [0.15, 0.36], [0.19, 0.5], [0.2, 0.56]], 14);
    cup.rotateZ(rng.range(-0.5, 0.5));
    cup.rotateY(rng.range(0, TAU));
    cup.translate(hoardL[0] + dx, hoardAt(dx, dz) - 0.08, hoardL[1] + dz);
    cup.setColor(C(rng.pick(['#d8a848', '#c89038', '#e0c070', '#b8b8c8'])), 1);
    gold.append(cup);
  }
  for (let i = 0; i < 6; i++) {
    const a = rng.range(0, TAU), r = rng.range(HR * 0.8, HR + 1.2);
    const dx = Math.cos(a) * r, dz = Math.sin(a) * r;
    const bar = Geometry.box(0.42, 0.12, 0.2, { y0: 0 });
    bar.deform((p) => [p[0] * (p[1] > 0.06 ? 0.85 : 1), p[1], p[2] * (p[1] > 0.06 ? 0.8 : 1)]);
    bar.rotateY(rng.range(0, TAU));
    bar.translate(hoardL[0] + dx, hoardAt(dx, dz) - 0.02, hoardL[1] + dz);
    bar.setColor(C('#d8a440'), 1);
    gold.append(bar);
  }
  // gems: cut stones in every colour, glinting in the heap
  for (let i = 0; i < 46; i++) {
    const a = rng.range(0, TAU), r = Math.sqrt(rng.next()) * (HR + 0.8);
    const dx = Math.cos(a) * r, dz = Math.sin(a) * r;
    const gm = Geometry.icosphere(rng.range(0.05, 0.1), 0);
    gm.scale(1, 0.75, 1);
    gm.rotateY(rng.range(0, TAU));
    gm.translate(hoardL[0] + dx, hoardAt(dx, dz) + 0.03, hoardL[1] + dz);
    gm.setColor(C(rng.pick(['#ff2a3a', '#2aff6a', '#3a6aff', '#c83aff', '#ffe03a', '#3affff'])), 1);
    gems.append(gm);
  }
  // an open chest at the foot of the heap, spilling coins
  {
    const cx = hoardL[0] + 2.4, cz = hoardL[1] + 2.2, cy = height(cx, cz) - 0.05;
    const ch = new Geometry();
    ch.append(Geometry.box(1.0, 0.55, 0.62, { y0: 0 }));
    const lid = Geometry.box(1.0, 0.12, 0.62, { y0: 0 });
    const lidTop = Geometry.cylinder(0.31, 0.31, 1.0, 12, 1);
    lidTop.rotateZ(Math.PI / 2);
    lidTop.translate(-0.5, 0.12, 0);
    lidTop.deform((p) => [p[0], Math.max(0.12, p[1]), p[2]]);
    lid.append(lidTop);
    lid.translate(0, 0, 0.31);
    lid.rotateX(-1.9);
    lid.translate(0, 0.55, -0.31);
    ch.append(lid);
    ch.rotateY(-0.7);
    ch.translate(cx, cy, cz);
    ch.setColor(C('#3a2212'), 1);
    wood.append(ch);
    for (const bx of [-0.36, 0.36]) {
      const band = Geometry.box(0.08, 0.57, 0.64, { y0: 0 });
      band.translate(bx, 0, 0);
      band.rotateY(-0.7);
      band.translate(cx, cy, cz);
      band.setColor(C('#b88a30'), 1);
      gold.append(band);
    }
    const fill = Geometry.sphere(0.46, 12, 6);
    fill.scale(1, 0.3, 0.6);
    fill.displace((p) => noise.n3(p[0] * 14, p[1] * 14, p[2] * 14) * 0.03, true);
    fill.rotateY(-0.7);
    fill.translate(cx, cy + 0.52, cz);
    fill.setColor(C('#d8a440'), 1);
    gold.append(fill);
  }
  // a sword stuck point-down in the heap, a round shield leaning on it, a helmeted skull
  {
    const sx0 = hoardL[0] - 0.6, sz0 = hoardL[1] - 0.4, sy0 = hoardAt(-0.6, -0.4);
    const sword = new Geometry();
    const bl = Geometry.box(0.09, 1.3, 0.018, { y0: 0 });
    bl.deform((p) => [p[0] * (0.3 + 0.7 * smoothstep(0, 0.25, p[1])), p[1], p[2]]);
    bl.translate(0, -0.45, 0);
    sword.append(bl);
    const guard = Geometry.box(0.42, 0.05, 0.06, { y0: 0 });
    guard.translate(0, 0.85, 0);
    sword.append(guard);
    const grip = Geometry.cylinder(0.022, 0.022, 0.26, 6, 1);
    grip.translate(0, 0.9, 0);
    sword.append(grip);
    const pom = Geometry.sphere(0.04, 8, 6);
    pom.translate(0, 1.18, 0);
    sword.append(pom);
    sword.rotateZ(0.18);
    sword.rotateY(0.5);
    sword.translate(sx0, sy0, sz0);
    sword.setColor(C('#9aa0aa'), 1);
    steel.append(sword);
    const sh = Geometry.cylinder(0.5, 0.5, 0.05, 20, 1);
    const boss = Geometry.sphere(0.12, 10, 6);
    boss.scale(1, 0.5, 1);
    boss.translate(0, 0.05, 0);
    sh.append(boss);
    sh.paint((p) => (Math.hypot(p[0], p[2]) > 0.44 || p[1] > 0.06 ? C('#8a8e98') : C('#5a1414')).concat([1]));
    sh.rotateX(-1.25);
    sh.rotateY(2.4);
    const shA = [-2.9, 0.9];
    sh.translate(hoardL[0] + shA[0], hoardAt(shA[0], shA[1]) + 0.45, hoardL[1] + shA[1]);
    steel.append(sh);
    const skA = [1.6, -2.7], sky = hoardAt(skA[0], skA[1]);
    const skull = Geometry.sphere(0.13, 12, 8);
    skull.scale(1, 0.95, 1.2);
    const jawS = Geometry.sphere(0.08, 8, 6);
    jawS.scale(1, 0.6, 1);
    jawS.translate(0, -0.1, 0.08);
    skull.append(jawS);
    skull.rotateY(1.2);
    skull.translate(hoardL[0] + skA[0], sky + 0.1, hoardL[1] + skA[1]);
    skull.setColor(C('#b8ac90'), 1);
    boneG.append(skull);
    const helm = Geometry.sphere(0.16, 12, 8);
    helm.deform((p) => [p[0], Math.max(p[1], -0.02), p[2]]);
    helm.rotateZ(0.4);
    helm.translate(hoardL[0] + skA[0] + 0.05, sky + 0.16, hoardL[1] + skA[1]);
    helm.setColor(C('#6a6e78'), 1);
    steel.append(helm);
  }
  gold.computeNormals();
  const goldM = W.M.hoardGold || (W.M.hoardGold = new Material({ uniforms: { uRough: 0.3, uRim: 0.35, uWrap: 0.2, uFill: 0.2, uGlitter: [22, 0.03, 0.35], uDetail: [0, 0, 0, 0] } }));
  for (const [geo, mat, name] of [[gold, goldM, 'hoard'], [wood, W.M.wood, 'hoardChest'], [steel, W.M.metal, 'hoardSteel'], [boneG, W.M.plaster, 'hoardBones'], [gems, W.M.crystal, 'hoardGems']]) {
    const hm = W.mesh(geo, mat, name);
    hm.maxDistance = name === 'hoard' ? 320 : 170;
    node.add(hm);
  }
  const hy = hy0;
  P.addSurface({ type: 'disc', ...(() => { const [wx, wz] = toWorld(hoardL[0], hoardL[1]); return { x: wx, z: wz }; })(), r: HR, top: hy + HH, dome: HH, bottom: hy - 1 });
  W.scene.add(node);
  // ------------------------------------------------------------ beacon, light, region
  sea.beacon(x, z, 210, '#ff5a3a', 0.9);
  const [lxW, lzW] = toWorld(0, 4);
  W.light([lxW, height(0, 4) + 5, lzW], C('#ff6a2a'), 2.2, 26, 0.18, 3);
  for (const [a, r] of [[0.8, 40], [2.6, 44], [4.4, 38]]) {
    const lx = Math.cos(a) * r, lz = Math.sin(a) * r;
    const [wx, wz] = toWorld(lx, lz);
    W.light([wx, height(lx, lz) + 1.2, wz], C('#ff4a1a'), 1.6, 14, 0.25, 1);
  }
  {
    const [vx, vz] = toWorld(VOLC[0], VOLC[1]);
    const vy = height(VOLC[0], VOLC[1]);
    W.light([vx, vy + 4, vz], C('#ff5a1a'), 2.4, 30, 0.2, 3);
    const smoke = particleSystem(W.gl, 40, { RISE: 1, SMOKE: 1 }, (i, r) => ({
      p: [vx + r.range(-2, 2), vy + 1, vz + r.range(-2, 2)], params: [2.5, 9, 0.6, 3], size: 2.5, life: r.range(9, 14), speed: r.range(22, 34), spread: 3, color: [0.05, 0.03, 0.035], intensity: 1,
    }), { blend: 'normal', seed: 61 });
    smoke.maxDistance = 900;
    W.scene.add(smoke);
    const embers = particleSystem(W.gl, 160, { RISE: 1 }, (i, r) => {
      const a = r.range(0, TAU), d = Math.sqrt(r.next()) * (R - 8);
      const lx = Math.cos(a) * d, lz = Math.sin(a) * d;
      const [ex, ez] = toWorld(lx, lz);
      return { p: [ex, height(lx, lz) + 0.2, ez], params: [1, 0.2, 0.6, 1.5], size: r.range(0.04, 0.09), life: r.range(4, 8), speed: r.range(3, 8), spread: 1.5, color: [1.6, 0.45, 0.12], intensity: 2.2 };
    }, { seed: 62 });
    embers.maxDistance = 260;
    W.scene.add(embers);
  }
  sea.region('ashIsle', 'Hamusziget', 'A Hétfejű birodalma. A hamu még meleg, a kövek alatt parázs izzik, és valami nagyon nagy alszik a kincsén. Csak lopakodva…', x, z, R);
  sea.landmarks.push({ id: 'ashIsle', x, z, clear: 130 });
  const ga = 1.9, gr = coast(ga) - 3;
  const shore = toWorld(Math.cos(ga) * gr, Math.sin(ga) * gr);
  W.anchors.ashIsle = [shore[0], height(Math.cos(ga) * gr, Math.sin(ga) * gr), shore[1]];
  // everything the creatures need to know about their realm
  W.ashIsle = {
    x, z, R, face, height, coast, toWorld, toLocal, cover,
    lair: toWorld(0, -3), lairY: height(0, -3),
    hoard: toWorld(hoardL[0], hoardL[1]), hoardY: hy + HH, volcano: toWorld(VOLC[0], VOLC[1]), volcanoY: height(VOLC[0], VOLC[1]),
    ground: (wx, wz) => { const [lx, lz] = toLocal(wx, wz); return height(lx, lz); },
  };
}
