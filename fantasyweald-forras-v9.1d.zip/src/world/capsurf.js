// Walkable tops that follow the real shape of a mushroom cap (or any dome), measured from its geometry.
// The old physics discs were a simple parabola around the stem: the bent stem shifts the cap sideways and
// the real profile is flatter, so feet sank into the cap and the camera could slip under its surface
// (where the cap is invisible from inside). The profile below matches the drawn cap within a few cm.
const NA = 32, NR = 14;

// polar height table of the upward-facing part of a cap, in the model's local space
export function capProfile(geo) {
  const p = geo.p, n = geo.n, nv = p.length / 3;
  let top = -Infinity, cx = 0, cz = 0, bottom = Infinity;
  for (let i = 0; i < nv; i++) {
    if (p[i * 3 + 1] > top) { top = p[i * 3 + 1]; cx = p[i * 3]; cz = p[i * 3 + 2]; }
    bottom = Math.min(bottom, p[i * 3 + 1]);
  }
  // rim radius per angle and max height per (angle, radius) bin, only from faces that look up
  const rim = new Float32Array(NA);
  let R = 0;
  for (let i = 0; i < nv; i++) R = Math.max(R, Math.hypot(p[i * 3] - cx, p[i * 3 + 2] - cz));
  const tab = new Float32Array(NA * (NR + 1)).fill(-Infinity);
  for (let i = 0; i < nv; i++) {
    if (n[i * 3 + 1] < 0.2) continue;
    const dx = p[i * 3] - cx, dz = p[i * 3 + 2] - cz, y = p[i * 3 + 1];
    const r = Math.hypot(dx, dz);
    const a = ((Math.atan2(dz, dx) / (Math.PI * 2)) * NA + NA) % NA;
    const ai = Math.round(a) % NA, ri = Math.round((r / R) * NR);
    rim[ai] = Math.max(rim[ai], r);
    const k = ai * (NR + 1) + ri;
    if (y > tab[k]) tab[k] = y;
  }
  // (v9.1d) the underside too: the lowest downward-facing point per bin, so a head under the middle of a big cap
  // meets the real gills, not a flat plane at the rim's lowest point
  const und = new Float32Array(NA * (NR + 1)).fill(Infinity);
  for (let i = 0; i < nv; i++) {
    if (n[i * 3 + 1] > -0.2) continue;
    const dx = p[i * 3] - cx, dz = p[i * 3 + 2] - cz, y = p[i * 3 + 1];
    const r = Math.hypot(dx, dz);
    const a = ((Math.atan2(dz, dx) / (Math.PI * 2)) * NA + NA) % NA;
    const k = (Math.round(a) % NA) * (NR + 1) + Math.round((r / R) * NR);
    if (y < und[k]) und[k] = y;
  }
  // fill holes: along each ray, carry the last known height outwards; unknown centre = apex
  for (let a = 0; a < NA; a++) {
    let last = top;
    for (let r = 0; r <= NR; r++) {
      const k = a * (NR + 1) + r;
      if (tab[k] === -Infinity) tab[k] = last; else last = tab[k];
    }
    if (rim[a] === 0) rim[a] = R * 0.8;
    // the underside: carried inwards from the rim (unknown rim = the lowest point), never above the top
    let lu = bottom;
    for (let r = NR; r >= 0; r--) {
      const k = a * (NR + 1) + r;
      if (und[k] === Infinity) und[k] = lu; else lu = und[k];
      und[k] = Math.min(und[k], tab[k] - 0.05);
    }
  }
  return { cx, cz, R, rim, tab, und, top, bottom };
}

function sampleProfile(P, lx, lz, T = P.tab) {
  const dx = lx - P.cx, dz = lz - P.cz;
  const r = Math.hypot(dx, dz);
  const af = ((Math.atan2(dz, dx) / (Math.PI * 2)) * NA + NA) % NA;
  const a0 = Math.floor(af) % NA, a1 = (a0 + 1) % NA, ta = af - Math.floor(af);
  const rimR = P.rim[a0] * (1 - ta) + P.rim[a1] * ta;
  if (r > rimR * 0.97) return null;
  const rf = Math.min(NR, (r / P.R) * NR);
  const r0 = Math.floor(rf), r1 = Math.min(NR, r0 + 1), tr = rf - r0;
  const W = NR + 1;
  const h0 = T[a0 * W + r0] * (1 - tr) + T[a0 * W + r1] * tr;
  const h1 = T[a1 * W + r0] * (1 - tr) + T[a1 * W + r1] * tr;
  return h0 * (1 - ta) + h1 * ta;
}

// a physics 'fn' surface for a cap placed at (x, y, z) with rotation yaw and uniform scale s
export function capSurface(P, x, y, z, yaw, s, extra = {}) {
  const c = Math.cos(yaw), sn = Math.sin(yaw);
  // local -> world (rotation about Y): x' = x c + z s, z' = -x s + z c
  const wcx = x + (P.cx * c + P.cz * sn) * s, wcz = z + (-P.cx * sn + P.cz * c) * s;
  let rimMax = 0;
  for (let i = 0; i < P.rim.length; i++) rimMax = Math.max(rimMax, P.rim[i]);
  return Object.assign({
    type: 'fn', x: wcx, z: wcz, r: (rimMax + Math.hypot(P.cx, P.cz)) * s, bottom: y + P.bottom * s,
    top: y + P.top * s,
    topFn: (wx, wz) => {
      // back to the model's local space
      const ox = wx + (wcx - x), oz = wz + (wcz - z);
      const lx = (ox * c - oz * sn) / s, lz = (ox * sn + oz * c) / s;
      const h = sampleProfile(P, lx, lz);
      return h === null ? null : y + h * s;
    },
    bottomFn: P.und ? (wx, wz) => {
      const ox = wx + (wcx - x), oz = wz + (wcz - z);
      const lx = (ox * c - oz * sn) / s, lz = (ox * sn + oz * c) / s;
      const h = sampleProfile(P, lx, lz, P.und);
      return h === null ? null : y + h * s;
    } : undefined,
  }, extra);
}
