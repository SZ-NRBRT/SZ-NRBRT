// The endless dream sea around the island: five landmarks at fixed places (the Endless Stair, the
// Forgotten Playground, the Colonnade, the Sleeping Moon and the Field of Doors), light pillars to find
// your way, and beyond them an infinite scatter of odd things generated cell by cell as you wander.
// Some doors lead somewhere else.
import { Geometry, catmullRom } from '../engine/geometry.js';
import { Node, Mesh, Material } from '../engine/scene.js';
import { RNG, TAU, lerp, clamp, smoothstep } from '../engine/math.js';
import { C } from '../models/materials.js';
import * as D from '../models/dream.js';
import { cloudPuff } from '../models/sky.js';
import { WORLD } from './layout.js';
const WATER_Y = WORLD.waterLevel;
import { addShard } from './sites.js';
import { buildAshIsle } from './ashisle.js';
import { geometrySurface } from './hull.js';

const BASE_Y = WATER_Y - 0.1;      // (v7.2: the sea is deep) the dream things stand on the water, their feet just under it
const CELL = 88;
const NEAR_R = 4;                  // cells around the camera that exist
const CLEAR_R = 420;               // nothing procedural closer to the centre than this

const TYPES = [
  ['door', 14, () => D.dreamDoor], ['stairs', 8, () => D.dreamStairs], ['lamps', 13, () => D.dreamLamp],
  ['chair', 8, () => D.dreamChair], ['tv', 8, () => D.dreamTV], ['arches', 7, () => D.dreamArches],
  ['columns', 8, () => D.dreamColumns], ['duck', 6, () => D.dreamDuck], ['ball', 6, () => D.dreamBall],
  ['bed', 6, () => D.dreamBed], ['clock', 6, () => D.dreamClock], ['clouds', 9, null],
];
const SCALE = { door: [1.0, 2.2], stairs: [1.0, 1.35], lamps: [1.0, 1.6], chair: [1.6, 4.0], tv: [1.0, 2.6], arches: [1.0, 1.6], columns: [1.0, 1.4], duck: [1.0, 3.2], ball: [1.0, 2.6], bed: [1.0, 1.8], clock: [1.0, 2.2] };

function hash2(i, j) {
  let h = (i * 374761393 + j * 668265263) ^ 0x5bd1e995;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return (h ^ (h >>> 16)) >>> 0;
}

export class DreamSea {
  constructor(W) {
    this.W = W;
    this.defs = new Map();     // type|variant -> { def, gpu: {mat: GpuGeometry} }
    this.cells = new Map();
    this.portals = [];
    this.animated = [];
    this.landmarks = [];
    this.lastCell = null;
    this.beacons();
    this.endlessStair(Math.cos(0.61) * 440, Math.sin(0.61) * 440);
    this.playground(Math.cos(2.0) * 420, Math.sin(2.0) * 420);
    this.colonnade(Math.cos(3.23) * 470, Math.sin(3.23) * 470);
    this.sleepingMoon(Math.cos(5.76) * 520, Math.sin(5.76) * 520);
    this.fieldOfDoors(Math.cos(4.45) * 560, Math.sin(4.45) * 560);
    buildAshIsle(this, Math.cos(1.3) * 575, Math.sin(1.3) * 575); // (v8) the Seven-Headed Dragon's realm
  }

  // ------------------------------------------------------------ shared helpers
  mat(key) {
    const M = this.W.M;
    if (key === 'glossy') return M.glossy;
    return M[key] || M.plaster;
  }
  // a prop definition (geometry uploaded once, shared by every copy)
  def(type, variant, build) {
    const key = type + '|' + variant;
    let d = this.defs.get(key);
    if (!d) {
      const def = build();
      const gpu = {};
      for (const k in def.parts) gpu[k] = this.W.gpu(def.parts[k]);
      d = { def, gpu };
      this.defs.set(key, d);
    }
    return d;
  }
  // place a definition: meshes under one node, physics transformed to the world, lights
  place(d, x, z, yaw, s, y = BASE_Y, { name = 'dream', dist = 420 } = {}) {
    const W = this.W, P = W.physics, def = d.def;
    const node = new Node(name);
    node.setPos(x, y, z);
    node.setRotY(yaw);
    node.setScale(s);
    for (const k in d.gpu) {
      const m = W.meshG(d.gpu[k], this.mat(k), name + ':' + k);
      m.maxDistance = dist;
      if (k === 'glow' || k === 'glowSoft') m.castShadow = false;
      node.add(m);
    }
    W.scene.add(node);
    const c = Math.cos(yaw), sn = Math.sin(yaw);
    const tr = (lx, lz) => [x + (lx * c + lz * sn) * s, z + (-lx * sn + lz * c) * s];
    const phys = [];
    for (const col of def.colliders) {
      const o = { yMin: y + (col.yMin ?? -0.5) * s, yMax: y + (col.yMax ?? 12) * s };
      if (col.type === 'circle') {
        const [wx, wz] = tr(col.x, col.z);
        phys.push(P.addCircle(wx, wz, col.r * s, o));
      } else {
        const [ax, az] = tr(col.ax, col.az), [bx, bz] = tr(col.bx, col.bz);
        phys.push(P.addSeg(ax, az, bx, bz, col.r * s, o));
      }
    }
    for (const sf of def.surfaces) {
      const [wx, wz] = tr(sf.x, sf.z);
      const w = { ...sf, x: wx, z: wz, yaw: (sf.yaw || 0) + yaw, top: y + sf.top * s, bottom: y + (sf.bottom ?? -1) * s };
      if (sf.type === 'disc') { w.r = sf.r * s; w.dome = (sf.dome || 0) * s; }
      else { w.hx = sf.hx * s; w.hz = sf.hz * s; }
      phys.push(P.addSurface(w));
    }
    const lights = def.lights.map((l) => {
      const [wx, wz] = tr(l.pos[0], l.pos[2]);
      return W.light([wx, y + l.pos[1] * s, wz], l.color, l.intensity, l.radius * Math.sqrt(s), 0.06, 1);
    });
    return { node, phys, lights, tr, s, y, yaw, x, z };
  }
  region(id, name, blurb, x, z, radius) {
    this.W.regions.push({ id, name, blurb, center: [x, z], radius, hidden: true, sea: true });
  }
  // a glowing column of light that can be seen from anywhere (no fog on it)
  beacon(x, z, h, col, r = 0.7) {
    const W = this.W;
    // (v9.1d) the column rises from its foot (it used to start half its height up in the sky)
    const g = Geometry.cylinder(r * 0.6, r, h, 10, 12, { capTop: false, capBottom: false });
    g.paint((p) => {
      const t = p[1] / h;
      const k = ((1 - t) * (1 - t) * 0.9 + 0.1 * (1 - t)) * 0.3 * smoothstep(0.05, 0.22, t);
      return C(col).map((v) => v * k).concat([1]);
    });
    const mat = new Material({ defines: { UNLIT: 1, ADDITIVE: 1 }, transparent: true, blend: 'additive', depthWrite: false, castShadow: false, cull: 'none', renderOrder: 9, uniforms: { uFogScale: 0.0, uGlitter: [9, 0, 0] } });
    const m = W.mesh(g, mat, 'beacon');
    m.castShadow = false;
    m.maxDistance = Infinity;
    m.setPos(x, W.h(x, z) - 0.5, z);
    W.scene.add(m);
    return m;
  }
  beacons() {
    const W = this.W, a = W.anchors.cauldron;
    // the wizard's cauldron sends up a pillar of moonlight: from far out at sea it shows the way home
    if (a) this.beacon(a[0], a[2], 320, '#9fd0ff', 0.9);
  }

  // ------------------------------------------------------------ landmark: the Endless Stair
  endlessStair(x, z) {
    const W = this.W, P = W.physics;
    const N = 176, rise = 0.34, dA = 0.44, rIn = 0.75, rOut = 2.9;
    const steps = new Geometry(), rail = new Geometry();
    const railPts = [];
    for (let i = 0; i < N; i++) {
      const a = i * dA, top = (i + 1) * rise;
      const rm = (rIn + rOut) / 2;
      const cx = x + Math.cos(a) * rm, cz = z + Math.sin(a) * rm;
      const b = Geometry.box(rOut - rIn, 0.22, 1.1, { y0: -0.22 });
      b.rotateY(-a);
      b.translate(cx, BASE_Y + top, cz);
      steps.append(b);
      P.addSurface({ type: 'box', x: cx, z: cz, hx: (rOut - rIn) / 2, hz: 0.6, yaw: -a + Math.PI / 2 - Math.PI / 2, top: BASE_Y + top, bottom: BASE_Y + top - 0.6 });
      railPts.push([x + Math.cos(a) * (rOut - 0.1), BASE_Y + top + 0.85, z + Math.sin(a) * (rOut - 0.1)]);
      if (i > 0) {
        const p = railPts[i - 1], q = railPts[i];
        P.addSeg(p[0], p[2], q[0], q[2], 0.1, { yMin: BASE_Y + top - 0.9, yMax: BASE_Y + top + 1.0 });
      }
      if (i % 2 === 0) {
        const post = Geometry.cylinder(0.035, 0.035, 0.85, 5, 1);
        post.translate(railPts[i][0], railPts[i][1] - 0.85, railPts[i][2]);
        rail.append(post);
      }
    }
    steps.setColor(C('#eee8f4'), 0.9);
    rail.append(Geometry.tube(railPts, () => 0.04, 5, { capEnd: true }));
    rail.setColor(C('#8a80a8'), 1);
    const H = N * rise;
    // (v9.1d) the core runs from the water up to the landing (it used to start half way up and stick out
    // thirty metres above the top)
    const pole = Geometry.cylinder(rIn * 0.9, rIn, H + 0.5, 16, 1);
    pole.translate(x, BASE_Y - 0.5, z);
    pole.setColor(C('#d8d0e8'), 0.85);
    steps.append(pole);
    W.physics.addCircle(x, z, rIn * 0.9, { yMin: BASE_Y - 1, yMax: BASE_Y + H - 0.3 });
    const sm = W.mesh(steps, W.M.plaster, 'endlessStair');
    sm.maxDistance = 900;
    W.scene.add(sm);
    const rm = W.mesh(rail, W.M.metal, 'endlessRail');
    rm.maxDistance = 500;
    W.scene.add(rm);
    // the top: a round landing among clouds, and a door standing there.
    // (v9.1d) the landing has a stairwell: the last turn of the stair comes up through an opening in it (before, the
    // landing was a whole disc and its underside was a ceiling right over the last steps - you had to pass
    // through the floor to get up)
    const topY = BASE_Y + H + 0.02;
    const RL = 3.4, lip = rOut + 0.15;
    const wa0 = (N - 6) * dA - 0.36, wa1 = (N - 1) * dA + 0.3;
    const inWell = (ang) => { let d = ang - wa0; d -= Math.floor(d / TAU) * TAU; return d < wa1 - wa0; };
    const land = new Geometry();
    {
      const SEG = 96, T0 = topY, T1 = topY - 0.3;
      const ring = (r, y) => { const ids = []; for (let k = 0; k < SEG; k++) { const a = (k / SEG) * TAU; ids.push(land.vert(x + Math.cos(a) * r, y, z + Math.sin(a) * r)); } return ids; };
      const oT = ring(RL, T0), oB = ring(RL * 0.93, T1), lT = ring(lip, T0), lB = ring(lip, T1), cT = ring(rIn * 0.9, T0), cB = ring(rIn * 0.9, T1);
      for (let k = 0; k < SEG; k++) {
        const k1 = (k + 1) % SEG, am = ((k + 0.5) / SEG) * TAU;
        land.quad(oT[k], lT[k], lT[k1], oT[k1]);          // outer lip, top
        land.quad(oB[k], oB[k1], lB[k1], lB[k]);          // outer lip, underside
        land.quad(oT[k], oT[k1], oB[k1], oB[k]);          // rim
        if (!inWell(am)) {
          land.quad(lT[k], cT[k], cT[k1], lT[k1]);        // floor
          land.quad(lB[k], lB[k1], cB[k1], cB[k]);
        } else {
          land.quad(lT[k], lT[k1], lB[k1], lB[k]);        // the stairwell's wall
        }
      }
      // the two straight ends of the stairwell
      for (const a of [wa0, wa1]) {
        const k = Math.round((((a % TAU) + TAU) % TAU) / TAU * SEG) % SEG;
        land.quad(cT[k], lT[k], lB[k], cB[k]);
        land.quad(cT[k], cB[k], lB[k], lT[k]);
      }
      land.computeNormals();
      if (land.n[oT[0] * 3 + 1] < 0) { for (let i = 0; i < land.idx.length; i += 3) { const t = land.idx[i + 1]; land.idx[i + 1] = land.idx[i + 2]; land.idx[i + 2] = t; } land.computeNormals(); }
    }
    land.setColor(C('#eee8f4'), 1);
    // (seen from both sides: from below, the stairwell's walls and the underside must never look hollow)
    const landMat = new Material({ uniforms: { ...W.M.plaster.uniforms }, defines: { ...W.M.plaster.defines }, cull: 'none' });
    const lm = W.mesh(land, landMat, 'stairTop');
    W.scene.add(lm);
    P.addSurface({
      type: 'fn', x, z, r: RL - 0.05, top: topY, bottom: topY - 0.4,
      topFn: (lx, lz) => { const d = Math.hypot(lx, lz); if (d > RL - 0.05) return null; return d < lip && d > rIn * 0.85 && inWell(Math.atan2(lz, lx)) ? null : topY; },
    });
    const clouds = [];
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * TAU;
      clouds.push({ x: x + Math.cos(a) * 6.3, y: topY - 1.4 + (i % 3) * 0.5, z: z + Math.sin(a) * 6.3, R: 2.2 + (i % 2), seed: 1700 + i, hole: { x, z, r: RL + 0.2 } });
    }
    this.cloudGroup(clouds);
    const dd = this.def('door', 'stairtop', () => D.dreamDoor(4401, { color: '#ffe29a', open: 0.35 }));
    // the door and the shard stand on the solid half, opposite the stairwell
    const da = (wa0 + wa1) / 2 + Math.PI, sa = da + 0.9;
    const door = this.place(dd, x + Math.cos(da) * 1.6, z + Math.sin(da) * 1.6, Math.PI / 2 - da, 1, topY - 0.02, { name: 'topDoor' });
    this.portal(door, 'Felhőkert', () => W.anchors.skyGarden);
    addShard(W, x + Math.cos(sa) * 1.9, z + Math.sin(sa) * 1.9, topY);
    W.light([x, topY + 2.5, z], C('#cfe0ff'), 2, 10, 0.05, 2);
    const bm = this.beacon(x, z, 160, '#ffe0a8', 0.5);
    bm.setPos(x, topY + 6, z);
    this.region('endlessStair', 'Végtelen Lépcső', 'Egy csigalépcső, ami a víz közepéből indul, és a felhőkig ér. Fent egy ajtó áll. Vajon hová nyílik?', x, z, 28);
    this.landmarks.push({ id: 'endlessStair', x, z, top: [x, topY, z] });
    W.anchors.endlessStairTop = [x + Math.cos(da + 0.5) * 2.2, topY, z + Math.sin(da + 0.5) * 2.2];
  }

  // ------------------------------------------------------------ landmark: the Forgotten Playground
  playground(x, z) {
    const W = this.W, P = W.physics;
    const yaw = Math.atan2(-x, -z);
    const c = Math.cos(yaw), s = Math.sin(yaw);
    const tr = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c];
    // the slide: a ladder up to a little platform, and a long chute down
    {
      const g = new Geometry(), chute = new Geometry();
      const H = 3.6, n = 12, rise = H / n;
      for (let i = 0; i < n; i++) {
        const top = (i + 1) * rise, lz = -3.2 + i * 0.26;
        const st = Geometry.box(1.0, 0.08, 0.3, { y0: top - 0.08 });
        st.translate(-4, 0, lz);
        g.append(st);
        const [wx, wz] = tr(-4, lz);
        P.addSurface({ type: 'box', x: wx, z: wz, hx: 0.5, hz: 0.17, yaw, top: BASE_Y + top, bottom: BASE_Y + top - 0.4 });
      }
      for (const sx of [-4.55, -3.45]) {
        const rl = Geometry.box(0.1, H + 1.2, 0.1, { y0: 0 });
        rl.rotateX(-0.25);
        rl.translate(sx, 0, -3.3);
        g.append(rl);
      }
      const plat = Geometry.box(1.4, 0.15, 1.4, { y0: H - 0.15 });
      plat.translate(-4, 0, 0.1);
      g.append(plat);
      const [px, pz] = tr(-4, 0.1);
      P.addSurface({ type: 'box', x: px, z: pz, hx: 0.7, hz: 0.7, yaw, top: BASE_Y + H, bottom: BASE_Y + H - 0.5 });
      for (const [lx, lz] of [[-4.6, -0.5], [-3.4, -0.5], [-4.6, 0.7], [-3.4, 0.7]]) {
        const leg = Geometry.box(0.12, H, 0.12, { y0: 0 });
        leg.translate(lx, 0, lz);
        g.append(leg);
        const [wx, wz] = tr(lx, lz);
        P.addCircle(wx, wz, 0.1, { yMin: BASE_Y - 0.5, yMax: BASE_Y + H - 0.2 });
      }
      g.setColor(C('#8ab0e8'), 0.9);
      // chute: from the platform down to the water, with raised sides
      const L = 7.5, W0 = 1.1;
      const prof = (t) => H - 0.1 - (H - 0.35) * (t < 0.15 ? t / 0.15 * 0.1 : 0.1 + (t - 0.15) / 0.85 * 0.9);
      for (let i = 0; i < 24; i++) {
        const t0 = i / 24, t1 = (i + 1) / 24;
        for (const [a, b] of [[-W0 / 2, W0 / 2]]) {
          const q = [[a, prof(t0), 0.8 + t0 * L], [b, prof(t0), 0.8 + t0 * L], [b, prof(t1), 0.8 + t1 * L], [a, prof(t1), 0.8 + t1 * L]];
          const vi = q.map((p) => chute.vert(p[0] - 4, p[1], p[2], 0, 1, 0));
          chute.quad(vi[0], vi[3], vi[2], vi[1]);
          for (const sx of [a, b]) {
            const w = [[sx, prof(t0), 0.8 + t0 * L], [sx, prof(t0) + 0.3, 0.8 + t0 * L], [sx, prof(t1) + 0.3, 0.8 + t1 * L], [sx, prof(t1), 0.8 + t1 * L]];
            const wi = w.map((p) => chute.vert(p[0] - 4, p[1], p[2], 1, 0, 0));
            chute.quad(wi[0], wi[1], wi[2], wi[3]);
            chute.quad(wi[3], wi[2], wi[1], wi[0]);
          }
        }
      }
      chute.computeNormals();
      chute.setColor(C('#ff9ab8'), 1);
      const node = new Node('playground');
      node.setPos(x, BASE_Y, z);
      node.setRotY(yaw);
      node.add(W.mesh(g, W.M.metal, 'slideFrame'));
      const ch = W.mesh(chute, W.M.glossy, 'chute');
      ch.material = W.M.glossyDS;
      node.add(ch);
      W.scene.add(node);
      // the chute is a ramp you slide down
      const [cx, cz] = tr(-4, 0.8 + L / 2);
      const down = [Math.sin(yaw), Math.cos(yaw)];
      P.addSurface({ type: 'ramp', x: cx, z: cz, hx: W0 / 2, hz: L / 2, yaw, y0: BASE_Y + prof(0), y1: BASE_Y + prof(1), bottom: BASE_Y + prof(1) - 0.6, slide: down });
      for (const sx of [-W0 / 2 - 0.02, W0 / 2 + 0.02]) {
        const [ax, az] = tr(-4 + sx, 0.8), [bx, bz] = tr(-4 + sx, 0.8 + L);
        P.addSeg(ax, az, bx, bz, 0.05, { yMin: BASE_Y, yMax: BASE_Y + H + 0.4 });
      }
      addShard(W, px, pz, BASE_Y + H);
    }
    // swings: they swing on their own, as if someone had just left
    {
      const g = new Geometry();
      const bw = 5.2, bh = 4.6, lx0 = 3.2;
      for (const sx of [-bw / 2, bw / 2]) {
        for (const sz of [-1, 1]) {
          const leg = Geometry.tube([[lx0 + sx, 0, sz * 1.3], [lx0 + sx, bh, 0]], () => 0.08, 6, { capEnd: true });
          g.append(leg);
          const [wx, wz] = tr(lx0 + sx, sz * 1.2);
          P.addCircle(wx, wz, 0.1, { yMin: BASE_Y - 0.5, yMax: BASE_Y + 1.5 });
        }
      }
      const bar = Geometry.cylinder(0.07, 0.07, bw, 8, 1);
      bar.rotateZ(Math.PI / 2);
      bar.translate(lx0, bh, 0);
      g.append(bar);
      g.setColor(C('#e8c060'), 0.9);
      const frame = W.mesh(g, W.M.metal, 'swingFrame');
      const node = new Node('swings');
      node.setPos(x, BASE_Y, z);
      node.setRotY(yaw);
      node.add(frame);
      W.scene.add(node);
      for (const [k, sx] of [[0, -1.2], [1, 1.2]]) {
        const sw = new Node('swing');
        sw.setPos(lx0 + sx, bh, 0);
        const sg = new Geometry();
        for (const dx of [-0.35, 0.35]) {
          const rope = Geometry.cylinder(0.02, 0.02, 3.6, 4, 1);
          rope.translate(dx, -3.6, 0);
          sg.append(rope);
        }
        sg.setColor(C('#c8b8a0'), 1);
        const seat = Geometry.box(0.9, 0.07, 0.35, { y0: 0 });
        seat.translate(0, -3.62, 0);
        seat.setColor(C(k ? '#9fd8f0' : '#f2a7c8'), 1);
        sg.append(seat);
        const m = W.mesh(sg, W.M.wood, 'swingSeat');
        sw.add(m);
        sw.dynamic = true;
        node.add(sw);
        this.animated.push((t) => sw.setEuler(Math.sin(t * 1.4 + k * 1.9) * (0.35 + 0.1 * Math.sin(t * 0.1 + k)), 0, 0));
      }
    }
    // merry-go-round, turning slowly by itself
    {
      const g = new Geometry();
      const disc = Geometry.cylinder(2.6, 2.6, 0.18, 24, 1);
      disc.translate(0, 0.45, 0);
      disc.paint((p) => C(Math.floor(((Math.atan2(p[2], p[0]) + Math.PI) / TAU) * 6) % 2 ? '#ffe29a' : '#ff9ab8').concat([1]));
      g.append(disc);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        const bar = Geometry.tube([[Math.cos(a) * 2.2, 0.54, Math.sin(a) * 2.2], [Math.cos(a) * 2.2, 1.5, Math.sin(a) * 2.2], [0, 1.9, 0]], () => 0.045, 5, { capEnd: true });
        bar.setColor(C('#d0d8e8'), 1);
        g.append(bar);
      }
      const hub = Geometry.cylinder(0.25, 0.3, 0.5, 10, 1);
      hub.translate(0, 0.1, 0);
      g.append(hub);
      const node = new Node('merry');
      const [mx, mz] = tr(1.5, 7.5);
      node.setPos(mx, BASE_Y, mz);
      node.add(W.mesh(g, W.M.metal, 'merry'));
      node.dynamic = true;
      W.scene.add(node);
      this.animated.push((t) => node.setRotY(t * 0.25));
      P.addSurface({ type: 'disc', x: mx, z: mz, r: 2.55, top: BASE_Y + 0.54, bottom: BASE_Y + 0.2 });
    }
    // seesaw
    {
      const g = new Geometry();
      const piv = Geometry.box(0.4, 0.55, 0.5, { y0: 0 });
      g.append(piv);
      const plank = Geometry.box(0.45, 0.1, 5.0, { y0: 0 });
      plank.rotateX(0.18);
      plank.translate(0, 0.52, 0);
      g.append(plank);
      g.setColor(C('#9fd8a0'), 0.9);
      const [sx, sz] = tr(-2.5, 7.5);
      const m = W.mesh(g, W.M.wood, 'seesaw');
      m.setPos(sx, BASE_Y, sz);
      m.setRotY(yaw + 0.4);
      W.scene.add(m);
    }
    for (const [lx, lz] of [[-7, 3], [6.5, -2], [0, 12]]) {
      const [wx, wz] = tr(lx, lz);
      const d = this.def('lamps', 'pg', () => D.dreamLamp(3));
      this.place(d, wx, wz, yaw + lx, 1.1);
    }
    this.beacon(x, z, 150, '#ffb8d8', 0.45);
    this.region('playground', 'Elfeledett Játszótér', 'Egy játszótér a sekély víz közepén. A hinták maguktól lengenek, mintha valaki épp most szállt volna le róluk.', x, z, 26);
    this.landmarks.push({ id: 'playground', x, z });
    W.anchors.playground = [x, BASE_Y, z];
  }

  // ------------------------------------------------------------ landmark: the Colonnade
  colonnade(x, z) {
    const W = this.W, P = W.physics;
    const g = new Geometry(), orbs = new Geometry();
    const n = 6, sp = 6.5, H = 9;
    const off = ((n - 1) * sp) / 2;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const px = x - off + i * sp, pz = z - off + j * sp;
        const col = Geometry.box(0.9, H, 0.9, { y0: 0 });
        col.translate(px, BASE_Y, pz);
        g.append(col);
        const base = Geometry.box(1.2, 0.4, 1.2, { y0: 0 });
        base.translate(px, BASE_Y, pz);
        g.append(base);
        P.addCircle(px, pz, 0.62, { yMin: BASE_Y - 1, yMax: BASE_Y + H });
        if (i < n - 1) { const b = Geometry.box(sp, 0.6, 0.7, { y0: 0 }); b.translate(px + sp / 2, BASE_Y + H, pz); g.append(b); }
        if (j < n - 1) { const b = Geometry.box(0.7, 0.6, sp, { y0: 0 }); b.translate(px, BASE_Y + H, pz + sp / 2); g.append(b); }
        if (i < n - 1 && j < n - 1 && (i + j) % 2 === 0) {
          const o = Geometry.sphere(0.35, 12, 8);
          o.translate(px + sp / 2, BASE_Y + H - 1.6, pz + sp / 2);
          orbs.append(o);
          const cord = Geometry.cylinder(0.015, 0.015, 1.3, 4, 1);
          cord.translate(px + sp / 2, BASE_Y + H - 1.28, pz + sp / 2);
          cord.setColor(C('#3a3440'), 1);
          g.append(cord);
        }
      }
    }
    g.paint((p) => {
      // tiled look: faint grout lines on the pillars
      const line = (Math.abs(((p[1] + 0.25) % 0.5) - 0.25) < 0.015) ? 0.82 : 1;
      return C('#eef2f6').map((v) => v * line).concat([0.9]);
    });
    const m = W.mesh(g, W.M.plaster, 'colonnade');
    m.maxDistance = 800;
    W.scene.add(m);
    orbs.setColor(C('#fff4d8'), 1);
    orbs.setExtra([2.4]);
    const om = W.mesh(orbs, W.M.glow, 'orbs');
    om.castShadow = false;
    W.scene.add(om);
    for (const [i, j] of [[1, 1], [3, 3], [1, 3], [3, 1]]) W.light([x - off + (i + 0.5) * sp, BASE_Y + H - 1.8, z - off + (j + 0.5) * sp], C('#fff0d0'), 1.8, 10, 0.03, 1);
    // pedestal in the middle with a star shard
    const ped = Geometry.cylinder(0.8, 1.0, 1.1, 16, 1);
    ped.translate(x, BASE_Y, z);
    ped.setColor(C('#dfe6f0'), 1);
    W.scene.add(W.mesh(ped, W.M.stoneFine, 'pedestal'));
    P.addSurface({ type: 'disc', x, z, r: 0.85, top: BASE_Y + 1.1, bottom: BASE_Y - 0.5 });
    addShard(W, x, z, BASE_Y + 1.1);
    this.beacon(x, z, 150, '#c8f0ff', 0.45);
    this.region('colonnade', 'Oszlopcsarnok', 'Csempézett oszlopok végtelennek tűnő sora a víz fölött. Olyan, mint egy uszoda, ahonnan elfolyt az épület.', x, z, 26);
    this.landmarks.push({ id: 'colonnade', x, z });
    W.anchors.colonnade = [x + 3, BASE_Y, z + 3];
  }

  // ------------------------------------------------------------ landmark: the Sleeping Moon
  sleepingMoon(x, z) {
    const W = this.W, P = W.physics;
    const R = 16, cy = BASE_Y - 5;
    const face = Math.atan2(-x, -z); // looks back towards the island
    const g = Geometry.sphere(R, 40, 28);
    g.paint((p) => {
      const n = (Math.sin(p[0] * 0.4) + Math.sin(p[2] * 0.5 + p[1] * 0.3)) * 0.5;
      return (n > 0.7 ? C('#c8c8e8') : C('#e8e6f8')).concat([1]);
    });
    g.paintExtra(() => [0.25]);
    const node = new Node('sleepingMoon');
    node.setPos(x, cy, z);
    node.setRotY(face);
    node.add(W.mesh(g, W.M.glowSoft, 'moonBody'));
    // closed eyes, a smile, rosy cheeks
    const feat = new Geometry();
    for (const sx of [-1, 1]) {
      const eye = Geometry.torus(2.0, 0.28, 6, 16, Math.PI);
      eye.rotateX(Math.PI / 2); // a downward arc: sleeping eyes
      eye.translate(sx * 5, 9.5, 0);
      feat.append(eye);
    }
    const smile = Geometry.torus(4.0, 0.35, 6, 20, Math.PI);
    smile.rotateX(Math.PI / 2);
    smile.translate(0, 4.8, 0);
    feat.append(smile);
    // project the features onto the sphere's face side (+z)
    feat.deform((p) => [p[0], p[1], Math.sqrt(Math.max(0, R * R - p[0] * p[0] - p[1] * p[1])) + 0.15]);
    feat.setColor(C('#4a4070'), 1);
    node.add(W.mesh(feat, W.M.cloth, 'moonFace'));
    const cheeks = new Geometry();
    for (const sx of [-1, 1]) {
      const ch = Geometry.sphere(1.6, 12, 8);
      ch.scale(1, 0.6, 0.3);
      const px = sx * 7.5, py = 6.5;
      ch.translate(px, py, Math.sqrt(R * R - px * px - py * py) + 0.05);
      cheeks.append(ch);
    }
    cheeks.setColor(C('#ff9ac0'), 1);
    cheeks.setExtra([0.6]);
    node.add(W.mesh(cheeks, W.M.glowSoft, 'moonCheeks'));
    // a nightcap
    const cap = Geometry.lathe([[7.5, 0], [6.5, 3], [4, 7], [1.5, 10], [0.3, 11]], 20);
    cap.deform((p) => [p[0] + (p[1] / 11) ** 2 * 5, p[1], p[2]]);
    cap.computeNormals();
    cap.translate(-1.5, R - 3.2, -2);
    cap.paint((p) => (Math.sin(p[1] * 1.4) > 0.3 ? C('#7a8ae8') : C('#e8ecff')).concat([1]));
    const pom = Geometry.sphere(1.2, 12, 8);
    pom.translate(-1.5 + 5.2, R - 3.2 + 11.2, -2);
    pom.setColor(C('#fff8e0'), 1);
    cap.append(pom);
    node.add(W.mesh(cap, W.M.cloth, 'moonCap'));
    W.scene.add(node);
    W.physics.addCircle(x, z, R * 0.93, { yMin: BASE_Y - 1, yMax: cy + R * 0.6 });
    // the top of the head is walkable; clouds spiral up to it
    P.addSurface({
      type: 'fn', x, z, r: R * 0.7, top: cy + R, bottom: cy + R * 0.5,
      topFn: (lx, lz) => { const d2 = lx * lx + lz * lz; return d2 > R * R * 0.49 ? null : cy + Math.sqrt(R * R - d2); },
    });
    const clouds = [];
    const n = 12;
    for (let i = 0; i < n; i++) {
      const a = face + Math.PI * 0.4 + i * 0.42;
      const r = R + 2.2 - i * 0.25;
      clouds.push({ x: x + Math.sin(a) * r, y: BASE_Y + 0.6 + i * 1.05, z: z + Math.cos(a) * r, R: 1.7, seed: 1800 + i, flat: 0.4 });
    }
    this.cloudGroup(clouds);
    addShard(W, x, z, cy + R);
    // Z-z-z: letters drift up from its mouth and fade
    const zg = new Geometry();
    const zz = (s) => {
      const q = new Geometry();
      q.append(Geometry.box(1.2 * s, 0.22 * s, 0.22 * s, { y0: 0.5 * s }));
      q.append(Geometry.box(1.2 * s, 0.22 * s, 0.22 * s, { y0: -0.72 * s }));
      const d = Geometry.box(1.55 * s, 0.22 * s, 0.22 * s, { y0: -0.11 * s });
      d.rotateZ(0.78);
      q.append(d);
      return q;
    };
    zg.append(zz(1));
    zg.setColor(C('#dfe8ff'), 1);
    zg.setExtra([2.2]);
    const zgpu = W.gpu(zg);
    const zs = [];
    for (let i = 0; i < 3; i++) {
      const zm = W.meshG(zgpu, W.M.glow, 'zzz');
      zm.castShadow = false;
      zm.dynamic = true;
      W.scene.add(zm);
      zs.push(zm);
    }
    const mouth = [x + Math.sin(face) * (R + 1) , cy + 8, z + Math.cos(face) * (R + 1)];
    this.animated.push((t) => {
      for (let i = 0; i < 3; i++) {
        const u = (t * 0.12 + i / 3) % 1;
        const s = 0.6 + u * 1.6;
        zs[i].setPos(mouth[0] + Math.sin(face + 1.2) * u * 6, mouth[1] + u * 14, mouth[2] + Math.cos(face + 1.2) * u * 6);
        zs[i].setRotY(face + Math.sin(t + i) * 0.3);
        zs[i].setScale(s * (u < 0.85 ? 1 : (1 - u) / 0.15));
      }
    });
    W.light([mouth[0], mouth[1] + 3, mouth[2]], C('#dfe8ff'), 2.4, 18, 0.04, 2);
    this.beacon(x, z, 170, '#fff0c0', 0.5);
    this.region('sleepingMoon', 'Alvó Hold', 'A Hold lejött pihenni a tengerre. Hálósapkát húzott, és azóta horkol. Csak csendesen!', x, z, 34);
    this.landmarks.push({ id: 'sleepingMoon', x, z, top: [x, cy + R, z] });
    W.anchors.sleepingMoon = [x + Math.sin(face) * (R + 5), BASE_Y, z + Math.cos(face) * (R + 5)];
    W.anchors.moonTop = [x + 1.5, cy + R - 0.1, z];
  }

  // ------------------------------------------------------------ landmark: the Field of Doors (each leads somewhere)
  fieldOfDoors(x, z) {
    const W = this.W, S = W.L.sites, A = W.anchors;
    const site = (s) => () => [s.x, null, s.z];
    const entry = (s) => () => [s.entry[0], null, s.entry[1]];
    const dests = [
      ['Holdfény-tisztás', entry(S.glade)], ['Gombafalu', entry(S.village)], ['Csillagtó', entry(S.lake)],
      ['Kéklő Gombaerdő', entry(S.mushroom)], ['Álompiramis', entry(S.pyramid)], ['Holdarc-kert', entry(S.moongarden)],
      ['Csillagász tornya', () => A.towerTop], ['Kőmarok kapuja', entry(S.castle)], ['Felhőkikötő', () => A.harbour],
      ['Felhőkert', () => A.skyGarden], ['Végtelen Lépcső', () => A.endlessStairTop], ['Alvó Hold', () => A.moonTop],
      ['Oszlopcsarnok', () => A.colonnade], ['Elfeledett Játszótér', () => A.playground], ['Lidércláp', entry(S.swamp)],
      ['Kristálymező', site(S.crystal)], ['Feledés romjai', site(S.ruins)], ['Hullócsillag-kráter', entry(S.crater)],
    ];
    const yaw = Math.atan2(-x, -z);
    const c = Math.cos(yaw), s = Math.sin(yaw);
    const rng = new RNG(99);
    let k = 0;
    for (let i = -2; i <= 2; i++) {
      for (let j = -2; j <= 2; j++) {
        const lx = i * 6.5 + rng.range(-0.8, 0.8), lz = j * 6.5 + rng.range(-0.8, 0.8);
        if (i === 0 && j === 0) continue;
        const wx = x + lx * c + lz * s, wz = z - lx * s + lz * c;
        const d = this.def('door', 'field' + (k % 7), () => D.dreamDoor(900 + k, { color: D.PASTELS[k % 7], open: 0.25 + (k % 3) * 0.2 }));
        const p = this.place(d, wx, wz, yaw + rng.range(-0.25, 0.25), 1.25, BASE_Y, { name: 'fieldDoor' });
        const dest = dests[k % dests.length];
        this.portal(p, dest[0], dest[1]);
        k++;
      }
    }
    addShard(W, x, z, BASE_Y);
    this.beacon(x, z, 150, '#d8b8ff', 0.45);
    this.region('fieldOfDoors', 'Ajtók Mezeje', 'Huszonnégy ajtó áll a vízben, és mindegyik máshová nyílik. Az egyik biztosan haza.', x, z, 26);
    this.landmarks.push({ id: 'fieldOfDoors', x, z });
  }

  // is the player walking through one of the doors? (returns the portal, once)
  checkPortals(pl, t) {
    if (this.cool && t < this.cool) return null;
    const px = pl.pos[0], pz = pl.pos[2];
    for (const p of this.portals) {
      const dx = px - p.x, dz = pz - p.z;
      if (dx * dx + dz * dz > 9 * p.hw * p.hw + 4) continue;
      const c = Math.cos(p.yaw), s = Math.sin(p.yaw);
      const lx = dx * c - dz * s, lz = dx * s + dz * c;
      if (Math.abs(lx) < p.hw && Math.abs(lz) < 0.28 && pl.pos[1] > p.y - 0.6 && pl.pos[1] < p.y + p.h) {
        this.cool = t + 3;
        return p;
      }
    }
    return null;
  }
  // doors you can walk through
  portal(p, name, dest) {
    const d = p.node.children.length ? p : null;
    if (!d) return;
    const hw = 0.66 * p.s, h = 3.0 * p.s;
    this.portals.push({ x: p.x, z: p.z, y: p.y, yaw: p.yaw, hw, h, name, dest });
  }
  cloudGroup(list) {
    const W = this.W;
    const g = new Geometry();
    for (const q of list) {
      const pg = cloudPuff(q.seed, q.R, { flat: q.flat ?? 0.45, glow: 0.03 });
      let top = -Infinity;
      for (let i = 1; i < pg.p.length; i += 3) top = Math.max(top, pg.p[i]);
      pg.translate(q.x, q.y, q.z);
      g.append(pg);
      const cs = geometrySurface(W.physics, [{ g: pg, m: null }], { cell: 0.25, bottom: q.y - q.R * 0.3, sink: 0.1, soft: true });
      // (v9.1d) a cloud never becomes a floor or a ceiling inside a hole (the Endless Stair's column)
      if (q.hole) {
        const f = cs.topFn, H = q.hole;
        cs.topFn = (lx, lz, pad) => (Math.hypot(cs.x + lx - H.x, cs.z + lz - H.z) < H.r ? null : f(lx, lz, pad));
      }
    }
    const m = W.mesh(g, W.M.cloud, 'seaClouds');
    m.castShadow = false;
    m.maxDistance = 700;
    W.scene.add(m);
  }

  // ------------------------------------------------------------ the infinite scatter
  update(cam, t) {
    for (const f of this.animated) f(t);
    const ci = Math.floor(cam[0] / CELL), cj = Math.floor(cam[2] / CELL);
    const key = ci + ',' + cj;
    if (key === this.lastCell) return;
    this.lastCell = key;
    for (const c of this.cells.values()) c.active = false;
    for (let dj = -NEAR_R; dj <= NEAR_R; dj++) {
      for (let di = -NEAR_R; di <= NEAR_R; di++) {
        if (di * di + dj * dj > NEAR_R * NEAR_R + 1) continue;
        const i = ci + di, j = cj + dj, k = i + ',' + j;
        let c = this.cells.get(k);
        if (!c) { c = this.makeCell(i, j); this.cells.set(k, c); }
        c.active = true;
      }
    }
    for (const c of this.cells.values()) {
      if (c.shown === c.active) continue;
      c.shown = c.active;
      for (const it of c.items) {
        it.node.visible = c.active;
        for (const l of it.lights) l.enabled = c.active;
      }
    }
  }
  makeCell(i, j) {
    const cell = { items: [], active: true, shown: true };
    const rng = new RNG(hash2(i, j) % 2147483646 + 1);
    const cx = (i + 0.5) * CELL + rng.range(-CELL * 0.3, CELL * 0.3), cz = (j + 0.5) * CELL + rng.range(-CELL * 0.3, CELL * 0.3);
    if (Math.hypot(cx, cz) < CLEAR_R || Math.hypot(cx, cz) > 700) return cell; // (the dream ends at 680 m)
    if (this.landmarks.some((l) => Math.hypot(l.x - cx, l.z - cz) < (l.clear || 70))) return cell;
    if (rng.next() < 0.22) return cell;
    let total = 0;
    for (const t of TYPES) total += t[1];
    let pick = rng.next() * total, type = TYPES[0];
    for (const t of TYPES) { pick -= t[1]; if (pick <= 0) { type = t; break; } }
    const [name, , getBuild] = type;
    const yaw = rng.range(0, TAU);
    if (name === 'clouds') {
      // a little bank of clouds sitting on the water, walkable
      const list = [];
      for (let k = 0; k < rng.int(3, 6); k++) list.push({ x: cx + rng.range(-8, 8), y: BASE_Y + rng.range(-0.4, 1.2), z: cz + rng.range(-8, 8), R: rng.range(2, 4.5), seed: (hash2(i, j) + k) % 9000 });
      const node = new Node('seaCloudCell');
      const g = new Geometry();
      for (const q of list) {
        const pg = cloudPuff(q.seed, q.R, { flat: 0.4, glow: 0.03 });
        let top = -Infinity;
        for (let v = 1; v < pg.p.length; v += 3) top = Math.max(top, pg.p[v]);
        pg.translate(q.x, q.y, q.z);
        g.append(pg);
        geometrySurface(this.W.physics, [{ g: pg, m: null }], { cell: 0.25, bottom: q.y - q.R * 0.3, sink: 0.1, soft: true });
      }
      const m = this.W.mesh(g, this.W.M.cloud, 'seaClouds');
      m.castShadow = false;
      m.maxDistance = 450;
      node.add(m);
      this.W.scene.add(node);
      cell.items.push({ node, lights: [] });
      return cell;
    }
    const build = getBuild();
    const variant = rng.int(0, 2);
    const d = this.def(name, variant, () => build(hash2(variant, name.length) % 1000 + 17));
    const sr = SCALE[name] || [1, 1.5];
    const sc = rng.range(sr[0], sr[1]);
    if (name === 'lamps') {
      // a row of street lamps leading nowhere
      const n = rng.int(2, 5);
      const dx = Math.cos(yaw) * 9, dz = Math.sin(yaw) * 9;
      for (let k = 0; k < n; k++) cell.items.push(this.place(d, cx + dx * k, cz + dz * k, yaw + Math.PI / 2, sc));
      return cell;
    }
    const p = this.place(d, cx, cz, yaw, sc);
    cell.items.push(p);
    // now and then a glowing door leads home
    if (name === 'door' && rng.next() < 0.45) this.portal(p, 'Holdfény-tisztás', () => [this.W.L.sites.glade.entry[0], null, this.W.L.sites.glade.entry[1]]);
    return cell;
  }
}
