// Particle systems (all animation happens on the GPU) and the butterfly swarms.
import { Geometry } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Material } from '../engine/scene.js';
import { RNG } from '../engine/math.js';

let quadGeo = null;
function quad(gl) {
  if (!quadGeo) {
    const g = new Geometry();
    const a = g.vert(-0.5, -0.5, 0), b = g.vert(0.5, -0.5, 0), c = g.vert(0.5, 0.5, 0), d = g.vert(-0.5, 0.5, 0);
    g.quad(a, b, c, d);
    quadGeo = new GpuGeometry(gl, g);
    quadGeo.shared = true; // lives across world rebuilds
  }
  return quadGeo;
}

// fill(i, rng) -> { p:[x,y,z], seed, params:[a,b,c,d], size, life, speed, spread, color:[r,g,b], intensity }
export function particleSystem(gl, count, defines, fill, { blend = 'additive', seed = 1, bounds = null, renderOrder = 10 } = {}) {
  const rng = new RNG(seed);
  const data = new Float32Array(count * 20);
  let minx = Infinity, miny = Infinity, minz = Infinity, maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
  for (let i = 0; i < count; i++) {
    const f = fill(i, rng);
    const o = i * 20;
    data[o] = f.p[0]; data[o + 1] = f.p[1]; data[o + 2] = f.p[2]; data[o + 3] = f.seed ?? rng.next();
    const pr = f.params || [0, 0, 0, 0];
    data[o + 4] = pr[0]; data[o + 5] = pr[1]; data[o + 6] = pr[2]; data[o + 7] = pr[3];
    data[o + 8] = f.size ?? 0.1; data[o + 9] = f.life ?? 1; data[o + 10] = f.speed ?? 1; data[o + 11] = f.spread ?? 1;
    data[o + 16] = f.color[0]; data[o + 17] = f.color[1]; data[o + 18] = f.color[2]; data[o + 19] = f.intensity ?? 1;
    const s = (f.spread ?? 1) * 2 + (f.speed ?? 0) * (defines.RISE ? 1 : 0) + 1;
    minx = Math.min(minx, f.p[0] - s); maxx = Math.max(maxx, f.p[0] + s);
    miny = Math.min(miny, f.p[1] - s); maxy = Math.max(maxy, f.p[1] + s);
    minz = Math.min(minz, f.p[2] - s); maxz = Math.max(maxz, f.p[2] + s);
  }
  const mat = new Material({
    kind: 'particles',
    defines,
    transparent: true,
    blend,
    depthWrite: false,
    castShadow: false,
    renderOrder,
    uniforms: { uTimeOffset: 0, uOrigin: [0, 0, 0] },
  });
  const mesh = new Mesh(quad(gl), mat, 'particles');
  mesh.setInstances(data, count);
  mesh.castShadow = false;
  if (bounds === 'none') mesh.frustumCulled = false;
  else {
    const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, cz = (minz + maxz) / 2;
    mesh.boundsWorld = [cx, cy, cz, Math.hypot(maxx - cx, maxy - cy, maxz - cz)];
  }
  mesh.frustumData = data;
  return mesh;
}

// Butterfly swarm around a center
export function butterflies(gl, count, center, { radius = 4, height = 1.5, color = [0.3, 0.6, 2.2], seed = 3, intensity = 1.6 } = {}) {
  const g = new Geometry();
  // two wings: x from 0..±w, z from -h..h; uv.x = |x|/w, uv.y = z/h
  const w = 0.16, h = 0.14;
  for (const s of [-1, 1]) {
    const a = g.vert(0, 0, -h, 0, 1, 0, 0, -1);
    const b = g.vert(s * w, 0, -h, 0, 1, 0, 1, -1);
    const c = g.vert(s * w, 0, h, 0, 1, 0, 1, 1);
    const d = g.vert(0, 0, h, 0, 1, 0, 0, 1);
    g.quad(a, b, c, d);
  }
  const geo = new GpuGeometry(gl, g);
  const rng = new RNG(seed);
  const data = new Float32Array(count * 20);
  for (let i = 0; i < count; i++) {
    const o = i * 20;
    data[o] = center[0] + rng.range(-radius, radius) * 0.4;
    data[o + 1] = center[1] + rng.range(0, height);
    data[o + 2] = center[2] + rng.range(-radius, radius) * 0.4;
    data[o + 3] = rng.next();
    data[o + 4] = radius * rng.range(0.3, 1.0);
    data[o + 5] = height * rng.range(0.3, 1.0);
    data[o + 6] = rng.range(0.25, 0.6) * rng.sign();
    data[o + 7] = rng.range(14, 22);
    const tint = rng.range(0.7, 1.3);
    data[o + 16] = color[0] * tint; data[o + 17] = color[1] * tint; data[o + 18] = color[2]; data[o + 19] = intensity;
  }
  const mat = new Material({ kind: 'butterfly', transparent: true, blend: 'additive', depthWrite: false, castShadow: false, cull: 'none', renderOrder: 11 });
  const mesh = new Mesh(geo, mat, 'butterflies');
  mesh.setInstances(data, count);
  mesh.boundsWorld = [center[0], center[1] + height, center[2], radius * 2 + height * 2];
  mesh.castShadow = false;
  return mesh;
}

// Ring buffer for trail sparkles emitted by the player's staff
export class TrailEmitter {
  constructor(gl, count = 160) {
    this.count = count;
    this.mesh = particleSystem(gl, count, { TRAIL: 1, STAR: 1 }, (i) => ({
      p: [0, -1000, 0], params: [-100, 0, 0, 0], size: 0.12, life: 1.2, speed: 0.4, spread: 0.3, color: [0.5, 0.8, 1.6], intensity: 1.8,
    }), { bounds: 'none' });
    this.data = this.mesh.instanceData;
    this.cursor = 0;
    this.dirty = false;
  }
  emit(p, time, { size = 0.12, life = 1.2, rise = 0.4, spread = 0.3, color = [0.5, 0.8, 1.6], intensity = 1.8 } = {}) {
    const o = this.cursor * 20;
    const d = this.data;
    d[o] = p[0]; d[o + 1] = p[1]; d[o + 2] = p[2]; d[o + 3] = Math.random();
    d[o + 4] = time;
    d[o + 8] = size; d[o + 9] = life; d[o + 10] = rise; d[o + 11] = spread;
    d[o + 16] = color[0]; d[o + 17] = color[1]; d[o + 18] = color[2]; d[o + 19] = intensity;
    this.cursor = (this.cursor + 1) % this.count;
    this.dirty = true;
  }
  flush() {
    if (!this.dirty) return;
    this.mesh.updateInstances(this.count);
    this.dirty = false;
  }
}

// (v8) Ring buffer for the dragon's fire: every particle flies off with its own velocity
export class FireEmitter {
  constructor(gl, count = 700) {
    this.count = count;
    this.mesh = particleSystem(gl, count, { FIRE: 1 }, () => ({
      p: [0, -1000, 0], params: [-100, 0, 0, 0], size: 0.5, life: 1, speed: 0, spread: 0.5, color: [1, 1, 1], intensity: 2,
    }), { bounds: 'none', renderOrder: 12 });
    this.data = this.mesh.instanceData;
    this.cursor = 0;
    this.dirty = false;
  }
  emit(p, v, time, { size = 0.6, life = 0.9, rise = 1.2, spread = 0.8, color = [1, 1, 1], intensity = 2.2 } = {}) {
    const o = this.cursor * 20;
    const d = this.data;
    d[o] = p[0]; d[o + 1] = p[1]; d[o + 2] = p[2]; d[o + 3] = Math.random();
    d[o + 4] = time; d[o + 5] = v[0]; d[o + 6] = v[1]; d[o + 7] = v[2];
    d[o + 8] = size; d[o + 9] = life; d[o + 10] = rise; d[o + 11] = spread;
    d[o + 16] = color[0]; d[o + 17] = color[1]; d[o + 18] = color[2]; d[o + 19] = intensity;
    this.cursor = (this.cursor + 1) % this.count;
    this.dirty = true;
  }
  flush() {
    if (!this.dirty) return;
    this.mesh.updateInstances(this.count);
    this.dirty = false;
  }
}

// Glowing jellyfish drifting through the air
export function jellyfish(gl, count, center, { radius = 20, height = 10, spread = 30, color = [0.5, 0.7, 1.6], seed = 5, yBase = 8 } = {}) {
  const g = new Geometry();
  const bell = Geometry.lathe([[0.0, 0.62], [0.3, 0.58], [0.52, 0.38], [0.62, 0.08], [0.56, -0.04]], 16);
  bell.setExtra([0, 0, 0, 0]);
  g.append(bell);
  for (let k = 0; k < 8; k++) {
    const a = (k / 8) * Math.PI * 2;
    const x = Math.cos(a) * 0.35, z = Math.sin(a) * 0.35;
    const base = g.vertexCount;
    const segs = 6;
    for (let i = 0; i <= segs; i++) {
      const t = i / segs;
      g.extra = [1, t, 0, k * 1.7];
      g.vert(x - Math.sin(a) * 0.04, -t * 2.2, z + Math.cos(a) * 0.04, Math.cos(a), 0, Math.sin(a));
      g.vert(x + Math.sin(a) * 0.04, -t * 2.2, z - Math.cos(a) * 0.04, Math.cos(a), 0, Math.sin(a));
    }
    for (let i = 0; i < segs; i++) {
      const q = base + i * 2;
      g.quad(q, q + 1, q + 3, q + 2);
    }
  }
  const geo = new GpuGeometry(gl, g);
  const rng = new RNG(seed);
  const data = new Float32Array(count * 20);
  for (let i = 0; i < count; i++) {
    const o = i * 20;
    const a = rng.range(0, Math.PI * 2), d = Math.sqrt(rng.next()) * spread;
    data[o] = center[0] + Math.cos(a) * d;
    data[o + 1] = center[1] + yBase + rng.range(0, height);
    data[o + 2] = center[2] + Math.sin(a) * d;
    data[o + 3] = rng.next();
    data[o + 4] = rng.range(2, radius * 0.4);
    data[o + 5] = rng.range(0.5, 2.5);
    data[o + 6] = rng.range(0.2, 0.5);
    data[o + 7] = rng.range(0.6, 1.6);
    const tint = rng.range(0.7, 1.3);
    data[o + 16] = color[0] * tint; data[o + 17] = color[1]; data[o + 18] = color[2] * rng.range(0.8, 1.2); data[o + 19] = rng.range(1.5, 3);
  }
  const mat = new Material({ kind: 'jelly', transparent: true, blend: 'additive', depthWrite: false, castShadow: false, cull: 'none', renderOrder: 12 });
  const mesh = new Mesh(geo, mat, 'jellyfish');
  mesh.setInstances(data, count);
  mesh.boundsWorld = [center[0], center[1] + yBase + height / 2, center[2], spread + radius + height];
  mesh.castShadow = false;
  return mesh;
}
