// (v8) Walkable surfaces taken straight from the rendered geometry: for every cell of a fine grid, the
// highest point of the triangles above it. What you can stand on is then exactly what you can see
// (a cloud's lumpy blobs, an island's ragged rim), instead of a rough disc around it.
//
//   const s = geometrySurface(physics, [{ g: geometry, m: worldMatrixOrNull }, ...], { cell, bottom })
//
// g may be a Geometry (p/idx arrays) or a GPU geometry's cpu copy ({ p, idx } typed arrays).

export function heightGrid(parts, cell = 0.25) {
  // world-space vertices of every part
  const tris = [];
  let minx = Infinity, minz = Infinity, maxx = -Infinity, maxz = -Infinity, miny = Infinity;
  for (const { g, m } of parts) {
    const p = g.p, idx = g.idx;
    const nv = p.length / 3;
    const w = new Float32Array(nv * 3);
    for (let i = 0; i < nv; i++) {
      const x = p[i * 3], y = p[i * 3 + 1], z = p[i * 3 + 2];
      if (m) {
        w[i * 3] = m[0] * x + m[4] * y + m[8] * z + m[12];
        w[i * 3 + 1] = m[1] * x + m[5] * y + m[9] * z + m[13];
        w[i * 3 + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
      } else { w[i * 3] = x; w[i * 3 + 1] = y; w[i * 3 + 2] = z; }
      minx = Math.min(minx, w[i * 3]); maxx = Math.max(maxx, w[i * 3]);
      minz = Math.min(minz, w[i * 3 + 2]); maxz = Math.max(maxz, w[i * 3 + 2]);
      miny = Math.min(miny, w[i * 3 + 1]);
    }
    tris.push({ w, idx });
  }
  const nx = Math.max(2, Math.ceil((maxx - minx) / cell) + 2), nz = Math.max(2, Math.ceil((maxz - minz) / cell) + 2);
  const h = new Float32Array(nx * nz).fill(-Infinity);
  const x0 = minx - cell * 0.5, z0 = minz - cell * 0.5;
  for (const { w, idx } of tris) {
    for (let t = 0; t < idx.length; t += 3) {
      const a = idx[t] * 3, b = idx[t + 1] * 3, c = idx[t + 2] * 3;
      const ax = w[a], ay = w[a + 1], az = w[a + 2];
      const bx = w[b], by = w[b + 1], bz = w[b + 2];
      const cx = w[c], cy = w[c + 1], cz = w[c + 2];
      const d = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz);
      if (Math.abs(d) < 1e-9) continue; // seen edge-on from above
      const i0 = Math.max(0, Math.floor((Math.min(ax, bx, cx) - x0) / cell)), i1 = Math.min(nx - 1, Math.ceil((Math.max(ax, bx, cx) - x0) / cell));
      const j0 = Math.max(0, Math.floor((Math.min(az, bz, cz) - z0) / cell)), j1 = Math.min(nz - 1, Math.ceil((Math.max(az, bz, cz) - z0) / cell));
      for (let j = j0; j <= j1; j++) {
        const pz = z0 + (j + 0.5) * cell;
        for (let i = i0; i <= i1; i++) {
          const px = x0 + (i + 0.5) * cell;
          const l1 = ((bz - cz) * (px - cx) + (cx - bx) * (pz - cz)) / d;
          const l2 = ((cz - az) * (px - cx) + (ax - cx) * (pz - cz)) / d;
          const l3 = 1 - l1 - l2;
          if (l1 < -1e-4 || l2 < -1e-4 || l3 < -1e-4) continue;
          const y = l1 * ay + l2 * by + l3 * cy;
          const k = j * nx + i;
          if (y > h[k]) h[k] = y;
        }
      }
    }
  }
  // close pinholes, then soften the bumps a little (the blobs of a cloud would make you bob)
  const H = h.slice();
  for (let j = 1; j < nz - 1; j++) {
    for (let i = 1; i < nx - 1; i++) {
      const k = j * nx + i;
      let s = 0, n = 0;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
        if (!di && !dj) continue;
        const v = h[k + dj * nx + di];
        if (v > -Infinity) { s += v; n++; }
      }
      if (h[k] === -Infinity) { if (n >= 6) H[k] = s / n; }
      else if (n) H[k] = (h[k] * 3 + s) / (3 + n);
    }
  }
  let top = -Infinity;
  for (let k = 0; k < H.length; k++) if (H[k] > top) top = H[k];
  return { h: H, nx, nz, x0, z0, cell, top, miny, minx, maxx, minz, maxz };
}

// sample a height grid at world x,z (null where there is nothing)
export function sampleGrid(G, x, z) {
  const fx = (x - G.x0) / G.cell - 0.5, fz = (z - G.z0) / G.cell - 0.5;
  const i = Math.floor(fx), j = Math.floor(fz);
  if (i < -1 || j < -1 || i >= G.nx || j >= G.nz) return null;
  const ci = Math.min(G.nx - 1, Math.max(0, Math.round(fx))), cj = Math.min(G.nz - 1, Math.max(0, Math.round(fz)));
  if (G.h[cj * G.nx + ci] === -Infinity) return null; // the nearest cell is empty: off the edge
  // bilinear over the valid corners
  let s = 0, wsum = 0;
  const u = fx - i, v = fz - j;
  for (let dj = 0; dj <= 1; dj++) for (let di = 0; di <= 1; di++) {
    const ii = i + di, jj = j + dj;
    if (ii < 0 || jj < 0 || ii >= G.nx || jj >= G.nz) continue;
    const val = G.h[jj * G.nx + ii];
    if (val === -Infinity) continue;
    const wgt = (di ? u : 1 - u) * (dj ? v : 1 - v) + 1e-6;
    s += val * wgt;
    wsum += wgt;
  }
  return wsum ? s / wsum : null;
}

export function geometrySurface(physics, parts, { cell = 0.25, bottom = null, sink = 0.02, ...extra } = {}) {
  const G = heightGrid(parts, cell);
  const cx = (G.minx + G.maxx) / 2, cz = (G.minz + G.maxz) / 2;
  const r = Math.hypot(G.maxx - G.minx, G.maxz - G.minz) / 2 + cell;
  const s = physics.addSurface({
    type: 'fn', x: cx, z: cz, r, top: G.top - sink, bottom: bottom ?? G.miny,
    topFn: (lx, lz) => {
      const y = sampleGrid(G, cx + lx, cz + lz);
      return y === null ? null : y - sink;
    },
    ...extra,
  });
  s.grid = G;
  return s;
}
