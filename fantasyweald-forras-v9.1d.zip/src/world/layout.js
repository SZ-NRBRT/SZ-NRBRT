// The world plan: one fixed, hand-designed map. Everything about *where* things are lives here:
// named places, which way they face, the road network, the river and its bridges, lakes,
// hills, the mountain pass, biome zones and the irregular mountain border.
//
//   North: the great mountains with Kőmarok castle held by a stone hand; the river Holdpatak
//          springs from a gorge beside it and winds south-west into Csillagtó.
//   West:  Csillagtó with its waterfall cliff, the Gombafalu village, the will-o'-wisp swamp.
//   South: the blue Giant Mushroom Forest and the red fly agaric grove.
//   East:  the moon garden hill, the astronomer's hill, the dream desert with the pyramid
//          (behind a rocky ridge with a pass), the fallen star crater.
//   Hidden (no road leads there): floating islands, crystal basin, sleeping giant, ruins.
import { RNG, clamp, smoothstep, lerp, TAU } from '../engine/math.js';
import { Noise } from '../engine/noise.js';

export const WORLD = {
  size: 720,
  res: 505,           // height samples per side (~1.43 m spacing)
  waterLevel: -0.35,
};

export const DEFAULT_SEED = 7;

// Named places. `r` is the footprint used for spacing and clearing, `path` whether roads lead
// there, `face` the point (or site) the place turns towards, `entry` how far its road stops.
const SITES = [
  { id: 'glade', name: 'Holdfény-tisztás', x: 0, z: 0, r: 30, face: [6, -60], entry: 12, blurb: 'Vén Barnabás kunyhója. Itt mindig rotyog valami az üstben.' },
  { id: 'village', name: 'Gombafalu', x: -66, z: 46, r: 34, face: 'glade', entry: 16, blurb: 'Gombaházak, lámpásfüzérek és kíváncsi törpék.' },
  { id: 'lake', name: 'Csillagtó', x: -162, z: -4, r: 46, face: [-80, 30], lakeR: 42, blurb: 'A víz alulról világít. A manók szerint a csillagok ide járnak fürdeni.' },
  { id: 'swamp', name: 'Lidércláp', x: -184, z: 116, r: 38, face: [-100, 140], entry: 24, pondR: 20, blurb: 'Kék lidércfények táncolnak a köd fölött. Ne kövesd őket túl messzire.' },
  { id: 'amanita', name: 'Légyölő-liget', x: -84, z: 160, r: 32, face: 'village', entry: 10, blurb: 'Piros kalapú gombák erdeje. Némelyikről jó magasra lehet pattanni.' },
  { id: 'mushroom', name: 'Kéklő Gombaerdő', x: 32, z: 178, r: 58, face: 'glade', entry: 0, blurb: 'Óriásgombák világítanak, mint lámpások egy álomban.' },
  { id: 'pyramid', name: 'Álompiramis', x: 172, z: 138, r: 48, face: [150, 70], entry: 30, blurb: 'Homokdűnék közt álló piramis. Itt az ég is kinyitja a szemét.' },
  { id: 'islands', name: 'Lebegő szigetek', x: 88, z: 84, r: 26, hidden: true, face: 'glade', blurb: 'Kövek lebegnek a levegőben. Az ugrógombák felrepítenek.' },
  { id: 'crater', name: 'Hullócsillag-kráter', x: 214, z: 22, r: 28, face: 'moongarden', entry: 22, blurb: 'Itt csapódott be egy csillag. A szíve még mindig dobog.' },
  { id: 'moongarden', name: 'Holdarc-kert', x: 98, z: -20, r: 30, face: 'glade', entry: 11, blurb: 'A lehullott hold arca vigyorog a virágok közt. Pillangók őrzik.' },
  { id: 'tower', name: 'Csillagász tornya', x: 132, z: -104, r: 22, face: 'moongarden', entry: 9, blurb: 'Egy ferde torony a Csillaghegy tetején. Valaki fent lakik.' },
  { id: 'crystal', name: 'Kristálymező', x: 200, z: -120, r: 34, hidden: true, face: 'tower', blurb: 'Egy rejtett völgy, ahol a kristályok halkan zümmögnek, ha a hold rájuk süt.' },
  { id: 'rune', name: 'A Kék Láng köre', x: 30, z: -120, r: 30, face: 'glade', entry: 14, blurb: 'Csuklyás alakok virrasztanak a soha ki nem alvó kék tűz körül.' },
  { id: 'watcher', name: 'Egyszemű Kő', x: 96, z: -184, r: 26, face: 'tower', entry: 11, blurb: 'Egy mohos kő, amely figyel. Bárhová mész, a szeme követ.' },
  { id: 'ruins', name: 'Feledés romjai', x: -176, z: -146, r: 26, hidden: true, face: [-120, -100], blurb: 'Egy régi város kövei a holt erdőben. Már senki sem emlékszik a nevére.' },
  { id: 'giant', name: 'Az Alvó Óriás', x: -104, z: -196, r: 36, hidden: true, face: [-60, -150], blurb: 'Egy kőóriás alszik a dombok közt, mióta a hegyek fiatalok voltak.' },
  { id: 'castle', name: 'Kőmarok vára', x: 0, z: -256, r: 30, rim: true, face: [0, 0], entry: 7, blurb: 'Egy kőből faragott kéz tartja a várat. A kapu zárva.' },
];

// Roads: [from, to, via points]. Via points steer the road around hills, over the pass and onto
// the bridges; between them the road meanders naturally.
const ROADS = [
  ['glade', 'rune', [[14, -48], [36, -80]]],
  ['rune', 'castle', [[16, -160], [4, -200], [-6, -226]]],
  ['glade', 'village', [[-30, 22]]],
  ['village', 'lake', [[-96, 22]]],
  ['village', 'swamp', [[-110, 70], [-128, 96], [-140, 126]]],
  ['village', 'amanita', [[-72, 104]]],
  ['amanita', 'mushroom', [[-30, 176]]],
  ['glade', 'mushroom', [[8, 60], [22, 110]]],
  ['mushroom', 'pyramid', [[100, 176], [124, 150]]],
  ['glade', 'moongarden', [[44, -8]]],
  ['moongarden', 'crater', [[150, 0], [184, 18]]],
  ['moongarden', 'tower', [[118, -58]]],
  ['tower', 'watcher', [[120, -150]]],
  ['rune', 'tower', [[70, -128], [100, -112]]],
  ['pyramid', 'crater', [[196, 88]]],
  ['rune', 'lake', [[-20, -118], [-58, -96], [-92, -58], [-118, -34]]],
];

// Rivers: Holdpatak springs from a gorge beside the castle and winds down into Csillagtó;
// the little Ezüstér runs from the eastern hills into a pond.
const RIVERS = [
  { id: 'holdpatak', width: 6.5, depth: 2.4, points: [[70, -345], [58, -292], [44, -252], [22, -212], [0, -194], [-30, -178], [-58, -158], [-72, -128], [-96, -104], [-112, -76], [-126, -58], [-148, -44]] },
  { id: 'ezuster', width: 4.2, depth: 0.62, points: [[182, -86], [162, -58], [146, -30], [136, -2], [134, 22], [145, 42]] },
];

const LAKES = [
  { id: 'lake', x: -162, z: -4, r: 42, depth: 4.2 },
  { id: 'swampPond', x: -192, z: 110, r: 20, depth: 2.2, shallow: true },
  { id: 'pond0', x: -214, z: 150, r: 9, depth: 1.8, shallow: true },
  { id: 'pond1', x: -34, z: 108, r: 10, depth: 2.2, shallow: true },
  { id: 'pond2', x: 150, z: 52, r: 11, depth: 2.2, shallow: true },
  { id: 'pond3', x: 64, z: -164, r: 9, depth: 2.0, shallow: true },
  { id: 'pond4', x: -120, z: -150, r: 8, depth: 1.9, shallow: true },
];

// Shaped land: round hills, long ridges (with a pass the road climbs over) and basins.
const HILLS = [
  { x: 132, z: -104, r: 52, h: 15, top: 0.35 },   // Csillaghegy: the astronomer's hill
  { x: 98, z: -20, r: 46, h: 4.5, top: 0.5 },      // the moon garden rise
  { x: -104, z: -196, r: 54, h: 7, top: 0.2 },     // the giant's hills
  { x: -52, z: -226, r: 40, h: 9, top: 0.1 },
  { x: 60, z: 30, r: 34, h: 5, top: 0.1 },
  { x: -18, z: -70, r: 30, h: 4, top: 0.1 },
  { x: 150, z: -40, r: 30, h: 6, top: 0.2 },
];
const RIDGES = [
  // rocky ridge between the mushroom forest and the dream desert; the road crosses at a pass
  { a: [96, 250], b: [120, 96], w: 22, h: 17, pass: [112, 160], passW: 26, passH: 6.5 },
  { a: [174, -46], b: [164, -182], w: 16, h: 12, pass: [170, -120], passW: 18, passH: 1.2 },   // wall hiding the crystal valley (one narrow gap)
  { a: [-236, 60], b: [-250, -80], w: 20, h: 9 },    // hills behind the lake
];
const BASINS = [
  { x: 200, z: -120, r: 40, depth: 5 },   // crystal valley
];

// ---------------------------------------------------------------- helpers
function dist(a, b) {
  return Math.hypot(a.x - b.x, a.z - b.z);
}
function segDist(px, pz, a, b) {
  const vx = b[0] - a[0], vz = b[1] - a[1];
  const l2 = vx * vx + vz * vz || 1;
  let t = ((px - a[0]) * vx + (pz - a[1]) * vz) / l2;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return { d: Math.hypot(px - a[0] - vx * t, pz - a[1] - vz * t), t };
}
export function polyDist(px, pz, pts) {
  let best = Infinity, bi = 0, bt = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    // segDist inlined (same arithmetic, no garbage per segment)
    const a = pts[i], c = pts[i + 1];
    const vx = c[0] - a[0], vz = c[1] - a[1];
    const l2 = vx * vx + vz * vz || 1;
    let t = ((px - a[0]) * vx + (pz - a[1]) * vz) / l2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const d = Math.hypot(px - a[0] - vx * t, pz - a[1] - vz * t);
    if (d < best) { best = d; bi = i; bt = t; }
  }
  return { d: best, i: bi, t: bt };
}

// Distance from a point to a polyline, accelerated with a grid of segments. Exact whenever the distance is
// below `reach`; otherwise some value >= reach (callers only care about nearby lines).
export function lineIndex(pts, reach = 40, cell = 16) {
  const grid = new Map();
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    const x0 = Math.floor((Math.min(a[0], b[0]) - reach) / cell), x1 = Math.floor((Math.max(a[0], b[0]) + reach) / cell);
    const z0 = Math.floor((Math.min(a[1], b[1]) - reach) / cell), z1 = Math.floor((Math.max(a[1], b[1]) + reach) / cell);
    for (let gx = x0; gx <= x1; gx++) {
      for (let gz = z0; gz <= z1; gz++) {
        const k = gx * 65536 + gz;
        let l = grid.get(k);
        if (!l) grid.set(k, (l = []));
        l.push(i);
      }
    }
  }
  return {
    reach,
    dist(px, pz) {
      const l = grid.get(Math.floor(px / cell) * 65536 + Math.floor(pz / cell));
      if (!l) return Infinity;
      let best = Infinity;
      for (let k = 0; k < l.length; k++) {
        const i = l[k], a = pts[i], c = pts[i + 1];
        const vx = c[0] - a[0], vz = c[1] - a[1];
        const l2 = vx * vx + vz * vz || 1;
        let t = ((px - a[0]) * vx + (pz - a[1]) * vz) / l2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const d = Math.hypot(px - a[0] - vx * t, pz - a[1] - vz * t);
        if (d < best) best = d;
      }
      return best;
    },
  };
}
function catmull(pts, n) {
  const out = [];
  const P = (i) => pts[Math.max(0, Math.min(pts.length - 1, i))];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    for (let s = 0; s < n; s++) {
      const t = s / n, t2 = t * t, t3 = t2 * t;
      out.push([0, 1].map((k) => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)));
    }
  }
  out.push(pts[pts.length - 1].slice());
  return out;
}

export function generateLayout() {
  const seed = DEFAULT_SEED;
  const rng = new RNG(seed * 7919 + 13);
  const nz = new Noise(seed * 131 + 7);
  const L = { seed, size: WORLD.size, res: WORLD.res, waterLevel: WORLD.waterLevel, noise: nz };

  // irregular mountain border: radius of the walkable land by angle
  L.border = (ang) => 286 + 14 * Math.sin(ang * 2 + 0.7) + 10 * Math.sin(ang * 3 + 2.1) + 6 * Math.sin(ang * 5 + 4.0);
  L.borderAt = (x, z) => L.border(Math.atan2(z, x));

  // ------------------------------------------------------------ sites
  const sites = {};
  for (const T of SITES) sites[T.id] = { ...T, path: !T.hidden };
  const toPoint = (f) => (typeof f === 'string' ? [sites[f].x, sites[f].z] : f);
  for (const s of Object.values(sites)) {
    const [tx, tz] = toPoint(s.face);
    s.yaw = Math.atan2(tx - s.x, tz - s.z); // local +Z faces the approach
  }
  // castle: the gate sits on the rim, the stone hand beyond it
  {
    const c = sites.castle;
    const a = Math.atan2(c.z, c.x);
    const b = L.border(a);
    c.x = Math.cos(a) * (b - 20);
    c.z = Math.sin(a) * (b - 20);
    c.handX = Math.cos(a) * (b + 26);
    c.handZ = Math.sin(a) * (b + 26);
    c.yaw = Math.atan2(-c.x, -c.z);
  }
  for (const s of Object.values(sites)) {
    const d = s.entry ?? s.r * 0.5;
    s.entry = [s.x + Math.sin(s.yaw) * d, s.z + Math.cos(s.yaw) * d];
  }
  // the lake's road ends at its shore: pier start
  {
    const lk = sites.lake;
    lk.entry = [lk.x + Math.sin(lk.yaw) * (lk.lakeR + 3), lk.z + Math.cos(lk.yaw) * (lk.lakeR + 3)];
  }
  L.sites = sites;
  const placed = Object.values(sites);

  // ------------------------------------------------------------ water
  L.lakes = LAKES.map((l) => ({ ...l }));
  L.rivers = RIVERS.map((r) => ({ ...r, points: catmull(r.points, 5) }));
  for (const r of L.rivers) r.index = lineIndex(r.points, 40);

  // ------------------------------------------------------------ land shapes
  L.hills = HILLS;
  L.ridges = RIDGES;
  L.basins = BASINS;

  // ------------------------------------------------------------ roads
  const paths = [];
  ROADS.forEach(([from, to, via], k) => {
    const A = sites[from].entry, B = sites[to].entry;
    const ctrl = [A, ...via, B];
    let pts = [];
    for (let i = 0; i < ctrl.length - 1; i++) {
      const seg = meander(ctrl[i], ctrl[i + 1], rng, nz, L.lakes, placed.filter((s) => s.id !== from && s.id !== to), i === 0, i === ctrl.length - 2);
      if (i > 0) seg.shift();
      pts = pts.concat(seg);
    }
    const main = from === 'glade' || to === 'castle';
    paths.push({ id: 'p' + k, width: main ? 3.2 : 2.6, points: pts, from, to });
  });
  L.paths = paths;

  // bridges: where a road crosses the river
  L.bridges = [];
  for (const rv of L.rivers) {
    const rp = rv.points;
    for (const p of paths) {
      const pts = catmull(p.points, 6);
      for (let i = 0; i < pts.length - 1; i++) {
        for (let j = 0; j < rp.length - 1; j++) {
          const hit = segIntersect(pts[i], pts[i + 1], rp[j], rp[j + 1]);
          if (!hit) continue;
          if (L.bridges.some((b) => Math.hypot(b.x - hit[0], b.z - hit[1]) < 20)) continue;
          const a = pts[Math.max(0, i - 3)], b = pts[Math.min(pts.length - 1, i + 4)];
          L.bridges.push({ x: hit[0], z: hit[1], yaw: Math.atan2(b[0] - a[0], b[1] - a[1]), road: p.id, river: rv.id, span: rv.width + 7, stone: rv.id === 'holdpatak' });
        }
      }
    }
  }

  // ------------------------------------------------------------ flattened building grounds
  L.shapes = [];
  const flat = { glade: 0.85, village: 0.9, castle: 0.85, rune: 0.95, tower: 0.85, pyramid: 0.7, crater: 0, moongarden: 0.6, watcher: 0.55, amanita: 0.3, ruins: 0.6, giant: 0.4, crystal: 0.35, swamp: 0.5, islands: 0.5, mushroom: 0.0, lake: 0 };
  for (const s of placed) {
    const f = flat[s.id] ?? 0.5;
    if (f <= 0) continue;
    const rr = s.id === 'castle' ? 26 : s.id === 'pyramid' ? 34 : s.r * 0.8;
    L.shapes.push({ c: [s.x, s.z], r: rr, flat: f, id: s.id });
  }

  // ------------------------------------------------------------ regions for discovery/UI
  L.regions = placed.map((s) => ({
    id: s.id, name: s.name, blurb: s.blurb,
    center: [s.x, s.z],
    radius: s.id === 'mushroom' ? 64 : s.id === 'lake' ? s.lakeR + 16 : s.id === 'pyramid' ? 50 : s.id === 'crystal' ? 42 : s.r + 4,
    hidden: !s.path,
  }));

  // spawn in the glade, looking up the north road towards the castle
  const g = sites.glade;
  L.spawn = { x: g.x + Math.sin(g.yaw) * 6, z: g.z + Math.cos(g.yaw) * 6, yaw: g.yaw };

  L.biome = (x, z) => biomeAt(L, x, z);
  return L;
}

function segIntersect(p1, p2, p3, p4) {
  const d = (p2[0] - p1[0]) * (p4[1] - p3[1]) - (p2[1] - p1[1]) * (p4[0] - p3[0]);
  if (Math.abs(d) < 1e-9) return null;
  const t = ((p3[0] - p1[0]) * (p4[1] - p3[1]) - (p3[1] - p1[1]) * (p4[0] - p3[0])) / d;
  const u = ((p3[0] - p1[0]) * (p2[1] - p1[1]) - (p3[1] - p1[1]) * (p2[0] - p1[0])) / d;
  if (t < 0 || t > 1 || u < 0 || u > 1) return null;
  return [p1[0] + (p2[0] - p1[0]) * t, p1[1] + (p2[1] - p1[1]) * t];
}

// Winding road from A to B that bends around lakes and other sites. The ends stay put.
function meander(A, B, rng, nz, lakes, avoid, freeStart, freeEnd) {
  const dx = B[0] - A[0], dz = B[1] - A[1];
  const len = Math.hypot(dx, dz) || 1;
  const n = Math.max(2, Math.round(len / 12));
  const px = -dz / len, pz = dx / len;
  const amp = Math.min(14, len * 0.16) * rng.range(0.5, 1.0);
  const ph = rng.range(0, 100);
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const env = Math.sin(t * Math.PI);
    const w = (nz.n2(ph + t * 2.3, 0.5) * 0.8 + Math.sin(t * Math.PI * 2 + ph) * 0.3) * amp * env;
    let x = A[0] + dx * t + px * w;
    let z = A[1] + dz * t + pz * w;
    if (i > 0 && i < n) {
      for (let it = 0; it < 3; it++) {
        for (const l of lakes) {
          const d = Math.hypot(x - l.x, z - l.z), m = l.r + 7;
          if (d < m) { x = l.x + ((x - l.x) / (d || 1)) * m; z = l.z + ((z - l.z) / (d || 1)) * m; }
        }
        for (const s of avoid) {
          const d = Math.hypot(x - s.x, z - s.z), m = s.r * 0.75;
          if (d < m) { x = s.x + ((x - s.x) / (d || 1)) * m; z = s.z + ((z - s.z) / (d || 1)) * m; }
        }
      }
    }
    pts.push([x, z]);
  }
  return pts;
}

// Biome weights 0..1 used for vegetation, ground tint, grass and atmosphere.
// soft disc falloff around a point (no closure per biome query)
function fall(x, z, cx, cz, r, soft = 0.4) {
  const dx = x - cx, dz = z - cz;
  return 1 - smoothstep(r * (1 - soft), r, Math.sqrt(dx * dx + dz * dz));
}
function biomeAt(L, x, z) {
  const S = L.sites;
  const n = L.noise.fbm2(x * 0.012 + 40, z * 0.012 - 7, 3);
  const f = (cx, cz, r, soft) => fall(x, z, cx, cz, r, soft);
  // only the nearest ~25 m of a river matter here, so the indexed distance (exact within 40 m) is enough
  let rd = 99;
  for (const rv of L.rivers || []) rd = Math.min(rd, (rv.index ? rv.index.dist(x, z) : polyDist(x, z, rv.points).d) - rv.width * 0.5);
  const desert = f(S.pyramid.x + 8, S.pyramid.z + 6, 92 + n * 16, 0.45) * smoothstep(96, 118, x + z * 0.15);
  const north = smoothstep(-110, -190, z + n * 20);
  const dead = Math.max(f(S.watcher.x, S.watcher.z, 52), f(S.ruins.x, S.ruins.z, 58), f(S.giant.x, S.giant.z, 50) * 0.7) * 0.9;
  const meadow = Math.max(f(S.moongarden.x, S.moongarden.z, 44), f(S.village.x, S.village.z, 38), f(S.glade.x, S.glade.z, 30) * 0.7, f(S.islands.x, S.islands.z, 30) * 0.8);
  return {
    mushroom: f(S.mushroom.x, S.mushroom.z, 76 + n * 12),
    amanita: f(S.amanita.x, S.amanita.z, 44 + n * 6),
    desert,
    crystal: f(S.crystal.x, S.crystal.z, 46 + n * 6),
    swamp: Math.max(f(S.swamp.x, S.swamp.z, 62 + n * 10), f(S.lake.x, S.lake.z, S.lake.lakeR + 22, 0.5) * 0.6, (1 - smoothstep(6, 22, rd)) * 0.45),
    meadow,
    dead,
    pines: north * (1 - dead) * (1 - f(S.rune.x, S.rune.z, 24)),
    blossom: Math.max(f(S.moongarden.x, S.moongarden.z, 70, 0.5), f(S.glade.x, S.glade.z, 55, 0.6) * 0.55, f(S.village.x, S.village.z, 52, 0.5) * 0.6) * (1 - desert),
    islands: f(S.islands.x, S.islands.z, 44),
    river: 1 - smoothstep(4, 16, rd),
  };
}
