// Collision & walkable surfaces.
//
// Two kinds of obstacles:
//  - colliders: vertical circles / capsule segments (tree trunks, walls). They push the player out
//    sideways. Optional yMin / yMax lets you walk over or under them.
//  - surfaces: things you can stand on (rocks, steps, ramps, platforms, mushroom caps, islands).
//    A surface is also a solid volume between `bottom` and its top: if its top is higher than the
//    player can step up, it blocks movement like a wall.
//
// Surface types (all in world space, `yaw` rotates the local frame):
//   box  : { x, z, hx, hz, yaw, top, bottom }
//   disc : { x, z, r, top, bottom, dome }          dome: how much lower the rim is than the center
//   ramp : { x, z, hx, hz, yaw, y0, y1, bottom }   top goes from y0 at local -hz to y1 at +hz
//   fn   : { x, z, r, yaw, topFn(lx, lz) -> number|null, bottom }
// Optional on any surface: bounce (launch speed), tag, disabled (ignored until enabled).

const CELL = 8;

class Grid {
  constructor() {
    this.map = new Map();
  }
  key(i, j) {
    return i * 73856093 ^ j * 19349663;
  }
  insert(obj, minx, minz, maxx, maxz) {
    for (let i = Math.floor(minx / CELL); i <= Math.floor(maxx / CELL); i++) {
      for (let j = Math.floor(minz / CELL); j <= Math.floor(maxz / CELL); j++) {
        const k = this.key(i, j);
        let l = this.map.get(k);
        if (!l) this.map.set(k, (l = []));
        l.push(obj);
      }
    }
  }
  query(x, z) {
    return this.map.get(this.key(Math.floor(x / CELL), Math.floor(z / CELL))) || EMPTY;
  }
}
const EMPTY = [];

function toLocal(s, x, z) {
  const dx = x - s.x, dz = z - s.z;
  if (!s.yaw) return [dx, dz];
  const c = Math.cos(s.yaw), sn = Math.sin(s.yaw);
  // inverse of world = local rotated by yaw (x' = x c + z s, z' = -x s + z c)
  return [dx * c - dz * sn, dx * sn + dz * c];
}

// Solid grid: the steep (wall-like) triangles of every static mesh, rasterized into small cells that hold
// the height ranges where something solid is. Built once from the real geometry, so whatever you see
// blocks you exactly where it is: a giant's shoulder, a crystal, a flared stem, a ruin wall. Flat parts
// (floors, roofs, caps) are left to the walkable surfaces.
const SOLID_CELL = 0.25;
export const SOLID_SPACING = SOLID_CELL * 0.9;
const V_SPACING = 0.55; // vertical sample spacing
const MERGE = 0.62;     // height gaps smaller than this are closed (always more than V_SPACING)
export class SolidGrid {
  // open-addressing hash of cells; each cell keeps its first height interval inline, extra ones (stacked
  // things: a stair above a stair) go to a small side map
  constructor(bits = 19) {
    this.alloc(bits);
    this.more = new Map(); // slot -> [y0, y1, y0, y1, ...]
    this.cells = 0;
  }
  alloc(bits) {
    this.bits = bits;
    this.cap = 1 << bits;
    this.mask = this.cap - 1;
    this.keys = new Int32Array(this.cap).fill(-1);
    this.lo = new Float32Array(this.cap);
    this.hi = new Float32Array(this.cap);
  }
  slot(k) {
    let h = Math.imul(k, 0x9E3779B1) >>> (32 - this.bits);
    const keys = this.keys, mask = this.mask;
    while (keys[h] !== -1 && keys[h] !== k) h = (h + 1) & mask;
    return h;
  }
  grow() {
    const { keys, lo, hi, more } = this;
    const old = this.cap;
    this.alloc(this.bits + 1);
    this.more = new Map();
    for (let i = 0; i < old; i++) {
      if (keys[i] === -1) continue;
      const h = this.slot(keys[i]);
      this.keys[h] = keys[i]; this.lo[h] = lo[i]; this.hi[h] = hi[i];
      const m = more.get(i);
      if (m) this.more.set(h, m);
    }
  }
  addY(x, y, z) {
    const k = (Math.floor(x / SOLID_CELL) + 8192) * 16384 + (Math.floor(z / SOLID_CELL) + 8192);
    const h = this.slot(k);
    if (this.keys[h] === -1) {
      this.keys[h] = k; this.lo[h] = y; this.hi[h] = y;
      if (++this.cells > this.cap * 0.6) this.grow();
      return;
    }
    const a = this.lo[h], b = this.hi[h];
    if (y >= a - MERGE && y <= b + MERGE) {
      if (y < a) this.lo[h] = y;
      else if (y > b) this.hi[h] = y;
      return;
    }
    let l = this.more.get(h);
    if (!l) { this.more.set(h, [y, y]); return; }
    for (let i = 0; i < l.length; i += 2) {
      if (y >= l[i] - MERGE && y <= l[i + 1] + MERGE) {
        if (y < l[i]) l[i] = y;
        if (y > l[i + 1]) l[i + 1] = y;
        return;
      }
    }
    l.push(y, y);
  }
  // world-space triangle; only steep ones count
  addTriangle(ax, ay, az, bx, by, bz, cx, cy, cz) {
    const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (nl < 1e-9 || Math.abs(ny) / nl > 0.8) return;
    // dense horizontally (no holes between cells), coarse vertically (intervals merge across small gaps)
    const eh = Math.max(Math.sqrt(ux * ux + uz * uz), Math.sqrt(vx * vx + vz * vz), Math.hypot(cx - bx, cz - bz));
    const ev = Math.max(Math.abs(uy), Math.abs(vy), Math.abs(cy - by));
    const k = Math.min(64, Math.max(1, Math.ceil(Math.max(eh / SOLID_SPACING, ev / V_SPACING))));
    for (let i = 0; i <= k; i++) {
      for (let j = 0; j <= k - i; j++) {
        const u = i / k, v = j / k, w = 1 - u - v;
        this.addY(ax * w + bx * u + cx * v, ay * w + by * u + cy * v, az * w + bz * u + cz * v);
      }
    }
  }
  // points on the steep triangles of a mesh (local space), spaced for the grid; reused for every instance
  static samples(p, idx, spacing, maxR = Infinity, maxY = Infinity) {
    let out = new Float32Array(4096), n = 0;
    const r2 = maxR * maxR;
    for (let t = 0; t < idx.length; t += 3) {
      const a = idx[t] * 3, b = idx[t + 1] * 3, c = idx[t + 2] * 3;
      if (p[a + 1] > maxY && p[b + 1] > maxY && p[c + 1] > maxY) continue;
      const ax = p[a], ay = p[a + 1], az = p[a + 2];
      const ux = p[b] - ax, uy = p[b + 1] - ay, uz = p[b + 2] - az, vx = p[c] - ax, vy = p[c + 1] - ay, vz = p[c + 2] - az;
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
      if (nl < 1e-12 || Math.abs(ny) / nl > 0.8) continue;
      const eh = Math.max(Math.sqrt(ux * ux + uz * uz), Math.sqrt(vx * vx + vz * vz), Math.hypot(p[c] - p[b], p[c + 2] - p[b + 2]));
      const ev = Math.max(Math.abs(uy), Math.abs(vy), Math.abs(p[c + 1] - p[b + 1]));
      const k = Math.min(64, Math.max(1, Math.ceil(Math.max(eh / spacing, ev / (V_SPACING * spacing / SOLID_SPACING)))));
      for (let i = 0; i <= k; i++) {
        for (let j = 0; j <= k - i; j++) {
          const u = i / k, v = j / k;
          const x = ax + ux * u + vx * v, z = az + uz * u + vz * v, y = ay + uy * u + vy * v;
          if (x * x + z * z > r2 || y > maxY) continue;
          if (n + 3 > out.length) { const o2 = new Float32Array(out.length * 2); o2.set(out); out = o2; }
          out[n++] = x; out[n++] = y; out[n++] = z;
        }
      }
    }
    return out.subarray(0, n);
  }
  // a model's steep geometry as vertical columns: [x, z, y0, y1, ...] in local space, one per small local cell
  // (many samples collapse into a few columns, so placing thousands of instances is cheap)
  static columns(p, idx, spacing, maxR = Infinity, maxY = Infinity) {
    const pts = SolidGrid.samples(p, idx, spacing, maxR, maxY);
    const cols = new Map();
    for (let i = 0; i < pts.length; i += 3) {
      const cx = Math.floor(pts[i] / spacing), cz = Math.floor(pts[i + 2] / spacing), y = pts[i + 1];
      const k = cx * 65536 + cz;
      let l = cols.get(k);
      if (!l) { cols.set(k, [y, y]); continue; }
      let done = false;
      for (let j = 0; j < l.length; j += 2) {
        if (y >= l[j] - MERGE && y <= l[j + 1] + MERGE) { l[j] = Math.min(l[j], y); l[j + 1] = Math.max(l[j + 1], y); done = true; break; }
      }
      if (!done) l.push(y, y);
    }
    const out = [];
    for (const [k, l] of cols) {
      const cz = ((k % 65536) + 65536 + 32768) % 65536 - 32768, cx = (k - cz) / 65536;
      for (let j = 0; j < l.length; j += 2) out.push((cx + 0.5) * spacing, (cz + 0.5) * spacing, l[j], l[j + 1]);
    }
    return new Float32Array(out);
  }
  addColumns(cols, w, yMax = Infinity) {
    for (let i = 0; i < cols.length; i += 4) {
      const x = cols[i], z = cols[i + 1], a = cols[i + 2], b = cols[i + 3];
      const base = w[1] * x + w[9] * z + w[13];
      let y0 = base + w[5] * a, y1 = base + w[5] * b;
      if (y0 > y1) { const t = y0; y0 = y1; y1 = t; }
      if (y0 > yMax) continue;
      const my = (a + b) / 2;
      this.addRange(w[0] * x + w[4] * my + w[8] * z + w[12], w[2] * x + w[6] * my + w[10] * z + w[14], y0, Math.min(y1, yMax + 1));
    }
  }
  addRange(x, z, y0, y1) {
    const k = (Math.floor(x / SOLID_CELL) + 8192) * 16384 + (Math.floor(z / SOLID_CELL) + 8192);
    const h = this.slot(k);
    if (this.keys[h] === -1) {
      this.keys[h] = k; this.lo[h] = y0; this.hi[h] = y1;
      if (++this.cells > this.cap * 0.6) this.grow();
      return;
    }
    const a = this.lo[h], b = this.hi[h];
    if (y1 >= a - MERGE && y0 <= b + MERGE) {
      if (y0 < a) this.lo[h] = y0;
      if (y1 > b) this.hi[h] = y1;
      return;
    }
    let l = this.more.get(h);
    if (!l) { this.more.set(h, [y0, y1]); return; }
    for (let i = 0; i < l.length; i += 2) {
      if (y1 >= l[i] - MERGE && y0 <= l[i + 1] + MERGE) {
        if (y0 < l[i]) l[i] = y0;
        if (y1 > l[i + 1]) l[i + 1] = y1;
        return;
      }
    }
    l.push(y0, y1);
  }
  // add precomputed local sample points through a world matrix (skipping points above yMax)
  addSamples(pts, w, yMax = Infinity) {
    for (let i = 0; i < pts.length; i += 3) {
      const x = pts[i], y = pts[i + 1], z = pts[i + 2];
      const wy = w[1] * x + w[5] * y + w[9] * z + w[13];
      if (wy > yMax) continue;
      this.addY(w[0] * x + w[4] * y + w[8] * z + w[12], wy, w[2] * x + w[6] * y + w[10] * z + w[14]);
    }
  }
  pack() {
    // merge side intervals that grew into each other (or into the inline one); pad everything a little
    for (const [h, l] of this.more) {
      const pairs = [[this.lo[h], this.hi[h]]];
      for (let i = 0; i < l.length; i += 2) pairs.push([l[i], l[i + 1]]);
      pairs.sort((a, b) => a[0] - b[0]);
      const out = [pairs[0]];
      for (let i = 1; i < pairs.length; i++) {
        const o = out[out.length - 1];
        if (pairs[i][0] <= o[1] + MERGE) o[1] = Math.max(o[1], pairs[i][1]);
        else out.push(pairs[i]);
      }
      this.lo[h] = out[0][0]; this.hi[h] = out[0][1];
      l.length = 0;
      for (let i = 1; i < out.length; i++) l.push(out[i][0] - 0.05, out[i][1] + 0.05);
      if (!l.length) this.more.delete(h);
    }
    for (let i = 0; i < this.cap; i++) if (this.keys[i] !== -1) { this.lo[i] -= 0.05; this.hi[i] += 0.05; }
  }
  // is anything solid in the cell of (x,z) between heights y0 and y1?
  hit(x, z, y0, y1) {
    const k = (Math.floor(x / SOLID_CELL) + 8192) * 16384 + (Math.floor(z / SOLID_CELL) + 8192);
    const h = this.slot(k);
    if (this.keys[h] === -1) return false;
    if (this.lo[h] < y1 && this.hi[h] > y0) return true;
    const l = this.more.get(h);
    if (l) for (let i = 0; i < l.length; i += 2) if (l[i] < y1 && l[i + 1] > y0) return true;
    return false;
  }
  // a body (feet y, radius r, height h) touching something it can't step over?
  body(x, z, y, r, h, stepUp) {
    // from just above what can be stepped over to shoulder height (heads duck under ledges)
    const y0 = y + stepUp + 0.02, y1 = y + h - 0.2;
    return this.hit(x, z, y0, y1) || this.hit(x + r, z, y0, y1) || this.hit(x - r, z, y0, y1) || this.hit(x, z + r, y0, y1) || this.hit(x, z - r, y0, y1);
  }
}

export class Physics {
  constructor(terrain, opts = {}) {
    this.terrain = terrain;
    this.colliders = new Grid();
    this.surfaces = new Grid();
    this.allColliders = [];
    this.allSurfaces = [];
    this.boundary = opts.boundary || null; // fn(x,z) -> [x,z]
    this.solid = null; // SolidGrid, built after the world is assembled
    this.movers = [];  // surfaces that travel (the turtle's shell): not in the grid, checked every query
  }
  addMover(s) {
    s.yaw = s.yaw || 0;
    s.mover = true;
    if (s.bottom === undefined) s.bottom = -Infinity;
    this.movers.push(s);
    return s;
  }

  // ------------------------------------------------------------ building
  addCircle(x, z, r, o = {}) {
    const c = { type: 'circle', x, z, r, yMin: o.yMin ?? -Infinity, yMax: o.yMax ?? Infinity, tag: o.tag };
    this.colliders.insert(c, x - r, z - r, x + r, z + r);
    this.allColliders.push(c);
    return c;
  }
  addSeg(ax, az, bx, bz, r, o = {}) {
    const c = { type: 'seg', ax, az, bx, bz, r, yMin: o.yMin ?? -Infinity, yMax: o.yMax ?? Infinity, tag: o.tag };
    this.colliders.insert(c, Math.min(ax, bx) - r, Math.min(az, bz) - r, Math.max(ax, bx) + r, Math.max(az, bz) + r);
    this.allColliders.push(c);
    return c;
  }
  addSurface(s) {
    s.yaw = s.yaw || 0;
    let ext;
    if (s.type === 'disc' || s.type === 'fn') ext = s.r;
    else ext = Math.hypot(s.hx, s.hz);
    if (s.type === 'ramp') s.top = Math.max(s.y0, s.y1);
    if (s.bottom === undefined) s.bottom = -Infinity;
    s.ext = ext;
    this.surfaces.insert(s, s.x - ext - 1, s.z - ext - 1, s.x + ext + 1, s.z + ext + 1);
    this.allSurfaces.push(s);
    return s;
  }

  // ------------------------------------------------------------ queries
  // top of a surface at world x,z (or null outside its footprint). pad grows the footprint.
  topAt(s, x, z, pad = 0) {
    if (s.type === 'disc') {
      const d = Math.hypot(x - s.x, z - s.z);
      if (d > s.r + pad) return null;
      const t = Math.min(1, d / s.r);
      return s.top - (s.dome || 0) * t * t;
    }
    const [lx, lz] = toLocal(s, x, z);
    if (s.type === 'fn') {
      if (Math.hypot(lx, lz) > s.r + pad) return null;
      return s.topFn(lx, lz, pad);
    }
    if (Math.abs(lx) > s.hx + pad || Math.abs(lz) > s.hz + pad) return null;
    if (s.type === 'ramp') {
      const t = Math.max(0, Math.min(1, (lz + s.hz) / (2 * s.hz)));
      return s.y0 + (s.y1 - s.y0) * t;
    }
    return s.top;
  }

  // highest walkable height at (x,z) for feet at y
  ground(x, z, y = Infinity, stepUp = 0.6) {
    let g = this.terrain.heightAt(x, z);
    let hit = null;
    const list = this.surfaces.query(x, z);
    for (let i = 0, n = list.length + this.movers.length; i < n; i++) {
      const s = i < list.length ? list[i] : this.movers[i - list.length];
      if (s.disabled) continue;
      const t = this.topAt(s, x, z);
      if (t === null) continue;
      if (t > g && t <= y + stepUp) {
        g = t;
        hit = s;
      }
    }
    this.lastGroundSurface = hit;
    return g;
  }

  // would a body (radius r, feet y, height h) overlap a surface volume it can't step onto?
  // (fromX, fromZ): where the body is now. If that spot is already inside solid geometry (an old save, a
  // teleport) the solid grid doesn't hold it, so it can always walk out.
  blocked(x, z, y, r = 0.3, h = 1.2, stepUp = 0.6, fromX = null, fromZ = null) {
    if (this.solid) {
      // judge the body where its feet will be (stepping up onto a stair raises the body with it)
      const keep = this.lastGroundSurface;
      const feet = Math.max(y, this.ground(x, z, y, stepUp));
      this.lastGroundSurface = keep;
      if (this.solid.body(x, z, feet, r, h, stepUp) && !(fromX !== null && this.solid.body(fromX, fromZ, y, r, h, stepUp))) return true;
    }
    const list = this.surfaces.query(x, z);
    for (let i = 0, n = list.length + this.movers.length; i < n; i++) {
      const s = i < list.length ? list[i] : this.movers[i - list.length];
      if (s.disabled || s.bottom >= y + h) continue; // we pass underneath
      // already overlapping it where we stand (slid under an overhang, an old save...): let the body walk out
      if (this.surfaceHits(s, x, z, y, r, stepUp, h) && !(fromX !== null && this.surfaceHits(s, fromX, fromZ, y, r, stepUp, h))) return true;
    }
    return false;
  }
  // does a surface volume rise above the step height anywhere under a body (centre and four rim points)?
  // (v9.1d) a surface with a real underside (bottomFn, e.g. a mushroom cap) only blocks where that underside
  // comes down lower than the head - under the middle of a big cap there is room to walk
  surfaceHits(s, x, z, y, r, stepUp, h = 1.2) {
    for (let k = 0; k < 5; k++) {
      const px = k === 1 ? x + r : k === 2 ? x - r : x, pz = k === 3 ? z + r : k === 4 ? z - r : z;
      const t = this.topAt(s, px, pz);
      if (t !== null && t > y + stepUp && (!s.bottomFn || this.bottomAt(s, px, pz) < y + h)) return true;
    }
    return false;
  }
  // the underside of a surface at (x, z): its own profile if it has one, else the flat bottom
  bottomAt(s, x, z) {
    if (s.bottomFn) {
      const [lx, lz] = toLocal(s, x, z);
      const b = s.bottomFn(lx, lz);
      if (b !== null && b !== undefined) return b;
    }
    return s.bottom;
  }

  // lowest underside of a surface above a head at height y (null if open sky)
  ceiling(x, z, y) {
    let best = null;
    const list = this.surfaces.query(x, z);
    for (let i = 0, n = list.length + this.movers.length; i < n; i++) {
      const s = i < list.length ? list[i] : this.movers[i - list.length];
      if (s.disabled || !Number.isFinite(s.bottom)) continue;
      const b = s.bottomFn ? this.bottomAt(s, x, z) : s.bottom;
      if (b < y - 0.05) continue;
      if (this.topAt(s, x, z) === null) continue;
      if (best === null || b < best) best = b;
    }
    return best;
  }

  // push a body out of colliders; returns [x, z]
  resolve(x, z, r, y = 0, h = 1.2) {
    for (let iter = 0; iter < 2; iter++) {
      const list = this.colliders.query(x, z);
      for (let i = 0; i < list.length; i++) {
        const c = list[i];
        if (y > c.yMax || y + h < c.yMin) continue;
        if (c.type === 'circle') {
          const dx = x - c.x, dz = z - c.z;
          const d = Math.hypot(dx, dz);
          const m = c.r + r;
          if (d < m) {
            if (d < 1e-5) { x += m; continue; }
            x = c.x + (dx / d) * m;
            z = c.z + (dz / d) * m;
          }
        } else {
          const vx = c.bx - c.ax, vz = c.bz - c.az;
          const l2 = vx * vx + vz * vz || 1;
          let t = ((x - c.ax) * vx + (z - c.az) * vz) / l2;
          t = t < 0 ? 0 : t > 1 ? 1 : t;
          const px = c.ax + vx * t, pz = c.az + vz * t;
          const dx = x - px, dz = z - pz;
          const d = Math.hypot(dx, dz);
          const m = c.r + r;
          if (d < m && d > 1e-5) {
            x = px + (dx / d) * m;
            z = pz + (dz / d) * m;
          }
        }
      }
    }
    if (this.boundary) [x, z] = this.boundary(x, z);
    return [x, z];
  }

  // camera helper: is the point inside something solid?
  // is this point inside something (for the camera)? pad: how close it may get to things
  pointSolid(x, y, z, pad = 0.15) {
    if (y < this.terrain.heightAt(x, z) + Math.min(0.1, pad)) return true;
    if (this.solid && this.solid.hit(x, z, y - pad * 1.2, y + pad * 1.2)) return true;
    const cl = this.colliders.query(x, z);
    for (let i = 0; i < cl.length; i++) {
      const c = cl[i];
      if (c.type !== 'circle' || c.r < 0.35) continue;
      if (y < c.yMin || y > c.yMax) continue;
      if (Math.hypot(x - c.x, z - c.z) < c.r + pad) return true;
    }
    const sl = this.surfaces.query(x, z);
    for (let i = 0; i < sl.length; i++) {
      const s = sl[i];
      if (s.noCamera || s.disabled) continue;
      const t = this.topAt(s, x, z, pad);
      if (t !== null && y < t + pad && y > (s.bottomFn ? this.bottomAt(s, x, z) : s.bottom) - pad) return true;
    }
    return false;
  }
}
