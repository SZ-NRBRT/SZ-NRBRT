// Biome-driven vegetation and the small wonders hidden in the wild.
// Everything numerous is instanced: one batch per model, culled and LOD-selected per instance (engine/batch.js).
import { Geometry } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Node } from '../engine/scene.js';
import { InstanceBatch } from '../engine/batch.js';
import { capProfile, capSurface } from './capsurf.js';
import { RNG, mat4, quat, TAU, smoothstep, lerp } from '../engine/math.js';
import { noise } from '../engine/noise.js';
import { C } from '../models/materials.js';
import * as flora from '../models/flora.js';
import * as Wd from '../models/wonders.js';
import { addShard, bouncePad, sparkles } from './sites.js';
import { particleSystem, jellyfish } from './fx.js';
import { heightGrid, sampleGrid } from './hull.js';

// how far from each site center big vegetation keeps away
const CLEAR = {
  glade: 24, village: 30, castle: 30, lake: 0, pyramid: 32, mushroom: 17, islands: 18, crystal: 14, swamp: 22,
  giant: 40, crater: 38, rune: 24, amanita: 10, moongarden: 26, watcher: 28, tower: 30, ruins: 28,
};

export function scatterVegetation(W) {
  const L = W.L, T = W.terrain, M = W.M, occ = W.occ, P = W.physics;
  const rng = new RNG(L.seed * 31 + 7);
  const qMul = [0.5, 0.78, 1.0][W.quality] ?? 0.78;
  const biome = (x, z) => L.biome(x, z);
  const inside = (x, z, m = 0) => Math.hypot(x, z) < L.borderAt(x, z) - m;
  const pathD = (x, z) => T.sample(T.pathDist, x, z);
  const wet = (x, z) => W.waterDepth(x, z) > -0.35;
  const slope = (x, z) => T.normalAt(x, z)[1];
  // (v8) seat a tree on the lowest ground under its root flare, so on a slope or a river bank no root hangs
  // in the air (the uphill roots simply disappear into the ground)
  const seat = (x, z, R) => {
    let m = T.heightAt(x, z);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      m = Math.min(m, T.heightAt(x + Math.cos(a) * R * 0.55, z + Math.sin(a) * R * 0.55), T.heightAt(x + Math.cos(a) * R, z + Math.sin(a) * R) + 0.35);
    }
    return m;
  };
  const hand = L.sites.castle;
  const siteClear = (x, z, mul = 1) => {
    for (const id in L.sites) {
      const s = L.sites[id];
      const c = (CLEAR[id] ?? s.r * 0.6) * mul;
      if (c > 0 && Math.hypot(x - s.x, z - s.z) < c) return false;
    }
    if (Math.hypot(x - hand.handX, z - hand.handZ) < 40 * mul) return false;
    return true;
  };
  const darts = (count, tries, test) => {
    const out = [];
    for (let i = 0; i < tries && out.length < count; i++) {
      const x = rng.range(-296, 296), z = rng.range(-296, 296);
      const r = test(x, z, rng);
      if (r) out.push(r);
    }
    return out;
  };
  const forestN = (x, z) => L.noise.fbm2(x * 0.011 + 13, z * 0.011 - 3, 3);
  W.curiosities = [];
  W.bigRocks = [];

  // ================================================================ giant blue mushrooms
  {
    const gmOpts = (v, lod) => ({ capRatio: [0.55, 0.5, 0.62][v], bend: [0.12, 0.2, 0.06][v], stemR: [0.075, 0.07, 0.08][v], variant: v, lod });
    const variants = [0, 1, 2].map((v) => flora.giantMushroom(100 + v, gmOpts(v, 0)));
    const lods = [0, 1, 2].map((v) => flora.giantMushroom(100 + v, gmOpts(v, 1)));
    const place = [[], [], []];
    let lights = 8;
    const list = darts(Math.round(80 * qMul) + 14, 12000, (x, z, r) => {
      const b = biome(x, z);
      const wild = b.mushroom < 0.2;
      if (wild && r.next() > 0.03) return null;
      if (!inside(x, z, 12) || wet(x, z) || !siteClear(x, z)) return null;
      const pd = pathD(x, z);
      if (pd < 4.5 || slope(x, z) < 0.8) return null;
      const s = wild ? r.range(5, 11) : r.range(7, 23) * (pd < 10 ? 0.75 : 1);
      const rad = s * 0.12 + 1.5;
      if (!occ.free(x, z, rad)) return null;
      occ.add(x, z, rad);
      return { x, z, s };
    });
    const profiles = variants.map((gv) => capProfile(gv.cap));
    for (const g of list) {
      const v = rng.int(0, 2);
      const gv = variants[v];
      const y = seat(g.x, g.z, g.s * 0.11) - 0.3;
      const yaw = rng.range(0, TAU);
      place[v].push({ x: g.x, y, z: g.z, yaw, scale: g.s });
      const under = y + g.s * (gv.capY - 0.06 * gv.R);
      P.addCircle(g.x, g.z, g.s * 0.085, { yMax: under - 0.2 });
      // the cap is a real platform, shaped exactly like the drawn one
      P.addSurface(capSurface(profiles[v], g.x, y, g.z, yaw, g.s));
      if (g.s > 14 && lights-- > 0) W.light([g.x, y + g.s * 0.72, g.z], C('#58c8ff'), 2.2, g.s * 0.9);
      if (g.s < 12 && rng.chance(0.25)) {
        const a = rng.range(0, TAU), d = g.s * gv.R + 1.6;
        const bx = g.x + Math.cos(a) * d, bz = g.z + Math.sin(a) * d;
        if (!wet(bx, bz) && occ.free(bx, bz, 1.2)) bouncePad(W, bx, bz);
      }
    }
    variants.forEach((gv, i) => inst(W, [{ geo: gv.stem, lod: lods[i].stem, mat: M.stem }, { geo: gv.cap, lod: lods[i].cap, mat: M.giantCap }], place[i], { maxDistance: 230, shadowDistance: 80, chunk: 130, lodDist: 75 }));
  }

  // ================================================================ fly agarics: bouncy giants in the grove, little ones everywhere
  {
    const variants = [0, 1].map((v) => flora.amanita(200 + v, { capRatio: [0.45, 0.52, 0.4][v], open: [0.4, 0.8, 0.2][v] }));
    const lods = [0, 1].map((v) => flora.amanita(200 + v, { capRatio: [0.45, 0.52, 0.4][v], open: [0.4, 0.8, 0.2][v], lod: 1 }));
    const place = [[], []];
    const grove = darts(Math.round(80 * qMul) + 10, 9000, (x, z, r) => {
      const b = biome(x, z);
      if (b.amanita < 0.15 || wet(x, z) || !inside(x, z, 10)) return null;
      const pd = pathD(x, z);
      if (pd < 2.2) return null;
      const big = r.chance(0.28) && pd > 5;
      const s = big ? r.range(2.5, 5.5) : r.range(0.4, 1.6);
      const rad = s * 0.25 + 0.2;
      if (!occ.free(x, z, rad)) return null;
      occ.add(x, z, rad);
      return { x, z, s };
    });
    const small = darts(Math.round(140 * qMul), 9000, (x, z, r) => {
      if (!inside(x, z, 10) || wet(x, z) || pathD(x, z) < 2.5 || slope(x, z) < 0.8) return null;
      const b = biome(x, z);
      if (b.desert > 0.3 || b.crystal > 0.5) return null;
      if (!occ.free(x, z, 0.4)) return null;
      occ.add(x, z, 0.4);
      return { x, z, s: r.range(0.3, 1.1) };
    });
    const aprof = variants.map((av) => capProfile(av.cap));
    for (const a of grove.concat(small)) {
      const v = rng.int(0, 1);
      const y = T.heightAt(a.x, a.z) - 0.05;
      const yaw = rng.range(0, TAU);
      place[v].push({ x: a.x, y, z: a.z, yaw, scale: a.s, tiltX: a.s > 2 ? 0 : rng.range(-0.1, 0.1), tiltZ: a.s > 2 ? 0 : rng.range(-0.1, 0.1) });
      if (a.s > 2) {
        P.addCircle(a.x, a.z, a.s * 0.09, { yMax: y + a.s * 0.78 });
        P.addSurface(capSurface(aprof[v], a.x, y, a.z, yaw, a.s, { bounce: 12.5, tag: 'bounce' }));
      }
    }
    variants.forEach((av, i) => inst(W, [{ geo: av.stem, lod: lods[i].stem, mat: M.stem }, { geo: av.cap, lod: lods[i].cap, mat: M.amanitaCap }], place[i], { maxDistance: 130, shadowDistance: 45, chunk: 80, lodDist: 40 }));
  }

  // ================================================================ trees: forests in noisy patches, dead woods, swamp giants
  {
    const tOpts = (v, lod) => ({ height: 10 + v * 1.8, spread: 0.9 + v * 0.2, lod });
    const tv = [0, 1, 2].map((v) => flora.gnarledTree(300 + v * 7, tOpts(v, 0)));
    const tl = [0, 1, 2].map((v) => flora.gnarledTree(300 + v * 7, tOpts(v, 1)));
    const dv = [0, 1].map((v) => flora.gnarledTree(400 + v * 5, { height: 8 + v * 2, dead: true, spread: 1.2 }));
    const dl = [0, 1].map((v) => flora.gnarledTree(400 + v * 5, { height: 8 + v * 2, dead: true, spread: 1.2, lod: 1 }));
    // glowing blossom trees (moon garden, glade, village) and dark pines (the north)
    const bOpts = (v, lod) => ({ height: 8 + v * 1.6, spread: 1.35, lod, leafA: ['#e0a0d8', '#c8b4ff'][v], leafB: ['#b890f0', '#f0c8e8'][v], glow: 0.22, cardScale: 1.15 });
    const bv = [0, 1].map((v) => flora.gnarledTree(700 + v * 11, bOpts(v, 0)));
    const bl = [0, 1].map((v) => flora.gnarledTree(700 + v * 11, bOpts(v, 1)));
    const pv = [0, 1].map((v) => flora.pine(640 + v, { height: 11 + v * 3 }));
    const treePlace = [[], [], []], deadPlace = [[], []], blossomPlace = [[], []], pinePlace = [[], []];
    const trees = darts(Math.round(1350 * qMul), 80000, (x, z, r) => {
      if (!inside(x, z, 14) || wet(x, z) || slope(x, z) < 0.78) return null;
      if (pathD(x, z) < 6.5) return null;
      if (!siteClear(x, z)) return null;
      const b = biome(x, z);
      if (b.desert > 0.25 || b.crystal > 0.4 || b.islands > 0.6) return null;
      let dens = smoothstep(-0.12, 0.38, forestN(x, z)) * 0.85 + 0.04;
      dens *= 1 - smoothstep(0.1, 0.6, b.mushroom);
      dens *= 1 - b.amanita * 0.6;
      dens *= 1 - b.meadow * 0.7;
      dens = Math.max(dens, b.dead * 0.35, b.pines * 0.75, b.blossom * 0.3);
      if (r.next() > dens) return null;
      const s = r.range(0.8, 1.35);
      if (!occ.free(x, z, 2.6 * s)) return null;
      occ.add(x, z, 2.6 * s);
      const kind = r.next() < b.dead * 0.85 + 0.03 ? 'dead' : r.next() < b.blossom * 0.9 ? 'blossom' : r.next() < b.pines * 0.9 ? 'pine' : 'tree';
      return { x, z, s, kind };
    });
    for (const t of trees) {
      const place = { x: t.x, y: seat(t.x, t.z, (t.kind === 'pine' ? 0.8 : 1.9) * t.s) - 0.1, z: t.z, yaw: rng.range(0, TAU), scale: t.s, tint: [rng.range(0.85, 1.1), 1, rng.range(0.9, 1.15), 1] };
      if (t.kind === 'dead') deadPlace[rng.int(0, 1)].push(place);
      else if (t.kind === 'blossom') blossomPlace[rng.int(0, 1)].push({ ...place, tint: [1, 1, 1, 1] });
      else if (t.kind === 'pine') pinePlace[rng.int(0, 1)].push({ ...place, y: place.y - 0.1, scale: t.s * 1.1 });
      else treePlace[rng.int(0, 2)].push(place);
      P.addCircle(t.x, t.z, (t.kind === 'pine' ? 0.4 : 0.55) * t.s, { yMax: place.y + 9 * t.s });
    }
    bv.forEach((v, i) => inst(W, [{ geo: v.wood, lod: bl[i].wood, mat: M.bark }, { geo: v.leaves, lod: bl[i].leaves, shadowNear: true, mat: M.leaves }], blossomPlace[i], { maxDistance: 210, shadowDistance: 55, chunk: 120, lodDist: 65 }));
    pv.forEach((v, i) => inst(W, [{ geo: v, mat: M.bark, solidR: 0.55 }], pinePlace[i], { maxDistance: 260, shadowDistance: 45, chunk: 130 }));
    W.blossomSpots = blossomPlace.flat();
    // petals drifting down from the blossom trees, one system per grove
    const groves = [];
    for (const b of W.blossomSpots) {
      let g = groves.find((q) => Math.hypot(q.x - b.x, q.z - b.z) < 60);
      if (!g) groves.push((g = { x: b.x, z: b.z, list: [] }));
      g.list.push(b);
    }
    groves.forEach((g, gi) => {
      const n = Math.min(260, g.list.length * 10);
      if (n < 10) return;
      const m = particleSystem(W.gl, Math.round(n * qMul), { PETAL: 1 }, (i, r) => {
        const b = g.list[i % g.list.length];
        const a = r.range(0, TAU), d = r.range(0, 3.2) * b.scale;
        return { p: [b.x + Math.cos(a) * d, b.y + 7.5 * b.scale, b.z + Math.sin(a) * d], params: [7 * b.scale, 0, 0, 0], size: r.range(0.06, 0.11), speed: r.range(0.5, 0.9), spread: r.range(0.3, 0.8), color: C(r.pick(['#ffc8ec', '#e8d0ff', '#ffe0f4'])), intensity: r.range(1.2, 2.2) };
      }, { seed: 600 + gi });
      m.maxDistance = 110;
      W.scene.add(m);
    });
    W.treeSpots = trees;
    tv.forEach((v, i) => inst(W, [{ geo: v.wood, lod: tl[i].wood, mat: M.bark }, { geo: v.leaves, lod: tl[i].leaves, shadowNear: true, mat: M.leaves }], treePlace[i], { maxDistance: 200, shadowDistance: 55, chunk: 120, lodDist: 65 }));
    dv.forEach((v, i) => inst(W, [{ geo: v.wood, lod: dl[i].wood, mat: M.bark }], deadPlace[i], { maxDistance: 200, shadowDistance: 55, chunk: 130, lodDist: 65 }));

    const sv = [0, 1].map((v) => flora.swampTree(500 + v, { height: 15 + v * 4 }));
    const sl = [0, 1].map((v) => flora.swampTree(500 + v, { height: 15 + v * 4, lod: 1 }));
    const swPlace = [[], []];
    const sw = darts(Math.round(60 * qMul) + 10, 12000, (x, z, r) => {
      const b = biome(x, z);
      if (b.swamp < 0.3 || !inside(x, z, 12)) return null;
      if (W.waterDepth(x, z) > 0.6) return null;
      if (pathD(x, z) < 4 || slope(x, z) < 0.72 || !siteClear(x, z, 0.8)) return null;
      if (!occ.free(x, z, 3)) return null;
      occ.add(x, z, 3);
      return { x, z, s: r.range(0.8, 1.2) };
    });
    for (const t of sw) {
      swPlace[rng.int(0, 1)].push({ x: t.x, y: seat(t.x, t.z, 3.4 * t.s) - 0.2, z: t.z, yaw: rng.range(0, TAU), scale: t.s });
      P.addCircle(t.x, t.z, 1.4 * t.s, { yMax: T.heightAt(t.x, t.z) + 12 });
    }
    sv.forEach((v, i) => inst(W, [{ geo: v.wood, lod: sl[i].wood, mat: M.bark, solidR: 4.5 }, { geo: v.leaves, lod: sl[i].leaves, shadowNear: true, mat: M.leaves }, { geo: v.moss, lod: null, mat: M.mossStrands, shadow: false }], swPlace[i], { maxDistance: 200, shadowDistance: 60, chunk: 100, lodDist: 60 }));
  }

  // ================================================================ pines on the mountain rim
  {
    const pv = [0, 1, 2].map((v) => flora.pine(600 + v, { height: 9 + v * 2 }));
    const place = [[], [], []];
    const pines = darts(Math.round(1500 * qMul), 40000, (x, z, r) => {
      const rr = Math.hypot(x, z), b = L.borderAt(x, z);
      if (rr > b + 30 || rr < b - 60) return null;
      if (rr < b - 25 && r.next() > 0.25) return null;
      if (Math.hypot(x - hand.handX, z - hand.handZ) < 42 || Math.hypot(x - hand.x, z - hand.z) < 30) return null;
      if (slope(x, z) < 0.5 || wet(x, z)) return null;
      if (rr < b && pathD(x, z) < 4) return null;
      if (!occ.free(x, z, 1.8)) return null;
      occ.add(x, z, 1.8);
      return { x, z, s: r.range(0.8, 1.7) };
    });
    for (const p of pines) {
      place[rng.int(0, 2)].push({ x: p.x, y: seat(p.x, p.z, 0.8 * p.s) - 0.2, z: p.z, yaw: rng.range(0, TAU), scale: p.s });
      P.addCircle(p.x, p.z, 0.35 * p.s);
    }
    pv.forEach((v, i) => inst(W, [{ geo: v, mat: M.bark, solidR: 0.55 }], place[i], { maxDistance: 320, shadowDistance: 40, chunk: 150 }));
  }

  // ================================================================ palms around the dream desert
  {
    const pv = [0, 1].map((v) => flora.palm(700 + v * 3, { height: 8 + v * 2 }));
    const place = [[], []];
    const palms = darts(Math.round(34 * qMul) + 8, 6000, (x, z, r) => {
      const b = biome(x, z);
      if (b.desert < 0.15 || b.desert > 0.92 || wet(x, z) || !siteClear(x, z)) return null;
      if (pathD(x, z) < 4 || !occ.free(x, z, 2.5)) return null;
      occ.add(x, z, 2.5);
      return { x, z, s: r.range(0.9, 1.3) };
    });
    for (const p of palms) {
      place[rng.int(0, 1)].push({ x: p.x, y: seat(p.x, p.z, 0.6 * p.s) - 0.1, z: p.z, yaw: rng.range(0, TAU), scale: p.s });
      P.addCircle(p.x, p.z, 0.35);
    }
    pv.forEach((v, i) => inst(W, [{ geo: v.trunk, mat: M.bark }, { geo: v.fronds, mat: M.fronds }], place[i], { maxDistance: 190 }));
  }

  // ================================================================ rocks: boulders you can climb, pebbles, rim giants
  {
    const flats = [0.6, 0.85, 0.45];
    const rv = flats.map((f, v) => flora.rock(800 + v, { flat: f }));
    const rl = flats.map((f, v) => flora.rock(800 + v, { flat: f, detail: 2 }));
    const tops = rv.map((g) => g.bounds().max[1]);
    // (v8) the walkable top of each rock shape, taken from the rock itself (a disc was too small or too big)
    const rgrid = rv.map((g) => heightGrid([{ g, m: null }], 0.06));
    const place = [[], [], []], small = [[], [], []];
    const rocks = darts(Math.round(760 * qMul), 30000, (x, z, r) => {
      const rr = Math.hypot(x, z), b = L.borderAt(x, z);
      if (rr > b + 20) return null;
      if (pathD(x, z) < 2.4 || !siteClear(x, z, 0.7)) return null;
      const bi = biome(x, z);
      const rim = rr > b - 30;
      const boulder = r.chance(0.12 + bi.dead * 0.3 + bi.desert * 0.2);
      const s = rim ? r.range(1.5, 5) : boulder ? r.range(1.2, 3.2) : r.range(0.3, 1.2);
      if (!occ.free(x, z, s)) return null;
      occ.add(x, z, s * 0.8);
      return { x, z, s, desert: bi.desert, crystal: bi.crystal };
    });
    for (const k of rocks) {
      const v = rng.int(0, 2);
      const y = T.heightAt(k.x, k.z) - k.s * 0.15;
      const tint = k.desert > 0.4 ? [1.5, 1.25, 1.0, 1] : k.crystal > 0.4 ? [1.05, 0.9, 1.35, 1] : [rng.range(0.85, 1.1), rng.range(0.9, 1.1), rng.range(0.9, 1.2), 1];
      const yaw = rng.range(0, TAU);
      (k.s < 1.1 ? small : place)[v].push({ x: k.x, y, z: k.z, yaw, scale: k.s, tint });
      if (k.s > 0.55) {
        const G = rgrid[v], sc = k.s, y0 = y;
        const top = y + G.top * sc;
        P.addSurface({
          type: 'fn', x: k.x, z: k.z, yaw, r: Math.max(-G.minx, G.maxx, -G.minz, G.maxz) * 1.42 * sc, top, bottom: y - 1,
          topFn: (lx, lz) => { const h = sampleGrid(G, lx / sc, lz / sc); return h === null ? null : y0 + h * sc - 0.02; },
        });
        if (k.s > 1.3) W.bigRocks.push({ x: k.x, z: k.z, top, s: k.s });
      }
    }
    rv.forEach((g, i) => inst(W, [{ geo: g, lod: rl[i], mat: M.stone }], place[i], { maxDistance: 240, shadowDistance: 45, chunk: 120, lodDist: 55 }));
    rl.forEach((g, i) => inst(W, [{ geo: g, mat: M.stone }], small[i], { maxDistance: 110, shadowDistance: 35, chunk: 80 }));
  }

  // ================================================================ crystals
  {
    const cv = [0, 1, 2].map((v) => Wd.crystalCluster(950 + v, 4 + v * 2));
    const cols = ['#9d7bff', '#6fe6ff', '#ff8ad8', '#8fb0ff', '#b9a0ff'];
    const place = [[], [], []];
    const list = darts(Math.round(110 * qMul) + 16, 12000, (x, z, r) => {
      const b = biome(x, z);
      const p = b.crystal > 0.1 ? 0.9 * b.crystal + 0.1 : 0.008;
      if (r.next() > p || wet(x, z) || !inside(x, z, 6)) return null;
      if (pathD(x, z) < 2 || !siteClear(x, z, 0.5)) return null;
      const s = b.crystal > 0.1 ? r.range(0.5, 1.9) : r.range(0.4, 1.0);
      if (!occ.free(x, z, s * 0.6)) return null;
      occ.add(x, z, s * 0.6);
      return { x, z, s };
    });
    for (const c of list) {
      const col = C(rng.pick(cols));
      place[rng.int(0, 2)].push({ x: c.x, y: T.heightAt(c.x, c.z) - 0.15, z: c.z, yaw: rng.range(0, TAU), scale: c.s, tint: [col[0] * 1.6, col[1] * 1.6, col[2] * 1.6, 1], tiltX: rng.range(-0.15, 0.15), tiltZ: rng.range(-0.15, 0.15) });
      if (c.s > 1.1) P.addCircle(c.x, c.z, c.s * 0.4, { yMax: T.heightAt(c.x, c.z) + c.s * 1.6 });
    }
    cv.forEach((g, i) => inst(W, [{ geo: g, mat: M.crystal }], place[i], { maxDistance: 160, shadowDistance: 30 }));
  }

  // ================================================================ fallen logs you can walk along
  {
    const lv = [0, 1].map((v) => flora.log(1300 + v, { length: 6 + v * 2, radius: 0.45 + v * 0.1 }));
    const lens = [6, 8], rads = [0.45, 0.55];
    const place = [[], []];
    const logs = darts(Math.round(46 * qMul) + 8, 8000, (x, z, r) => {
      if (!inside(x, z, 14) || wet(x, z) || slope(x, z) < 0.9) return null;
      if (pathD(x, z) < 5 || !siteClear(x, z)) return null;
      const b = biome(x, z);
      if (b.desert > 0.3 || forestN(x, z) < -0.1) return null;
      if (!occ.free(x, z, 4)) return null;
      occ.add(x, z, 4);
      return { x, z };
    });
    for (const g of logs) {
      const v = rng.int(0, 1), yaw = rng.range(0, TAU);
      const y = T.heightAt(g.x, g.z) - rads[v] * 0.45;
      place[v].push({ x: g.x, y, z: g.z, yaw, scale: 1 });
      // log runs along its local x axis
      P.addSurface({ type: 'box', x: g.x, z: g.z, hx: lens[v] / 2, hz: rads[v] * 0.8, yaw, top: y + rads[v] * 1.75, bottom: y - 1 });
    }
    lv.forEach((g, i) => inst(W, [{ geo: g, mat: M.moss }], place[i], { maxDistance: 140, shadowDistance: 40 }));
  }

  // ================================================================ reeds and lily pads around every pond and the lake
  {
    const rv = [0, 1].map((v) => reeds(1400 + v));
    const place = [[], []];
    // along the river banks
    for (const river of L.rivers || []) {
      const pts = river.points;
      for (let i = 1; i < pts.length - 1; i++) {
        const a = pts[i - 1], b = pts[i + 1];
        const dx = b[0] - a[0], dz = b[1] - a[1], dl = Math.hypot(dx, dz) || 1;
        for (let k = 0; k < Math.round(3 * qMul) + 1; k++) {
          const side = rng.sign(), off = river.width / 2 + rng.range(0.2, 2.2);
          const t = rng.range(-0.5, 0.5);
          const x = pts[i][0] + dx * t * 0.5 - (dz / dl) * off * side, z = pts[i][1] + dz * t * 0.5 + (dx / dl) * off * side;
          if (!inside(x, z, 6)) continue;
          const wd = W.waterDepth(x, z);
          if (wd < -0.6 || wd > 0.5 || pathD(x, z) < 3 || !occ.free(x, z, 0.4)) continue;
          occ.add(x, z, 0.4);
          place[rng.int(0, 1)].push({ x, y: Math.max(T.heightAt(x, z), L.waterLevel - 0.5) - 0.1, z, yaw: rng.range(0, TAU), scale: rng.range(0.7, 1.2) });
        }
      }
      W.fireflies(pts[Math.floor(pts.length * 0.55)], 40, Math.round(50 * qMul), C('#8affe0'), { h: 1.2, seed: 880 + pts.length });
    }
    for (const lk of L.lakes) {
      const n = Math.round((lk.r * 2.2 + 10) * qMul);
      for (let i = 0; i < n * 3 && place[0].length + place[1].length < 9999; i++) {
        const a = rng.range(0, TAU), d = lk.r * rng.range(0.75, 1.15);
        const x = lk.x + Math.cos(a) * d, z = lk.z + Math.sin(a) * d;
        const wd = W.waterDepth(x, z);
        if (wd < -0.3 || wd > 0.7) continue;
        if (pathD(x, z) < 2 || !occ.free(x, z, 0.5)) continue;
        occ.add(x, z, 0.5);
        place[rng.int(0, 1)].push({ x, y: Math.max(T.heightAt(x, z), L.waterLevel - 0.6) - 0.1, z, yaw: rng.range(0, TAU), scale: rng.range(0.7, 1.3) });
      }
      if (lk.id.startsWith('pond')) {
        const pads = new Geometry();
        for (let i = 0; i < 16; i++) {
          const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * lk.r * 0.8;
          const x = lk.x + Math.cos(a) * d, z = lk.z + Math.sin(a) * d;
          if (W.waterDepth(x, z) < 0.15) continue;
          const p = Geometry.disc(rng.range(0.3, 0.7), 10);
          p.translate(x, L.waterLevel + 0.03, z);
          p.setColor(C(rng.pick(['#1f5a46', '#23604a'])), 1);
          pads.append(p);
          if (rng.chance(0.35)) {
            const bud = Geometry.sphere(0.1, 8, 6);
            bud.translate(x, L.waterLevel + 0.12, z);
            bud.setColor(C(rng.pick(['#ffb8f0', '#b8f0ff'])), 1);
            bud.setExtra([2.2]);
            pads.append(bud);
          }
        }
        if (pads.vertexCount) {
          const m = W.mesh(pads, M.glowSoft, 'pads');
          m.castShadow = false;
          m.maxDistance = 110;
          W.scene.add(m);
        }
        W.fireflies([lk.x, lk.z], lk.r + 4, Math.round(30 * qMul), C('#7affd0'), { h: 1, seed: 300 + Math.round(lk.x) });
      }
    }
    rv.forEach((g, i) => inst(W, [{ geo: g, mat: M.plants, shadow: false }], place[i], { maxDistance: 90, castShadow: false }));
  }

  // ================================================================ curiosities: the small wonders hidden in the wild
  const wild = (r, tries = 400, extra = null) => {
    for (let i = 0; i < tries; i++) {
      const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * 250;
      const x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (!inside(x, z, 26) || wet(x, z) || slope(x, z) < 0.85) continue;
      if (pathD(x, z) < r + 6 || !siteClear(x, z, 1.1)) continue;
      if (W.curiosities.some((c) => Math.hypot(c.x - x, c.z - z) < 45)) continue;
      if (!occ.free(x, z, r)) continue;
      if (extra && !extra(x, z)) continue;
      occ.add(x, z, r);
      return [x, z];
    }
    return null;
  };
  const cur = (kind, name, blurb, x, z, r = 6) => {
    const c = { id: kind + W.curiosities.length, kind, name, blurb, x, z, r };
    W.curiosities.push(c);
    return c;
  };
  const clusterGeo = flora.glowShroomCluster(2024, 4);
  const clusterGpu = W.gpu(clusterGeo);
  // fairy rings
  for (let k = 0; k < 5; k++) {
    const p = wild(4);
    if (!p) break;
    const [x, z] = p;
    const n = 13, R = rng.range(2.3, 3.1);
    const data = [];
    const col = C(rng.pick(['#9fe7ff', '#c8a8ff', '#a8ffcf', '#ffc8f0']));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + rng.range(-0.1, 0.1);
      const px = x + Math.cos(a) * R, pz = z + Math.sin(a) * R;
      data.push({ x: px, y: T.heightAt(px, pz) - 0.02, z: pz, yaw: rng.range(0, TAU), scale: rng.range(1.3, 2.2), tint: [col[0] * 1.3, col[1] * 1.3, col[2] * 1.3, 1.5] });
    }
    inst(W, [{ gpu: clusterGpu, mat: M.glowSoft, shadow: false }], data, { maxDistance: 120, castShadow: false });
    sparkles(W, [x, z], R, 36, ['#e8f4ff', '#bfe0ff'], { h0: 0.2, h1: 2.2, seed: 700 + k, dist: 120, size: [0.05, 0.12] });
    W.light([x, T.heightAt(x, z) + 1.2, z], col, 1.6, 6, 0.05);
    cur('ring', 'Tündérkör', 'Gombák körben — a tündérek itt táncolnak, amikor senki sem látja.', x, z, R + 1);
    addShard(W, x, z, T.heightAt(x, z) + 0.2);
  }
  // sleeping stone heads, half sunk into the ground
  {
    const sh = stoneHead(5);
    const gS = W.gpu(sh.stone), gE = W.gpu(sh.eyes);
    for (let k = 0; k < 3; k++) {
      const p = wild(6);
      if (!p) break;
      const [x, z] = p;
      const s = rng.range(2.6, 3.4);
      const y = T.heightAt(x, z) - s * 0.35;
      const yaw = rng.range(0, TAU);
      const node = new Node('stoneHead');
      node.setPos(x, y, z);
      node.setRotY(yaw);
      node.setScale(s);
      node.add(W.meshG(gS, M.bigStone));
      const eyes = W.meshG(gE, M.glow);
      eyes.castShadow = false;
      node.add(eyes);
      W.scene.add(node);
      const top = y + s * sh.top;
      P.addSurface({ type: 'disc', x, z, r: s * 0.95, top, dome: s * 0.75, bottom: y - 2 });
      // a stepping rock beside it
      const a = yaw + Math.PI * 0.75;
      const rx = x + Math.cos(a) * s * 1.5, rz = z + Math.sin(a) * s * 1.5;
      const rock = W.mesh(flora.rock(1500 + k, { flat: 0.7 }), M.stone, 'stepRock');
      let ry = Infinity;
      for (let k2 = 0; k2 <= 8; k2++) { const aa = (k2 / 8) * TAU, rr = k2 ? 1.1 : 0; ry = Math.min(ry, T.heightAt(rx + Math.cos(aa) * rr, rz + Math.sin(aa) * rr)); }
      ry -= 0.15;
      rock.setPos(rx, ry, rz);
      rock.setScale(1.2);
      W.scene.add(rock);
      P.addSurface({ type: 'disc', x: rx, z: rz, r: 1.0, top: ry + 1.25, dome: 0.4, bottom: ry - 1 });
      W.light(nodePoint(x, y, z, yaw, s, [0, 0.35, 0.95]), C('#9dffb0'), 1.8, 7, 0.05);
      cur('head', 'Alvó kőfej', 'Egy régi király feje. A szeme még világít — talán csak álmodik.', x, z, s + 3);
      addShard(W, x, z, top);
    }
  }
  // floating stones circling a glowing crystal
  for (let k = 0; k < 2; k++) {
    const p = wild(6);
    if (!p) break;
    const [x, z] = p;
    const g0 = T.heightAt(x, z);
    const core = Wd.crystalCluster(1600 + k, 5);
    core.setColor(C('#9fd8ff'), 1);
    const cm = W.mesh(core, M.crystal, 'floatCore');
    cm.setPos(x, g0 + 2.3, z);
    cm.setScale(0.9);
    W.scene.add(cm);
    const stones = [];
    const rg = W.gpu(flora.rock(1700 + k, { flat: 0.8 }));
    for (let i = 0; i < 7; i++) {
      const m = W.meshG(rg, M.stone, 'floatStone');
      const sc = rng.range(0.3, 0.8);
      m.setScale(sc, sc * 0.7, sc);
      W.scene.add(m);
      stones.push({ m, r: rng.range(2.2, 4.2), h: rng.range(1.0, 4.5), sp: rng.range(0.15, 0.4) * rng.sign(), ph: rng.range(0, TAU) });
    }
    W.animated.push((t) => {
      cm.setEuler(0, t * 0.4, 0);
      cm.position[1] = g0 + 2.3 + Math.sin(t * 0.8) * 0.2;
      for (const s of stones) {
        const a = s.ph + t * s.sp;
        s.m.setPos(x + Math.cos(a) * s.r, g0 + s.h + Math.sin(t * 0.7 + s.ph) * 0.3, z + Math.sin(a) * s.r);
        s.m.setEuler(t * s.sp, a, 0);
      }
    });
    W.light([x, g0 + 2.6, z], C('#8fd0ff'), 2.4, 9, 0.05);
    sparkles(W, [x, z], 4, 30, ['#cfe8ff'], { h0: 0.5, h1: 5, seed: 800 + k, dist: 120 });
    cur('float', 'Lebegő kövek', 'A kövek itt elfelejtették, hogyan kell leesni.', x, z, 6);
    addShard(W, x, z, g0 + 1.3);
  }
  // giant bones
  {
    const bg = giantBones(9);
    const gB = W.gpu(bg);
    // (v9.1) the whole skeleton lies on the ground: sample its footprint and pick the flattest spot (and heading) found
    const foot = (x, z, yaw) => {
      const c0 = Math.cos(yaw), s0 = Math.sin(yaw);
      let lo = Infinity, hi = -Infinity;
      for (let lz = -11; lz <= 11; lz += 2) for (let lx = -3; lx <= 3; lx += 1.5) {
        const h = T.heightAt(x + lx * c0 + lz * s0, z - lx * s0 + lz * c0);
        lo = Math.min(lo, h); hi = Math.max(hi, h);
      }
      return [lo, hi];
    };
    for (let k = 0; k < 2; k++) {
      let best = null;
      wild(7, 1800, (x, z) => {
        const b = biome(x, z), pref = b.desert > 0.25 || b.dead > 0.15 ? 0.5 : 0;
        for (let q = 0; q < 4; q++) {
          const yw = rng.range(0, TAU), f = foot(x, z, yw), sc = f[1] - f[0] - pref;
          if (!best || sc < best.sc) best = { x, z, yaw: yw, sc };
        }
        return best.sc < 0.35;
      });
      if (!best) break;
      if (best.sc >= 0.35) occ.add(best.x, best.z, 7);
      const { x, z, yaw } = best;
      const m = W.meshG(gB, M.stoneFine, 'bones');
      const c = Math.cos(yaw), s = Math.sin(yaw);
      const tr = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c];
      const hAt = (lx, lz) => T.heightAt(...tr(lx, lz));
      // the skull and the jaw must rest on the ground; the rib tips reach 1.6 m below the base, so they stay buried
      let ribMin = Infinity;
      for (let i = 0; i < 6; i++) for (const sd of [-1, 1]) ribMin = Math.min(ribMin, hAt(sd * 2.5, -4 + i * 1.6 - 1.1));
      ribMin = Math.min(ribMin, hAt(0.3, -10.8) + 0.1);
      const y = Math.min(ribMin + 1.3, Math.max(foot(x, z, yaw)[0] - 0.12, hAt(0.3, 8.6) - 0.2, hAt(2.1, 8.6) - 0.12, hAt(0.3, 10.8) - 0.1));
      m.setPos(x, y, z);
      m.setRotY(yaw);
      W.scene.add(m);
      for (let i = 0; i < 6; i++) for (const sd of [-1, 1]) {
        const [bx, bz] = tr(sd * 2.5, -4 + i * 1.6 - 1.1);
        P.addCircle(bx, bz, 0.3);
      }
      const [hx, hz] = tr(0.3, 8.6);
      P.addSurface({ type: 'disc', x: hx, z: hz, r: 1.2, top: y + 2.1, dome: 0.9, bottom: y - 1 });
      // the spine can be walked on
      const [sx, sz] = tr(0, 0);
      P.addSurface({ type: 'box', x: sx, z: sz, hx: 0.35, hz: 5.2, yaw, top: y + 3.9, bottom: y + 3.1 });
      cur('bones', 'Óriáscsontok', 'Valami hatalmas feküdt le itt egyszer, és sosem kelt fel.', x, z, 9);
      addShard(W, sx, sz, y + 0.5);
    }
  }
  // lantern trees
  {
    const tree = flora.gnarledTree(1800, { height: 11, dead: true, spread: 1.4 });
    const gT = W.gpu(tree.wood);
    for (let k = 0; k < 3; k++) {
      const p = wild(5);
      if (!p) break;
      const [x, z] = p;
      const y = T.heightAt(x, z) - 0.1;
      const m = W.meshG(gT, M.bark, 'lanternTree');
      (W.lanternTrees = W.lanternTrees || []).push([x, y, z]);
      m.setPos(x, y, z);
      m.setRotY(rng.range(0, TAU));
      W.scene.add(m);
      P.addCircle(x, z, 0.6);
      const rope = new Geometry(), bulbs = new Geometry();
      for (let i = 0; i < 9; i++) {
        const a = rng.range(0, TAU), d = rng.range(1.2, 3.4);
        const lx = x + Math.cos(a) * d, lz = z + Math.sin(a) * d;
        const top = y + rng.range(6.5, 8.5), ly = top - rng.range(1.0, 2.4);
        const r = Geometry.cylinder(0.012, 0.012, top - ly, 3, 1);
        r.translate(lx, ly, lz);
        r.setColor(C('#2a2630'), 1);
        rope.append(r);
        const b = Geometry.sphere(0.16, 8, 6);
        b.scale(1, 1.25, 1);
        b.translate(lx, ly - 0.1, lz);
        b.setColor(C(rng.pick(['#ffb45a', '#ffd27a', '#ff9a50'])), 1);
        b.setExtra([3.2]);
        bulbs.append(b);
      }
      const rm = W.mesh(rope, M.wood, 'ltRope');
      rm.castShadow = false;
      const bm = W.mesh(bulbs, M.glow, 'ltBulbs');
      bm.castShadow = false;
      W.scene.add(rm, bm);
      W.light([x, y + 6.5, z], C('#ffa04a'), 2.6, 12, 0.08);
      cur('ltree', 'Lámpásfa', 'Valaki minden este meggyújtja ezeket a lámpásokat. Még senki sem látta, ki.', x, z, 6);
      addShard(W, x + 1.2, z + 1.2);
    }
  }
  // a couple of wandering sky jellyfish swarms
  for (let k = 0; k < 2; k++) {
    const p = wild(2);
    if (!p) break;
    W.scene.add(jellyfish(W.gl, 8, [p[0], T.heightAt(p[0], p[1]), p[1]], { spread: 30, yBase: 14, height: 16, color: [0.5, 0.75, 1.6], seed: 900 + k }));
  }

  // ================================================================ small stuff: glowing mushroom clusters, ferns, flowers
  {
    const cv = [0, 1].map((v) => flora.glowShroomCluster(900 + v, 3 + v * 3));
    const place = [[], []];
    const palette = [C('#5fe3ff'), C('#c86bff'), C('#6dff9a'), C('#ff6bd0'), C('#8aa2ff'), C('#e8f0ff')];
    const list = darts(Math.round(1100 * qMul), 50000, (x, z, r) => {
      if (!inside(x, z, 8) || wet(x, z)) return null;
      const pd = pathD(x, z);
      if (pd < 1.6) return null;
      const b = biome(x, z);
      let p = 0.08 + b.mushroom * 0.55 + b.swamp * 0.3 + (pd < 6 ? 0.25 : 0) + smoothstep(0.1, 0.4, forestN(x, z)) * 0.15;
      p *= 1 - b.desert * 0.9;
      if (r.next() > p) return null;
      if (!occ.free(x, z, 0.35)) return null;
      occ.add(x, z, 0.3);
      return { x, z };
    });
    for (const c of list) {
      const col = rng.pick(palette);
      place[rng.int(0, 1)].push({ x: c.x, y: T.heightAt(c.x, c.z) - 0.02, z: c.z, yaw: rng.range(0, TAU), scale: rng.range(0.8, 2.0), tint: [col[0], col[1], col[2], rng.range(0.8, 1.4)] });
    }
    cv.forEach((g, i) => inst(W, [{ geo: g, mat: M.glowSoft, shadow: false }], place[i], { maxDistance: 95, castShadow: false }));
  }
  {
    const fv = [0, 1].map((v) => flora.fern(1000 + v));
    const place = [[], []];
    const ferns = darts(Math.round(1800 * qMul), 50000, (x, z, r) => {
      if (!inside(x, z, 10) || wet(x, z)) return null;
      if (pathD(x, z) < 2.5) return null;
      const b = biome(x, z);
      if (b.desert > 0.2 || b.crystal > 0.5) return null;
      const dens = smoothstep(-0.2, 0.4, forestN(x, z)) * 0.8 + b.swamp * 0.4 + b.mushroom * 0.2;
      if (r.next() > dens) return null;
      if (!occ.free(x, z, 0.5)) return null;
      occ.add(x, z, 0.3);
      return { x, z };
    });
    for (const f of ferns) place[rng.int(0, 1)].push({ x: f.x, y: T.heightAt(f.x, f.z) - 0.05, z: f.z, yaw: rng.range(0, TAU), scale: rng.range(0.7, 1.5) });
    fv.forEach((g, i) => inst(W, [{ geo: g, mat: M.plants, shadow: false }], place[i], { maxDistance: 80, castShadow: false }));
  }
  {
    const cols = ['#e0302a', '#f2c43a', '#f5f1ff', '#9fb4ff'];
    const fv = cols.map((c, i) => flora.flower(1100 + i, c));
    const place = cols.map(() => []);
    const list = darts(Math.round(2800 * qMul), 70000, (x, z, r) => {
      if (!inside(x, z, 10) || wet(x, z) || pathD(x, z) < 1.8) return null;
      const b = biome(x, z);
      const patch = smoothstep(0.25, 0.55, L.noise.fbm2(x * 0.03 - 50, z * 0.03 + 9, 2));
      const p = b.meadow * 0.95 + patch * 0.35 * (1 - b.desert) * (1 - b.dead);
      if (r.next() > p) return null;
      return { x, z };
    });
    for (const f of list) place[rng.int(0, cols.length - 1)].push({ x: f.x, y: T.heightAt(f.x, f.z) - 0.02, z: f.z, yaw: rng.range(0, TAU), scale: rng.range(0.8, 1.6) });
    fv.forEach((g, i) => inst(W, [{ geo: g, mat: M.plants, shadow: false }], place[i], { maxDistance: 75, castShadow: false }));
  }

  // ================================================================ extra star shards in the wild (some on top of big rocks)
  {
    let n = 0;
    const far = (x, z, d = 28) => !W.shardSpots.some((s) => Math.hypot(s.x - x, s.z - z) < d);
    for (const r of rng.shuffle ? rng.shuffle(W.bigRocks.slice()) : W.bigRocks.slice()) {
      if (n >= 6) break;
      if (!far(r.x, r.z, 40) || !inside(r.x, r.z, 20)) continue;
      addShard(W, r.x, r.z, r.top);
      n++;
    }
    for (let k = 0; k < 600 && n < 13; k++) {
      const a = rng.range(0, TAU), d = rng.range(30, 250);
      const x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (!inside(x, z, 16) || wet(x, z) || !far(x, z, 40) || !occ.free(x, z, 1)) continue;
      occ.add(x, z, 1);
      addShard(W, x, z);
      n++;
    }
  }
}

// ---------------------------------------------------------------- instancing helper
// parts: [{ geo | gpu, mat, shadow }], placements: [{ x,y,z,yaw,scale,tiltX,tiltZ,tint }]
// One InstanceBatch per model: every frame each instance is culled on its own and picks its own detail level
// (see engine/batch.js). `chunk` only sets how far past maxDistance / shadowDistance things may still show,
// matching the reach the old chunked meshes had.
export function inst(W, parts, placements, { chunk = 70, maxDistance = Infinity, shadowDistance = 70, castShadow = true, lodDist = 0 } = {}) {
  if (!placements.length) return null;
  const gpuParts = parts.map((pt) => ({
    geo: pt.gpu || new GpuGeometry(W.gl, pt.geo),
    // far version: a simpler geometry, the same one (undefined) or nothing at all (null)
    far: !lodDist ? null : pt.lod === null ? null : pt.lod ? new GpuGeometry(W.gl, pt.lod) : 'same',
    mat: pt.mat, shadow: pt.shadow !== false, shadowNear: !!pt.shadowNear, solidR: pt.solidR,
  }));
  const m = mat4.create();
  const q = [0, 0, 0, 1];
  const pos = [0, 0, 0], scl = [1, 1, 1];
  const data = new Float32Array(placements.length * 20);
  placements.forEach((p, i) => {
    quat.fromEuler(q, p.tiltX || 0, p.yaw || 0, p.tiltZ || 0);
    const sc = p.scale;
    pos[0] = p.x; pos[1] = p.y; pos[2] = p.z;
    if (Array.isArray(sc)) { scl[0] = sc[0]; scl[1] = sc[1]; scl[2] = sc[2]; } else scl[0] = scl[1] = scl[2] = sc;
    mat4.compose(m, pos, q, scl);
    const o = i * 20;
    for (let k = 0; k < 16; k++) data[o + k] = m[k];
    const t = p.tint || [1, 1, 1, 1];
    data[o + 16] = t[0]; data[o + 17] = t[1]; data[o + 18] = t[2]; data[o + 19] = t[3] ?? 1;
  });
  const batch = new InstanceBatch(W.gl, data, placements.length, gpuParts, {
    maxDistance, shadowDistance, castShadow, lodDist, reach: chunk * 0.5, name: parts[0].mat === W.M.bark ? 'bark' : '',
  });
  W.scene.batches.push(batch);
  return batch;
}

function nodePoint(x, y, z, yaw, s, p) {
  const c = Math.cos(yaw), sn = Math.sin(yaw);
  return [x + (p[0] * c + p[2] * sn) * s, y + p[1] * s, z + (-p[0] * sn + p[2] * c) * s];
}

// ---------------------------------------------------------------- small models only used here
function reeds(seed) {
  const rng = new RNG(seed);
  const g = new Geometry();
  for (let i = 0; i < 9; i++) {
    const a = rng.range(0, TAU), d = rng.range(0, 0.35);
    const x0 = Math.cos(a) * d, z0 = Math.sin(a) * d;
    const h = rng.range(1.1, 2.1), lean = rng.range(-0.25, 0.25), yaw = rng.range(0, TAU);
    const w = 0.035;
    const segs = 4;
    const base = g.vertexCount;
    for (let j = 0; j <= segs; j++) {
      const t = j / segs;
      const off = lean * t * t;
      const ww = w * (1 - t * 0.85);
      const cx = x0 + Math.cos(yaw) * off, cz = z0 + Math.sin(yaw) * off;
      g.vert(cx - Math.sin(yaw) * ww, t * h, cz + Math.cos(yaw) * ww, Math.cos(yaw), 0.3, Math.sin(yaw));
      g.vert(cx + Math.sin(yaw) * ww, t * h, cz - Math.cos(yaw) * ww, Math.cos(yaw), 0.3, Math.sin(yaw));
    }
    for (let j = 0; j < segs; j++) {
      const q = base + j * 2;
      g.quad(q, q + 1, q + 3, q + 2);
    }
    if (rng.chance(0.45)) {
      const cat = Geometry.cylinder(0.05, 0.05, 0.26, 6, 1);
      cat.translate(x0 + Math.cos(yaw) * lean * 0.8, h * 0.82, z0 + Math.sin(yaw) * lean * 0.8);
      cat.setColor(C('#3a2a22'), 1);
      g.append(cat);
    }
  }
  g.paint((p) => {
    const t = Math.min(1, p[1] / 2);
    return [...(t < 0.5 ? C('#16302e') : C('#2d5a4c')), 0.6 + t * 0.4];
  });
  g.windByHeight(0.2, 2.1, 1.5);
  return g;
}

// a big stone head (unit size, ~1.25 tall) with glowing eyes
function stoneHead(seed) {
  const g = Geometry.icosphere(1, 4);
  g.deform((p) => {
    let [x, y, z] = p;
    const n = noise.fbm3(x * 1.4 + seed, y * 1.4, z * 1.4, 3) * 0.12;
    y *= 1.25;
    // brow ridge, nose and chin on the +z face
    const face = Math.max(0, z);
    const brow = Math.exp(-(((y - 0.38) / 0.14) ** 2)) * Math.exp(-((x / 0.7) ** 2)) * 0.12 * face;
    const nose = Math.exp(-((x / 0.14) ** 2) - (((y - 0.08) / 0.28) ** 2)) * 0.32 * face;
    const eyeSock = Math.exp(-(((Math.abs(x) - 0.33) / 0.14) ** 2) - (((y - 0.26) / 0.1) ** 2)) * -0.1 * face;
    const k = 1 + n;
    return [x * k, y * k, z * k + brow + nose + eyeSock];
  });
  g.computeNormals();
  g.paint((p, nn) => {
    const v = noise.n3(p[0] * 3 + seed, p[1] * 3, p[2] * 3) * 0.5 + 0.5;
    let c = [lerp(0.05, 0.12, v), lerp(0.055, 0.12, v), lerp(0.08, 0.17, v)];
    const moss = smoothstep(0.35, 0.8, nn[1]);
    c = [lerp(c[0], 0.02, moss), lerp(c[1], 0.09, moss), lerp(c[2], 0.07, moss)];
    return [...c, smoothstep(-0.6, 0.6, p[1]) * 0.5 + 0.5];
  });
  const eyes = new Geometry();
  for (const s of [-1, 1]) {
    const e = Geometry.sphere(0.1, 10, 8);
    e.scale(1, 0.55, 0.6);
    e.translate(s * 0.33, 0.33, 0.9);
    eyes.append(e);
  }
  eyes.setColor(C('#b5ffc8'), 1);
  eyes.setExtra([4]);
  return { stone: g, eyes, top: 1.22 };
}

// the ribcage, spine and skull of something enormous (v9: knobbly vertebrae, a real skull with eye sockets,
// teeth, horns and a fallen lower jaw; everything rests on the ground at y = 0)
function giantBones(seed) {
  const rng = new RNG(seed);
  const g = new Geometry();
  const spineY = (z) => 3.5 + Math.sin(((z + 5.5) / 11) * Math.PI) * 0.45;
  // one vertebra: a knobbly disc with a spike on top and two side processes, its axis along the chain
  const vertebra = (x, y, z, pitch, r, spike) => {
    const v = new Geometry();
    v.append(Geometry.lathe([[0.0, -0.22], [r * 0.8, -0.2], [r, -0.1], [r * 0.9, 0.0], [r, 0.1], [r * 0.8, 0.2], [0.0, 0.22]].map(([a, b]) => [a, b * r / 0.27]), 10));
    v.rotateX(Math.PI / 2);
    v.scale(1, 1.1, 1);
    const sp = Geometry.cylinder(0.02, r * 0.48, spike, 6, 2, { capBottom: false });
    sp.rotateX(-0.35);
    sp.translate(0, r * 0.55, 0);
    v.append(sp);
    for (const sd of [-1, 1]) {
      const tp = Geometry.cylinder(0.03, r * 0.3, r * 1.55, 5, 1, { capBottom: false });
      tp.rotateZ(-sd * 1.35);
      tp.translate(sd * r * 0.45, r * 0.07, 0);
      v.append(tp);
    }
    v.rotateX(pitch);
    v.translate(x, y, z);
    g.append(v);
  };
  // the chain: tail on the ground, the arched back, then the neck sloping down to the skull
  const chain = [];
  for (let i = 0; i <= 5; i++) { const t = i / 5; chain.push([Math.sin(t * 2) * 0.35, lerp(-0.15, 3.1, t * t * (3 - 2 * t)), lerp(-11.2, -6.6, t), 0.1 + t * 0.14]); }
  for (let i = 0; i < 12; i++) { const z = -6 + i * 1.0; chain.push([Math.sin(i * 0.5) * 0.12, spineY(z), z, 0.27 - Math.abs(i - 5) * 0.01]); }
  for (let i = 1; i <= 3; i++) { const t = i / 4; chain.push([lerp(Math.sin(5.5) * 0.12, 0.3, t), lerp(spineY(5), 1.1, t * t), lerp(5.7, 7.5, t), 0.22 - t * 0.04]); }
  g.append(Geometry.tube(chain.map((c) => [c[0], c[1], c[2]]), (t, i) => chain[i][3] * 0.45, 7, { capStart: true, capEnd: true }));
  chain.forEach((c, i) => {
    const a = chain[Math.max(0, i - 1)], b = chain[Math.min(chain.length - 1, i + 1)];
    const pitch = -Math.atan2(b[1] - a[1], b[2] - a[2]);
    vertebra(c[0], c[1], c[2], pitch, c[3], c[3] * 2.4);
  });
  // ribs: they arc out from the spine and their tips sink into the earth
  for (let i = 0; i < 6; i++) {
    const zc = -4 + i * 1.6;
    const sy = spineY(zc);
    const span = 2.6 - Math.abs(i - 2.5) * 0.15;
    for (const sd of [-1, 1]) {
      const pts = [];
      for (let j = 0; j <= 9; j++) {
        const t = j / 9;
        const a = t * Math.PI * 0.64;
        pts.push([sd * Math.sin(a) * span * 1.05, sy - (1 - Math.cos(a)) * sy * 1.03 + t * 0.1, zc - Math.sin(t * Math.PI * 0.5) * 1.1 + rng.range(-0.04, 0.04)]);
      }
      g.append(Geometry.tube(pts, (t) => 0.2 - t * 0.1, 7, { capStart: true, capEnd: true }));
    }
  }
  const bonePaint = (geo, oy = 0) => geo.paint((p, n) => {
    const v = noise.n3(p[0] * 2 + seed, p[1] * 2, p[2] * 2) * 0.5 + 0.5;
    const y = p[1] + oy;
    let c = [lerp(0.34, 0.5, v), lerp(0.32, 0.47, v), lerp(0.29, 0.42, v)];
    // earth at the bottom, a little moss on top
    const e = smoothstep(0.0, 0.6, y);
    c = [lerp(c[0] * 0.55, c[0], e), lerp(c[1] * 0.55, c[1], e), lerp(c[2] * 0.6, c[2], e)];
    if (n[1] > 0.7) { const m = smoothstep(0.7, 0.95, n[1]) * smoothstep(0.3, 0.7, noise.n3(p[0] * 1.5, p[1], p[2] * 1.5 + seed) * 0.5 + 0.5) * 0.6; c = [lerp(c[0], 0.08, m), lerp(c[1], 0.2, m), lerp(c[2], 0.17, m)]; }
    return [c[0], c[1], c[2], smoothstep(-0.2, 1.6, y) * 0.4 + 0.6];
  });
  g.computeNormals();
  bonePaint(g);
  // the skull, resting on its jaw line in front of the spine
  const SZ = 8.6, SY = 0.62;
  const skull = new Geometry();
  const cr = Geometry.icosphere(1, 3);
  cr.deform((p) => [p[0] * (1.0 - Math.max(0, p[2]) * 0.15), p[1] * (p[1] > 0 ? 0.95 : 0.7), p[2] * 1.25]);
  skull.append(cr);
  const snout = Geometry.lathe([[0.82, 0], [0.74, 0.6], [0.58, 1.3], [0.4, 1.95], [0.24, 2.3], [0.0, 2.42]], 14);
  snout.rotateX(Math.PI / 2);
  snout.scale(1, 0.62, 1);
  snout.translate(0, -0.25, 0.8);
  skull.append(snout);
  // brow ridges over the eye sockets
  for (const s of [-1, 1]) {
    const br = Geometry.icosphere(1, 1);
    br.scale(0.45, 0.22, 0.5);
    br.translate(s * 0.62, 0.55, 0.75);
    skull.append(br);
  }
  // horns: sweeping back, then curling forward like a ram's
  for (const s of [-1, 1]) {
    const pts = [];
    for (let j = 0; j <= 16; j++) {
      const t = j / 16, th = 1.25 + t * Math.PI * 1.55, r = 0.85 * (1 - 0.45 * t);
      pts.push([s * (0.78 + t * 0.55), 0.1 + Math.sin(th) * r, -0.5 + Math.cos(th) * r]);
    }
    skull.append(Geometry.tube(pts, (t) => 0.27 * (1 - t * 0.85), 10, { capStart: true, capEnd: true }));
  }
  // eye sockets and nostrils: deep dark hollows
  const hollows = new Geometry();
  for (const s of [-1, 1]) {
    const e = Geometry.icosphere(1, 1);
    e.scale(0.3, 0.19, 0.24);
    e.rotateZ(s * 0.35);
    e.translate(s * 0.56, 0.26, 0.84);
    hollows.append(e);
    const n = Geometry.icosphere(1, 1);
    n.scale(0.1, 0.08, 0.14);
    n.translate(s * 0.13, -0.05, 3.08);
    hollows.append(n);
  }
  hollows.setColor([0.012, 0.01, 0.014], 0.4);
  // upper teeth
  for (let k = 0; k < 7; k++) for (const s of [-1, 1]) {
    const z = 1.0 + k * 0.28, x = s * (0.52 - k * 0.05);
    const t = Geometry.cylinder(0.0, 0.07, 0.32 - k * 0.015, 5, 1, { capBottom: false });
    t.rotateX(Math.PI);
    t.translate(x, -0.5, z);
    skull.append(t);
  }
  skull.computeNormals();
  skull.displace((p) => noise.n3(p[0] * 3 + seed, p[1] * 3, p[2] * 3) * 0.035, true);
  // dark eye sockets and nostrils (painted deep)
  skull.paint((p, n) => {
    const sock = Math.max(0, 1 - Math.hypot((Math.abs(p[0]) - 0.62) / 0.3, (p[1] - 0.25) / 0.24, (p[2] - 0.95) / 0.3));
    const nose = Math.max(0, 1 - Math.hypot((Math.abs(p[0]) - 0.14) / 0.1, (p[1] + 0.05) / 0.12, (p[2] - 2.7) / 0.25));
    const v = noise.n3(p[0] * 2.3 + seed, p[1] * 2.3, p[2] * 2.3) * 0.5 + 0.5;
    const bone = [lerp(0.34, 0.5, v), lerp(0.32, 0.47, v), lerp(0.29, 0.42, v)];
    const k = Math.min(1, sock * 2.2 + nose * 2.5);
    return [bone[0] * (1 - k * 0.92), bone[1] * (1 - k * 0.92), bone[2] * (1 - k * 0.9), 1 - k * 0.5];
  });
  skull.append(hollows);
  skull.rotateY(0.18);
  skull.rotateZ(0.12); // lying slightly on one side
  skull.translate(0.3, SY, SZ);
  g.append(skull);
  // the lower jaw, fallen off and lying beside the skull
  const jaw = new Geometry();
  for (const s of [-1, 1]) {
    const pts = [];
    for (let j = 0; j <= 8; j++) {
      const t = j / 8;
      pts.push([s * lerp(0.75, 0.12, t * t), 0.22 + Math.sin(t * Math.PI) * 0.12, t * 2.6]);
    }
    jaw.append(Geometry.tube(pts, (t) => 0.2 - t * 0.08, 7, { capStart: true, capEnd: true }));
    for (let k = 0; k < 5; k++) {
      const t = 0.3 + k * 0.13;
      const tooth = Geometry.cylinder(0.0, 0.06, 0.26, 5, 1, { capBottom: false });
      tooth.translate(s * lerp(0.75, 0.12, t * t), 0.3, t * 2.6);
      jaw.append(tooth);
    }
  }
  jaw.computeNormals();
  bonePaint(jaw);
  jaw.rotateY(-0.55);
  jaw.translate(2.1, 0, 7.4);
  g.append(jaw);
  return g;
}

