// Builds every named place of the generated layout: structures, props, lights, particles,
// lore stones, star shard spots, moon gates and quest locations.
import { Geometry } from '../engine/geometry.js';
import { Node, Mesh } from '../engine/scene.js';
import { RNG, TAU, lerp } from '../engine/math.js';
import { C, runeTexture } from '../models/materials.js';
import * as flora from '../models/flora.js';
import * as S from '../models/structures.js';
import * as Wd from '../models/wonders.js';
import { particleSystem, butterflies, jellyfish } from './fx.js';
import { LORE } from '../data/lore.js';
import { capProfile, capSurface } from './capsurf.js';
import { buildSky } from './sky.js';
import { geometrySurface } from './hull.js';

export const BOUNCE = 18; // launch speed of the purple bounce mushrooms (~7.7 m high)
const PAD_XZ = 1.25, PAD_Y = 0.3; // squat, cushion-like: you simply walk onto them

// local frame of a site: lx to the right, lz forward (towards its road)
function frame(site) {
  const c = Math.cos(site.yaw), s = Math.sin(site.yaw);
  return (lx, lz) => [site.x + lx * c + lz * s, site.z - lx * s + lz * c];
}

export function placeSites(W) {
  const L = W.L;
  const rng = new RNG(L.seed * 17 + 1000);
  const ctx = { W, L, rng, lore: 0 };
  W.bouncePads = W.bouncePads || [];
  W.wisps = [];
  glade(ctx);
  village(ctx);
  mushroomForest(ctx);
  castle(ctx);
  lake(ctx);
  pyramid(ctx);
  islands(ctx);
  crystal(ctx);
  swamp(ctx);
  giant(ctx);
  crater(ctx);
  runeCircle(ctx);
  amanitaGrove(ctx);
  moonGarden(ctx);
  watcher(ctx);
  tower(ctx);
  ruins(ctx);
  bridges(ctx);
  roadLamps(ctx);
  buildSky(ctx);
  W.loreCount = ctx.lore;
}

// ---------------------------------------------------------------- shared helpers
export function addShard(W, x, z, y = null, id = null) {
  const yy = y !== null ? y : W.groundHeight(x, z);
  W.shardSpots.push({ id: id || 's' + W.shardSpots.length, x, y: yy, z });
}
export function addLore(ctx, x, z, yaw, yAt = null) {
  const { W } = ctx;
  const i = ctx.lore++;
  if (!W._loreGeo) {
    const g = Wd.loreStoneGeometry();
    W._loreGeo = { stone: W.gpu(g.stone), rune: W.gpu(g.rune) };
  }
  const node = new Node('lore');
  const y = (yAt ?? W.h(x, z)) - 0.05;
  node.setPos(x, y, z);
  node.setRotY(yaw);
  node.add(W.meshG(W._loreGeo.stone, W.M.stone, 'loreStone'));
  const rm = W.meshG(W._loreGeo.rune, W.M.glow, 'loreRune');
  rm.castShadow = false;
  node.add(rm);
  W.scene.add(node);
  W.physics.addCircle(x, z, 0.55, { yMin: yAt === null ? -Infinity : y - 1, yMax: y + 1.6 });
  W.loreSpots.push({ id: 'lore' + i, x, y, z, text: LORE[i % LORE.length], node, rune: rm });
  W.occ.add(x, z, 1.2);
}
export function addGate(ctx, id, name, x, z, yaw) {
  const { W } = ctx;
  if (!W.occ.free(x, z, 2.5) || W.waterDepth(x, z) > -0.4) {
    const p = W.freeSpot(ctx.rng, x, z, 14, 3);
    if (p) { x = p[0]; z = p[1]; }
  }
  // (v9.1) prefer the flattest ground within a few steps, then sit it by its corners: the step sinks a little
  // on the high side, the stepped plinth covers the low side
  const c = Math.cos(yaw), s = Math.sin(yaw);
  const span = (x, z) => {
    let hi = -Infinity, lo = Infinity;
    for (const [lx, lz] of [[-4, -1.5], [4, -1.5], [-4, 1.5], [4, 1.5], [0, 0]]) {
      const h = W.h(x + lx * c + lz * s, z - lx * s + lz * c);
      hi = Math.max(hi, h); lo = Math.min(lo, h);
    }
    return [lo, hi];
  };
  let best = span(x, z), bx = x, bz = z;
  for (let r = 2; r <= 6; r += 2) for (let k = 0; k < 8; k++) {
    const a = (k / 8) * TAU, tx = x + Math.cos(a) * r, tz = z + Math.sin(a) * r;
    if (W.waterDepth(tx, tz) > -0.4 || !W.occ.free(tx, tz, 2.5)) continue;
    const sp = span(tx, tz);
    if (sp[1] - sp[0] < best[1] - best[0] - 0.3) { best = sp; bx = tx; bz = tz; }
  }
  x = bx; z = bz;
  const hi = best[1];
  const y = Math.max(W.h(x, z) - 0.2, hi - 0.7);
  const R = W.place(Wd.buildMoonGate(W.ctx), x, z, yaw, 0, { y });
  R.anchors.portal.material.uniforms.uPortalActive = 0;
  W.gates.push({ id, name, x, z, yaw, y: R.world.y, portal: R.anchors.portal, front: R.world.tp([0, 0, 2.6]) });
  W.occ.add(x, z, 4);
}
export function bouncePad(W, x, z, y = null, scale = 1, bounce = BOUNCE) {
  if (!W._bounceGeo) {
    const b = Wd.bounceShroom(3);
    W._bounceGeo = { stem: W.gpu(b.stem), cap: W.gpu(b.cap), top: b.top, R: b.R, capGeo: b.cap };
  }
  const b = W._bounceGeo;
  const yy = y !== null ? y : W.h(x, z) - 0.05;
  const node = new Node('bounce');
  node.setPos(x, yy, z);
  const sx = PAD_XZ * scale, sy = PAD_Y * scale;
  node.setScale(sx, sy, sx);
  node.setRotY(Math.abs(x * 7.13 + z * 3.1) % TAU);
  node.add(W.meshG(b.stem, W.M.stem, 'bounceStem'));
  const cap = W.meshG(b.cap, W.M.bounceCap, 'bounceCap');
  node.add(cap);
  W.scene.add(node);
  // (v8) the bounce surface follows the drawn cap: the dome's slope and its wide rim
  node.updateWorld(null, true);
  const s = geometrySurface(W.physics, [{ g: b.capGeo, m: node.world }], { cell: 0.15, bottom: yy, sink: 0, bounce, tag: 'bounce' });
  const pad = { x, y: yy + b.top * sy, z, node, cap, surface: s, squash: 0, sx, sy };
  s.pad = pad;
  W.bouncePads.push(pad);
  W.occ.add(x, z, 1.5 * scale);
  return pad;
}
function smoke(W, p, count = 24, color = [0.05, 0.055, 0.1], seed = 1) {
  const m = particleSystem(W.gl, count, { RISE: 1, SMOKE: 1 }, (i, r) => ({
    p: [p[0], p[1], p[2]], params: [0.6, 2.8, 0.6, 1.2], size: 1.0, life: r.range(5, 8), speed: r.range(3, 6), spread: 0.7, color, intensity: 1,
  }), { blend: 'normal', seed });
  m.maxDistance = 110;
  W.scene.add(m);
}
function flame(W, p, count, color, { size = 0.6, speed = [0.6, 1.0], spread = 0.08, seed = 1, dist = 120 } = {}) {
  const m = particleSystem(W.gl, count, { RISE: 1, FLAME: 1 }, (i, r) => ({ p: [p[0] + r.range(-spread, spread), p[1], p[2] + r.range(-spread, spread)], params: [0.6, 0.15, 0.5, 0.1], size, life: r.range(0.5, 0.8), speed: r.range(speed[0], speed[1]), spread, color, intensity: 3 }), { seed });
  m.maxDistance = dist;
  W.scene.add(m);
  return m;
}
export function sparkles(W, center, radius, count, colors, { h0 = 0.3, h1 = 4, seed = 1, dist = 140, size = [0.06, 0.16] } = {}) {
  const m = particleSystem(W.gl, count, { FIREFLY: 1, STAR: 1 }, (i, r) => {
    const a = r.range(0, TAU), d = Math.sqrt(r.next()) * radius;
    const x = center[0] + Math.cos(a) * d, z = center[1] + Math.sin(a) * d;
    return { p: [x, Math.max(W.h(x, z), W.L.waterLevel) + r.range(h0, h1), z], params: [r.range(1, 4), 0, 0, 0], size: r.range(size[0], size[1]), speed: r.range(0.2, 0.6), spread: r.range(0.5, 2), color: C(r.pick(colors)), intensity: r.range(3, 6) };
  }, { seed });
  m.maxDistance = dist;
  W.scene.add(m);
  return m;
}
// a lightweight clone of a structure result (shares GPU geometry and materials)
export function cloneStructure(R) {
  const copy = (src) => {
    const n = src instanceof Mesh ? new Mesh(src.geometry, src.material, src.name) : new Node(src.name);
    if (src instanceof Mesh) { n.castShadow = src.castShadow; n.maxDistance = src.maxDistance; n.shadowDistance = src.shadowDistance; }
    n.position = src.position.slice();
    n.quaternion = src.quaternion.slice();
    n.scale = src.scale.slice();
    n.visible = src.visible;
    for (const c of src.children) n.add(copy(c));
    return n;
  };
  return { root: copy(R.root), colliders: R.colliders, surfaces: R.surfaces, platforms: R.platforms, lights: R.lights, anchors: { ...R.anchors } };
}

// ---------------------------------------------------------------- the glade: wizard's hut, cauldron
function glade(ctx) {
  const { W, L } = ctx;
  const s = L.sites.glade;
  const T = frame(s);
  const [hx, hz] = T(-4, -8);
  const hutYaw = Math.atan2(s.x - hx, s.z + 2 - hz) + 0.2;
  const hut = W.place(S.buildHut(W.ctx), hx, hz, hutYaw, -0.05);
  W.hut = hut;
  const F = [Math.sin(hutYaw), Math.cos(hutYaw)], side = [F[1], -F[0]];
  const cx = hx + F[0] * 7.2 + side[0] * 2.4, cz = hz + F[1] * 7.2 + side[1] * 2.4;
  const cauldron = W.place(S.buildCauldron(W.ctx), cx, cz, hutYaw, -0.05);
  W.cauldron = cauldron;
  W.anchors.cauldron = [cx, W.h(cx, cz), cz];
  W.anchors.hutFacing = hutYaw;
  W.anchors.hutDoor = hut.world.tp(hut.anchors.door);
  W.anchors.chimney = hut.world.tp(hut.anchors.chimney);
  smoke(W, W.anchors.chimney, 40, [0.05, 0.055, 0.1], 14);
  const cp = cauldron.world.tp(cauldron.anchors.fire), ctop = cauldron.world.tp(cauldron.anchors.top);
  const add = (m) => { m.maxDistance = 90; W.scene.add(m); };
  add(particleSystem(W.gl, 36, { RISE: 1, FLAME: 1 }, (i, r) => ({ p: [cp[0] + r.range(-0.3, 0.3), cp[1], cp[2] + r.range(-0.3, 0.3)], params: [0.55, 0.15, 0.5, 0.05], size: 0.55, life: r.range(0.6, 1.0), speed: r.range(0.5, 0.9), spread: 0.12, color: C('#ff7a2a'), intensity: 2.8 }), { seed: 15 }));
  add(particleSystem(W.gl, 18, { RISE: 1, SMOKE: 1 }, (i, r) => ({ p: [ctop[0] + r.range(-0.3, 0.3), ctop[1], ctop[2] + r.range(-0.3, 0.3)], params: [0.35, 1.3, 0.35, 0.6], size: 0.8, life: r.range(3, 5), speed: r.range(1.8, 2.8), spread: 0.35, color: [0.05, 0.22, 0.12], intensity: 1 }), { blend: 'normal', seed: 16 }));
  add(particleSystem(W.gl, 24, { RISE: 1 }, (i, r) => ({ p: [ctop[0] + r.range(-0.4, 0.4), ctop[1] - 0.02, ctop[2] + r.range(-0.4, 0.4)], params: [0.8, 0.3, 0.7, 0], size: 0.12, life: r.range(0.8, 1.6), speed: r.range(0.1, 0.35), spread: 0.08, color: C('#7dffab'), intensity: 3 }), { seed: 17 }));
  W.fireflies([s.x, s.z], 28, 60, C('#9fe7ff'), { seed: 1 });
  const [gx, gz] = T(12, -4);
  addGate(ctx, 'glade', 'Holdfény-tisztás', gx, gz, Math.atan2(s.x - gx, s.z - gz));
  const [lx, lz] = T(-11, 5);
  addLore(ctx, lx, lz, Math.atan2(s.x - lx, s.z - lz));
  const [sx, sz] = hut.world.tr(-2.5, -4.6);
  addShard(W, sx, sz);
}

// ---------------------------------------------------------------- Gombafalu: the mushroom village
function village(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.village;
  const T = frame(s);
  W.place(Wd.buildWell(W.ctx), s.x, s.z, s.yaw, -0.1);
  const houses = [];
  const n = 6;
  for (let i = 0; i < n; i++) {
    // leave the road side (local +z) open
    const a = Math.PI / 2 + 0.75 + (i / (n - 1)) * (TAU - 1.5) + rng.range(-0.08, 0.08);
    const r = 14 + rng.range(-1.5, 2.5);
    const [x, z] = T(Math.cos(a) * r, Math.sin(a) * r);
    const yaw = Math.atan2(s.x - x, s.z - z) + rng.range(-0.2, 0.2);
    const R = W.place(Wd.buildMushroomHouse(W.ctx, i % 4, 30 + i + L.seed * 3), x, z, yaw, -0.15);
    houses.push(R);
    smoke(W, R.world.tp(R.anchors.chimney), 14, [0.06, 0.06, 0.1], 40 + i);
    W.occ.add(x, z, 6);
  }
  W.villageHouses = houses;
  // lantern strings between neighbouring houses and to the well
  const rope = new Geometry(), bulbs = new Geometry();
  const wellTop = [s.x, W.h(s.x, s.z) + 3.3, s.z];
  for (let i = 0; i < n; i++) {
    const a = houses[i].world.tp([0, 3.0, 1.9]);
    if (i < n - 1) {
      const b = houses[i + 1].world.tp([0, 3.0, 1.9]);
      const ls = Wd.lanternString(a, b, 1.3, i);
      rope.append(ls.rope); bulbs.append(ls.bulbs);
    }
    if (i % 2 === 0) {
      const ls2 = Wd.lanternString(a, wellTop, 1.6, 10 + i);
      rope.append(ls2.rope); bulbs.append(ls2.bulbs);
    }
  }
  const rm = W.mesh(rope, W.M.wood, 'ropes');
  rm.castShadow = false;
  W.scene.add(rm);
  const bm = W.mesh(bulbs, W.M.glow, 'bulbs');
  bm.castShadow = false;
  W.scene.add(bm);
  W.light([s.x, W.h(s.x, s.z) + 3, s.z], C('#ffb870'), 2.5, 14, 0.05, 2);
  // benches (logs) around the well
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * TAU + 0.5;
    const x = s.x + Math.cos(a) * 5.2, z = s.z + Math.sin(a) * 5.2;
    const log = flora.log(70 + k, { length: 2.4, radius: 0.26 });
    const m = W.mesh(log, W.M.bark, 'bench');
    const y = W.h(x, z) - 0.2;
    const yaw = -a + Math.PI / 2;
    m.setPos(x, y, z);
    m.setRotY(yaw);
    W.scene.add(m);
    W.physics.addSurface({ type: 'box', x, z, hx: 1.2, hz: 0.28, yaw, top: y + 0.46, bottom: y - 1 });
  }
  W.anchors.village = { x: s.x, z: s.z, y: W.h(s.x, s.z), yaw: s.yaw, houses: houses.map((h) => ({ door: h.world.tp(h.anchors.door), yaw: h.world.yaw })) };
  // a bounce pad so you can hop onto the red house's cap
  const hc = houses[0];
  const [bx, bz] = hc.world.tr(4.4, 4.4);
  bouncePad(W, bx, bz);
  const ct = hc.world.tp(hc.anchors.capTop);
  addShard(W, ct[0], ct[2], ct[1] - 0.1);
  const [gx, gz] = T(-13, 11);
  addGate(ctx, 'village', 'Gombafalu', gx, gz, Math.atan2(s.x - gx, s.z - gz));
  const [lx, lz] = T(6.5, -6.5);
  addLore(ctx, lx, lz, Math.atan2(s.x - lx, s.z - lz));
  W.fireflies([s.x, s.z], 26, 40, C('#ffd88a'), { seed: 21 });
}

// ---------------------------------------------------------------- Kéklő Gombaerdő: a spiral of giant mushrooms up to the mother
function mushroomForest(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.mushroom;
  const mom = flora.giantMushroom(77, { capRatio: 0.5, bend: 0.05, stemR: 0.065, variant: 1 });
  const momSc = 26;
  const node = new Node('motherMushroom');
  const my = W.h(s.x, s.z) - 0.4;
  node.setPos(s.x, my, s.z);
  node.setScale(momSc);
  node.add(W.mesh(mom.stem, W.M.stem));
  node.add(W.mesh(mom.cap, W.M.greatCap));
  W.scene.add(node);
  const capTop = my + momSc * (mom.capY + 0.635 * mom.R);
  const capR = momSc * mom.R;
  const capUnder = my + momSc * (mom.capY - 0.06 * mom.R);
  W.physics.addCircle(s.x, s.z, momSc * 0.075, { yMax: capUnder - 0.3 });
  W.physics.addSurface(capSurface(capProfile(mom.cap), s.x, my, s.z, 0, momSc));
  W.occ.add(s.x, s.z, 15);
  W.light([s.x, capUnder - 2, s.z], C('#7a86ff'), 5, 26, 0, 3);
  W.anchors.momTop = [s.x, capTop, s.z];
  // staircase: giant caps of growing size spiralling around the mother, a bounce mushroom on each
  const geo = flora.giantMushroom(78, { capRatio: 0.72, bend: 0.04, stemR: 0.075, variant: 0 });
  const gStem = W.gpu(geo.stem), gCap = W.gpu(geo.cap);
  const prof = capProfile(geo.cap);
  const k = geo.capY + 0.635 * geo.R;
  const n = 7;
  let ang = rng.range(0, TAU);
  const steps = [];
  const baseY = my + 0.4;
  for (let i = 0; i < n; i++) {
    const targetTop = baseY + 4.2 + i * 3.9;
    let sc = (targetTop - baseY + 0.3) / k;
    let cr = sc * geo.R;
    const ringR = capR + cr + 2.4;
    if (i > 0) {
      const p = steps[i - 1];
      const chord = p.cr + cr + 2.2;
      const rAvg = (ringR + p.ringR) / 2;
      ang += 2 * Math.asin(Math.min(0.98, chord / (2 * rAvg)));
    }
    const x = s.x + Math.cos(ang) * ringR, z = s.z + Math.sin(ang) * ringR;
    const y = W.h(x, z) - 0.3;
    sc = Math.max(2.5, (targetTop - y) / k);
    cr = sc * geo.R;
    const top = y + sc * k;
    const n2 = new Node('stairShroom');
    const yaw = rng.range(0, TAU);
    n2.setPos(x, y, z);
    n2.setScale(sc);
    n2.setRotY(yaw);
    n2.add(W.meshG(gStem, W.M.stem));
    n2.add(W.meshG(gCap, W.M.giantCap));
    W.scene.add(n2);
    const under = y + sc * (geo.capY - 0.06 * geo.R);
    W.physics.addCircle(x, z, sc * 0.09, { yMax: under - 0.2 });
    const surf = W.physics.addSurface(capSurface(prof, x, y, z, yaw, sc));
    steps.push({ x, z, y, sc, top, cr, ringR, surf });
    W.occ.add(x, z, cr + 1);
  }
  // bounce mushrooms: one on the ground next to the first cap, one on each cap towards the next
  const f = steps[0];
  {
    const dx = f.x - s.x, dz = f.z - s.z, dl = Math.hypot(dx, dz);
    const t = [-dz / dl, dx / dl];
    const px = f.x - t[0] * (f.cr + 1.5), pz = f.z - t[1] * (f.cr + 1.5);
    bouncePad(W, px, pz, null, 1, launch(W.h(px, pz) + 0.53, f.top));
  }
  for (let i = 0; i < n; i++) {
    const a = steps[i];
    const b = i < n - 1 ? steps[i + 1] : { x: s.x, z: s.z };
    const dx = b.x - a.x, dz = b.z - a.z, dl = Math.hypot(dx, dz);
    const d = a.cr * 0.78;
    const x = a.x + (dx / dl) * d, z = a.z + (dz / dl) * d;
    const y = (W.physics.topAt(a.surf, x, z) ?? a.top) - 0.08;
    bouncePad(W, x, z, y, 1, launch(y + 0.58, i < n - 1 ? b.top : capTop));
  }
  W.mushroomSteps = steps;
  addShard(W, s.x, s.z, capTop, 'momTop');
  addShard(W, steps[3].x, steps[3].z, steps[3].top);
  addShard(W, steps[5].x, steps[5].z, steps[5].top);
  const la = ang + 2.2;
  const lx = s.x + Math.cos(la) * (capR + 7), lz = s.z + Math.sin(la) * (capR + 7);
  addLore(ctx, lx, lz, Math.atan2(s.x - lx, s.z - lz));
  sparkles(W, [s.x, s.z], 60, 220, ['#a8e8ff', '#8fb8ff', '#c8f0ff'], { h0: 1, h1: 24, seed: 12, dist: 160 });
  W.fireflies([s.x, s.z], 55, 100, C('#7ab8ff'), { h: 4, seed: 3 });
}

// ---------------------------------------------------------------- Kőmarok: gate, stone hand, hidden light stairway
function castle(ctx) {
  const { W, L } = ctx;
  const s = L.sites.castle;
  const gate = W.place(S.buildGate(W.ctx), s.x, s.z, s.yaw, 0, { y: W.h(s.x, s.z) - 0.15 });
  W.gate = gate;
  // the bars lift and the dark doorway vanishes when the gate opens: the door collider handles them instead
  gate.anchors.bars.noSolid = true;
  gate.anchors.dark.noSolid = true;
  W.gateDoor = gate.tagged && gate.tagged.gateDoor;
  W.anchors.gate = gate.world;
  const hand = W.place(S.buildStoneHand(W.ctx), s.handX, s.handZ, s.yaw, 0, { y: W.h(s.handX, s.handZ) - 6, collide: false });
  hand.root.traverse((n) => { if (n.geometry) { n.shadowDistance = 0; n.castShadow = false; } });
  W.hand = hand;
  // the castle ledge can be walked on once you get there
  const ledgeTop = hand.world.y + 33 + 1.35;
  W.physics.addCircle(s.handX, s.handZ, 22, { yMax: ledgeTop - 3 });
  W.physics.addCircle(s.handX, s.handZ, 9.5, { yMin: ledgeTop - 1 }); // the palm behind the castle
  const lc = hand.world.tp([0, 0, 14]);
  W.physics.addSurface({ type: 'disc', x: lc[0], z: lc[2], r: 11.5, top: ledgeTop, bottom: ledgeTop - 8 });
  W.physics.addCircle(lc[0], lc[2], 7.6, { yMin: ledgeTop - 1 });
  W.anchors.castleDoor = hand.world.tp([0, 34.35, 22.6]);
  W.anchors.castleDoor[1] = ledgeTop;
  // warm lanterns by the castle door (the finale deserves some light)
  for (const sx of [-3.2, 3.2]) W.light(hand.world.tp([sx, 34.35 + 2.4, 21.6]), C('#ffb060'), 3.2, 9, 0.12, 8);
  flame(W, hand.world.tp([-3.2, 34.35 + 2.1, 21.8]), 16, C('#ff9a45'), { seed: 91, size: 0.5, dist: 160 });
  flame(W, hand.world.tp([3.2, 34.35 + 2.1, 21.8]), 16, C('#ff9a45'), { seed: 92, size: 0.5, dist: 160 });
  W.anchors.ledgeTop = ledgeTop;
  // the light stairway: a helix from the courtyard up to the ledge, hidden until the quest opens it
  const end = hand.world.tp([0, 0, 26.5]);
  const rad = 5.2, dTh = TAU / 27;
  const gc = Math.cos(gate.world.yaw), gs = Math.sin(gate.world.yaw);
  const gateLocalZ = (x, z) => (x - gate.world.x) * gs + (z - gate.world.z) * gc;
  // keep the first turns of the helix clear of the gate wall
  let back = 10, start, y0, N, rise, th0, thEnd, ax0, ax1;
  for (let it = 0; it < 4; it++) {
    start = gate.world.tp([0, 0, -back]);
    y0 = W.h(start[0], start[2]);
    N = Math.max(12, Math.ceil((ledgeTop - y0) / 0.42));
    rise = (ledgeTop - y0) / N;
    thEnd = Math.atan2(end[2] - start[2], end[0] - start[0]);
    th0 = thEnd - (N - 1) * dTh;
    ax0 = [start[0] - Math.cos(th0) * rad, start[2] - Math.sin(th0) * rad];
    ax1 = [end[0] - Math.cos(thEnd) * rad, end[2] - Math.sin(thEnd) * rad];
    let maxZ = -Infinity;
    for (let i = 0; i < N; i++) {
      if (rise * (i + 1) > 9.5) break;
      const t = i / (N - 1), th = th0 + i * dTh;
      const x = lerp(ax0[0], ax1[0], t) + Math.cos(th) * rad, z = lerp(ax0[1], ax1[1], t) + Math.sin(th) * rad;
      maxZ = Math.max(maxZ, gateLocalZ(x, z));
    }
    if (maxZ < -3.2) break;
    back += maxZ + 3.6;
  }
  const g = new Geometry();
  const rail = new Geometry();
  const surfaces = [];
  const stepPts = [];
  for (let i = 0; i < N; i++) {
    const t = N > 1 ? i / (N - 1) : 1;
    const th = th0 + i * dTh;
    const ax = lerp(ax0[0], ax1[0], t), az = lerp(ax0[1], ax1[1], t);
    const x = ax + Math.cos(th) * rad, z = az + Math.sin(th) * rad;
    const y = y0 + rise * (i + 1);
    const yaw = -th;
    const b = Geometry.box(2.1, 0.16, 1.45, { y0: -0.16 });
    b.rotateY(yaw);
    b.translate(x, y, z);
    g.append(b);
    const dot = Geometry.sphere(0.07, 6, 4);
    dot.translate(ax + Math.cos(th) * (rad + 1.1), y + 0.5, az + Math.sin(th) * (rad + 1.1));
    rail.append(dot);
    surfaces.push(W.physics.addSurface({ type: 'box', x, z, hx: 1.1, hz: 0.78, yaw, top: y, bottom: y - 0.5, disabled: true, noCamera: true }));
    stepPts.push([x, y, z]);
  }
  g.setColor(C('#a8d8ff'), 1);
  g.setExtra([1.3]);
  rail.setColor(C('#dff0ff'), 1);
  rail.setExtra([4]);
  const snode = new Node('lightStairs');
  const sm = W.mesh(g, W.M.glass, 'lightStairs');
  sm.castShadow = false;
  const rl = W.mesh(rail, W.M.glow, 'lightRail');
  rl.castShadow = false;
  snode.add(sm, rl);
  snode.visible = false;
  W.scene.add(snode);
  const motes = particleSystem(W.gl, 160, { FIREFLY: 1, STAR: 1 }, (i, r) => {
    const p = stepPts[Math.floor(r.next() * stepPts.length)];
    return { p: [p[0] + r.range(-1.5, 1.5), p[1] + r.range(0, 2), p[2] + r.range(-1.5, 1.5)], params: [r.range(1, 3), 0, 0, 0], size: r.range(0.06, 0.14), speed: r.range(0.3, 0.7), spread: 1, color: C('#cfe8ff'), intensity: 4 };
  }, { seed: 88 });
  motes.maxDistance = 260;
  snode.add(motes);
  W.lightStairs = { node: snode, surfaces, steps: stepPts, start: [start[0], y0, start[2]], end: [end[0], ledgeTop, end[2]] };
  for (const k of ['torchL', 'torchR']) flame(W, gate.world.tp(gate.anchors[k]), 22, C('#ff8a3a'), { seed: 20 + (k === 'torchL' ? 1 : 2) });
  const [gx, gz] = frame(s)(10, 17);
  addGate(ctx, 'castle', 'Kőmarok kapuja', gx, gz, Math.atan2(s.x - gx, s.z - gz) + 0.4);
}

// ---------------------------------------------------------------- Csillagtó: pier, the fishers' log, lanterns, waterfall
function lake(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.lake;
  const e = s.entry;
  const dx = s.x - e[0], dz = s.z - e[1], dl = Math.hypot(dx, dz);
  const ux = dx / dl, uz = dz / dl;
  // the pier starts at the shore and reaches into the water
  let px = e[0], pz = e[1];
  for (let d = 0; d < 24; d += 0.5) {
    const x = e[0] + ux * d, z = e[1] + uz * d;
    if (W.h(x, z) < L.waterLevel + 0.25) { px = x - ux * 1.2; pz = z - uz * 1.2; break; }
  }
  const pierYaw = Math.atan2(-ux, -uz);
  W.pier = W.place(S.buildPier(W.ctx), px, pz, pierYaw, 0, { y: L.waterLevel });
  W.anchors.pierEnd = W.pier.world.tp(W.pier.anchors.end);
  W.occ.add(px + ux * 6, pz + uz * 6, 5);
  // the gnomes' log on the shore, around the lake from the pier
  const ang = Math.atan2(-uz, -ux) + 1.6 * (rng.chance(0.5) ? 1 : -1);
  let lr = s.lakeR + 3;
  for (let k = 0; k < 20; k++) {
    if (W.h(s.x + Math.cos(ang) * lr, s.z + Math.sin(ang) * lr) > L.waterLevel + 0.5) break;
    lr += 1;
  }
  const lx = s.x + Math.cos(ang) * lr, lz = s.z + Math.sin(ang) * lr;
  const tangentYaw = Math.atan2(Math.cos(ang), -Math.sin(ang));
  const logM = W.mesh(flora.log(5, { length: 7.5, radius: 0.55 }), W.M.moss, 'swampLog');
  const ly = W.h(lx, lz) - 0.25;
  logM.setPos(lx, ly, lz);
  logM.setRotY(tangentYaw - Math.PI / 2);
  W.scene.add(logM);
  const ta = [Math.sin(tangentYaw), Math.cos(tangentYaw)];
  W.physics.addSurface({ type: 'box', x: lx, z: lz, hx: 0.5, hz: 3.7, yaw: tangentYaw, top: ly + 1.0, bottom: ly - 1 });
  W.anchors.log = { x: lx, y: ly + 1.0, z: lz, yaw: tangentYaw, tangent: ta, faceYaw: Math.atan2(s.x - lx, s.z - lz) };
  W.occ.add(lx, lz, 6);
  addShard(W, lx + ta[0] * 3.0, lz + ta[1] * 3.0, ly + 1.0);
  addShard(W, ...W.pier.world.tr(0, -12.8), L.waterLevel + 0.5);
  // the moonflower grows on top of the waterfall cliff (side quest)
  const wt = W.anchors.waterfallTop, wd = W.anchors.waterfallDir;
  const fx = wt[0] - wd[0] * 4 + wd[1] * 2.5, fz = wt[2] - wd[1] * 4 - wd[0] * 2.5;
  W.anchors.moonflower = [fx, W.h(fx, fz), fz];
  W.occ.add(fx, fz, 2);
  const lan = particleSystem(W.gl, 26, { RISE: 1 }, (i, r) => {
    const a2 = r.range(0, TAU), d = Math.sqrt(r.next()) * s.lakeR * 0.8;
    return { p: [s.x + Math.cos(a2) * d, L.waterLevel + 0.3, s.z + Math.sin(a2) * d], params: [1, 0.8, 0.8, 1.5], size: 0.55, life: r.range(22, 34), speed: r.range(18, 30), spread: 2.5, color: C('#ffb86a'), intensity: 2.2 };
  }, { seed: 31 });
  lan.maxDistance = 240;
  W.scene.add(lan);
  const side = [-uz, ux];
  addGate(ctx, 'lake', 'Csillagtó', e[0] + side[0] * 9 - ux * 5, e[1] + side[1] * 9 - uz * 5, Math.atan2(ux, uz));
  const la = ang + 0.8;
  const lorep = [s.x + Math.cos(la) * (s.lakeR + 6), s.z + Math.sin(la) * (s.lakeR + 6)];
  if (W.waterDepth(lorep[0], lorep[1]) < -0.3 && W.occ.free(lorep[0], lorep[1], 1.5)) addLore(ctx, lorep[0], lorep[1], Math.atan2(s.x - lorep[0], s.z - lorep[1]));
  else {
    const p = W.freeSpot(rng, s.x, s.z, s.lakeR + 14, 1.5, 80, (x, z) => Math.hypot(x - s.x, z - s.z) > s.lakeR + 3);
    if (p) addLore(ctx, p[0], p[1], rng.range(0, TAU));
  }
  const wb = W.anchors.waterfallBase;
  const mist = particleSystem(W.gl, 40, { RISE: 1, SMOKE: 1 }, (i, r) => ({ p: [wb[0] + r.range(-2, 2), wb[1], wb[2] + r.range(-2, 2)], params: [1.2, 4.0, 0.5, 1.5], size: 1.5, life: r.range(3, 5), speed: r.range(1.5, 3), spread: 1.2, color: [0.12, 0.3, 0.35], intensity: 1 }), { blend: 'normal', seed: 22 });
  mist.maxDistance = 150;
  W.scene.add(mist);
  const spk = particleSystem(W.gl, 60, { RISE: 1, STAR: 1 }, (i, r) => ({ p: [wb[0] + r.range(-2, 2), wb[1], wb[2] + r.range(-2, 2)], params: [1, 0.2, 0.6, 1], size: 0.1, life: r.range(1, 2.5), speed: r.range(1, 4), spread: 1.5, color: C('#a8fff4'), intensity: 4 }), { seed: 23 });
  spk.maxDistance = 150;
  W.scene.add(spk);
  W.scene.add(butterflies(W.gl, 16, [s.x + Math.cos(ang) * s.lakeR * 0.6, L.waterLevel + 0.8, s.z + Math.sin(ang) * s.lakeR * 0.6], { radius: 9, height: 1.5, color: [0.3, 1.2, 1.8], seed: 4 }));
  W.fireflies([s.x, s.z], s.lakeR + 10, 150, C('#6affd5'), { h: 1.2, seed: 2 });
}

// ---------------------------------------------------------------- Álompiramis in the dream desert
function pyramid(ctx) {
  const { W, L } = ctx;
  const s = L.sites.pyramid;
  const R = W.place(S.buildPyramid(W.ctx), s.x, s.z, s.yaw, 0, { y: W.h(s.x, s.z) });
  W.pyramid = R;
  W.anchors.pyramidTop = R.world.tp(R.anchors.top);
  W.anchors.stairsFoot = R.world.tp(R.anchors.stairsFoot);
  const cap = R.world.tp([0, 19.6, 0]);
  const pm = particleSystem(W.gl, 90, { FIREFLY: 1, STAR: 1 }, (i, r) => ({ p: [cap[0] + r.range(-5, 5), cap[1] + r.range(-4, 6), cap[2] + r.range(-5, 5)], params: [r.range(1, 3), 0, 0, 0], size: r.range(0.1, 0.25), speed: r.range(0.3, 0.8), spread: r.range(1, 3), color: C('#bfe6ff'), intensity: 4 }), { seed: 24 });
  pm.maxDistance = 240;
  W.scene.add(pm);
  // obelisks at the corners
  const ob = Wd.obelisk(3);
  const obS = W.gpu(ob.stone), obR = W.gpu(ob.runes);
  for (const [cx, cz] of [[-17, -17], [17, -17], [-17, 17], [17, 17]]) {
    const [x, z] = R.world.tr(cx, cz);
    const node = new Node('obelisk');
    const y = W.h(x, z) - 0.2;
    node.setPos(x, y, z);
    node.setRotY(s.yaw);
    node.add(W.meshG(obS, W.M.stone));
    const rm = W.meshG(obR, W.M.glow);
    rm.castShadow = false;
    node.add(rm);
    W.scene.add(node);
    W.physics.addCircle(x, z, 0.8, { yMax: y + 7 });
    W.physics.addSurface({ type: 'disc', x, z, r: 0.65, top: y + 7.4, bottom: y + 6.4 });
    W.occ.add(x, z, 1.5);
  }
  const [ox, oz] = R.world.tr(17, 17);
  addShard(W, ox, oz, W.h(ox, oz) - 0.2 + 7.4);
  const [bx, bz] = R.world.tr(14.6, 19.8);
  bouncePad(W, bx, bz);
  addShard(W, ...R.world.tr(0, 2.2), W.anchors.pyramidTop[1]);
  const [gx, gz] = R.world.tr(-11, 27);
  addGate(ctx, 'pyramid', 'Álompiramis', gx, gz, s.yaw + 0.3);
  const [lx, lz] = R.world.tr(8, 25);
  addLore(ctx, lx, lz, s.yaw);
}

// ---------------------------------------------------------------- Lebegő szigetek: a spiral of floating islands
function islands(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.islands;
  const g0 = W.h(s.x, s.z);
  let dir = rng.range(0, TAU);
  const turn = rng.sign();
  const first = bouncePad(W, s.x, s.z);
  let bx = s.x, bz = s.z, padTop = first.y;
  const list = [];
  for (let i = 0; i < 7; i++) {
    const R0 = 5.2 - i * 0.3;
    const cx = bx + Math.cos(dir) * (R0 + 1.4), cz = bz + Math.sin(dir) * (R0 + 1.4);
    const top = padTop + 3.2;
    const isl = Wd.floatingIsland(W.ctx, 200 + i + L.seed, R0);
    isl.node.setPos(cx, top, cz);
    isl.node.setRotY(rng.range(0, TAU));
    W.scene.add(isl.node);
    // (v8) walkable exactly where the island's top is drawn (its rim is ragged, and the island is turned)
    isl.node.updateWorld(null, true);
    const im = isl.node.children.find((n) => n.name === 'island');
    const surf = geometrySurface(W.physics, [{ g: im.geometry.cpu, m: im.world }], { cell: 0.3, bottom: top - Math.max(2, isl.depth * 0.8), sink: 0.0 });
    list.push({ x: cx, z: cz, top: surf.top, R: R0, node: isl.node, base: top, surf });
    dir += rng.range(0.45, 0.8) * turn;
    if (i < 6) {
      bx = cx + Math.cos(dir) * (R0 - 1.3);
      bz = cz + Math.sin(dir) * (R0 - 1.3);
      const pad = bouncePad(W, bx, bz, W.physics.topAt(surf, bx, bz) - 0.05);
      padTop = pad.y;
    }
  }
  W.islands = list;
  const topI = list[list.length - 1];
  const shrine = new Geometry();
  shrine.append(Geometry.cylinder(0.45, 0.6, 1.0, 8, 1));
  const ring = Geometry.torus(0.9, 0.06, 5, 20);
  ring.rotateX(Math.PI / 2);
  ring.translate(0, 1.6, 0);
  shrine.append(ring);
  shrine.setColor(C('#4a5070'), 1);
  const sh = W.mesh(shrine, W.M.stoneFine, 'shrine');
  sh.setPos(topI.x, topI.top - 0.05, topI.z);
  W.scene.add(sh);
  W.physics.addCircle(topI.x, topI.z, 0.55, { yMin: topI.top - 0.5, yMax: topI.top + 0.95 });
  W.anchors.islandShrine = [topI.x, topI.top + 1.6, topI.z];
  addShard(W, list[2].x, list[2].z, list[2].top);
  addShard(W, list[4].x, list[4].z, list[4].top);
  W.light([topI.x, topI.top + 2.2, topI.z], C('#bfe6ff'), 3, 11, 0.1, 2);
  W.scene.add(jellyfish(W.gl, 14, [s.x, g0, s.z], { spread: 36, yBase: 10, height: 26, color: [0.55, 0.6, 1.7], seed: 8 }));
  W.fireflies([s.x, s.z], 30, 40, C('#dfe6ff'), { seed: 41, h: 6 });
  const lp = W.freeSpot(rng, s.x, s.z, 14, 1.5);
  if (lp) addLore(ctx, lp[0], lp[1], rng.range(0, TAU));
}

// ---------------------------------------------------------------- Kristálymező
function crystal(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.crystal;
  const giants = [];
  for (let i = 0; i < 6; i++) {
    const p = W.freeSpot(rng, s.x, s.z, 24, 3);
    if (!p) continue;
    const g = Wd.crystalCluster(500 + i, 7);
    const col = C(rng.pick(['#9d7bff', '#6fe6ff', '#ff8ad8', '#8fb0ff']));
    g.setColor(col, 1);
    const m = W.mesh(g, W.M.crystal, 'bigCrystal');
    const sc = rng.range(2.4, 4.2);
    const y = W.h(p[0], p[1]) - 0.3;
    m.setPos(p[0], y, p[1]);
    m.setScale(sc);
    m.setRotY(rng.range(0, TAU));
    W.scene.add(m);
    W.physics.addCircle(p[0], p[1], sc * 0.45, { yMax: y + sc * 2 });
    if (i < 4) W.light([p[0], y + sc * 1.4, p[1]], col.map((v) => v * 1.2 + 0.1), 3.5, 12, 0.08);
    giants.push({ x: p[0], z: p[1], y, sc });
  }
  const lens = W.freeSpot(rng, s.x, s.z, 18, 1.5) || [s.x + 4, s.z];
  W.anchors.lensSpot = [lens[0], W.h(lens[0], lens[1]), lens[1]];
  W.scene.add(jellyfish(W.gl, 16, [s.x, W.h(s.x, s.z), s.z], { spread: 30, yBase: 6, height: 14, color: [0.8, 0.5, 1.6], seed: 9 }));
  sparkles(W, [s.x, s.z], 30, 120, ['#c9a8ff', '#a8f0ff'], { h0: 0.3, h1: 4, seed: 51 });
  const p2 = W.freeSpot(rng, s.x, s.z, 20, 1.5);
  if (p2) addLore(ctx, p2[0], p2[1], rng.range(0, TAU));
  if (giants[0]) addShard(W, giants[0].x + giants[0].sc * 0.9, giants[0].z);
  const p3 = W.freeSpot(rng, s.x, s.z, 26, 1);
  if (p3) addShard(W, p3[0], p3[1]);
}

// ---------------------------------------------------------------- Lidércláp: the will-o'-wisp swamp
function swamp(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.swamp;
  const pond = L.lakes.find((l) => l.id === 'swampPond');
  const pads = new Geometry();
  for (let i = 0; i < 46; i++) {
    const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * pond.r * 0.9;
    const x = pond.x + Math.cos(a) * d, z = pond.z + Math.sin(a) * d;
    if (W.waterDepth(x, z) < 0.15) continue;
    const r = rng.range(0.35, 0.85);
    const p = Geometry.disc(r, 12);
    p.translate(x, L.waterLevel + 0.03, z);
    p.setColor(C(rng.pick(['#1f5a46', '#23604a', '#1a4d44'])), 1);
    pads.append(p);
    if (rng.chance(0.4)) {
      const bud = Geometry.sphere(0.12, 8, 6);
      bud.scale(1, 1.3, 1);
      bud.translate(x + r * 0.3, L.waterLevel + 0.15, z);
      bud.setColor(C(rng.pick(['#ffb8f0', '#b8f0ff', '#fff0b8'])), 1);
      bud.setExtra([2.2]);
      pads.append(bud);
    }
  }
  const pm = W.mesh(pads, W.M.glowSoft, 'lilyPads');
  pm.castShadow = false;
  pm.maxDistance = 120;
  W.scene.add(pm);
  // will-o'-wisps: floating orbs with their own light
  const orb = Geometry.sphere(0.18, 10, 8);
  orb.setColor(C('#bfe0ff'), 1);
  orb.setExtra([4]);
  const orbG = W.gpu(orb);
  for (let i = 0; i < 4; i++) {
    const home = [pond.x + rng.range(-pond.r, pond.r) * 0.8, 0, pond.z + rng.range(-pond.r, pond.r) * 0.8];
    const light = W.light([home[0], L.waterLevel + 1.5, home[2]], C('#7fb8ff'), 2.2, 7, 0.2);
    const node = W.meshG(orbG, W.M.glow, 'wisp');
    node.castShadow = false;
    W.scene.add(node);
    W.wisps.push({ home, light, node, seed: rng.next() * 10 });
  }
  W.animated.push((t) => {
    for (const w of W.wisps) {
      const x = w.home[0] + Math.sin(t * 0.3 + w.seed) * 6 + Math.sin(t * 0.71 + w.seed * 2) * 2;
      const z = w.home[2] + Math.cos(t * 0.27 + w.seed) * 6;
      const y = Math.max(W.h(x, z), L.waterLevel) + 1.2 + Math.sin(t * 1.3 + w.seed) * 0.5;
      w.node.setPos(x, y, z);
      w.light.position = [x, y, z];
    }
  });
  const mf = particleSystem(W.gl, 90, { FIREFLY: 1 }, (i, r) => {
    const a = r.range(0, TAU), d = Math.sqrt(r.next()) * 34;
    const x = s.x + Math.cos(a) * d, z = s.z + Math.sin(a) * d;
    return { p: [x, Math.max(W.h(x, z), L.waterLevel) + r.range(0.3, 2.5), z], params: [r.range(0.5, 1.5), 0, 0, 0], size: r.range(0.15, 0.3), speed: r.range(0.3, 0.7), spread: r.range(1, 3), color: C('#8fc4ff'), intensity: 4 };
  }, { seed: 61 });
  mf.maxDistance = 140;
  W.scene.add(mf);
  // a stump in the pond with a shard on it
  const a = rng.range(0, TAU);
  const sx = pond.x + Math.cos(a) * pond.r * 0.4, sz = pond.z + Math.sin(a) * pond.r * 0.4;
  const stump = Geometry.cylinder(0.55, 0.7, 1.4, 10, 1);
  stump.setColor(C('#3a3440'), 1);
  const st = W.mesh(stump, W.M.bark, 'stump');
  const sy = W.h(sx, sz) - 0.2;
  st.setPos(sx, sy, sz);
  W.scene.add(st);
  W.physics.addSurface({ type: 'disc', x: sx, z: sz, r: 0.62, top: sy + 1.4, bottom: sy - 1 });
  addShard(W, sx, sz, sy + 1.4);
  W.anchors.swampStump = [sx, sy + 1.4, sz];
  const lp = W.freeSpot(rng, s.x, s.z, 30, 1.5, 60, (x, z) => W.waterDepth(x, z) < -0.5);
  if (lp) addLore(ctx, lp[0], lp[1], rng.range(0, TAU));
}

// ---------------------------------------------------------------- Az Alvó Óriás
function giant(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.giant;
  const yaw = s.yaw + rng.range(-0.6, 0.6) + Math.PI / 2;
  const R = W.place(Wd.buildGiant(W.ctx), s.x, s.z, yaw, -1.2);
  W.giant = R;
  const body = R.anchors.body;
  W.animated.push((t) => {
    body.scale[1] = 1 + (Math.sin(t * 0.55) * 0.5 + 0.5) * 0.025;
  });
  const mouth = R.world.tp(R.anchors.mouth);
  const snore = particleSystem(W.gl, 14, { RISE: 1, SMOKE: 1 }, (i, r) => ({ p: [mouth[0], mouth[1], mouth[2]], params: [0.5, 2.6, 0.5, 1], size: 1.1, life: r.range(3, 5), speed: r.range(2, 3.5), spread: 0.6, color: [0.12, 0.14, 0.24], intensity: 1 }), { blend: 'normal', seed: 71 });
  snore.maxDistance = 120;
  W.scene.add(snore);
  W.anchors.giantMouth = mouth;
  const [bx, bz] = R.world.tr(13, 2);
  bouncePad(W, bx, bz);
  addShard(W, ...R.world.tr(0, -13.5), R.world.y + 5.0);
  addShard(W, ...R.world.tr(3.8, 20), R.world.y + 6.4);
  const [lx, lz] = R.world.tr(-13, -6);
  addLore(ctx, lx, lz, yaw + Math.PI / 2);
  W.fireflies([s.x, s.z], 30, 40, C('#b6ffcf'), { seed: 72 });
}

// ---------------------------------------------------------------- Hullócsillag-kráter
function crater(ctx) {
  const { W, L } = ctx;
  const s = L.sites.crater;
  const R = W.place(Wd.buildStarHeart(W.ctx), s.x, s.z, s.yaw, 0);
  W.starHeart = R;
  const star = R.anchors.star;
  W.animated.push((t) => {
    star.setEuler(t * 0.2, t * 0.35, 0);
    star.position[1] = 3.2 + Math.sin(t * 0.9) * 0.3;
  });
  const c = R.world.tp([0, 3.2, 0]);
  W.anchors.starHeart = c;
  const up = particleSystem(W.gl, 110, { RISE: 1, STAR: 1 }, (i, r) => ({ p: [c[0] + r.range(-4, 4), R.world.y + 0.2, c[2] + r.range(-4, 4)], params: [1, 0.3, 0.6, 0.2], size: r.range(0.08, 0.2), life: r.range(3, 6), speed: r.range(4, 10), spread: 2.5, color: C(r.pick(['#ffe2a0', '#bfe6ff'])), intensity: 4.5 }), { seed: 81 });
  up.maxDistance = 220;
  W.scene.add(up);
  const [lx, lz] = frame(s)(0, 25);
  addLore(ctx, lx, lz, s.yaw + Math.PI);
  const [sx, sz] = frame(s)(-9, 3);
  addShard(W, sx, sz);
}

// ---------------------------------------------------------------- A Kék Láng köre
function runeCircle(ctx) {
  const { W, L } = ctx;
  const s = L.sites.rune;
  const R = W.place(S.buildRuneCircle(W.ctx, runeTexture(W.gl)), s.x, s.z, s.yaw, 0);
  W.runes = R;
  W.anchors.rune = R.world;
  const fl = R.world.tp(R.anchors.flame);
  const add = (m) => { m.maxDistance = 140; W.scene.add(m); };
  add(particleSystem(W.gl, 70, { RISE: 1, FLAME: 1 }, (i, r) => ({ p: [fl[0] + r.range(-0.7, 0.7), fl[1], fl[2] + r.range(-0.7, 0.7)], params: [1.3, 0.2, 0.45, 0.1], size: 1.4, life: r.range(0.8, 1.4), speed: r.range(1.8, 3.2), spread: 0.25, color: C('#3a8cff'), intensity: 3.2 }), { seed: 18 }));
  add(particleSystem(W.gl, 50, { RISE: 1, STAR: 1 }, (i, r) => ({ p: [fl[0] + r.range(-0.5, 0.5), fl[1] + 0.5, fl[2] + r.range(-0.5, 0.5)], params: [1.0, 0.3, 0.6, 0.3], size: 0.18, life: r.range(1.5, 3), speed: r.range(3, 6), spread: 0.8, color: C('#9fd0ff'), intensity: 4 }), { seed: 19 }));
  const gm = flora.giantMushroom(11, { capRatio: 0.5, bend: 0.1, stemR: 0.06, variant: 1 });
  const [gx, gz] = R.world.tr(15, -17);
  const node = new Node('greatMushroom');
  const gy = W.h(gx, gz) - 0.5;
  node.setPos(gx, gy, gz);
  node.setScale(34);
  node.add(W.mesh(gm.stem, W.M.stem));
  node.add(W.mesh(gm.cap, W.M.greatCap));
  W.scene.add(node);
  W.physics.addCircle(gx, gz, 34 * 0.075, { yMax: gy + 34 * gm.capY - 0.5 });
  W.light([gx - 6, gy + 25, gz + 8], C('#8a90ff'), 5, 28, 0, 3);
  W.occ.add(gx, gz, 8);
}

// ---------------------------------------------------------------- Légyölő-liget: huge bouncy fly agarics
function amanitaGrove(ctx) {
  const { W, L, rng } = ctx;
  const s = L.sites.amanita;
  const geo = flora.amanita(33, { capRatio: 0.48, open: 0.75 });
  const gS = W.gpu(geo.stem), gC = W.gpu(geo.cap);
  const prof = capProfile(geo.cap);
  const R = 0.48, top = 0.82 + R * (0.7 - 0.75 * 0.35);
  const list = [];
  // a rising chain of 6 big caps + some loose ones
  let a = rng.range(0, TAU);
  for (let i = 0; i < 10; i++) {
    const chain = i < 6;
    const sc = chain ? 4 + i * 1.7 : rng.range(3, 6);
    let x, z;
    if (chain) {
      if (i > 0) {
        const prev = list[i - 1];
        a += rng.range(0.6, 1.0);
        const d = prev.sc * R + sc * R + 1.4;
        x = prev.x + Math.cos(a) * d; z = prev.z + Math.sin(a) * d;
      } else { x = s.x + Math.cos(a) * 10; z = s.z + Math.sin(a) * 10; }
      if (W.waterDepth(x, z) > -0.3) continue;
    } else {
      const p = W.freeSpot(rng, s.x, s.z, 28, sc * R + 1);
      if (!p) continue;
      [x, z] = p;
    }
    const y = W.h(x, z) - 0.15;
    const n = new Node('bigAmanita');
    const yaw = rng.range(0, TAU);
    n.setPos(x, y, z);
    n.setScale(sc);
    n.setRotY(yaw);
    n.add(W.meshG(gS, W.M.stem), W.meshG(gC, W.M.amanitaCap));
    W.scene.add(n);
    W.physics.addCircle(x, z, sc * 0.1, { yMax: y + sc * 0.78 });
    W.physics.addSurface(capSurface(prof, x, y, z, yaw, sc, { bounce: 14, tag: 'bounce' }));
    list.push({ x, z, y, sc, top: y + sc * top });
    W.occ.add(x, z, sc * R + 0.5);
  }
  if (list.length) {
    const f = list[0], nb = list[1] || s;
    const dx = f.x - nb.x, dz = f.z - nb.z, dl = Math.hypot(dx, dz) || 1;
    bouncePad(W, f.x + (dx / dl) * (f.sc * R + 1.8), f.z + (dz / dl) * (f.sc * R + 1.8));
    const hi = list.reduce((b, c) => (c.top > b.top ? c : b), list[0]);
    addShard(W, hi.x, hi.z, hi.top + 3.0);
  }
  W.amanitas = list;
  const [px, pz] = frame(s)(3, 6);
  W.anchors.pottom = [px, W.h(px, pz), pz];
  sparkles(W, [s.x, s.z], 30, 70, ['#ffd0a0', '#fff0c0'], { seed: 64 });
  const p = W.freeSpot(rng, s.x, s.z, 24, 1.5);
  if (p) addLore(ctx, p[0], p[1], rng.range(0, TAU));
  W.fireflies([s.x, s.z], 34, 50, C('#ffcf9a'), { seed: 65 });
}

// ---------------------------------------------------------------- Holdarc-kert
function moonGarden(ctx) {
  const { W, L } = ctx;
  const s = L.sites.moongarden;
  const R = W.place(S.buildMoonStatue(W.ctx), s.x, s.z, s.yaw, -0.6);
  W.moon = R;
  const mc = R.world.tp([0, 6, 0]);
  const sw = particleSystem(W.gl, 140, { FIREFLY: 1, STAR: 1 }, (i, r) => ({ p: [mc[0] + r.range(-7, 7), mc[1] + r.range(-5, 6), mc[2] + r.range(-7, 7)], params: [r.range(1, 4), 0, 0, 0], size: r.range(0.08, 0.2), speed: r.range(0.3, 0.9), spread: r.range(0.5, 2), color: C('#d0e0ff'), intensity: 5 }), { seed: 25 });
  sw.maxDistance = 150;
  W.scene.add(sw);
  W.scene.add(butterflies(W.gl, 40, [mc[0], mc[1] - 3, mc[2]], { radius: 7, height: 4, color: [0.25, 0.55, 2.6], seed: 3 }));
  const [bx, bz] = R.world.tr(5.5, 5);
  const pad = bouncePad(W, bx, bz);
  addShard(W, bx, bz, pad.y + 4.0);
  const [lx, lz] = R.world.tr(-6, 8);
  addLore(ctx, lx, lz, s.yaw);
  W.fireflies([s.x, s.z], 30, 60, C('#dfe6ff'), { seed: 5 });
}

// ---------------------------------------------------------------- Egyszemű Kő
function watcher(ctx) {
  const { W, L } = ctx;
  const s = L.sites.watcher;
  W.watcher = W.place(S.buildWatcher(W.ctx), s.x, s.z, s.yaw, -0.8);
  addShard(W, ...W.watcher.world.tr(-7.5, 3));
  W.fireflies([s.x, s.z], 28, 40, C('#8aff9a'), { seed: 6 });
}

// ---------------------------------------------------------------- Csillagász tornya
function tower(ctx) {
  const { W, L } = ctx;
  const s = L.sites.tower;
  const R = W.place(Wd.buildTower(W.ctx), s.x, s.z, s.yaw, -0.2);
  W.tower = R;
  W.anchors.towerTop = R.world.tp(R.anchors.top);
  W.anchors.towerFoot = R.world.tp(R.anchors.stairBottom);
  addShard(W, ...R.world.tr(R.anchors.top[0] - 1.6, 1.6), W.anchors.towerTop[1]);
  W.fireflies([s.x, s.z], 24, 30, C('#ffe9b8'), { seed: 91, h: 8 });
}

// ---------------------------------------------------------------- Feledés romjai
function ruins(ctx) {
  const { W, L } = ctx;
  const s = L.sites.ruins;
  const R = W.place(Wd.buildRuins(W.ctx, 5 + L.seed), s.x, s.z, s.yaw, -0.1);
  W.ruins = R;
  const tops = R.anchors.tops.slice().sort((a, b) => b[1] - a[1]);
  for (const t of tops.slice(0, 2)) addShard(W, ...R.world.tr(t[0], t[2]), R.world.y + t[1]);
  const [bx, bz] = R.world.tr(0, -4);
  bouncePad(W, bx, bz);
  const [lx, lz] = R.world.tr(0, 10);
  addLore(ctx, lx, lz, s.yaw + Math.PI);
  const [l2x, l2z] = R.world.tr(-10, -12);
  addLore(ctx, l2x, l2z, s.yaw);
  W.fireflies([s.x, s.z], 26, 40, C('#9fd0ff'), { seed: 95 });
}

// ---------------------------------------------------------------- lamps along the roads
function roadLamps(ctx) {
  const { W, rng } = ctx;
  const T = W.terrain;
  const lamp = S.buildLampPost(W.ctx);
  for (const p of T.paths) {
    const pts = p.pts || p.points;
    for (let i = 3; i < pts.length - 3; i += 5 + rng.int(0, 6)) {
      if (rng.chance(0.5)) continue;
      const a = pts[i], b = pts[i + 1];
      const dx = b[0] - a[0], dz = b[1] - a[1], dl = Math.hypot(dx, dz) || 1;
      const side = rng.sign();
      const off = (p.width || 3) / 2 + 1.1;
      const x = a[0] - (dz / dl) * off * side, z = a[1] + (dx / dl) * off * side;
      if (W.waterDepth(x, z) > -0.3 || !W.occ.free(x, z, 2)) continue;
      const yaw = Math.atan2(a[0] - x, a[1] - z) - Math.PI / 2;
      const R = W.place(cloneStructure(lamp), x, z, yaw, -0.05);
      R.root.traverse((n) => { if (n.geometry) n.maxDistance = 160; });
      (W.lampSpots = W.lampSpots || []).push(R.world.tp([0.9, 1.95, 0]));
      W.occ.add(x, z, 1.5);
    }
  }
}

// ---------------------------------------------------------------- bridges where roads cross the rivers
function bridges(ctx) {
  const { W, L } = ctx;
  W.bridges = [];
  L.bridges.forEach((b, i) => {
    const span = b.span;
    const fx = Math.sin(b.yaw), fz = Math.cos(b.yaw);
    // each end sits on its own bank (a gorge can have one bank much higher than the other)
    const bank = (sg) => {
      let h = -Infinity;
      for (const d of [0, 0.6, 1.2]) h = Math.max(h, W.h(b.x + sg * fx * (span / 2 + d), b.z + sg * fz * (span / 2 + d)));
      return Math.max(h, L.waterLevel + 0.6) - 0.04;
    };
    const hA = bank(-1), hB = bank(1);
    const y = hA;
    const road = L.paths.find((p) => p.id === b.road);
    const ca = Math.cos(b.yaw), sa = Math.sin(b.yaw);
    const ground = (lx, lz) => W.h(b.x + lx * ca + lz * sa, b.z - lx * sa + lz * ca) - y;
    const R = W.place(Wd.buildBridge(W.ctx, { span, width: (road ? road.width : 3) + 1.0, rise: b.stone ? 1.4 : 0.7, stone: b.stone, seed: 40 + i, endA: 0, endB: hB - hA, ground }), b.x, b.z, b.yaw, 0, { y });
    W.occ.add(b.x, b.z, span / 2 + 3);
    W.bridges.push({ x: b.x, z: b.z, y, yaw: b.yaw, span, R });
  });
}

// launch speed that carries you a little above a target height (so small caps are easy to land on)
function launch(fromY, toY) {
  return Math.max(12.5, Math.min(19, Math.sqrt(2 * 21 * Math.max(1, toY - fromY + 2.6))));
}
