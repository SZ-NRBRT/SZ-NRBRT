// The sky layer: the Cloud Harbour (Felhőkikötő) above the village, the Sky Garden (Felhőkert) above the
// floating islands, the wind wells (szélkutak) that carry you up, drifting cloud banks and shooting stars.
// Everything here is static scenery plus physics surfaces; game/skylife.js brings it to life.
import { Geometry } from '../engine/geometry.js';
import { noise } from '../engine/noise.js';
import { RNG, TAU, lerp } from '../engine/math.js';
import { C } from '../models/materials.js';
import * as Wd from '../models/wonders.js';
import * as S from '../models/structures.js';
import * as SK from '../models/sky.js';
import * as flora from '../models/flora.js';
import { particleSystem } from './fx.js';
import { addShard, addLore, sparkles } from './sites.js';
import { geometrySurface } from './hull.js';

export const HARBOUR_Y = 48;
export const GARDEN_Y = 100;

export function buildSky(ctx) {
  const { W, L } = ctx;
  const rng = new RNG(L.seed * 5 + 404);
  W.sky = { updrafts: [], docks: {}, regions: [], curios: [], puffs: [] };
  harbour(ctx, rng);
  garden(ctx, rng);
  cloudBanks(ctx, rng);
  meteors(W, rng);
  for (const r of W.sky.regions) W.regions.push(r);
}

// ---------------------------------------------------------------- shared pieces
// a floating island whose walkable top follows the drawn (noisy) outline
function skyIsland(W, x, y, z, R0, seed, top) {
  const isl = Wd.floatingIsland(W.ctx, seed, R0, { top });
  isl.node.setPos(x, y, z);
  W.scene.add(isl.node);
  const prof = [[0, 0.35], [0.5, 0.3], [0.9, 0.12], [1.0, -0.1]];
  const heightAt = (t) => {
    for (let i = 1; i < prof.length; i++) {
      if (t <= prof[i][0]) {
        const a = prof[i - 1], b = prof[i];
        return lerp(a[1], b[1], (t - a[0]) / (b[0] - a[0]));
      }
    }
    return null;
  };
  const edge = (lx, lz) => {
    const a = Math.atan2(lz, lx);
    return 1 + noise.n2(Math.cos(a) * 1.4 + seed, Math.sin(a) * 1.4) * 0.16;
  };
  // (v8) the walkable top is taken from the island mesh itself: its ragged rim included
  isl.node.updateWorld(null, true);
  const im = isl.node.children.find((n) => n.name === 'island');
  const surf = geometrySurface(W.physics, [{ g: im.geometry.cpu, m: im.world }], { cell: 0.3, bottom: y - isl.depth * 0.8, sink: 0.0 });
  return { ...isl, x, y, z, R: R0, surf, edge, top: (px, pz) => W.physics.topAt(surf, px, pz) };
}

// flowers and little glowing mushrooms scattered over an island top (kept clear of the given spots)
function garnish(W, isl, rng, n, keep, cols) {
  const plants = new Geometry();
  const glow = new Geometry();
  const fl = cols.map((c, i) => flora.flower(1500 + i, c));
  const gc = [flora.glowShroomCluster(1600, 3), flora.glowShroomCluster(1601, 5)];
  for (let i = 0; i < n; i++) {
    const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * isl.R * 0.86;
    const x = isl.x + Math.sin(a) * d, z = isl.z + Math.cos(a) * d;
    if (keep.some((k) => Math.hypot(k[0] - x, k[1] - z) < k[2])) continue;
    const y = isl.top(x, z);
    if (y === null) continue;
    const mush = rng.chance(0.3);
    const g = (mush ? rng.pick(gc) : rng.pick(fl)).clone();
    g.scale(mush ? rng.range(0.8, 1.4) : rng.range(0.9, 1.6));
    g.rotateY(rng.range(0, TAU));
    g.translate(x, y - 0.02, z);
    (mush ? glow : plants).append(g);
  }
  for (const [geo, name] of [[plants, 'skyFlowers'], [glow, 'skyShrooms']]) {
    if (!geo.vertexCount) continue;
    const m = W.mesh(geo, W.M.plants, name);
    m.castShadow = false;
    m.maxDistance = 90;
    W.scene.add(m);
  }
}

// merge a set of puffs into one mesh; optionally make them walkable
function puffGroup(W, list, { walk = false, name = 'clouds', shadow = false, dist = 600 } = {}) {
  const g = new Geometry();
  for (const p of list) {
    const pg = SK.cloudPuff(p.seed, p.R, { flat: p.flat ?? 0.5, glow: (p.glow ?? 0.1) * 0.4, tint: p.tint, shade: p.shade, blobs: p.blobs ?? 7, seg: p.seg ?? 10 });
    let top = -Infinity;
    for (let i = 1; i < pg.p.length; i += 3) top = Math.max(top, pg.p[i]);
    if (p.yaw) pg.rotateY(p.yaw);
    if (p.sy) pg.scale(1, p.sy, 1);
    pg.translate(p.x, p.y, p.z);
    g.append(pg);
    if (walk) {
      // (v8) you can stand wherever the cloud is drawn (its blobs reach well past a simple disc)
      p.surf = geometrySurface(W.physics, [{ g: pg, m: null }], { cell: 0.25, bottom: p.y - p.R * 0.3, sink: 0.1, soft: true });
      p.top = p.surf.top;
    }
    W.sky.puffs.push(p);
  }
  const m = W.mesh(g, W.M.cloud, name);
  m.castShadow = shadow;
  m.maxDistance = dist;
  W.scene.add(m);
  return m;
}

// a wind well: a spiralling column of streaks that lifts whoever steps in
function windWell(W, id, x, z, y0, y1, r, exit, { active = null, ground = false } = {}) {
  const u = { id, x, z, y0, y1, r, exit, active };
  W.sky.updrafts.push(u);
  const h = y1 - y0 + 4;
  const n = Math.round(50 + h * 1.3);
  const m = particleSystem(W.gl, n, { SWIRL: 1 }, (i, rr) => ({
    p: [x, y0 - 0.6, z], seed: rr.next(), params: [0.5, 1.3, 0.82, r],
    size: rr.range(0.45, 0.8), life: h / rr.range(8, 12), speed: h, spread: rr.range(1.2, 3.2),
    color: C(rr.pick(['#bfe8ff', '#d8ccff', '#f4f2ff'])), intensity: rr.range(1.0, 1.6),
  }), { seed: 71 + W.sky.updrafts.length });
  m.boundsWorld = [x, (y0 + y1) / 2, z, h / 2 + r + 3];
  m.maxDistance = 320;
  W.scene.add(m);
  u.fx = m;
  if (ground) {
    // a ring of old stones with a faintly glowing floor: you can see the wind well from afar
    const rim = SK.mirrorRim(r + 0.35, 17 + W.sky.updrafts.length);
    const node = W.mesh(rim.rim, W.M.stone, 'windRim');
    node.setPos(x, y0 - 0.05, z);
    W.scene.add(node);
    const floor = Geometry.disc(r + 0.2, 28);
    floor.translate(0, 0.03, 0);
    floor.paint((p) => [0.35, 0.6, 1.0, 1]);
    floor.paintExtra((p) => [0.45 + 0.35 * Math.sin(Math.atan2(p[2], p[0]) * 3 + Math.hypot(p[0], p[2]) * 4)]);
    const fm = W.mesh(floor, W.M.glowSoft, 'windFloor');
    fm.castShadow = false;
    fm.setPos(x, y0 - 0.05, z);
    W.scene.add(fm);
    W.light([x, y0 + 1.2, z], C('#9fd8ff'), 1.8, 7, 0.1, 3);
    W.occ.add(x, z, r + 3);
  }
  return u;
}

// wooden pier from (x0,z0) along direction yaw; deck at y. Returns its end point and surfaces.
function pier(W, x0, z0, yaw, y, len, width = 2.6, seed = 3) {
  const P = SK.skyPier(len, width, seed);
  const node = W.mesh(P.wood, W.M.planks, 'skyPier');
  node.setPos(x0, y, z0);
  node.setRotY(yaw);
  W.scene.add(node);
  const fr = W.mesh(P.frame, W.M.metal, 'pierLamps');
  fr.setPos(x0, y, z0); fr.setRotY(yaw); fr.castShadow = false;
  W.scene.add(fr);
  const gl = W.mesh(P.glass, W.M.glowSoft, 'pierGlass');
  gl.setPos(x0, y, z0); gl.setRotY(yaw); gl.castShadow = false;
  W.scene.add(gl);
  const c = Math.cos(yaw), s = Math.sin(yaw);
  const tr = (lx, lz) => [x0 + lx * c + lz * s, z0 - lx * s + lz * c];
  for (const q of P.lamps) {
    const [wx, wz] = tr(q[0], q[2]);
    W.light([wx, y + q[1], wz], C('#ffc070'), 2.0, 8, 0.12, 2);
  }
  const mid = tr(0, len / 2);
  W.physics.addSurface({ type: 'box', x: mid[0], z: mid[1], hx: width / 2 + 0.1, hz: len / 2, yaw, top: y, bottom: y - 0.45 });
  // rope rails keep you on the deck (the far end stays open)
  for (const sd of [-1, 1]) {
    const a = tr(sd * (width / 2 - 0.13), 0.6), b = tr(sd * (width / 2 - 0.13), len - 0.2);
    W.physics.addSeg(a[0], a[1], b[0], b[1], 0.1, { yMin: y - 0.2, yMax: y + 1.2 });
  }
  const end = tr(0, len - 0.6);
  return { end: [end[0], y, end[1]], dir: [s, c], tr, yaw };
}

// ---------------------------------------------------------------- Felhőkikötő: the Cloud Harbour
function harbour(ctx, rng) {
  const { W, L } = ctx;
  const v = L.sites.village, g = L.sites.glade;
  let bx = v.x - g.x, bz = v.z - g.z;
  const bl = Math.hypot(bx, bz);
  bx /= bl; bz /= bl;
  // the wind well stands behind the village (the cat knows)
  let base = [v.x + bx * 40, v.z + bz * 40];
  const fs = W.freeSpot(rng, base[0], base[1], 10, 3.5);
  if (fs) base = fs;
  const gy = W.h(base[0], base[1]);
  const Y = HARBOUR_Y, R0 = 11;
  // island beyond the well, so the column rises past its wind pier
  const hc = [base[0] + bx * 15.5, base[1] + bz * 15.5];
  const isl = skyIsland(W, hc[0], Y, hc[1], R0, 311, ['#3a4a7c', '#5a6aa0']);
  const toWell = Math.atan2(base[0] - hc[0], base[1] - hc[1]);
  // wind pier: from the rim towards the column
  const wpStart = [hc[0] + Math.sin(toWell) * R0 * 0.8, hc[1] + Math.cos(toWell) * R0 * 0.8];
  const deckY = Y + 0.22;
  const wp = pier(W, wpStart[0], wpStart[1], toWell, deckY, 5.2, 2.4, 21);
  const exit = [hc[0] + Math.sin(toWell) * R0 * 0.55, deckY, hc[1] + Math.cos(toWell) * R0 * 0.55];
  windWell(W, 'village', base[0], base[1], gy, deckY + 2.4, 1.35, exit, { ground: true });
  // the whale pier: on the far side, a little to the left
  const whaleDir = toWell + Math.PI + 0.55;
  const wqStart = [hc[0] + Math.sin(whaleDir) * R0 * 0.78, hc[1] + Math.cos(whaleDir) * R0 * 0.78];
  const wq = pier(W, wqStart[0], wqStart[1], whaleDir, deckY, 9.5, 2.8, 22);
  W.sky.docks.harbour = dock(wq, deckY);
  // clouds hugging the rim (walkable), and a bank below hiding the rock
  const rim = [];
  for (let i = 0; i < 15; i++) {
    const a = (i / 15) * TAU + rng.range(-0.1, 0.1);
    const nearPier = (d) => Math.abs(Math.atan2(Math.sin(a - d), Math.cos(a - d))) < 0.42;
    // puff angle is measured like atan2(dx, dz) of the pier directions
    if (nearPier(toWell) || nearPier(whaleDir)) continue;
    const R = rng.range(1.7, 2.6);
    const w = isl.edge(Math.cos(Math.PI / 2 - a), Math.sin(Math.PI / 2 - a));
    const d = R0 * w * rng.range(0.98, 1.08);
    rim.push({ x: hc[0] + Math.sin(a) * d, y: Y - 0.55, z: hc[1] + Math.cos(a) * d, R, seed: 900 + i, flat: 0.45 });
  }
  puffGroup(W, rim, { walk: true, name: 'harbourRim' });
  const below = [];
  for (let i = 0; i < 7; i++) {
    const a = rng.range(0, TAU), d = rng.range(0, R0 * 0.8);
    const R = rng.range(3.2, 5.2);
    below.push({ x: hc[0] + Math.sin(a) * d, y: Y - R * 1.05 - rng.range(1.5, 5), z: hc[1] + Math.cos(a) * d, R, seed: 940 + i, flat: 0.6, glow: 0.06, shade: '#4c5190' });
  }
  puffGroup(W, below, { name: 'harbourBelow' });
  // lighthouse on the rim, 90° from the wind pier
  const lhA = toWell + Math.PI / 2;
  const lh = [hc[0] + Math.sin(lhA) * R0 * 0.66, hc[1] + Math.cos(lhA) * R0 * 0.66];
  const lhY = isl.top(lh[0], lh[1]) - 0.1;
  const LH = SK.skyLighthouse(7.5);
  for (const [geo, mat] of [[LH.body, W.M.plaster], [LH.trim, W.M.stoneFine], [LH.lamp, W.M.glow]]) {
    const m = W.mesh(geo, mat, 'lighthouse');
    m.setPos(lh[0], lhY, lh[1]);
    m.setRotY(lhA + Math.PI);
    if (mat === W.M.glow) m.castShadow = false;
    W.scene.add(m);
  }
  W.physics.addCircle(lh[0], lh[1], 1.3, { yMin: lhY - 1, yMax: lhY + 9.5 });
  W.light([lh[0], lhY + LH.top, lh[1]], C('#cfeaff'), 2.4, 18, 0.05, 6);
  W.sky.lighthouse = [lh[0], lhY + LH.top, lh[1]];
  // sheep pen near the middle, the bell by the whale pier
  const penA = toWell - Math.PI / 2 + 0.3;
  const pen = [hc[0] + Math.sin(penA) * 4.2, hc[1] + Math.cos(penA) * 4.2];
  const penY = isl.top(pen[0], pen[1]);
  const penGateA = Math.atan2(hc[1] - pen[1], hc[0] - pen[0]); // gate faces the island centre
  const pg = SK.sheepPen(2.6, penGateA - Math.PI / 14, (lx, lz) => (isl.top(pen[0] + lx, pen[1] + lz) ?? penY) - (penY - 0.05));
  const pm = W.mesh(pg, W.M.plaster, 'sheepPen');
  pm.setPos(pen[0], penY - 0.05, pen[1]);
  W.scene.add(pm);
  for (let i = 1; i < 14; i++) {
    const a0 = penGateA - Math.PI / 14 + (i / 14) * TAU, a1 = penGateA - Math.PI / 14 + ((i + 1) / 14) * TAU;
    if (i === 13) break;
    W.physics.addSeg(pen[0] + Math.cos(a0) * 2.6, pen[1] + Math.sin(a0) * 2.6, pen[0] + Math.cos(a1) * 2.6, pen[1] + Math.sin(a1) * 2.6, 0.08, { yMin: penY - 0.3, yMax: penY + 0.8 });
  }
  W.sky.pen = [pen[0], penY, pen[1]];
  const bellP = wq.tr(-2.3, 0.4);
  placeBell(W, bellP[0], bellP[1], isl.top(bellP[0], bellP[1]), whaleDir, 'harbour');
  // lamp posts
  for (const a of [toWell + 0.7, toWell - 0.75, whaleDir + 0.9]) {
    const x = hc[0] + Math.sin(a) * R0 * 0.72, z = hc[1] + Math.cos(a) * R0 * 0.72;
    const R = S.buildLampPost(W.ctx);
    W.place(R, x, z, a + Math.PI, 0, { y: isl.top(x, z) - 0.05, floating: true });
  }
  // a stepping path of clouds off the edge, with a star shard at its end
  const chainA = lhA + 0.5;
  let cx = hc[0] + Math.sin(chainA) * (R0 + 1.2), cz = hc[1] + Math.cos(chainA) * (R0 + 1.2), cy = Y - 0.2;
  const steps = [];
  for (let i = 0; i < 5; i++) {
    const a = chainA + Math.sin(i * 1.3) * 0.5;
    cx += Math.sin(a) * 3.3; cz += Math.cos(a) * 3.3; cy += 0.55;
    steps.push({ x: cx, y: cy, z: cz, R: i === 4 ? 1.9 : rng.range(1.25, 1.5), seed: 960 + i, flat: 0.4, glow: 0.14 });
  }
  puffGroup(W, steps, { walk: true, name: 'cloudSteps' });
  const last = steps[steps.length - 1];
  addShard(W, last.x, last.z, last.top);
  addShard(W, wq.end[0], wq.end[2], deckY);
  // lore stone
  const ls = [hc[0] + Math.sin(toWell + 2.2) * 6.5, hc[1] + Math.cos(toWell + 2.2) * 6.5];
  addLore(ctx, ls[0], ls[1], toWell + 2.2 + Math.PI, isl.top(ls[0], ls[1]));
  // pale motes (the sparkles helper puts them at terrain height: lift them up to the harbour)
  lift(sparkles(W, hc, R0 + 6, 40, ['#dfe6ff', '#bfe8ff', '#ffe0f0'], { h0: 0.5, h1: 5, seed: 77, dist: 160 }), Y + 0.3 - W.h(hc[0], hc[1]));
  garnish(W, { ...isl, R: R0 }, rng, 70, [[pen[0], pen[1], 3.4], [lh[0], lh[1], 2], [ls[0], ls[1], 1.2], [bellP[0], bellP[1], 1.2], [hc[0] + Math.sin(toWell) * R0 * 0.8, hc[1] + Math.cos(toWell) * R0 * 0.8, 2], [wqStart[0], wqStart[1], 2]], ['#9fb4ff', '#f5f1ff', '#e6b8ff', '#ffd6a0']);
  W.sky.harbour = { x: hc[0], y: Y, z: hc[1], R: R0, isl, windPier: wp, whalePier: wq, base: [base[0], gy, base[1]] };
  W.sky.regions.push({ id: 'harbour', name: 'Felhőkikötő', blurb: 'Egy felhőkre kötött sziget. Innen indulnak a bálnák, és ide térnek haza a felhőbárányok.', center: [hc[0], hc[1]], radius: R0 + 12, hidden: false, sky: true, floor: Y - 8 });
  W.anchors.harbour = [hc[0], Y + 0.4, hc[1]];
}

// move a particle system placed at ground height up by dy
function lift(m, dy) {
  if (!m || !m.instanceData) return;
  const d = m.instanceData;
  for (let i = 1; i < d.length; i += 20) d[i] += dy;
  m.updateInstances(d.length / 20);
  if (m.boundsWorld) m.boundsWorld[1] += dy;
}

function dock(p, deckY) {
  // the whale lies broadside across the end of the pier; its saddle is 5.6 m beyond the planks
  const [dx, dz] = p.dir;
  const seat = [p.end[0] + dx * 6.0, deckY + 0.05, p.end[2] + dz * 6.0];
  return { mount: p.end, seat, heading: p.yaw + Math.PI / 2, dir: [dx, dz], deckY };
}

function placeBell(W, x, z, y, yaw, id) {
  const b = SK.skyBell();
  const post = W.mesh(b.post, W.M.wood, 'bellPost');
  post.setPos(x, y - 0.05, z);
  post.setRotY(yaw);
  W.scene.add(post);
  const bell = W.mesh(b.bell, W.M.metal, 'bell');
  bell.setPos(x, y - 0.05, z);
  bell.setRotY(yaw);
  bell.dynamic = true; // it swings
  W.scene.add(bell);
  W.physics.addCircle(x, z, 0.18, { yMin: y - 0.5, yMax: y + 2.8 });
  const c = Math.cos(yaw), s = Math.sin(yaw);
  const ax = x + b.anchor[0] * c, az = z - b.anchor[0] * s;
  (W.sky.bells = W.sky.bells || {})[id] = { node: bell, pos: [ax, y + b.anchor[1], az], yaw, base: [x, y - 0.05, z] };
}

// ---------------------------------------------------------------- Felhőkert: the Sky Garden
function garden(ctx, rng) {
  const { W, L } = ctx;
  const top = W.islands[W.islands.length - 1];
  const g = L.sites.glade;
  let dx = top.x - g.x, dz = top.z - g.z;
  const dl = Math.hypot(dx, dz);
  dx /= dl; dz /= dl;
  // turn a little so the garden hangs over open ground next to the island spiral
  const a0 = Math.atan2(dx, dz) + 0.6;
  dx = Math.sin(a0); dz = Math.cos(a0);
  const Y = GARDEN_Y, R0 = 13;
  // wind column on the top island, beside the shrine
  const col = [top.x + dx * 2.05, top.z + dz * 2.05];
  const colY = W.physics.topAt(top.surf, col[0], col[1]) ?? top.top;
  const gc = [col[0] + dx * 17.5, col[1] + dz * 17.5];
  const isl = skyIsland(W, gc[0], Y, gc[1], R0, 517, ['#2a5a6a', '#4f8a86']);
  const toWell = Math.atan2(col[0] - gc[0], col[1] - gc[1]);
  const deckY = Y + 0.22;
  const wpStart = [gc[0] + Math.sin(toWell) * R0 * 0.8, gc[1] + Math.cos(toWell) * R0 * 0.8];
  const wp = pier(W, wpStart[0], wpStart[1], toWell, deckY, 5.8, 2.4, 31);
  const exit = [gc[0] + Math.sin(toWell) * R0 * 0.55, deckY, gc[1] + Math.cos(toWell) * R0 * 0.55];
  windWell(W, 'islands', col[0], col[1], colY, deckY + 2.4, 1.15, exit, { active: 'gotKeyA' });
  // whale pier
  const whaleDir = toWell + Math.PI - 0.5;
  const wqStart = [gc[0] + Math.sin(whaleDir) * R0 * 0.78, gc[1] + Math.cos(whaleDir) * R0 * 0.78];
  const wq = pier(W, wqStart[0], wqStart[1], whaleDir, deckY, 9.5, 2.8, 32);
  W.sky.docks.garden = dock(wq, deckY);
  const bellP = wq.tr(2.3, 0.4);
  placeBell(W, bellP[0], bellP[1], isl.top(bellP[0], bellP[1]), whaleDir, 'garden');
  // rim clouds and the bank below
  const rim = [];
  for (let i = 0; i < 17; i++) {
    const a = (i / 17) * TAU + rng.range(-0.1, 0.1);
    const nearPier = (d) => Math.abs(Math.atan2(Math.sin(a - d), Math.cos(a - d))) < 0.4;
    if (nearPier(toWell) || nearPier(whaleDir)) continue;
    const R = rng.range(1.8, 2.8);
    const w = isl.edge(Math.cos(Math.PI / 2 - a), Math.sin(Math.PI / 2 - a));
    const d = R0 * w * rng.range(0.98, 1.08);
    rim.push({ x: gc[0] + Math.sin(a) * d, y: Y - 0.6, z: gc[1] + Math.cos(a) * d, R, seed: 1100 + i, flat: 0.45, tint: '#c4bce0' });
  }
  puffGroup(W, rim, { walk: true, name: 'gardenRim' });
  const below = [];
  for (let i = 0; i < 9; i++) {
    const a = rng.range(0, TAU), d = rng.range(0, R0 * 0.85);
    const R = rng.range(3.5, 6);
    below.push({ x: gc[0] + Math.sin(a) * d, y: Y - R * 1.05 - rng.range(1.5, 6), z: gc[1] + Math.cos(a) * d, R, seed: 1140 + i, flat: 0.6, glow: 0.07, shade: '#50508e', tint: '#c4bce0' });
  }
  puffGroup(W, below, { name: 'gardenBelow' });
  // the Sky Mirror: a still pool that shows the forest below
  const mirA = toWell + Math.PI * 0.75;
  const mir = [gc[0] + Math.sin(mirA) * 4.5, gc[1] + Math.cos(mirA) * 4.5];
  const mirY = isl.top(mir[0], mir[1]);
  const MR = SK.mirrorRim(2.5, 41);
  const rm = W.mesh(MR.rim, W.M.stoneFine, 'mirrorRim');
  rm.setPos(mir[0], mirY - 0.04, mir[1]);
  W.scene.add(rm);
  const wm = W.mesh(MR.water, W.M.glass, 'mirror');
  wm.setPos(mir[0], mirY - 0.04, mir[1]);
  wm.castShadow = false;
  W.scene.add(wm);
  W.light([mir[0], mirY + 1.0, mir[1]], C('#9fd8ff'), 2.0, 8, 0.05, 3);
  W.sky.curios.push({ id: 'skymirror', kind: 'sky', name: 'Égtükör', blurb: 'A tó nem az eget tükrözi, hanem a lenti erdőt — fejjel lefelé. Valaki integet belőle.', x: mir[0], z: mir[1], y: mirY, r: 4 });
  // star lilies all around
  const lilyCols = ['#bfe2ff', '#e6c8ff', '#ffd6ec', '#c8fff0'];
  const lg = new Geometry();
  const lilyTops = [];
  for (let i = 0; i < 11; i++) {
    const a = rng.range(0, TAU), d = rng.range(R0 * 0.3, R0 * 0.8);
    const x = gc[0] + Math.sin(a) * d, z = gc[1] + Math.cos(a) * d;
    if (Math.hypot(x - mir[0], z - mir[1]) < 3.6) continue;
    if (Math.abs(Math.atan2(Math.sin(a - whaleDir), Math.cos(a - whaleDir))) < 0.45 || Math.abs(Math.atan2(Math.sin(a - toWell), Math.cos(a - toWell))) < 0.45) continue;
    const Ly = SK.starLily(700 + i, rng.pick(lilyCols));
    Ly.geo.scale(1.35);
    Ly.geo.rotateY(rng.range(0, TAU));
    const y = isl.top(x, z) - 0.05;
    Ly.geo.translate(x, y, z);
    lg.append(Ly.geo);
    W.physics.addCircle(x, z, 0.14, { yMin: y - 0.5, yMax: y + 3 });
    lilyTops.push([x, y + 3.2, z]);
  }
  const lm = W.mesh(lg, W.M.glowSoft, 'starLilies');
  W.scene.add(lm);
  for (const t of lilyTops.slice(0, 4)) W.light(t, C('#cfe6ff'), 1.4, 7, 0.08, 1);
  // a moon gate: once awake, travel here from anywhere
  const gateA = toWell + Math.PI * 1.3;
  const gp = [gc[0] + Math.sin(gateA) * R0 * 0.55, gc[1] + Math.cos(gateA) * R0 * 0.55];
  const gy = isl.top(gp[0], gp[1]);
  const R = W.place(Wd.buildMoonGate(W.ctx, { plinth: false }), gp[0], gp[1], gateA + Math.PI, 0, { y: gy - 0.15, floating: true });
  R.anchors.portal.material.uniforms.uPortalActive = 0;
  W.gates.push({ id: 'garden', name: 'Felhőkert', x: gp[0], z: gp[1], yaw: gateA + Math.PI, y: R.world.y, portal: R.anchors.portal, front: R.world.tp([0, 0, 2.6]) });
  // the sleeping flock mother lies here (skylife.js adds the creature); remember a good spot
  const momA = toWell + Math.PI * 0.2;
  W.sky.flockMother = [gc[0] + Math.sin(momA) * R0 * 0.45, isl.top(gc[0] + Math.sin(momA) * R0 * 0.45, gc[1] + Math.cos(momA) * R0 * 0.45), gc[1] + Math.cos(momA) * R0 * 0.45, momA + Math.PI * 0.5];
  // the highest point of the world: a spiral of clouds, a shard at the top
  const chainA = toWell + Math.PI * 1.75;
  let cx = gc[0] + Math.sin(chainA) * (R0 + 1.0), cz = gc[1] + Math.cos(chainA) * (R0 + 1.0), cy = Y + 0.1;
  const steps = [];
  for (let i = 0; i < 6; i++) {
    const a = chainA + 1.6 + i * 0.95;
    cx += Math.sin(a) * 3.2; cz += Math.cos(a) * 3.2; cy += 0.7;
    steps.push({ x: cx, y: cy, z: cz, R: i === 5 ? 2.0 : rng.range(1.25, 1.5), seed: 1170 + i, flat: 0.4, glow: 0.16, tint: '#c8c0e4' });
  }
  puffGroup(W, steps, { walk: true, name: 'gardenSteps' });
  const last = steps[steps.length - 1];
  addShard(W, last.x, last.z, last.top);
  const behind = [gc[0] + Math.sin(momA + 0.5) * R0 * 0.7, gc[1] + Math.cos(momA + 0.5) * R0 * 0.7];
  addShard(W, behind[0], behind[1], isl.top(behind[0], behind[1]));
  const ls = [gc[0] + Math.sin(toWell - 1.2) * 7.5, gc[1] + Math.cos(toWell - 1.2) * 7.5];
  addLore(ctx, ls[0], ls[1], toWell - 1.2 + Math.PI, isl.top(ls[0], ls[1]));
  lift(sparkles(W, gc, R0 + 8, 60, ['#fff0c0', '#dfe6ff', '#ffc8f0', '#c8fff0'], { h0: 0.5, h1: 7, seed: 78, dist: 200 }), Y + 0.3 - W.h(gc[0], gc[1]));
  garnish(W, { ...isl, R: R0 }, rng, 110, [[mir[0], mir[1], 3.2], [gp[0], gp[1], 3], [W.sky.flockMother[0], W.sky.flockMother[2], 3.2], [ls[0], ls[1], 1.2], [bellP[0], bellP[1], 1.2], [wpStart[0], wpStart[1], 2], [wqStart[0], wqStart[1], 2]], ['#f5f1ff', '#ffc8f0', '#c8fff0', '#fff0a0', '#b8c8ff']);
  W.sky.garden = { x: gc[0], y: Y, z: gc[1], R: R0, isl, windPier: wp, whalePier: wq, column: [col[0], colY, col[1]] };
  W.sky.regions.push({ id: 'skygarden', name: 'Felhőkert', blurb: 'A világ legmagasabb kertje. A csillagliliomok éjjel-nappal világítanak, és a tóban a lenti erdő látszik.', center: [gc[0], gc[1]], radius: R0 + 12, hidden: true, sky: true, floor: Y - 8 });
  W.anchors.skyGarden = [gc[0], Y + 0.4, gc[1]];
}

// ---------------------------------------------------------------- drifting cloud banks (scenery)
function cloudBanks(ctx, rng) {
  const { W } = ctx;
  const list = [];
  const avoid = [W.sky.harbour, W.sky.garden];
  for (let i = 0; i < 12; i++) {
    let x = 0, z = 0;
    for (let k = 0; k < 20; k++) {
      const a = rng.range(0, TAU), d = rng.range(60, 250);
      x = Math.cos(a) * d; z = Math.sin(a) * d;
      if (avoid.every((s) => Math.hypot(s.x - x, s.z - z) > 45)) break;
    }
    const y = rng.range(58, 84);
    const n = rng.int(2, 4);
    for (let j = 0; j < n; j++) {
      list.push({ x: x + rng.range(-9, 9), y: y + rng.range(-1.5, 1.5), z: z + rng.range(-9, 9), R: rng.range(4, 7.5), seed: 1300 + i * 7 + j, flat: 0.45, glow: 0.06, shade: '#4a4f8c', tint: '#c0bce0', blobs: 6, seg: 8, sy: 0.75 });
    }
  }
  puffGroup(W, list, { name: 'cloudBanks', dist: 900 });
}

// ---------------------------------------------------------------- shooting stars
function meteors(W, rng) {
  const m = particleSystem(W.gl, 3, { METEOR: 1 }, (i, r) => ({
    p: [0, 0, 0], seed: r.next(), params: [r.range(0.8, 1.3), r.range(260, 420), r.range(140, 190), 0],
    size: r.range(1.1, 1.8), life: r.range(17, 34), speed: r.range(150, 230), spread: r.range(16, 26),
    color: C(r.pick(['#dff0ff', '#fff4d8', '#e8dcff'])), intensity: r.range(2.2, 3.2),
  }), { bounds: 'none', seed: 91 });
  m.maxDistance = Infinity;
  W.scene.add(m);
  W.sky.meteors = m;
  void rng;
}
