// Heightfield terrain generated from the world layout: rolling hills, an irregular mountain
// border, flattened sites, lakes, a crater, desert dunes and roads. Also builds LOD meshes
// (with skirts) and the data texture used by grass and water shaders.
import { smoothstep, clamp, lerp } from '../engine/math.js';
import { polyDist } from './layout.js';
import { catmullRom } from '../engine/geometry.js';
import { Geometry } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Material } from '../engine/scene.js';
import { createTexture } from '../engine/gl.js';

const SEG_CELL = 16;
// the dream sea: its floor lies just under the surface everywhere beyond the island
export const SEA_DEPTH = 4.5;   // (v7.2: real, deep water around the island, like the lake)
export const SEA_FLOOR = -0.35 - SEA_DEPTH; // (WORLD.waterLevel - SEA_DEPTH)
export const COAST_MIN = 300;   // the island's shore never comes closer than this to the centre
export const SEA_HOLE = 276;    // the sea's own water surface starts here (lakes and rivers live inside)
const hyp = (a, b) => Math.sqrt(a * a + b * b); // faster than Math.hypot in the per-sample loops

export class Terrain {
  constructor(layout) {
    this.L = layout;
    this.noise = layout.noise;
    this.size = layout.size;
    this.half = layout.size / 2;
    this.n = layout.res;
    this.cell = this.size / (this.n - 1);
    this.waterLevel = layout.waterLevel;
    const N = this.n * this.n;
    this.h = new Float32Array(N);
    this.wPath = new Float32Array(N);
    this.wSand = new Float32Array(N);
    this.wRock = new Float32Array(N);
    this.wMoss = new Float32Array(N);
    this.tintA = new Float32Array(N); // crystal violet
    this.tintB = new Float32Array(N); // pale dream sand
    this.grass = new Float32Array(N);
    this.flowers = new Float32Array(N);
    this.ao = new Float32Array(N);
    this.pathDist = new Float32Array(N);
    this.riverD = new Float32Array(N);
    this.buildPaths();
    this.prepareFeatures();
    this.generate();
  }

  // ------------------------------------------------------------ paths & segment index
  buildPaths() {
    this.segGrid = new Map();
    this.paths = this.L.paths.map((p) => {
      const pts = catmullRom(p.points, 6);
      return { ...p, pts, heights: null };
    });
    for (const p of this.paths) {
      for (let i = 0; i < p.pts.length - 1; i++) {
        const a = p.pts[i], b = p.pts[i + 1];
        const minx = Math.min(a[0], b[0]) - 14, maxx = Math.max(a[0], b[0]) + 14;
        const minz = Math.min(a[1], b[1]) - 14, maxz = Math.max(a[1], b[1]) + 14;
        const seg = { p, i };
        for (let gx = Math.floor(minx / SEG_CELL); gx <= Math.floor(maxx / SEG_CELL); gx++) {
          for (let gz = Math.floor(minz / SEG_CELL); gz <= Math.floor(maxz / SEG_CELL); gz++) {
            const k = gx * 10007 + gz;
            let l = this.segGrid.get(k);
            if (!l) this.segGrid.set(k, (l = []));
            l.push(seg);
          }
        }
      }
    }
  }

  nearestPath(x, z, maxD = 12) {
    let best = { d: Infinity, path: null, seg: 0, t: 0 };
    const l = this.segGrid.get(Math.floor(x / SEG_CELL) * 10007 + Math.floor(z / SEG_CELL));
    if (!l) return best;
    for (const { p, i } of l) {
      const a = p.pts[i], b = p.pts[i + 1];
      const vx = b[0] - a[0], vz = b[1] - a[1];
      const l2 = vx * vx + vz * vz || 1;
      let t = ((x - a[0]) * vx + (z - a[1]) * vz) / l2;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const d = Math.hypot(x - (a[0] + vx * t), z - (a[1] + vz * t));
      if (d < best.d && d < maxD) best = { d, path: p, seg: i, t };
    }
    return best;
  }

  // ------------------------------------------------------------ height
  prepareFeatures() {
    const L = this.L, S = L.sites;
    // flatten targets = natural height at each site center (hills included, so a place on a hill stays up there)
    for (const s of L.shapes) s.target = Math.max(1.0, this.shapedHeight(s.c[0], s.c[1]) * 0.75 + 0.8);
    this.rivers = (L.rivers || []).map((r) => ({ ...r, hw: r.width / 2, box: bbox(r.points, r.width + 16) }));
    this.lakes = L.lakes.map((lk) => ({ ...lk, ph: [this.noise.n2(lk.x * 0.1, 3) * 3, this.noise.n2(lk.z * 0.1, 7) * 3] }));
    // cliff with a waterfall on the far side of the big lake
    const lake = S.lake;
    const back = [-Math.sin(lake.yaw), -Math.cos(lake.yaw)];
    this.cliff = { x: lake.x + back[0] * (lake.lakeR + 11), z: lake.z + back[1] * (lake.lakeR + 11), r: 20, h: 16, dir: back };
    this.crater = { x: S.crater.x, z: S.crater.z, r: 21 };
  }

  baseHeight(x, z) {
    const nz = this.noise;
    let h = 2.4;
    h += nz.fbm2(x * 0.0065, z * 0.0065, 5) * 10;
    h += nz.fbm2(x * 0.03 + 7.3, z * 0.03 - 3.1, 3) * 1.4;
    // scattered rounded hills
    const hills = nz.fbm2(x * 0.011 + 91, z * 0.011 - 17, 3);
    h += smoothstep(0.1, 0.55, hills) * 9;
    return h;
  }

  // base terrain + the hand-placed hills, ridges and basins of the map
  shapedHeight(x, z) {
    const L = this.L, nz = this.noise;
    let h = this.baseHeight(x, z);
    for (const hl of L.hills || []) {
      const d = hyp(x - hl.x, z - hl.z) / hl.r;
      if (d >= 1) continue;
      const t = smoothstep(1, hl.top, d);
      h += hl.h * t * (1 + nz.n2(x * 0.05, z * 0.05) * 0.12 * (1 - t));
    }
    for (const rg of L.ridges || []) {
      const { d, t } = segDistT(x, z, rg.a, rg.b);
      const w = rg.w * (1 + nz.n2(x * 0.02 + 5, z * 0.02) * 0.25);
      if (d >= w) continue;
      const prof = smoothstep(w, w * 0.25, d) * Math.sin(t * Math.PI) ** 0.4;
      let hh = rg.h * (0.8 + nz.ridged2(x * 0.03, z * 0.03, 3) * 0.45);
      if (rg.pass) {
        const pd = hyp(x - rg.pass[0], z - rg.pass[1]);
        hh = lerp(rg.passH, hh, smoothstep(rg.passW * 0.35, rg.passW, pd));
      }
      h += hh * prof;
    }
    for (const b of L.basins || []) {
      const d = hyp(x - b.x, z - b.z) / b.r;
      if (d >= 1.3) continue;
      h -= b.depth * (1 - smoothstep(0.3, 1.0, d));
      h += Math.exp(-(((d - 1.05) / 0.16) ** 2)) * b.depth * 0.8; // rocky rim
    }
    return h;
  }

  // distance to the nearest river (minus its half width) and that river
  // (exact within ~35 m of a river, which is all anything uses)
  riverAt(x, z) {
    let best = null, bd = Infinity;
    for (const r of this.rivers) {
      const b = r.box;
      if (x < b[0] || x > b[2] || z < b[1] || z > b[3]) continue;
      const d = (r.index ? r.index.dist(x, z) : polyDist(x, z, r.points).d) - r.hw;
      if (d < bd) { bd = d; best = r; }
    }
    const o = this._rv || (this._rv = { d: 0, river: null });
    o.d = bd; o.river = best;
    return o;
  }
  // carve a river channel into a height (gorges through high ground come for free)
  carveRiver(h, x, z, rv) {
    if (!rv.river) return h;
    const r = rv.river, d = rv.d, hw = r.hw;
    if (d > 6) return h;
    // (v8) a proper channel: deep across most of its width, shallow only close to the banks
    const bed = this.L.waterLevel - r.depth * (1 - smoothstep(-hw * 0.4, 0, d) * 0.75) + this.noise.n2(x * 0.2, z * 0.2) * 0.12;
    const bank = this.L.waterLevel + 0.45;
    if (d < 0) return Math.min(h, bed);
    // banks rise from the water; steep walls where the land is high (a little gorge)
    const t = smoothstep(0, 4, d);
    const target = lerp(bed, Math.max(bank, h), t);
    return Math.min(h, target);
  }

  lakeFactor(lk, x, z) {
    const dx = x - lk.x, dz = z - lk.z;
    // far from the shore the exact wobble doesn't matter (every use saturates below 1.7): a lower bound will do
    const dd = Math.sqrt(dx * dx + dz * dz);
    if (dd > lk.r * 2.25) return dd / (lk.r * 1.31);
    const a = Math.atan2(dz, dx);
    const rr = lk.r * (1 + 0.14 * Math.sin(a * 3 + lk.ph[0]) + 0.08 * Math.sin(a * 5 + lk.ph[1]) + this.noise.n2(x * 0.03, z * 0.03) * 0.07);
    return hyp(dx, dz) / rr;
  }

  rawHeight(x, z) {
    const L = this.L, nz = this.noise;
    let h = this.shapedHeight(x, z);
    const r = hyp(x, z);
    const border = L.borderAt(x, z);
    // desert dunes near the pyramid flatten the land into soft waves
    const b = L.biome(x, z);
    if (b.desert > 0.01) {
      const dune = Math.pow(1 - Math.abs(nz.n2(x * 0.035, z * 0.02)), 3) * 2.2 + nz.fbm2(x * 0.01, z * 0.01, 2) * 1.5;
      h = lerp(h, 1.5 + dune, b.desert * 0.85);
    }
    // no mountain wall any more: the land runs down to a beach and into the endless deep dream sea
    const coast = Math.max(border + 8, COAST_MIN);
    if (r > coast - 60) {
      const cn = nz.n2(x * 0.02, z * 0.02) * 9 + nz.n2(x * 0.07, z * 0.07) * 3;
      const k = smoothstep(coast - 48, coast + 10, r + cn);
      // a gentle beach: the last stretch above the water is flattened, then it dips under the sea
      const beach = lerp(Math.min(h, L.waterLevel + 1.6), SEA_FLOOR, smoothstep(coast - 14, coast + 12, r + cn));
      h = lerp(h, beach, k);
    }
    // flat sites
    for (const s of L.shapes) {
      const d = hyp(x - s.c[0], z - s.c[1]) / s.r;
      if (d >= 1.35) continue;
      const w = 1 - smoothstep(0.55, 1.35, d);
      h = lerp(h, s.target + (h - s.target) * (1 - s.flat), w);
    }
    // waterfall cliff
    {
      const c = this.cliff;
      const d = hyp(x - c.x, z - c.z) / c.r;
      if (d < 1.6) h = Math.max(h, lerp(h, c.h + nz.fbm2(x * 0.08, z * 0.08, 3) * 4, 1 - smoothstep(0.45, 1.6, d)));
    }
    // fallen star crater: raised rim, deep bowl
    {
      const c = this.crater;
      const d = hyp(x - c.x, z - c.z) / c.r;
      if (d < 1.8) {
        const rim = Math.exp(-(((d - 1.0) / 0.22) ** 2)) * 3.2;
        const bowl = d < 1 ? -6.5 * (1 - d * d) : 0;
        h += rim + bowl;
      }
    }
    // lakes
    let dry = 10;
    for (const lk of this.lakes) {
      const lf = this.lakeFactor(lk, x, z);
      dry = Math.min(dry, lf);
      if (lf >= 1.35) continue;
      const shore = L.waterLevel + 0.55;
      const bed = L.waterLevel - lk.depth * (1 - Math.min(lf, 1) ** 2) - 0.25;
      if (lf < 1) h = lerp(shore, bed, smoothstep(1.0, 0.55, lf)) + nz.fbm2(x * 0.1, z * 0.1, 2) * 0.3;
      else h = lerp(shore + nz.fbm2(x * 0.1, z * 0.1, 2) * 0.2, h, smoothstep(1.0, 1.35, lf));
    }
    // rivers cut their channel; keep dry land above the water line outside lakes and rivers
    const rv = this.riverAt(x, z);
    if (rv.d < 8 && r < 318) {
      h = this.carveRiver(h, x, z, rv);
      dry = Math.min(dry, 0.9 + Math.max(0, rv.d) / 8);
    }
    const seaK = smoothstep(Math.max(border + 8, COAST_MIN) - 30, Math.max(border + 8, COAST_MIN) - 10, r);
    if (dry > 1.0 && seaK < 1) {
      const floor = lerp(L.waterLevel + 0.9, SEA_FLOOR, seaK);
      const k = smoothstep(1.0, 1.4, dry);
      const d = floor - h, rr = 0.8;
      const soft = d <= -rr ? h : d >= rr ? floor : h + (d + rr) * (d + rr) / (4 * rr);
      h = lerp(h, soft, k);
    }
    return h;
  }

  generate() {
    const n = this.n, half = this.half, cell = this.cell, L = this.L;
    const raw = new Float32Array(n * n);
    for (let j = 0; j < n; j++) {
      const z = -half + j * cell;
      for (let i = 0; i < n; i++) raw[j * n + i] = this.rawHeight(-half + i * cell, z);
    }
    this.raw = raw;
    for (const p of this.paths) {
      const hs = p.pts.map((q) => (this.riverAt(q[0], q[1]).d < 5 ? NaN : this.sampleGrid(raw, q[0], q[1])));
      // across a river the road keeps the banks' height (the bridge carries it)
      for (let i = 0; i < hs.length; i++) {
        if (!Number.isNaN(hs[i])) continue;
        let a = i - 1, b = i + 1;
        while (b < hs.length && Number.isNaN(hs[b])) b++;
        const ha = a >= 0 ? hs[a] : hs[b], hb = b < hs.length ? hs[b] : ha;
        for (let k = i; k < b && k < hs.length; k++) hs[k] = lerp(ha, hb, (k - a) / (b - a));
        i = b - 1;
      }
      let sm = hs.slice();
      for (let it = 0; it < 10; it++) {
        const o = sm.slice();
        for (let i = 1; i < sm.length - 1; i++) o[i] = (sm[i - 1] + sm[i] * 2 + sm[i + 1]) / 4;
        sm = o;
      }
      // never route a road under water
      p.heights = sm.map((v) => Math.max(v, L.waterLevel + 0.5));
    }
    const nz = this.noise;
    for (let j = 0; j < n; j++) {
      const z = -half + j * cell;
      for (let i = 0; i < n; i++) {
        const x = -half + i * cell;
        const k = j * n + i;
        let h = raw[k];
        const np = this.nearestPath(x, z, 12);
        this.pathDist[k] = np.d;
        let onRoad = 0;
        if (np.path) {
          const p = np.path;
          const ph = lerp(p.heights[np.seg], p.heights[np.seg + 1], np.t);
          const hw = p.width / 2;
          const bw = 1 - smoothstep(hw + 0.5, hw + 6, np.d);
          onRoad = bw;
          h = lerp(h, ph, bw);
          const jitter = nz.n2(x * 0.7, z * 0.7) * 0.35;
          this.wPath[k] = 1 - smoothstep(hw - 0.45 + jitter, hw + 0.35 + jitter, np.d);
        }
        // rivers flow under the bridges: re-cut the channel after the roads
        const rv = this.riverAt(x, z);
        if (rv.d < 6 && Math.hypot(x, z) < 318) {
          // the road keeps its embankment up to the bridge; only the channel under the deck is cut
          const carved = this.carveRiver(h, x, z, rv);
          const keep = onRoad * smoothstep(1.2, 2.6, rv.d);
          h = lerp(carved, h, keep);
          if (rv.d < 1.5) this.wPath[k] = 0;
        }
        this.riverD[k] = rv.d;
        this.h[k] = h;
      }
    }
    for (let j = 0; j < n; j++) {
      const z = -half + j * cell;
      for (let i = 0; i < n; i++) {
        const x = -half + i * cell;
        const k = j * n + i;
        const hl = this.h[j * n + Math.max(0, i - 1)], hr = this.h[j * n + Math.min(n - 1, i + 1)];
        const hd = this.h[Math.max(0, j - 1) * n + i], hu = this.h[Math.min(n - 1, j + 1) * n + i];
        const nx = (hl - hr) / (2 * cell), nzv = (hd - hu) / (2 * cell);
        const ny = 1 / Math.hypot(nx, 1, nzv);
        const r = Math.hypot(x, z);
        const border = L.borderAt(x, z);
        const b = L.biome(x, z);
        const rockN = nz.n2(x * 0.06, z * 0.06) * 0.08;
        let rock = smoothstep(0.86 + rockN, 0.72 + rockN, ny);
        const seaSand = smoothstep(Math.max(border + 8, COAST_MIN) - 40, Math.max(border + 8, COAST_MIN) - 5, r);
        const h = this.h[k];
        let shoreK = 10;
        for (const lk of this.lakes) shoreK = Math.min(shoreK, this.lakeFactor(lk, x, z));
        let sand = (1 - smoothstep(1.02, 1.25, shoreK)) * (1 - smoothstep(L.waterLevel + 0.9, L.waterLevel + 1.9, h));
        sand = Math.max(sand, b.desert * 0.9, (1 - smoothstep(0.5, 3.5, this.riverD[k])) * 0.85, seaSand);
        // crater: scorched glassy ground
        const cd = Math.hypot(x - this.crater.x, z - this.crater.z) / this.crater.r;
        let moss = smoothstep(0.0, 0.35, nz.fbm2(x * 0.03 + 11, z * 0.03 - 4, 3)) * 0.9;
        moss = Math.max(moss, (1 - smoothstep(1.1, 1.7, shoreK)) * 0.8, b.swamp * 0.9, b.mushroom * 0.6, (1 - smoothstep(3, 9, this.riverD[k])) * 0.8);
        const path = this.wPath[k];
        this.wRock[k] = Math.max(rock, (1 - smoothstep(0.8, 1.1, cd)) * 0.7) * (1 - path);
        this.wSand[k] = sand * (1 - rock) * (1 - path);
        this.wMoss[k] = moss * (1 - rock) * (1 - sand);
        this.tintA[k] = Math.max(b.crystal, (1 - smoothstep(0.6, 1.2, cd)) * 0.8);
        this.tintB[k] = b.desert;
        const avg = (hl + hr + hd + hu) / 4;
        this.ao[k] = clamp(1 - (avg - h) * 0.25, 0.55, 1.0);
        let g = 0.75 + nz.fbm2(x * 0.05 - 3, z * 0.05 + 8, 3) * 0.6;
        g = lerp(g, 1.1, b.meadow * 0.7);
        g *= (1 - path) * smoothstep(1.2, 3.2, this.pathDist[k]);
        g *= 1 - rock;
        g *= 1 - sand * 0.92;
        g *= 1 - b.crystal * 0.6;
        g *= 1 - smoothstep(0.7, 1.05, 1.4 - cd) * 0.9;
        g *= smoothstep(L.waterLevel + 0.1, L.waterLevel + 0.5, h);
        g *= 1 - smoothstep(border - 10, border + 14, r);
        this.grass[k] = clamp(g, 0, 1);
        this.flowers[k] = b.meadow;
      }
    }
  }

  // ------------------------------------------------------------ queries
  sampleGrid(arr, x, z) {
    const n = this.n;
    const fx = clamp((x + this.half) / this.cell, 0, n - 1.001);
    const fz = clamp((z + this.half) / this.cell, 0, n - 1.001);
    const i = Math.floor(fx), j = Math.floor(fz);
    const tx = fx - i, tz = fz - j;
    const a = arr[j * n + i], b = arr[j * n + i + 1], c = arr[(j + 1) * n + i], d = arr[(j + 1) * n + i + 1];
    return lerp(lerp(a, b, tx), lerp(c, d, tx), tz);
  }
  sample(arr, x, z) {
    return this.sampleGrid(arr, x, z);
  }
  // exact height on the rendered (full resolution) triangle mesh
  heightAt(x, z) {
    const n = this.n;
    const fx = clamp((x + this.half) / this.cell, 0, n - 1.0001);
    const fz = clamp((z + this.half) / this.cell, 0, n - 1.0001);
    const i = Math.floor(fx), j = Math.floor(fz);
    const tx = fx - i, tz = fz - j;
    const h00 = this.h[j * n + i], h10 = this.h[j * n + i + 1], h01 = this.h[(j + 1) * n + i], h11 = this.h[(j + 1) * n + i + 1];
    if (tx > tz) return h00 + (h10 - h00) * tx + (h11 - h10) * tz;
    return h00 + (h11 - h01) * tx + (h01 - h00) * tz;
  }
  normalAt(x, z) {
    const e = 0.6;
    const hl = this.heightAt(x - e, z), hr = this.heightAt(x + e, z);
    const hd = this.heightAt(x, z - e), hu = this.heightAt(x, z + e);
    const nx = hl - hr, nz = hd - hu, ny = 2 * e;
    const l = Math.hypot(nx, ny, nz);
    return [nx / l, ny / l, nz / l];
  }
  isWater(x, z) {
    return this.heightAt(x, z) < this.waterLevel - 0.25;
  }

  // ------------------------------------------------------------ GPU: chunked LOD meshes with skirts
  buildMeshes(gl) {
    const n = this.n, half = this.half, cell = this.cell;
    const CH = 64;
    // renderOrder 1: drawn after everything else that is solid, so hidden terrain pixels are never shaded
    const mat = new Material({
      defines: { TERRAIN: 1 },
      renderOrder: 1,
      uniforms: { uGlitter: [7.0, 0.1, 0.9], uRim: 0.12, uWrap: 0.2 },
    });
    this.material = mat;
    this.chunks = [];
    const meshes = [];
    for (let cj = 0; cj < n - 1; cj += CH) {
      for (let ci = 0; ci < n - 1; ci += CH) {
        const w = Math.min(CH, n - 1 - ci), hgt = Math.min(CH, n - 1 - cj);
        const lods = [];
        for (const step of [1, 2, 4]) {
          const g = this.chunkGeometry(ci, cj, w, hgt, step);
          const mesh = new Mesh(new GpuGeometry(gl, g), mat, 'terrain');
          mesh.castShadow = step === 1;
          mesh.visible = step === 1;
          mesh.noBatch = true;
          lods.push(mesh);
          meshes.push(mesh);
        }
        const cx = -half + (ci + w / 2) * cell, cz = -half + (cj + hgt / 2) * cell;
        this.chunks.push({ cx, cz, lods, size: Math.max(w, hgt) * cell });
      }
    }
    return meshes;
  }

  chunkGeometry(ci, cj, w, hgt, step) {
    const n = this.n, half = this.half, cell = this.cell;
    const g = new Geometry();
    const cols = Math.ceil(w / step), rows = Math.ceil(hgt / step);
    const vid = (i, j) => j * (cols + 1) + i;
    const put = (gi, gj, yOff = 0) => {
      gi = Math.min(gi, n - 1); gj = Math.min(gj, n - 1);
      const k = gj * n + gi;
      const x = -half + gi * cell, z = -half + gj * cell;
      const hl = this.h[gj * n + Math.max(0, gi - step)], hr = this.h[gj * n + Math.min(n - 1, gi + step)];
      const hd = this.h[Math.max(0, gj - step) * n + gi], hu = this.h[Math.min(n - 1, gj + step) * n + gi];
      const nx = hl - hr, ny = 2 * cell * step, nz = hd - hu;
      const l = Math.hypot(nx, ny, nz);
      g.color = [this.wPath[k], this.wSand[k], this.wRock[k], this.wMoss[k]];
      g.extra = [this.ao[k], this.tintA[k], this.tintB[k], 0];
      return g.vert(x, this.h[k] + yOff, z, nx / l, ny / l, nz / l, gi / (n - 1), gj / (n - 1));
    };
    for (let j = 0; j <= rows; j++) for (let i = 0; i <= cols; i++) put(ci + Math.min(i * step, w), cj + Math.min(j * step, hgt));
    for (let j = 0; j < rows; j++) {
      for (let i = 0; i < cols; i++) {
        const a = vid(i, j), b = vid(i + 1, j), c = vid(i, j + 1), d = vid(i + 1, j + 1);
        g.tri(a, c, d);
        g.tri(a, d, b);
      }
    }
    // skirts hide cracks between neighbouring chunks of different detail
    if (step > 1) {
      const drop = -1.2 * step;
      const edge = (list) => {
        for (let q = 0; q < list.length - 1; q++) {
          const [i0, j0] = list[q], [i1, j1] = list[q + 1];
          const a = vid(i0, j0), b = vid(i1, j1);
          const a2 = put(ci + Math.min(i0 * step, w), cj + Math.min(j0 * step, hgt), drop);
          const b2 = put(ci + Math.min(i1 * step, w), cj + Math.min(j1 * step, hgt), drop);
          g.tri(a, b, b2);
          g.tri(a, b2, a2);
          g.tri(a, b2, b);
          g.tri(a, a2, b2);
        }
      };
      const top = [], bottom = [], left = [], right = [];
      for (let i = 0; i <= cols; i++) { top.push([i, 0]); bottom.push([i, rows]); }
      for (let j = 0; j <= rows; j++) { left.push([0, j]); right.push([cols, j]); }
      edge(top); edge(bottom); edge(left); edge(right);
    }
    return g;
  }

  // pick detail per chunk based on distance to the camera
  updateLod(camPos, quality = 2) {
    if (!this.chunks) return;
    const d1 = [60, 90, 120][quality] ?? 90;
    const d2 = [150, 200, 260][quality] ?? 200;
    for (const c of this.chunks) {
      const d = Math.max(0, Math.hypot(c.cx - camPos[0], c.cz - camPos[2]) - c.size * 0.6);
      const lvl = d < d1 ? 0 : d < d2 ? 1 : 2;
      if (c.level === lvl) continue;
      c.level = lvl;
      c.lods.forEach((m, i) => (m.visible = i === lvl));
    }
  }

  buildDataTexture(gl) {
    const n = this.n;
    const half = new Uint16Array(n * n * 4);
    for (let k = 0; k < n * n; k++) {
      half[k * 4] = toHalf(this.h[k]);
      half[k * 4 + 1] = toHalf(this.grass[k]);
      half[k * 4 + 2] = toHalf(this.flowers[k]);
      half[k * 4 + 3] = toHalf(this.wPath[k]);
    }
    this.dataTex = createTexture(gl, {
      width: n, height: n, data: half,
      internalFormat: gl.RGBA16F, format: gl.RGBA, type: gl.HALF_FLOAT,
    });
    this.rect = [-this.half, -this.half, this.size, n];
    return this.dataTex;
  }
}

const f32 = new Float32Array(1);
const u32 = new Uint32Array(f32.buffer);
export function toHalf(v) {
  f32[0] = v;
  const x = u32[0];
  const sign = (x >> 16) & 0x8000;
  let exp = ((x >> 23) & 0xff) - 127 + 15;
  let mant = x & 0x7fffff;
  if (exp <= 0) {
    if (exp < -10) return sign;
    mant = (mant | 0x800000) >> (1 - exp);
    return sign | ((mant + 0x1000) >> 13);
  }
  if (exp >= 31) return sign | 0x7c00;
  return sign | (exp << 10) | ((mant + 0x1000) >> 13);
}

function bbox(pts, pad) {
  let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
  for (const p of pts) { a = Math.min(a, p[0]); b = Math.min(b, p[1]); c = Math.max(c, p[0]); d = Math.max(d, p[1]); }
  return [a - pad, b - pad, c + pad, d + pad];
}
function segDistT(px, pz, a, b) {
  const vx = b[0] - a[0], vz = b[1] - a[1];
  const l2 = vx * vx + vz * vz || 1;
  let t = ((px - a[0]) * vx + (pz - a[1]) * vz) / l2;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return { d: Math.hypot(px - a[0] - vx * t, pz - a[1] - vz * t), t };
}
