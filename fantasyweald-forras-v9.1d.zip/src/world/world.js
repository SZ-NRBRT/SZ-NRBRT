// The world: terrain, water, grass, landmarks (sites.js), vegetation (scatter.js), particles,
// collectibles, and the physics used by the game.
import { Geometry } from '../engine/geometry.js';
import { GpuGeometry, Mesh, Material, Node } from '../engine/scene.js';
import { ATTR } from '../engine/gl.js';
import { RNG, mat4, quat, TAU, smoothstep, lerp, clamp } from '../engine/math.js';
import { Terrain, SEA_HOLE } from './terrain.js';
import { Physics, SolidGrid, SOLID_SPACING } from './physics.js';
import { createMaterials, createTextures, C } from '../models/materials.js';
import { particleSystem } from './fx.js';
import { placeSites } from './sites.js';
import { scatterVegetation } from './scatter.js';
import { DreamSea } from './dreamsea.js';

// scatter bookkeeping: small things in a grid, big reservations in a list
class Occupancy {
  constructor(cell = 6) {
    this.cell = cell;
    this.map = new Map();
    this.big = [];
  }
  key(i, j) {
    return i * 92821 + j;
  }
  free(x, z, r) {
    for (const o of this.big) if (Math.hypot(o[0] - x, o[1] - z) < o[2] + r) return false;
    const c = this.cell;
    for (let i = Math.floor((x - r - 8) / c); i <= Math.floor((x + r + 8) / c); i++) {
      for (let j = Math.floor((z - r - 8) / c); j <= Math.floor((z + r + 8) / c); j++) {
        const l = this.map.get(this.key(i, j));
        if (!l) continue;
        for (const o of l) if (Math.hypot(o[0] - x, o[1] - z) < o[2] + r) return false;
      }
    }
    return true;
  }
  add(x, z, r) {
    if (r > 8) { this.big.push([x, z, r]); return; }
    const k = this.key(Math.floor(x / this.cell), Math.floor(z / this.cell));
    if (!this.map.has(k)) this.map.set(k, []);
    this.map.get(k).push([x, z, r]);
  }
}

export class World {
  constructor(gl, renderer, scene, quality, layout) {
    this.gl = gl;
    this.renderer = renderer;
    this.scene = scene;
    this.quality = quality;
    this.L = layout;
    this.regions = layout.regions;
    this.loadTimes = {};
  }
  // built in phases; `progress(fraction, text)` may return a promise (the loading screen gets a frame)
  async build(progress = () => {}) {
    const gl = this.gl, layout = this.L, scene = this.scene, renderer = this.renderer;
    const T0 = performance.now();
    const mark = (k) => { this.loadTimes[k] = Math.round(performance.now() - T0); };
    this.tex = createTextures(gl);
    this.M = createMaterials(gl, this.tex);
    this.ctx = { gl, M: this.M };
    this.terrain = new Terrain(layout);
    mark('terrain');
    await progress(0.35, 'Csörgedeznek a patakok…');
    // no invisible wall: beyond the island the dream sea goes on forever
    this.physics = new Physics(this.terrain);
    this.occ = new Occupancy(6);
    this.anchors = {};
    this.lights = [];
    this.interactables = [];
    this.shardSpots = [];
    this.loreSpots = [];
    this.gates = [];
    this.animated = [];

    mark('physics');
    for (const m of this.terrain.buildMeshes(gl)) {
      m.shadowDistance = 60;
      scene.add(m);
    }
    this.terrain.buildDataTexture(gl);
    renderer.frameTextures.uHeightTex = this.terrain.dataTex;
    renderer.frameUniforms.uTerrainRect = this.terrain.rect;

    mark('terrainMesh');
    this.reserveAreas();
    this.buildWater();
    this.buildSea();
    this.buildGrass();
    mark('water');
    await progress(0.45, 'Gombaházak nőnek…');
    placeSites(this);
    mark('sites');
    await progress(0.6, 'Kizöldül az erdő…');
    scatterVegetation(this);
    if (this.sky) for (const c of this.sky.curios) this.curiosities.push(c);
    this.dreamSea = new DreamSea(this);
    mark('scatter');
    await progress(0.75, 'Kinyílnak a gombák…');
    this.buildShards();
    this.buildFx();
    mark('fx');
  }

  // ------------------------------------------------------------ queries used by the game
  h(x, z) {
    return this.terrain.heightAt(x, z);
  }
  groundHeight(x, z, fromY = Infinity, stepUp = 0.6) {
    return this.physics.ground(x, z, fromY, stepUp);
  }
  collide(x, z, r, y = 0) {
    return this.physics.resolve(x, z, r, y);
  }
  waterDepth(x, z) {
    return this.L.waterLevel - this.terrain.heightAt(x, z);
  }
  regionAt(x, z, y = null) {
    let best = null, bd = Infinity;
    for (const r of this.regions) {
      const d = Math.hypot(x - r.center[0], z - r.center[1]);
      if (d >= r.radius) continue;
      // places in the sky only count up there, and up there they win
      if (r.sky) {
        if (y === null || y < r.floor) continue;
        return r;
      }
      if (d / r.radius < bd) { bd = d / r.radius; best = r; }
    }
    return best;
  }
  site(id) {
    return this.L.sites[id];
  }

  // ------------------------------------------------------------ solid grid from the real geometry
  // Call after the world has run a few frames (nodes that moved by then are skipped: they animate).
  buildSolidGrid() {
    const t0 = performance.now();
    const grid = new SolidGrid();
    const M = this.M;
    const soft = new Set([M.leaves, M.fronds, M.plants, M.mossStrands, M.glowSoft, M.glow, M.clothDS]);
    const skipNames = /^(pads|lilyPads|bulbs|shards|stairsLight)$/;
    const solidMat = (m) => m && m.kind === 'standard' && !m.transparent && !soft.has(m) && !m.defines.TERRAIN;
    const addMesh = (g, w, yMax = Infinity) => {
      const p = g.p, idx = g.idx, nv = p.length / 3;
      const T = new Float32Array(nv * 3);
      for (let i = 0; i < nv; i++) {
        const x = p[i * 3], y = p[i * 3 + 1], z = p[i * 3 + 2];
        T[i * 3] = w[0] * x + w[4] * y + w[8] * z + w[12];
        T[i * 3 + 1] = w[1] * x + w[5] * y + w[9] * z + w[13];
        T[i * 3 + 2] = w[2] * x + w[6] * y + w[10] * z + w[14];
      }
      for (let t = 0; t < idx.length; t += 3) {
        const a = idx[t] * 3, b = idx[t + 1] * 3, c = idx[t + 2] * 3;
        if (T[a + 1] > yMax && T[b + 1] > yMax && T[c + 1] > yMax) continue;
        grid.addTriangle(T[a], T[a + 1], T[a + 2], T[b], T[b + 1], T[b + 2], T[c], T[c + 1], T[c + 2]);
      }
    };
    // moved during the warm-up? tiny motions (a sleeping giant breathing) still count as solid
    const movedFar = (n) => {
      if (n._v0 === undefined || n.worldVersion === n._v0 || !n._w0) return false;
      const a = n._w0, b = n.world;
      const r = n.geometry ? n.geometry.bounds.radius : 1;
      let d = Math.hypot(a[12] - b[12], a[13] - b[13], a[14] - b[14]);
      for (let k = 0; k < 11; k++) if (k % 4 !== 3) d = Math.max(d, Math.abs(a[k] - b[k]) * r);
      return d > 0.8;
    };
    const visit = (n, moving) => {
      if (!n.visible) return;
      const mv = moving || n.dynamic === true || n.noSolid === true || movedFar(n);
      if (!mv && n.geometry && n.geometry.cpu && !n.instanceBuffer && solidMat(n.material) && !skipNames.test(n.name || '') &&
        n.geometry.bounds.radius * Math.cbrt(Math.abs(n.world[0] * n.world[5] * n.world[10]) || 1) > 0.15) addMesh(n.geometry.cpu, n.world);
      for (const c of n.children) visit(c, mv);
    };
    visit(this.scene, false);
    const t1 = performance.now();
    // instanced props: sample each model once, then only transform the points per instance (lower part only)
    const w = new Float32Array(16);
    for (const b of this.scene.batches) {
      for (const m of b.mainMeshes) {
        if (!solidMat(m.material) || !m.geometry.cpu || m.geometry.bounds.radius < 0.25) continue;
        if (b.far && m.instanceBuffer === b.far.buf) continue; // near models only
        let maxS = 0.1, minS = Infinity;
        for (let i = 0; i < b.count; i++) {
          const sc = Math.hypot(b.data[i * 20], b.data[i * 20 + 1], b.data[i * 20 + 2]);
          maxS = Math.max(maxS, sc); minS = Math.min(minS, sc);
        }
        // trees: the trunk (and the start of the roots) is what you bump into, not the boughs;
        // nothing above ~5 m matters for walking into things
        // columns fine enough that, rotated and scaled, they still cover every grid cell
        const cols = SolidGrid.columns(m.geometry.cpu.p, m.geometry.cpu.idx, SOLID_SPACING / (maxS * 1.45), m.solidR ?? (m.material === M.bark ? 1.1 : Infinity), (m.material === M.bark ? 3 : 6) / Math.max(0.05, minS));
        if (!cols.length) continue;
        for (let i = 0; i < b.count; i++) {
          const o = i * 20, x = b.data[o + 12], z = b.data[o + 14];
          if (Math.hypot(x, z) > this.L.borderAt(x, z) + 6) continue; // out of reach behind the rim
          for (let k = 0; k < 16; k++) w[k] = b.data[o + k];
          grid.addColumns(cols, w, this.terrain.heightAt(x, z) + 4.5);
        }
      }
    }
    const t2 = performance.now();
    grid.pack();
    this.physics.solid = grid;
    this.loadTimes.solidSplit = [Math.round(t1 - t0), Math.round(t2 - t1), Math.round(performance.now() - t2), grid.cells];
    this.loadTimes.solidGrid = Math.round(performance.now() - t0);
    return grid.cells;
  }

  // ------------------------------------------------------------ helpers
  mesh(geo, mat, name) {
    return new Mesh(new GpuGeometry(this.gl, geo), mat, name);
  }
  gpu(geo) {
    return new GpuGeometry(this.gl, geo);
  }
  meshG(gpu, mat, name) {
    return new Mesh(gpu, mat, name);
  }
  light(position, color, intensity, radius, flicker = 0, priority = 0) {
    const l = this.scene.addLight({ position, color, intensity, radius, flicker, priority });
    this.lights.push(l);
    return l;
  }
  // place a structure result (local space) at world x,z facing yaw
  // floating: the structure hangs in the air, so its colliders get a height range (not the whole column)
  place(R, x, z, yaw = 0, yOff = 0, { y = null, collide = true, floating = false } = {}) {
    const baseY = y !== null ? y : this.h(x, z) + yOff;
    R.root.setPos(x, baseY, z);
    R.root.setRotY(yaw);
    this.scene.add(R.root);
    const c = Math.cos(yaw), s = Math.sin(yaw);
    const tr = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c];
    const tp = (p) => {
      const [wx, wz] = tr(p[0], p[2]);
      return [wx, baseY + p[1], wz];
    };
    const P = this.physics;
    if (collide) {
      for (const col of R.colliders || []) {
        const o = { yMin: col.yMin !== undefined ? col.yMin + baseY : floating ? baseY - 1 : undefined, yMax: col.yMax !== undefined ? col.yMax + baseY : floating ? baseY + 12 : undefined, tag: col.tag };
        let c;
        if (col.type === 'circle') {
          const [wx, wz] = tr(col.x, col.z);
          c = P.addCircle(wx, wz, col.r, o);
        } else {
          const [ax, az] = tr(col.ax, col.az);
          const [bx, bz] = tr(col.bx, col.bz);
          c = P.addSeg(ax, az, bx, bz, col.r, o);
        }
        if (col.tag) (R.tagged = R.tagged || {})[col.tag] = c;
      }
      // legacy flat platforms -> surfaces
      for (const p of R.platforms || []) {
        const [wx, wz] = tr(p.x, p.z);
        if (p.round) P.addSurface({ type: 'disc', x: wx, z: wz, r: p.hx, top: baseY + p.top, bottom: baseY + p.top - 1.5 });
        else P.addSurface({ type: 'box', x: wx, z: wz, hx: p.hx, hz: p.hz, yaw: (p.yaw || 0) + yaw, top: baseY + p.top, bottom: baseY + p.top - 0.6 });
      }
      for (const sf of R.surfaces || []) {
        const [wx, wz] = tr(sf.x, sf.z);
        const w = { ...sf, x: wx, z: wz, yaw: (sf.yaw || 0) + yaw };
        if (w.top !== undefined) w.top += baseY;
        if (w.bottom !== undefined) w.bottom += baseY;
        if (w.y0 !== undefined) { w.y0 += baseY; w.y1 += baseY; }
        if (sf.topFn) {
          const fn = sf.topFn;
          w.topFn = (lx, lz, pad) => {
            const v = fn(lx, lz, pad);
            return v === null ? null : v + baseY;
          };
        }
        P.addSurface(w);
      }
    }
    for (const l of R.lights || []) this.light(tp(l.pos), l.color, l.intensity, l.radius, l.flicker || 0, l.priority || 0);
    // small details don't need to cast shadows (saves many draw calls in the shadow pass)
    R.root.traverse((n) => {
      if (n.geometry && n.geometry.bounds && n.geometry.bounds.radius * Math.max(1, n.scale[0]) < 0.4) n.castShadow = false;
    });
    R.world = { x, y: baseY, z, yaw, tp, tr };
    return R;
  }
  // sample a random free point inside a disc (for placing props)
  freeSpot(rng, cx, cz, r, rad, tries = 60, test = null) {
    for (let i = 0; i < tries; i++) {
      const a = rng.range(0, TAU), d = Math.sqrt(rng.next()) * r;
      const x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
      if (this.waterDepth(x, z) > -0.3) continue;
      if (this.terrain.sample(this.terrain.pathDist, x, z) < 2.5) continue;
      if (!this.occ.free(x, z, rad)) continue;
      if (test && !test(x, z)) continue;
      this.occ.add(x, z, rad);
      return [x, z];
    }
    return null;
  }

  reserveAreas() {
    const S = this.L.sites;
    const keep = { glade: 16, village: 22, castle: 26, rune: 15, tower: 7, pyramid: 20, crater: 23, moongarden: 9, watcher: 9, ruins: 16, giant: 20, islands: 8 };
    for (const id in keep) this.occ.add(S[id].x, S[id].z, keep[id]);
    const c = S.castle;
    this.occ.add(c.handX, c.handZ, 30);
    // keep the title screen's camera path free of trees and giant mushrooms
    const g = S.glade;
    const dl = Math.hypot(c.x - g.x, c.z - g.z) || 1;
    const bx = -(c.x - g.x) / dl, bz = -(c.z - g.z) / dl;
    for (let a = 0.45; a <= 1.25; a += 0.08) {
      const rx = bx * Math.cos(a) - bz * Math.sin(a), rz = bx * Math.sin(a) + bz * Math.cos(a);
      this.occ.add(g.x + rx * 21, g.z + rz * 21, 5.5);
    }
  }

  // ------------------------------------------------------------ water
  waterMaterial(shallow, river = false) {
    return new Material({
      kind: 'water',
      defines: river ? { RIVER: 1 } : {},
      cull: river ? 'none' : 'back',
      transparent: true,
      depthWrite: false,
      castShadow: false,
      renderOrder: 5,
      uniforms: {
        uDeep: shallow ? C('#0a3a32') : C('#04323c'),
        uShallow: shallow ? C('#1a6a60') : C('#0d8a8f'),
        uGlowCol: shallow ? C('#3fd6a0', 0.6) : C('#16c9c4', 0.9),
        uLevel: this.L.waterLevel,
      },
    });
  }
  buildWater() {
    const L = this.L;
    this.waters = [];
    for (const lk of L.lakes) {
      const size = lk.r * 2.9;
      const seg = lk.id === 'lake' ? 90 : 30;
      const g = Geometry.plane(size, size, seg, seg);
      const m = this.mesh(g, this.waterMaterial(!!lk.shallow), lk.id);
      m.setPos(lk.x, L.waterLevel, lk.z);
      m.castShadow = false;
      m.maxDistance = 260;
      this.scene.add(m);
      this.waters.push(m);
    }
    // rivers: a ribbon along each channel, the flow direction stored in the uv
    for (const rv of L.rivers || []) {
      const pts = rv.points.filter((p) => Math.hypot(p[0], p[1]) < SEA_HOLE - 2);
      if (pts.length < 2) continue;
      const g = new Geometry();
      const hw = rv.width / 2 + 2.6;
      const speed = rv.id === 'holdpatak' ? 1.4 : 0.9;
      for (let i = 0; i < pts.length; i++) {
        const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
        let dx = b[0] - a[0], dz = b[1] - a[1];
        const l = Math.hypot(dx, dz) || 1;
        dx /= l; dz /= l;
        for (const sd of [-1, 1]) g.vert(pts[i][0] - dz * hw * sd, 0, pts[i][1] + dx * hw * sd, 0, 1, 0, dx * speed, dz * speed);
      }
      for (let i = 0; i < pts.length - 1; i++) {
        const a = i * 2;
        g.quad(a, a + 1, a + 3, a + 2);
      }
      const m = this.mesh(g, this.waterMaterial(false, true), rv.id);
      m.setPos(0, L.waterLevel, 0);
      m.castShadow = false;
      m.maxDistance = 300;
      this.scene.add(m);
      this.waters.push(m);
    }
    // waterfall from the cliff into the big lake
    const cl = this.terrain.cliff;
    const lake = L.sites.lake;
    const dir = [lake.x - cl.x, lake.z - cl.z];
    const dl = Math.hypot(dir[0], dir[1]);
    dir[0] /= dl; dir[1] /= dl;
    const side = [-dir[1], dir[0]];
    let topD = 0, topY = 10;
    for (let d = 0; d < 30; d += 0.5) {
      const x = cl.x + dir[0] * d, z = cl.z + dir[1] * d;
      const hh = this.h(x, z);
      if (hh < cl.h - 2.5) { topD = d - 0.3; topY = this.h(cl.x + dir[0] * topD, cl.z + dir[1] * topD) - 0.3; break; }
    }
    let botD = topD + 6;
    for (let d = topD; d < topD + 30; d += 0.5) {
      if (this.h(cl.x + dir[0] * d, cl.z + dir[1] * d) < L.waterLevel - 0.3) { botD = d + 1.0; break; }
    }
    const wf = new Geometry();
    const W = 5.2, segs = 16;
    for (let j = 0; j <= segs; j++) {
      const t = j / segs;
      const d = lerp(topD, botD, Math.pow(t, 0.6));
      const x0 = cl.x + dir[0] * d, z0 = cl.z + dir[1] * d;
      const ground = this.h(x0, z0);
      const y = Math.max(lerp(topY, L.waterLevel - 0.2, t * t * 0.6 + t * 0.4), ground + 0.4 * (1 - t));
      for (let i = 0; i <= 6; i++) {
        const u = i / 6;
        const off = (u - 0.5) * W * (1 + t * 0.35);
        const bulge = 0.5 + Math.sin(u * Math.PI) * 0.5;
        wf.vert(x0 + side[0] * off + dir[0] * bulge, y, z0 + side[1] * off + dir[1] * bulge, dir[0], 0, dir[1], u, t);
      }
    }
    for (let j = 0; j < segs; j++) for (let i = 0; i < 6; i++) {
      const a = j * 7 + i;
      wf.quad(a, a + 7, a + 8, a + 1);
    }
    const wmat = new Material({ kind: 'waterfall', transparent: true, blend: 'additive', depthWrite: false, castShadow: false, cull: 'none', renderOrder: 6 });
    const wm = this.mesh(wf, wmat, 'waterfall');
    wm.castShadow = false;
    this.scene.add(wm);
    const bx = cl.x + dir[0] * (botD + 0.5), bz = cl.z + dir[1] * (botD + 0.5);
    this.anchors.waterfallBase = [bx, L.waterLevel, bz];
    this.anchors.waterfallTop = [cl.x + dir[0] * topD, topY, cl.z + dir[1] * topD];
    this.anchors.waterfallDir = dir;
  }

  // ------------------------------------------------------------ the endless dream sea around the island
  // Two big planes that follow the camera (in steps of the tile pattern, so nothing swims): a tiled floor
  // just under the surface, and the mirror-like water. Both leave a hole where the island is.
  buildSea() {
    // deep water all around the island: no floor to see, just water like the lake's (it follows the camera)
    const L = this.L;
    const SIZE = 2000, SEG = 40;
    const sg = Geometry.plane(SIZE, SIZE, SEG, SEG);
    const sm = this.waterMaterial(false);
    sm.defines = { SEA: 1 };
    sm.uniforms.uHole = [0, 0, SEA_HOLE, 0];
    sm.uniforms.uShallow = C('#2f6f8e');
    sm.uniforms.uDeep = C('#12305c');
    sm.uniforms.uGlowCol = C('#7fd8ff', 0.3);
    sm.uniforms.uLev = new Float32Array(48);
    sm.uniforms.uLure = [0, 0, 0, 1];
    const surf = this.mesh(sg, sm, 'sea');
    surf.castShadow = false;
    surf.noBatch = true;
    surf.dynamic = true;
    surf.setPos(0, L.waterLevel, 0);
    this.scene.add(surf);
    this.sea = { surf, step: 8, mat: sm };
  }
  updateSea(cam) {
    if (!this.sea) return;
    const s = this.sea.step;
    const x = Math.round(cam[0] / s) * s, z = Math.round(cam[2] / s) * s;
    const w = this.sea.surf.position;
    if (w[0] !== x || w[2] !== z) this.sea.surf.setPos(x, w[1], z);
  }

  // ------------------------------------------------------------ grass: a dense near patch + a sparse far ring
  buildGrass() {
    const gl = this.gl;
    const segs = 4;
    const g = new Geometry();
    for (let j = 0; j <= segs; j++) {
      const t = j / segs;
      if (j < segs) { g.vert(-0.5, t, 0); g.vert(0.5, t, 0); } else g.vert(0, 1, 0);
    }
    for (let j = 0; j < segs - 1; j++) { const a = j * 2; g.quad(a, a + 1, a + 3, a + 2); }
    const last = (segs - 1) * 2;
    g.tri(last, last + 1, last + 2);
    const geo = new GpuGeometry(gl, g);
    const layer = (count, patch, inner, width, seed) => {
      const rng = new RNG(seed);
      const inst = new Float32Array(count * 4);
      for (let i = 0; i < count; i++) {
        inst[i * 4] = rng.next(); inst[i * 4 + 1] = rng.next(); inst[i * 4 + 2] = rng.next(); inst[i * 4 + 3] = rng.next();
      }
      const vao = gl.createVertexArray();
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, geo.buffers.p);
      gl.enableVertexAttribArray(ATTR.aPosition);
      gl.vertexAttribPointer(ATTR.aPosition, 3, gl.FLOAT, false, 0, 0);
      const ib = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, ib);
      gl.bufferData(gl.ARRAY_BUFFER, inst, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(ATTR.aI0);
      gl.vertexAttribPointer(ATTR.aI0, 4, gl.FLOAT, false, 0, 0);
      gl.vertexAttribDivisor(ATTR.aI0, 1);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, geo.buffers.idx);
      gl.bindVertexArray(null);
      const mat = new Material({
        kind: 'grass',
        cull: 'none',
        castShadow: false,
        uniforms: {
          uGrassCenter: [0, 0, 0], uPatchSize: patch, uGrassRadius: patch * 0.5, uInnerRadius: inner, uBladeWidth: width, uBladeHeight: 0.42,
          uRootCol: C('#101a24'), uTipCol: C('#4a7383'), uTipCol2: C('#4a5f95'),
        },
      });
      const m = new Mesh(geo, mat, 'grass');
      m.vao = vao;
      m.instanceBuffer = ib;
      m.instanceCount = count;
      m.fullCount = count;
      m.frustumCulled = false;
      m.castShadow = false;
      this.scene.add(m);
      return m;
    };
    const q = this.quality;
    const near = [[12000, 26], [18000, 30], [26000, 34]][q] || [18000, 30];
    const far = [[7000, 56], [12000, 68], [18000, 80]][q] || [12000, 68];
    this.grassLayers = [layer(near[0], near[1], 0, 0.075, 99), layer(far[0], far[1], near[1] * 0.42, 0.11, 77)];
  }
  updateGrass(focus) {
    for (const g of this.grassLayers) g.material.uniforms.uGrassCenter = focus;
  }
  setGrassFraction(f) {
    for (const g of this.grassLayers) g.instanceCount = Math.floor(g.fullCount * f);
  }

  // ------------------------------------------------------------ star shards (instanced, animated on the CPU)
  buildShards() {
    const geo = new GpuGeometry(this.gl, starShardGeometryLocal());
    const n = this.shardSpots.length;
    const data = new Float32Array(Math.max(1, n) * 20);
    const mat = new Material({ defines: { UNLIT: 1 }, uniforms: { uGlitter: [9, 0, 0], uFogScale: 0.7 } });
    const mesh = new Mesh(geo, mat, 'shards');
    mesh.setInstances(data, n);
    mesh.castShadow = false;
    mesh.frustumCulled = false;
    this.scene.add(mesh);
    this.shardMesh = mesh;
    this.shardCollected = new Set();
    this.updateShards(0);
  }
  updateShards(time) {
    const m = this.shardMesh;
    const d = m.instanceData;
    const t = this._shardTmp || (this._shardTmp = { mm: mat4.create(), q: [0, 0, 0, 1], p: [0, 0, 0], s: [1, 1, 1] });
    const spots = this.shardSpots;
    for (let i = 0; i < spots.length; i++) {
      const s = spots[i];
      const got = this.shardCollected.has(s.id);
      const sc = got ? 0 : 1 + Math.sin(time * 3 + i) * 0.08;
      quat.fromEuler(t.q, 0, time * 1.4 + i, 0);
      t.p[0] = s.x; t.p[1] = s.y + 0.9 + Math.sin(time * 1.7 + i * 1.3) * 0.18; t.p[2] = s.z;
      t.s[0] = t.s[1] = t.s[2] = sc;
      mat4.compose(t.mm, t.p, t.q, t.s);
      const o = i * 20;
      for (let k = 0; k < 16; k++) d[o + k] = t.mm[k];
      d[o + 16] = 1; d[o + 17] = 1; d[o + 18] = 1; d[o + 19] = 1;
    }
    m.updateInstances(spots.length);
  }

  // ------------------------------------------------------------ ambient particles that are not tied to a site
  buildFx() {
    const gl = this.gl;
    const T = this.terrain;
    const qMul = [0.5, 0.8, 1.0][this.quality] ?? 0.8;
    const add = (m) => { this.scene.add(m); return m; };
    // fireflies drifting in many places
    const rng = new RNG(this.L.seed + 404);
    for (let k = 0; k < 14; k++) {
      const a = rng.range(0, TAU), d = rng.range(20, 230);
      const cx = Math.cos(a) * d, cz = Math.sin(a) * d;
      if (Math.hypot(cx, cz) > this.L.borderAt(cx, cz) - 20) continue;
      this.fireflies([cx, cz], 45, Math.round(60 * qMul), C(rng.pick(['#9fe7ff', '#b6ffcf', '#dfe6ff', '#9fd0ff'])), { seed: 100 + k });
    }
    this.motes = add(particleSystem(gl, Math.round(420 * qMul), { FALL: 1, STAR: 1 }, (i, r) => ({
      p: [r.next(), r.next(), r.next()], params: [r.range(1.5, 4.5), 0, 0, 0], size: r.range(0.03, 0.08), speed: r.range(0.08, 0.3), spread: 26, color: C('#c8d8ff'), intensity: r.range(2, 5),
    }), { bounds: 'none', seed: 13 }));
  }
  fireflies(center, radius, count, color, { h = 1.5, size = 0.09, seed = 1, yMin = 0.3 } = {}) {
    const T = this.terrain;
    const m = particleSystem(this.gl, count, { FIREFLY: 1 }, (i, r) => {
      const a = r.range(0, TAU), d = Math.sqrt(r.next()) * radius;
      const x = center[0] + Math.cos(a) * d, z = center[1] + Math.sin(a) * d;
      const y = Math.max(T.heightAt(x, z), this.L.waterLevel) + r.range(yMin, h * 2);
      return { p: [x, y, z], params: [r.range(0.8, 2.2), 0, 0, 0], size: size * r.range(0.7, 1.4), speed: r.range(0.4, 1.0), spread: r.range(0.6, 1.8), color, intensity: r.range(2.5, 5) };
    }, { seed });
    m.maxDistance = 140;
    this.scene.add(m);
    return m;
  }
}

// local copy to avoid a circular import with models/wonders.js
function starShardGeometryLocal() {
  const g = new Geometry();
  const pts = [];
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + Math.PI / 2;
    const r = i % 2 === 0 ? 0.42 : 0.14;
    pts.push([Math.cos(a) * r, Math.sin(a) * r]);
  }
  for (const zs of [1, -1]) {
    const c = g.vert(0, 0, 0.12 * zs, 0, 0, zs);
    const ids = pts.map((p) => g.vert(p[0], p[1], 0, 0, 0, zs));
    for (let i = 0; i < 8; i++) {
      if (zs > 0) g.tri(c, ids[i], ids[(i + 1) % 8]);
      else g.tri(c, ids[(i + 1) % 8], ids[i]);
    }
  }
  g.computeNormals();
  g.setColor(C('#ffe7a0'), 1);
  g.setExtra([3.0]);
  return g;
}
