import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
const b = await chromium.launch({ args: ['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage();
const r = await p.evaluate(() => { const c = document.createElement('canvas'); const gl = c.getContext('webgl2'); if (!gl) return 'no webgl2'; const exts = gl.getSupportedExtensions(); return { v: gl.getParameter(gl.VERSION), r: gl.getParameter(gl.RENDERER), cbf: exts.includes('EXT_color_buffer_float'), cbhf: exts.includes('EXT_color_buffer_half_float'), fl: exts.includes('OES_texture_float_linear'), maxS: gl.getParameter(gl.MAX_SAMPLES) }; });
console.log(r); await b.close();
