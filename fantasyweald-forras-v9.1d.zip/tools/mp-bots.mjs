// Load test for the multiplayer server: N pretend players walk in circles, now and then say something.
//   node tools/mp-bots.mjs <url> [n=50] [seconds=60] [cx,cy,cz] [pathfile.json]
// url: e.g. http://127.0.0.1:8124/mp.php (PHP) or http://127.0.0.1:8787/ (Node server)
// pathfile: optional [[x,y,z], ...] ring of ground points the bots walk along (otherwise a flat circle).
import { readFileSync } from 'node:fs';

const [,, url = 'http://127.0.0.1:8124/mp.php', nArg = '50', secArg = '60', centerArg = '0,0,0', pathFile] = process.argv;
const N = Number(nArg), SECONDS = Number(secArg);
const [cx, cy, cz] = centerArg.split(',').map(Number);
const path = pathFile ? JSON.parse(readFileSync(pathFile, 'utf8')) : null;
const SAY = ['Sziasztok!', 'Ki látta a holdszarvast?', 'Milyen nagy itt minden…', 'Úszom egyet a tóban.', 'Erre gyertek!', 'Hová tűnt a hold?', 'Ez a gomba nagyobb, mint egy ház.', 'Szép álmokat!'];

const stats = { req: 0, err: 0, lat: [], chats: 0, maxN: 0, bytes: 0 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function post(body) {
  const t0 = performance.now();
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const txt = await r.text();
  stats.req++;
  stats.bytes += txt.length;
  stats.lat.push(performance.now() - t0);
  return JSON.parse(txt);
}

function where(i, t) {
  if (path) {
    // walk along the ring, each bot at its own spot and pace
    const u = ((t * (0.6 + (i % 5) * 0.1)) / 4 + i * (path.length / N)) % path.length;
    const a = path[Math.floor(u) % path.length], b = path[(Math.floor(u) + 1) % path.length], f = u % 1;
    const x = a[0] + (b[0] - a[0]) * f, y = a[1] + (b[1] - a[1]) * f, z = a[2] + (b[2] - a[2]) * f;
    const yaw = Math.atan2(b[0] - a[0], b[2] - a[2]);
    return [x, y, z, yaw, (b[0] - a[0]) * 0.6, (b[2] - a[2]) * 0.6];
  }
  const r = 6 + (i % 7) * 3, w = (2.2 / r) * (i % 2 ? 1 : -1), a = i * 2.39 + t * w;
  return [cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, a + (w > 0 ? 0 : Math.PI), -Math.sin(a) * r * w, Math.cos(a) * r * w];
}

async function bot(i, until) {
  let j = await post({ a: 'join', name: 'Bot ' + (i + 1), color: i % 8 });
  if (!j.ok) { stats.err++; console.log('join failed', i, j); return; }
  const { id, key } = j;
  let since = j.since, interval = j.interval, seq = 0, nextChat = 5 + Math.random() * 40;
  const t0 = performance.now() / 1000;
  while (performance.now() < until) {
    const t = performance.now() / 1000 - t0;
    const [x, y, z, yaw, vx, vz] = where(i, t);
    const body = { a: 'sync', id, key, s: [x, y, z, yaw, vx, vz, 1], since, full: seq++ % 4 === 0 ? 1 : 0 };
    if (i % 3 === 0 && t > nextChat) { body.chat = SAY[(Math.random() * SAY.length) | 0]; nextChat = t + 15 + Math.random() * 30; stats.chats++; }
    try {
      j = await post(body);
      if (!j.ok) { stats.err++; if (j.err === 'unknown') return bot(i, until); }
      else { interval = j.interval; since = Math.max(since, ...j.c.map((c) => c[0])); stats.maxN = Math.max(stats.maxN, j.n); }
    } catch (e) { stats.err++; }
    await sleep(interval);
  }
  await post({ a: 'leave', id, key }).catch(() => {});
}

const until = performance.now() + SECONDS * 1000;
const report = setInterval(() => {
  const l = stats.lat.sort((a, b) => a - b);
  const p = (q) => (l.length ? l[Math.min(l.length - 1, Math.floor(l.length * q))].toFixed(1) : '-');
  console.log(`req ${stats.req} (${(stats.req / 5).toFixed(0)}/s)  err ${stats.err}  players ${stats.maxN}  chats ${stats.chats}  latency p50 ${p(0.5)} ms  p95 ${p(0.95)} ms  max ${p(0.999)} ms  avg reply ${(stats.bytes / Math.max(1, stats.req) / 1024).toFixed(1)} KB`);
  stats.req = 0; stats.lat = []; stats.bytes = 0;
}, 5000);
await Promise.all(Array.from({ length: N }, (_, i) => sleep(i * 40).then(() => bot(i, until))));
clearInterval(report);
console.log('done');
