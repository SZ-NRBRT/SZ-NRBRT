// Tries to misuse the multiplayer server the way a player with a modified client (F12) could, and checks
// that the server refuses or cleans everything. Run it against a local copy:
//   cd dist/web && MP_JOIN_GAP_MS=0 php -S 127.0.0.1:8124     (then, in another terminal)
//   node tools/mp-security-test.mjs http://127.0.0.1:8124/mp.php
const url = process.argv[2] || 'http://127.0.0.1:8124/mp.php';
const base = url.replace(/[^/]*$/, '');
let fails = 0, passes = 0;
const ok = (cond, what) => { if (cond) passes++; else { fails++; console.log('FAIL:', what); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function raw(body, { method = 'POST', path = url } = {}) {
  const r = await fetch(path, { method, headers: { 'Content-Type': 'application/json' }, body: method === 'POST' ? body : undefined });
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch (e) { /* not JSON */ }
  return { status: r.status, text, json };
}
const post = (obj) => raw(JSON.stringify(obj));

// every reply must be clean JSON (no PHP warnings or paths leaking out)
async function clean(body, what) {
  const r = typeof body === 'string' ? await raw(body) : await post(body);
  ok(r.json !== null, `${what}: reply is JSON (got ${r.text.slice(0, 80)})`);
  ok(!/warning|notice|fatal|\/home\/|\.php/i.test(r.text), `${what}: no PHP error text in reply`);
  return r;
}

const h = await raw(null, { method: 'GET', path: url + '?a=join' });
ok(h.json && h.json.ok && h.json.players !== undefined && !h.json.id, 'GET cannot join (only hello)');

// a normal player
const A = (await post({ a: 'join', name: 'Anna', color: 2 })).json;
ok(A && A.ok && /^p[0-9a-f]{8}$/.test(A.id), 'join gives a letter-prefixed id');
ok(A && /^[0-9a-f]{24}$/.test(A.key), 'join gives a 24-hex secret key');
await sleep(60);

// names: control, invisible and direction-flipping characters, zalgo, long, wrong types
const names = [
  ['<b>x</b>‮gnp.exe', (n) => !n.includes('‮')],
  ['Ź̂̃̄̅̆ȧ̈̉', (n) => !/\p{M}{2,}/u.test(n)],
  ['a'.repeat(500), (n) => [...n].length <= 16],
  ['​​​', (n) => n === 'Vándor'],
  [['arr'], (n) => n === 'Vándor'],
  [12345, (n) => n === 'Vándor'],
  ['  Béla\n\t Bátor  ', (n) => n === 'Béla Bátor'],
  // (v9) plain text only
  ['Béla 😀✨', (n) => n === 'Béla'],
  ['www.spam.hu', (n) => n === 'Vándor'],
];
const ids = [];
for (const [name, test] of names) {
  const r = await clean({ a: 'join', name, color: 'red' }, 'odd name');
  if (r.json && r.json.ok) {
    ids.push(r.json);
    const s = await post({ a: 'sync', id: r.json.id, key: r.json.key, since: 0, s: [0, 0, 0, 0, 0, 0, 1] });
    const joined = (s.json.c || []).filter((c) => c[1] === '' && c[3].endsWith('megérkezett az erdőbe.')).pop();
    const shown = joined ? joined[3].replace(' megérkezett az erdőbe.', '') : null;
    ok(shown !== null && test(shown), `name cleaned: ${JSON.stringify(name).slice(0, 40)} -> ${JSON.stringify(shown)}`);
    if (ids.length > 6) { const o = ids[ids.length - 2]; await post({ a: 'leave', id: o.id, key: o.key }); } // (keep within the per-address limit)
  } else ok(r.json && ['slow', 'ip'].includes(r.json.err), 'odd-name join refused only by limits');
  await sleep(40);
}

// wrong types and forged ids/keys never get through, and never break the reply
const B = ids[ids.length - 1];
for (const [body, what] of [
  [{ a: 'sync', id: ['x'], key: A.key }, 'id as array'],
  [{ a: 'sync', id: 12345678, key: A.key }, 'id as number'],
  [{ a: 'sync', id: A.id, key: B.key }, "someone else's key"],
  [{ a: 'sync', id: A.id, key: 'x'.repeat(24) }, 'made-up key'],
  [{ a: 'leave', id: A.id, key: '0'.repeat(24) }, 'kicking another player'],
  [{ a: 'sync', id: A.id }, 'no key'],
]) {
  const r = await clean(body, what);
  ok(r.json && r.json.ok === false && r.json.err === 'unknown', `${what} is refused`);
}
for (const [body, what] of [
  ['{"a":"sync","id":', 'broken JSON'],
  ['[' .repeat(50) + ']'.repeat(50), 'deep JSON'],
  [JSON.stringify({ a: 'sync', pad: 'x'.repeat(5000) }), 'oversized request'],
  [JSON.stringify({ a: 'eval', code: 'phpinfo()' }), 'unknown action'],
]) {
  const r = await clean(body, what);
  ok(r.json && r.json.ok === false, `${what} is refused`);
}

// positions and flags are clamped to the world; junk numbers become 0
await post({ a: 'sync', id: B.id, key: B.key, s: [1e9, 'x', -1e9, 1e30, 99999, -99999, 0xffff], since: 0 });
await sleep(80);
const seen = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: 0, full: 1 })).json;
const bRow = seen.p.find((p) => p[0] === B.id);
ok(bRow && Math.abs(bRow[3]) <= 760 && Math.abs(bRow[5]) <= 760, 'position clamped to the world');
ok(bRow && bRow[4] === 0, 'non-number y ignored');
ok(bRow && Math.abs(bRow[6]) <= Math.PI + 1e-3 && Math.abs(bRow[7]) <= 30 && Math.abs(bRow[8]) <= 30, 'yaw/velocity clamped');
ok(bRow && bRow[9] <= 31, 'unknown flag bits dropped');
ok(seen.p.every((p) => typeof p[0] === 'string') && !seen.p.some((p) => p[0] === A.id), 'ids are strings, you never see yourself');
ok(!JSON.stringify(seen).includes(B.key) && !JSON.stringify(seen).includes(A.key), 'nobody else\'s key is ever sent');

// chat: flood, repeat, control characters, over-long
let accepted = 0, since = seen.cid;
for (let i = 0; i < 8; i++) {
  const r = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since, chat: 'spam ' + i })).json;
  if (!r.cd) accepted++;
}
ok(accepted === 1, `chat flood: ${accepted} of 8 quick messages accepted (expected 1)`);
await sleep(1300);
const rep1 = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since, chat: 'spam 0' })).json;
ok(rep1.cd === 'repeat', 'the same message again is dropped');
await sleep(1300);
const long = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since, chat: '\u0007<script>alert(1)</script>' + 'é'.repeat(400) })).json;
const last = long.c[long.c.length - 1];
ok(last && [...last[3]].length <= 160 && !last[3].includes('\u0007'), 'long chat cut to 160 characters, control characters removed');
ok(last && !/[<>]/.test(last[3]) && last[3].startsWith('scriptalert(1)/script'), '(v9) no markup characters get through (and the game shows text as text anyway)');

// (v8) proximity chat: a normal message only reaches players within 30 m; "!all" reaches everybody, at most
// every 8 seconds; nobody learns where the sender was standing
{
  const N = (await post({ a: 'join', name: 'Közeli' })).json;
  await sleep(40);
  const F = (await post({ a: 'join', name: 'Távoli' })).json;
  ok(N && N.ok && F && F.ok, 'near and far players joined');
  await sleep(80);
  await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: 0 });
  await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: 0 });
  await post({ a: 'sync', id: F.id, key: F.key, s: [400, 0, 380, 0, 0, 0, 1], since: 0 });
  await sleep(1400);
  const base = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: 0 })).json.cid;
  const sent = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: base, chat: 'csak a közelieknek' })).json;
  ok(sent && !sent.cd, 'normal message accepted');
  await sleep(80);
  const nearGot = (await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: base })).json;
  const farGot = (await post({ a: 'sync', id: F.id, key: F.key, s: [400, 0, 380, 0, 0, 0, 1], since: base })).json;
  const hasMsg = (r, txt) => (r.c || []).some((c) => c[1] === A.id && c[3] === txt);
  ok(hasMsg(nearGot, 'csak a közelieknek'), 'a player 13 m away hears a normal message');
  ok(!hasMsg(farGot, 'csak a közelieknek'), 'a player 550 m away does not get it at all');
  ok((nearGot.c || []).every((c) => c.length === 6), 'chat lines carry no sender position');
  await sleep(1300);
  const shout = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: base, chat: '!all mindenkinek szól' })).json;
  ok(shout && !shout.cd, '!all message accepted');
  await sleep(80);
  const farGot2 = (await post({ a: 'sync', id: F.id, key: F.key, s: [400, 0, 380, 0, 0, 0, 1], since: base })).json;
  const line = (farGot2.c || []).find((c) => c[1] === A.id && c[3] === 'mindenkinek szól');
  ok(line && line[5] === 1, '!all reaches the far player, prefix removed, marked as for everybody');
  await sleep(1300);
  const again = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: base, chat: '!ALL megint' })).json;
  ok(again && again.cd === 'allfast', '!all can only be sent every 8 seconds');
  const empty = (await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: base, chat: '!all   ' })).json;
  ok(empty && empty.cd === 'empty', 'an empty !all is refused');
  // (v9) plain text only: emoji and symbols are dropped, links are refused (however they are written)
  await sleep(1300);
  const emo = (await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: base, chat: 'szia 😀🎉 ✨ ©™ ½ <i>!' })).json;
  ok(emo && !emo.cd, 'a message with emoji is accepted (without them)');
  await sleep(80);
  const got = (await post({ a: 'sync', id: A.id, key: A.key, s: [0, 0, 0, 0, 0, 0, 1], since: base })).json;
  ok((got.c || []).some((c) => c[1] === N.id && c[3] === 'szia i!'), 'emoji, symbols and tags are removed on the server');
  for (const bad of ['nézd: https://example.com', 'www.valami.hu', 'gyere ide discord.gg/abc', 'írj: pista@gmail.com', 'pelda (dot) com', 'javascript:alert(1)']) {
    const r = (await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: base, chat: bad })).json;
    ok(r && r.cd === 'link', 'link refused: ' + bad);
  }
  const only = (await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: base, chat: '😀😀🎉' })).json;
  ok(only && only.cd === 'empty', 'a message of nothing but emoji is refused');
  await sleep(1300);
  const fine = (await post({ a: 'sync', id: N.id, key: N.key, s: [12, 0, 5, 0, 0, 0, 1], since: base, chat: 'Szia. Me too, kb. 3.14 méter!' })).json;
  ok(fine && !fine.cd, 'ordinary sentences with dots are not mistaken for links');
  // walking over to where it was said later (or asking for everything again) never brings it back
  await post({ a: 'sync', id: F.id, key: F.key, s: [3, 0, 2, 0, 0, 0, 1], since: base });
  await sleep(80);
  const late = (await post({ a: 'sync', id: F.id, key: F.key, s: [3, 0, 2, 0, 0, 0, 1], since: 0 })).json;
  ok(!hasMsg(late, 'csak a közelieknek'), 'an out-of-range line does not turn up later, and old lines cannot be re-read');
}

// the stored state cannot be read over the web
const st = await raw(null, { method: 'GET', path: base + 'mp-data/state.php' });
ok(!/"players":\s*[\[{]/.test(st.text), 'state file is not readable over HTTP');

// one address cannot fill the forest
let refused = false;
for (let i = 0; i < 14; i++) {
  const r = (await post({ a: 'join', name: 'Tömeg ' + i })).json;
  if (r && !r.ok && r.err === 'ip') { refused = true; break; }
  await sleep(30);
}
ok(refused, 'one IP address cannot take more than its share of places');

console.log(`${passes} passed, ${fails} failed`);
process.exit(fails ? 1 : 0);
