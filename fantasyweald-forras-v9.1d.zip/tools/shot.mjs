// Usage: node tools/shot.mjs <script.js|inline-json> [out-prefix] [w] [h]
// The script is evaluated in the page; it gets `game` and must return a list of {name, fn} steps
// or simply use the `views` JSON: [{name, eval:"..."}]
import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import { readFileSync } from 'node:fs';
const [,, viewsFile, outPrefix = '/tmp/claude-0/-home-claude/ad965a2b-d4cb-56ad-9cc8-c1e8ede59903/scratchpad/shot', W = '960', H = '540'] = process.argv;
const views = JSON.parse(readFileSync(viewsFile, 'utf8'));
const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const mobile = !!process.env.MOBILE;
const p = await b.newPage(mobile ? { viewport: { width: +W, height: +H }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 } : { viewport: { width: +W, height: +H } });
const logs = [];
p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning' || m.text().startsWith('[log]')) logs.push(m.type() + ': ' + m.text().slice(0, 2000)); else logs.push('log: ' + m.text().slice(0, 300)); });
p.on('pageerror', (e) => logs.push('pageerror: ' + e.message + '\n' + (e.stack || '').slice(0, 800)));
await p.addInitScript((fq) => { window.__manual = true; if (fq !== '') window.__forceQuality = Number(fq); }, process.env.FQ ?? (mobile ? '' : '2'));
// KEEPCPU=1: keep CPU copies of meshes (collision audit)
if (process.env.KEEPCPU) await p.addInitScript(() => { window.__keepCpu = true; });
// SEED=1: deterministic Math.random (for A/B image comparisons between builds)
if (process.env.SEED) await p.addInitScript(() => { let s = 1234567; Math.random = () => { s = (s * 1103515245 + 12345) >>> 0; return (s >>> 8) / 16777216; }; });
const t0 = Date.now();
await p.goto(process.env.PAGE || 'file:///home/claude/alomrengeteg/dist/local.html');
try { await p.waitForFunction(() => window.__ready === true, null, { timeout: 120000 }); } catch (e) { logs.push('TIMEOUT waiting ready'); }
logs.push('ready after ' + (Date.now() - t0) + 'ms');
for (const v of views) {
  try {
    const r = await p.evaluate(async (code) => { const game = window.__game; const res = await (new (Object.getPrototypeOf(async function(){}).constructor)("game", code))(game); await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))); return res; }, v.eval);
    if (r !== undefined) logs.push(v.name + ' -> ' + JSON.stringify(r));
    await p.screenshot({ path: `${outPrefix}_${v.name}.png`, timeout: 120000 });
  } catch (e) { logs.push('view ' + v.name + ' failed: ' + e.message.slice(0, 1500)); }
}
console.log(logs.join('\n'));
await b.close();
