<?php
// Álomrengeteg – többjátékos szerver (egyetlen PHP-fájl, adatbázis nélkül).
// Ugyanabban a mappában kell lennie, mint az index.html. Az adatokat az mp-data mappában tartja (ezt
// magától létrehozza, kívülről nem olvasható). Regisztráció nincs: belépéskor a játékos kap egy nyilvános
// azonosítót és egy titkos kulcsot; a saját alakját csak a kulcsával mozgathatja.
//
// Biztonság: a szerver semmit sem hisz el a böngészőnek. Egy játékos (akár F12-vel átírt kliensből) csak a
// SAJÁT alakjának helyzetét, a saját nevét és a saját üzeneteit küldheti, és mindent ellenőrzünk:
//   - típusok és hosszak (4 KB-nál nagyobb kérés nincs), a pozíció a világ határain belül, a jelzők ismertek;
//   - a név és az üzenet tisztítva: vezérlőkarakterek, láthatatlan és irányváltó karakterek, "zalgo" ki;
//   - a játékos kulcsa titkos (sosem küldjük ki másnak), a más játékosokat senki sem mozgathatja/léptetheti ki;
//   - korlátok: max. MAX_PLAYERS fő, egy IP-címről max. MAX_PER_IP fő, belépés és kérések IP-nként
//     ritkítva, csevegés: legalább 1,2 mp szünet, rövid időn belül legfeljebb néhány üzenet, ismétlés nincs;
//   - (v8) közelségi csevegés: egy üzenetet csak a küldőtől CHAT_NEAR méteren belül lévők kapják meg (ezt a
//     szerver szűri, a kliens nem is látja a távoli üzeneteket); "!all " előtaggal mindenki megkapja, de ilyet
//     csak ALL_GAP_MS-enként lehet küldeni. A küldő helyzetét a válasz nem tartalmazza.
//   - a hibaüzenetek nem jutnak ki (nincs elérési út a válaszban), a tárolt fájl PHP-ként sem olvasható.
// A szerver soha nem futtat semmit a kapott adatokból, és csak a saját mp-data mappájába ír.
//
// Protokoll (JSON POST; "a" a művelet):
//   hello                                   -> { ok, v, players, max }          (GET ?a=hello is jó)
//   join  { name, color }                   -> { ok, id, key, t, interval, since }
//   sync  { id, key, s, chat?, since, full? } -> { ok, t, p:[...], c:[...], n, cid, full, interval, cd? }
//         c: [cid, id, name, text, t, all]  (all = 1: mindenkinek szólt, vagy rendszerüzenet)
//   leave { id, key }                       -> { ok }

const MAX_PLAYERS = 80;        // ennyien lehetnek fent egyszerre
const REQ_WINDOW_MS = 2000;    // IP-nként legfeljebb REQ_MAX kérés REQ_WINDOW_MS alatt
// egy IP-címről legfeljebb ennyien (egy család, egy iskola, egy mobilhálózat közös címe mögött...)
define('MAX_PER_IP', getenv('MP_MAX_PER_IP') ? (int) getenv('MP_MAX_PER_IP') : 10);
define('JOIN_GAP_MS', getenv('MP_JOIN_GAP_MS') !== false && getenv('MP_JOIN_GAP_MS') !== '' ? (int) getenv('MP_JOIN_GAP_MS') : 1500);
define('REQ_MAX', getenv('MP_REQ_MAX') ? (int) getenv('MP_REQ_MAX') : 120);
// (a getenv-es értékek csak a helyi terheléses teszthez kellenek; a tárhelyen az alapértékek érvényesek)
const TIMEOUT_MS = 12000;      // ennyi csend után a játékos kiesik
const CHAT_KEEP = 40;          // ennyi üzenetet őriz meg
const CHAT_GAP_MS = 1200;      // egy játékos két üzenete között legalább ennyi idő
const CHAT_BURST = 6;          // ...és 20 másodperc alatt legfeljebb ennyi üzenet
const CHAT_MAX = 160;          // karakter
const CHAT_NEAR = 30;          // (v8) ennyi méterre hallatszik egy sima üzenet
const ALL_GAP_MS = 8000;       // (v8) "!all" üzenet (mindenkinek) legfeljebb ennyi időnként
const NAME_MAX = 16;
const WORLD_R = 760;           // a világ szélén túl nincs mit keresni (a játékban 680 m-nél fal van)
const NEAR_R = 220;            // egy sima sync csak a közelieket hozza, a "full" mindenkit
const VERSION = 3;

error_reporting(0);
@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Cross-Origin-Resource-Policy: same-origin');

function now_ms() { return (int) round(microtime(true) * 1000); }
function out($a, $code = 200) {
  if ($code !== 200) http_response_code($code);
  echo json_encode($a, JSON_UNESCAPED_UNICODE);
  exit;
}
// names and chat: printable text only (no control, invisible or direction-flipping characters, no piles of
// combining marks), single spaces, limited length (counted in characters, not bytes)
function clean_text($s, $max) {
  if (!is_string($s) || $s === '' || strlen($s) > 1024) return '';
  if (!preg_match('//u', $s)) return ''; // not valid UTF-8
  if (class_exists('Normalizer')) { $n = Normalizer::normalize($s, Normalizer::FORM_C); if (is_string($n)) $s = $n; }
  $s = preg_replace('/[\x{0000}-\x{001F}\x{007F}-\x{009F}\x{00AD}\x{061C}\x{180E}\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}\x{FFF9}-\x{FFFB}]/u', '', $s);
  if (!is_string($s)) return '';
  $s = preg_replace('/(\p{M})\p{M}+/u', '$1', $s);
  $s = preg_replace('/\s+/u', ' ', $s);
  if (!is_string($s)) return '';
  // (v9) plain words only: letters, digits, spaces, everyday punctuation (no emoji, symbols or pictures)
  $s = preg_replace('/[\x{FE00}-\x{FE0F}\x{20E3}]|[^\p{L}\p{Mn}\p{Mc}\p{Nd} .,!?:;\'\"()\-–—…%+=\/&@#*_„”“‘’«»]/u', '', $s);
  if (!is_string($s)) return '';
  $s = trim(preg_replace('/ {2,}/', ' ', $s));
  if (function_exists('mb_substr')) return trim(mb_substr($s, 0, $max, 'UTF-8'));
  return trim(substr($s, 0, $max));
}
// (v9) no links in names or chat: web addresses, e-mail links, "example dot com"...
function has_link($s) {
  return is_string($s) && preg_match('/[a-z][a-z0-9+.\-]*:\/\/|(?<![\p{L}\p{N}])(?:www\s?\.|(?:https?|ftp|javascript|mailto|blob)\s?:|data\s?:\s?[a-z]+\/)|[\p{L}\p{N}\-]+(?:\.|\s?(?:\(dot\)|\[dot\]|\[\.\]|\(\.\))\s?|\s+(?:dot|pont)\s+)(?:com|net|org|hu|io|gg|ly|me|co|info|xyz|ru|de|uk|tv|app|dev|link|site|online|biz|us|eu|to|cc|tk|ml|ga|cf|gq|top|shop|store|live|stream|click|fun|pro|club|page|chat|social|tech|ai|gov|edu|fr|it|es|pl|ro|sk|at|ch|nl|be|cz|se|no|dk|fi|jp|cn|in|br|ca|au|nz|ws|pw|sh|gl|gd|vc|so|im|fm|am|bz|xxx|onion)(?![\p{L}\p{N}])/iu', $s) === 1;
}
function num($v, $lo, $hi) {
  $v = (is_int($v) || is_float($v)) ? (float) $v : 0.0;
  if (!is_finite($v)) $v = 0.0;
  return max($lo, min($hi, $v));
}
function rand_hex($n) {
  if (function_exists('random_bytes')) return bin2hex(random_bytes($n));
  if (function_exists('openssl_random_pseudo_bytes')) return bin2hex(openssl_random_pseudo_bytes($n));
  $s = '';
  for ($i = 0; $i < $n; $i++) $s .= sprintf('%02x', mt_rand(0, 255));
  return $s;
}
function field($req, $k) { return isset($req[$k]) ? $req[$k] : null; }

// ------------------------------------------------------------------ the request
$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
if ($method === 'OPTIONS') out(array('ok' => true));
if ($method === 'POST') {
  $raw = file_get_contents('php://input', false, null, 0, 4097);
  if (!is_string($raw) || strlen($raw) > 4096) out(array('ok' => false, 'err' => 'big'), 413);
  $req = json_decode($raw, true, 8);
  if (!is_array($req)) out(array('ok' => false, 'err' => 'bad'), 400);
} else {
  $req = array('a' => 'hello'); // GET can only ask how many are in the forest
}
$action = field($req, 'a');
if (!is_string($action) || !in_array($action, array('hello', 'join', 'sync', 'leave'), true)) out(array('ok' => false, 'err' => 'action'), 400);

// ------------------------------------------------------------------ storage (a lock file + one state file)
$dir = __DIR__ . '/mp-data';
if (!is_dir($dir)) {
  @mkdir($dir, 0755, true);
  @file_put_contents($dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n");
  @file_put_contents($dir . '/index.html', '');
}
$lock = @fopen($dir . '/lock', 'c');
if (!$lock) out(array('ok' => false, 'err' => 'storage'), 500);
flock($lock, LOCK_EX);
// the state is kept in a .php file that exits at once if anybody ever manages to request it
$file = $dir . '/state.php';
$PREFIX = "<?php exit; ?>\n";
$data = @file_get_contents($file);
$S = null;
if (is_string($data) && strncmp($data, $PREFIX, strlen($PREFIX)) === 0) $S = json_decode(substr($data, strlen($PREFIX)), true);
if (!is_array($S)) $S = array();
foreach (array('players', 'chat', 'ips') as $k) if (!isset($S[$k]) || !is_array($S[$k])) $S[$k] = array();
if (!isset($S['cid']) || !is_int($S['cid'])) $S['cid'] = 0;
if (!isset($S['salt']) || !is_string($S['salt'])) $S['salt'] = rand_hex(16);
$t = now_ms();

function finish($S, $dirty) {
  global $lock, $file, $PREFIX;
  if ($dirty) {
    $tmp = $file . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, $PREFIX . json_encode($S, JSON_UNESCAPED_UNICODE)) !== false) @rename($tmp, $file);
    else @unlink($tmp);
  }
  flock($lock, LOCK_UN);
  fclose($lock);
}
function reply($S, $dirty, $a, $code = 200) { finish($S, $dirty); out($a, $code); }
function say(&$S, $text, $t, $pid = '', $name = '', $all = 1, $x = 0, $y = 0, $z = 0) {
  $S['cid']++;
  $S['chat'][] = array($S['cid'], $pid, $name, $text, $t, $all ? 1 : 0, $x, $y, $z);
  if (count($S['chat']) > CHAT_KEEP) $S['chat'] = array_slice($S['chat'], -CHAT_KEEP);
}

// drop the ones who went quiet, and forget old IP records
foreach ($S['players'] as $pid => $p) {
  if (!is_array($p) || !isset($p['t']) || $t - $p['t'] > TIMEOUT_MS) unset($S['players'][$pid]);
}
foreach ($S['ips'] as $h => $r) {
  if (!is_array($r) || $t - max($r[0], $r[2], $r[3]) > 60000) unset($S['ips'][$h]);
}

// per-IP request budget (the address is only kept as a salted hash)
$ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '?';
$iph = substr(hash('sha256', $S['salt'] . '|' . $ip), 0, 16);
if (!isset($S['ips'][$iph])) $S['ips'][$iph] = array($t, 0, 0, 0); // window start, requests, last join, last chat
$R = &$S['ips'][$iph];
if ($t - $R[0] > REQ_WINDOW_MS) { $R[0] = $t; $R[1] = 0; }
$R[1]++;
if ($R[1] > REQ_MAX) { unset($R); reply($S, true, array('ok' => false, 'err' => 'slow'), 429); }

function interval_for($n) {
  // fewer requests when the forest is crowded (keeps a shared host happy)
  if ($n <= 10) return 220;
  if ($n <= 25) return 320;
  if ($n <= 50) return 450;
  return 600;
}

if ($action === 'hello') {
  unset($R);
  reply($S, true, array('ok' => true, 'v' => VERSION, 'players' => count($S['players']), 'max' => MAX_PLAYERS));
}

if ($method !== 'POST') { unset($R); reply($S, true, array('ok' => false, 'err' => 'method'), 405); }

if ($action === 'join') {
  if (count($S['players']) >= MAX_PLAYERS) { unset($R); reply($S, true, array('ok' => false, 'err' => 'full')); }
  $mine = 0;
  foreach ($S['players'] as $p) if ($p['ip'] === $iph) $mine++;
  if ($mine >= MAX_PER_IP) { unset($R); reply($S, true, array('ok' => false, 'err' => 'ip')); }
  if ($t - $R[2] < JOIN_GAP_MS) { unset($R); reply($S, true, array('ok' => false, 'err' => 'slow')); }
  $R[2] = $t;
  unset($R);
  $name = clean_text(field($req, 'name'), NAME_MAX);
  if ($name === '' || has_link($name) || !preg_match('/[\p{L}\p{N}]/u', $name)) $name = 'Vándor';
  $color = field($req, 'color');
  $color = is_int($color) ? max(0, min(7, $color)) : 0;
  // ids always start with a letter: PHP turns purely numeric array keys into integers
  do { $id = 'p' . rand_hex(4); } while (isset($S['players'][$id]));
  $key = rand_hex(12);
  $S['players'][$id] = array('n' => $name, 'c' => $color, 'k' => $key, 'ip' => $iph, 's' => array(0, 0, 0, 0, 0, 0, 0), 't' => $t, 'st' => 0, 'lc' => 0, 'cb' => array(), 'lm' => '', 'la' => 0, 'cc' => max(0, $S['cid'] - 12));
  say($S, $name . ' megérkezett az erdőbe.', $t);
  reply($S, true, array('ok' => true, 'id' => $id, 'key' => $key, 't' => $t, 'interval' => interval_for(count($S['players'])), 'since' => max(0, $S['cid'] - 12)));
}

// everything else needs your own id and secret key
$id = field($req, 'id');
$key = field($req, 'key');
if (!is_string($id) || !preg_match('/^p[0-9a-f]{8}$/', $id) || !is_string($key) || !preg_match('/^[0-9a-f]{24}$/', $key)
  || !isset($S['players'][$id]) || !hash_equals((string) $S['players'][$id]['k'], $key)) {
  unset($R);
  reply($S, true, array('ok' => false, 'err' => 'unknown'));
}

if ($action === 'leave') {
  unset($R);
  $name = $S['players'][$id]['n'];
  unset($S['players'][$id]);
  say($S, $name . ' felébredt, és hazament.', $t);
  reply($S, true, array('ok' => true));
}

// ------------------------------------------------------------------ sync: my state in, everybody else's out
$me = &$S['players'][$id];
$s = field($req, 's');
if (is_array($s) && count($s) === 7 && $t - $me['st'] >= 60) {
  $yaw = num($s[3], -1e4, 1e4);
  $yaw = fmod($yaw + M_PI * 101, 2 * M_PI) - M_PI;
  $me['s'] = array(
    round(num($s[0], -WORLD_R, WORLD_R), 2), round(num($s[1], -40, 400), 2), round(num($s[2], -WORLD_R, WORLD_R), 2),
    round($yaw, 3), round(num($s[4], -30, 30), 2), round(num($s[5], -30, 30), 2),
    ((int) num($s[6], 0, 1023)) & 31,
  );
  $me['st'] = $t;
}
$me['t'] = $t;
$cd = null;
$chat = field($req, 'chat');
if ($chat !== null) {
  $msg = clean_text($chat, CHAT_MAX);
  $recent = array();
  foreach ($me['cb'] as $ct) if (is_int($ct) && $t - $ct < 20000) $recent[] = $ct;
  // "!all ..." (or "!ALL ...") goes to everybody; anything else only to the ones nearby
  $all = 0;
  if (preg_match('/^!all(\s+|$)/i', $msg, $mm)) { $all = 1; $msg = trim(substr($msg, strlen($mm[0]))); }
  $lastAll = isset($me['la']) && is_int($me['la']) ? $me['la'] : 0;
  if ($msg === '') $cd = 'empty';
  else if (has_link($msg)) $cd = 'link';
  else if ($t - $me['lc'] < CHAT_GAP_MS || $t - $R[3] < 500) $cd = 'fast';
  else if (count($recent) >= CHAT_BURST) $cd = 'burst';
  else if ($msg === $me['lm'] && $t - $me['lc'] < 20000) $cd = 'repeat';
  else if ($all && $t - $lastAll < ALL_GAP_MS) $cd = 'allfast';
  else {
    say($S, $msg, $t, $id, $me['n'], $all, $me['s'][0], $me['s'][1], $me['s'][2]);
    if ($all) $me['la'] = $t;
    $me['lc'] = $t;
    $me['lm'] = $msg;
    $recent[] = $t;
    $R[3] = $t;
  }
  $me['cb'] = $recent;
}
unset($R);
$mx = $me['s'][0];
$my = $me['s'][1];
$mz = $me['s'][2];
unset($me);
$since = field($req, 'since');
$since = is_int($since) ? $since : 0;
$full = field($req, 'full') ? true : false;
$players = array();
foreach ($S['players'] as $pid => $p) {
  $pid = (string) $pid;
  if ($pid === $id || empty($p['st'])) continue; // (just joined, no position yet)
  $ps = $p['s'];
  if (!$full && ($ps[0] - $mx) * ($ps[0] - $mx) + ($ps[2] - $mz) * ($ps[2] - $mz) > NEAR_R * NEAR_R) continue;
  $players[] = array($pid, $p['n'], $p['c'], $ps[0], $ps[1], $ps[2], $ps[3], $ps[4], $ps[5], $ps[6], $t - $p['st']);
}
$lines = array();
// (v8) each player has a chat cursor on the server too: a line that was out of range when it was said is
// used up anyway (it never turns up later when you walk over there), and nobody can rewind to old lines
$from = max($since, isset($S['players'][$id]['cc']) && is_int($S['players'][$id]['cc']) ? $S['players'][$id]['cc'] : 0);
foreach ($S['chat'] as $c) {
  if (!is_array($c) || $c[0] <= $from) continue;
  // (v8) nearby only, unless it was for everybody (system lines are); the sender's position stays here
  $all = !isset($c[5]) || $c[5];
  if (!$all && $c[1] !== $id) {
    $dx = $c[6] - $mx; $dy = $c[7] - $my; $dz = $c[8] - $mz;
    if ($dx * $dx + $dy * $dy + $dz * $dz > CHAT_NEAR * CHAT_NEAR) continue;
  }
  $lines[] = array($c[0], $c[1], $c[2], $c[3], $c[4], $all ? 1 : 0);
}
$S['players'][$id]['cc'] = $S['cid'];
$n = count($S['players']);
$res = array('ok' => true, 't' => $t, 'p' => $players, 'c' => $lines, 'n' => $n, 'cid' => $S['cid'], 'full' => $full, 'interval' => interval_for($n));
if ($cd) $res['cd'] = $cd;
reply($S, true, $res);
